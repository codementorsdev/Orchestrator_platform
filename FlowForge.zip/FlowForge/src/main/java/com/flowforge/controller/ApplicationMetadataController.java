package com.flowforge.controller;

import com.flowforge.dto.ApplicationMetadataPayloadDTO;
import com.flowforge.entity.ApplicationMetadata;
import com.flowforge.service.ApplicationMetadataService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/applications")
public class ApplicationMetadataController {
    private final ApplicationMetadataService applicationMetadataService;

    public ApplicationMetadataController(ApplicationMetadataService applicationMetadataService) {
        this.applicationMetadataService = applicationMetadataService;
    }

    @PostMapping
    public ApplicationMetadata createApplication(
            @RequestBody ApplicationMetadataPayloadDTO applicationMetadataPayloadDTO,
            @RequestHeader("X-Execution-UUID") UUID executionUuid) {
        return applicationMetadataService.saveFullPayload(applicationMetadataPayloadDTO, executionUuid);
    }

    @GetMapping("/{id}")
    public ApplicationMetadata getApplicationById(@PathVariable Long id) {
        return applicationMetadataService.getApplicationById(id);
    }

    @GetMapping
    public List<ApplicationMetadata> getAllApplications() {
        return applicationMetadataService.getAllApplications();
    }
}
