package com.flowforge.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowforge.dto.FlowDTO;
import com.flowforge.entity.*;
import com.flowforge.service.FlowExecutionService;
import com.flowforge.service.FlowService;
import com.flowforge.service.PipelineExecutionService;
import org.gitlab4j.api.GitLabApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/flows")
public class CallbackController {

    private final PipelineExecutionService pipelineExecutionService;
    private final FlowService flowService;
    private final FlowExecutionService flowExecutionService;
    private final FlowExecutionController flowExecutionController;
    private final ApplicationEventPublisher eventPublisher;

    @Autowired
    public CallbackController(PipelineExecutionService pipelineExecutionService, FlowService flowService, FlowExecutionService flowExecutionService, FlowExecutionController flowExecutionController, ApplicationEventPublisher eventPublisher) {
        this.pipelineExecutionService = pipelineExecutionService;
        this.flowService = flowService;
        this.flowExecutionService = flowExecutionService;
        this.flowExecutionController = flowExecutionController;
        this.eventPublisher = eventPublisher;
    }

    @PostMapping("/callback")
    public ResponseEntity<String> callback(@RequestBody String payload) {
        try {
            // 1. Parse the payload to extract the necessary information
            ObjectMapper mapper = new ObjectMapper();
            JsonNode payloadJson = mapper.readTree(payload);
            Long pipelineExecutionId = Long.parseLong(payloadJson.get("pipelineExecutionId").asText());
            String status = payloadJson.get("status").asText();
            String logs = payloadJson.get("logs").asText();
            String executionPayload = payloadJson.get("executionPayload").toString();

            // 2. Update the corresponding PipelineExecution record with the received information
            Optional<PipelineExecution> pipelineExecutionOptional = Optional.ofNullable(pipelineExecutionService.getPipelineExecutionById(pipelineExecutionId));

            if (pipelineExecutionOptional.isPresent()) {
                PipelineExecution pipelineExecution = pipelineExecutionOptional.get();
                pipelineExecution.setStatus(status);
                pipelineExecution.setEndTime(LocalDateTime.now());
                pipelineExecution.setLogs(logs);
                pipelineExecution.setExecutionPayload(executionPayload);
                pipelineExecutionService.updatePipelineExecution(pipelineExecutionId, pipelineExecution);

                // Publish a PipelineExecutionEvent
                eventPublisher.publishEvent(new PipelineExecutionEvent(this, pipelineExecutionId));

                // 3. Identify the next pipeline in the flow sequence (if any)
            Optional<FlowDTO> flowOptional = Optional.ofNullable(flowService.getFlowById(pipelineExecution.getFlowExecutionId()));
                if (flowOptional.isPresent()) {
                    Flow flow = flowService.convertToEntity(flowOptional.get());
                    List<Pipeline> pipelines = flow.getPipelines();
                    int currentPipelineIndex = -1;
                    for (int i = 0; i < pipelines.size(); i++) {
                        if (pipelines.get(i).getId().equals(pipelineExecution.getPipelineId())) {
                            currentPipelineIndex = i;
                            break;
                        }
                    }

                    // 4. Pass the execution payload to the next pipeline as input parameters
                    if (currentPipelineIndex != -1 && currentPipelineIndex < pipelines.size() - 1) {
                        Pipeline nextPipeline = pipelines.get(currentPipelineIndex + 1);
                        triggerNextPipelineAsync(nextPipeline, pipelineExecution.getExecutionPayload());
                        System.out.println("Triggering next pipeline: " + nextPipeline.getName());
                    } else {
                        // Handle the case where there are no more pipelines in the flow
                        System.out.println("No more pipelines in the flow");
                        // Update FlowExecution status based on all PipelineExecutions
                        List<PipelineExecution> pipelineExecutions = pipelineExecutionService.getAllPipelineExecutionsByFlowExecutionId(pipelineExecution.getFlowExecutionId());
                        boolean allSuccess = pipelineExecutions.stream().allMatch(pe -> Status.COMPLETED.toString().equals(pe.getStatus()));
                        boolean anyFailed = pipelineExecutions.stream().anyMatch(pe -> Status.FAILED.toString().equals(pe.getStatus()));
                        
                        FlowExecution flowExecution = flowExecutionService.getFlowExecutionById(pipelineExecution.getFlowExecutionId());
                        if (flowExecution != null) {
                            flowExecution.setEndTime(LocalDateTime.now());
                            flowExecution.setStatus(anyFailed ? Status.FAILED.toString() : 
                                              allSuccess ? Status.COMPLETED.toString() : Status.IN_PROGRESS.toString());
                            flowExecutionService.updateFlowExecution(flowExecution.getId(), flowExecution);
                        }
                    }
                }

                System.out.println("Received callback payload: " + payload);
                return new ResponseEntity<>("Callback received", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("PipelineExecution not found", HttpStatus.NOT_FOUND);
            }


        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("Failed to process callback: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Async
    public void triggerNextPipelineAsync(Pipeline nextPipeline, String executionPayload) throws GitLabApiException {
        UUID executionUuid = UUID.fromString(executionPayload);
        pipelineExecutionService.triggerPipeline(nextPipeline, executionUuid);
    }
}
