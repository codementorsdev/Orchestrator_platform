package com.flowforge.controller;

import com.flowforge.dto.FlowExecutionDTO;
import com.flowforge.entity.Flow;
import com.flowforge.entity.FlowExecution;
import com.flowforge.entity.Status;
import com.flowforge.service.FlowExecutionService;
import com.flowforge.service.FlowService;
import com.flowforge.service.PipelineExecutionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/flows/{flowId}/executions")
public class FlowExecutionController {

    private static final Logger logger = LoggerFactory.getLogger(FlowExecutionController.class);

    @Autowired
    private FlowExecutionService flowExecutionService;

    @Autowired
    private FlowService flowService;

    @Autowired
    private PipelineExecutionService pipelineExecutionService;

    @PostMapping
    public ResponseEntity<FlowExecution> createFlowExecution(@RequestBody FlowExecution flowExecution) {
        FlowExecution createdFlowExecution = flowExecutionService.createFlowExecution(flowExecution);
        return new ResponseEntity<>(createdFlowExecution, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<FlowExecution>> getAllFlowExecutions() {
        List<FlowExecution> flowExecutions = flowExecutionService.getAllFlowExecutions();
        return new ResponseEntity<>(flowExecutions, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FlowExecutionDTO> getFlowExecutionById(@PathVariable Long id) {
        FlowExecution flowExecution = flowExecutionService.getFlowExecutionById(id);
        if (flowExecution != null) {
            return new ResponseEntity<>(flowExecutionService.convertToDTO(flowExecution), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<FlowExecutionDTO> updateFlowExecution(@PathVariable Long id, @RequestBody FlowExecutionDTO flowExecutionDTO) {
        FlowExecution updatedFlowExecution = flowExecutionService.updateFlowExecution(
            id, flowExecutionService.convertToEntity(flowExecutionDTO));
        if (updatedFlowExecution != null) {
            return new ResponseEntity<>(flowExecutionService.convertToDTO(updatedFlowExecution), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFlowExecution(@PathVariable Long id) {
        flowExecutionService.deleteFlowExecution(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/{flowId2}/executions")
    public ResponseEntity<List<FlowExecutionDTO>> getAllFlowExecutionsByFlowId(@PathVariable Long flowId2) {
        List<FlowExecution> flowExecutions = flowExecutionService.getAllFlowExecutionsByFlowId(flowId2);
        if (flowExecutions != null) {
            List<FlowExecutionDTO> dtos = flowExecutions.stream()
                .map(flowExecutionService::convertToDTO)
                .toList();
            return new ResponseEntity<>(dtos, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/execute")
    public ResponseEntity<String> executeFlow(@PathVariable Long flowId) {
        Flow flow = flowService.getFlowWithPipelines(flowId);

        if (flow != null) {
            // Create and save the flow execution first
            FlowExecution flowExecution = new FlowExecution();
            flowExecution.setFlowId(flowId);
            flowExecution.setStatus(Status.PENDING.toString());
            flowExecution.setStartTime(LocalDateTime.now());
            flowExecution.setExecutionUuid(UUID.randomUUID());
            flowExecution = flowExecutionService.createFlowExecution(flowExecution);

            // Start async processing
            flowExecutionService.processFlowExecutionAsync(flow, flowExecution.getId());

            return ResponseEntity.accepted()
                .body("Flow execution started for flow ID: " + flowId + ". Execution ID: " + flowExecution.getId());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{executionId}/status")
    public ResponseEntity<String> getFlowExecutionStatus(@PathVariable Long flowId2, @PathVariable Long executionId) {
        FlowExecution flowExecution = flowExecutionService.getFlowExecutionById(executionId);
        if (flowExecution != null && flowExecution.getFlowId().equals(flowId2)) {
            return new ResponseEntity<>(flowExecution.getStatus(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
