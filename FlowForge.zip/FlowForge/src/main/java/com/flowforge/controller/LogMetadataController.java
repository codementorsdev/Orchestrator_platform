package com.flowforge.controller;

import com.flowforge.entity.LogMetadata;
import com.flowforge.service.LogMetadataService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/logs")
public class LogMetadataController {
    private final LogMetadataService logMetadataService;

    public LogMetadataController(LogMetadataService logMetadataService) {
        this.logMetadataService = logMetadataService;
    }

    @PostMapping
    public LogMetadata createLog(@RequestBody LogMetadata logMetadata) {
        return logMetadataService.saveLog(logMetadata);
    }

    @GetMapping("/test/{testId}")
    public List<LogMetadata> getLogsByTestId(@PathVariable Long testId) {
        return logMetadataService.getLogsByTestId(testId);
    }
}
