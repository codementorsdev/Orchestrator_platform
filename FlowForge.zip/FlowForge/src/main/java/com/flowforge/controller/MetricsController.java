package com.flowforge.controller;

import com.flowforge.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/metrics")
public class MetricsController {

    private final ApplicationService applicationService;
    private final FlowService flowService;
    private final PipelineService pipelineService;
    private final FlowExecutionService flowExecutionService;
    private final PipelineExecutionService pipelineExecutionService;

    @Autowired
    public MetricsController(ApplicationService applicationService, FlowService flowService, PipelineService pipelineService, FlowExecutionService flowExecutionService, PipelineExecutionService pipelineExecutionService) {
        this.applicationService = applicationService;
        this.flowService = flowService;
        this.pipelineService = pipelineService;
        this.flowExecutionService = flowExecutionService;
        this.pipelineExecutionService = pipelineExecutionService;
    }

    @GetMapping("/summary")
    public ResponseEntity<String> getSummaryMetrics() {
        long totalApplications = applicationService.getAllApplications().size();
        long totalFlows = flowService.getAllFlows().size();
        long totalPipelines = pipelineService.getAllPipelines().size();

        String summary = String.format("Total Applications: %d, Total Flows: %d, Total Pipelines: %d", totalApplications, totalFlows, totalPipelines);
        return new ResponseEntity<>(summary, HttpStatus.OK);
    }

    @GetMapping("/flows")
    public ResponseEntity<String> getFlowExecutionStatistics() {
        long totalFlowExecutions = flowExecutionService.getAllFlowExecutions().size();
        String statistics = String.format("Total Flow Executions: %d", totalFlowExecutions);
        return new ResponseEntity<>(statistics, HttpStatus.OK);
    }

    @GetMapping("/pipelines")
    public ResponseEntity<String> getPipelineExecutionStatistics() {
        long totalPipelineExecutions = pipelineExecutionService.getAllPipelineExecutions().size();
        String statistics = String.format("Total Pipeline Executions: %d", totalPipelineExecutions);
        return new ResponseEntity<>(statistics, HttpStatus.OK);
    }
}
