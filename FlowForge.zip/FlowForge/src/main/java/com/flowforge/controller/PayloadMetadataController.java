package com.flowforge.controller;

import com.flowforge.dto.ApplicationMetadataPayloadDTO;
import com.flowforge.service.ApplicationMetadataService;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/payloads")
@Tag(name = "Payload API", description = "Operations with complete test metadata payloads")
public class PayloadMetadataController {
    private final ApplicationMetadataService applicationMetadataService;

    public PayloadMetadataController(ApplicationMetadataService applicationMetadataService) {
        this.applicationMetadataService = applicationMetadataService;
    }

    @Operation(summary = "Save complete test metadata payload", 
               description = "Persists a complete test metadata hierarchy including application, suites, tests and logs")
    @ApiResponse(responseCode = "200", description = "Successfully saved payload",
            content = @Content(schema = @Schema(implementation = ApplicationMetadataPayloadDTO.class)))
    @PostMapping
    public ApplicationMetadataPayloadDTO savePayload(
            @RequestBody @Schema(description = "Complete test metadata payload to save")
            ApplicationMetadataPayloadDTO payloadDTO,
            @RequestHeader("X-Execution-UUID") UUID executionUuid) {
        return applicationMetadataService.getFullPayloadById(
            applicationMetadataService.saveFullPayload(payloadDTO, executionUuid).getId()
        );
    }

    @Operation(summary = "Get payload by ID", 
               description = "Retrieves a complete test metadata payload by its ID")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved payload",
            content = @Content(schema = @Schema(implementation = ApplicationMetadataPayloadDTO.class)))
    @GetMapping("/{id}")
    public ApplicationMetadataPayloadDTO getPayloadById(
            @Parameter(description = "ID of the payload to retrieve", required = true)
            @PathVariable Long id) {
        return applicationMetadataService.getFullPayloadById(id);
    }
}
