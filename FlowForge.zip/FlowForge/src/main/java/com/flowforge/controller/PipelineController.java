package com.flowforge.controller;

import com.flowforge.dto.PipelineDTO;
import com.flowforge.service.PipelineService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pipelines")
public class PipelineController {

    @Autowired
    private PipelineService pipelineService;

    @PostMapping
    public ResponseEntity<PipelineDTO> createPipeline(@Valid @RequestBody PipelineDTO pipelineDTO) {
        PipelineDTO createdPipeline = pipelineService.createPipeline(pipelineDTO);
        return new ResponseEntity<>(createdPipeline, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<PipelineDTO>> getAllPipelines() {
        List<PipelineDTO> pipelines = pipelineService.getAllPipelines();
        return new ResponseEntity<>(pipelines, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PipelineDTO> getPipelineById(@PathVariable Long id) {
        PipelineDTO pipeline = pipelineService.getPipelineById(id);
        if (pipeline != null) {
            return new ResponseEntity<>(pipeline, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<PipelineDTO> updatePipeline(@PathVariable Long id, @Valid @RequestBody PipelineDTO pipelineDTO) {
        PipelineDTO updatedPipeline = pipelineService.updatePipeline(id, pipelineDTO);
        if (updatedPipeline != null) {
            return new ResponseEntity<>(updatedPipeline, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePipeline(@PathVariable Long id) {
        pipelineService.deletePipeline(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
