package com.flowforge.controller;

import com.flowforge.entity.SuiteMetadata;
import com.flowforge.service.SuiteMetadataService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/suites")
public class SuiteMetadataController {
    private final SuiteMetadataService suiteMetadataService;

    public SuiteMetadataController(SuiteMetadataService suiteMetadataService) {
        this.suiteMetadataService = suiteMetadataService;
    }

    @PostMapping
    public SuiteMetadata createSuite(@RequestBody SuiteMetadata suiteMetadata) {
        return suiteMetadataService.saveSuite(suiteMetadata);
    }

    @GetMapping("/application/{applicationId}")
    public List<SuiteMetadata> getSuitesByApplicationId(@PathVariable Long applicationId) {
        return suiteMetadataService.getSuitesByApplicationId(applicationId);
    }
}
