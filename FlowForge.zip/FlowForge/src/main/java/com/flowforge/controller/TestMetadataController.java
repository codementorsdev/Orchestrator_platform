package com.flowforge.controller;

import com.flowforge.entity.TestMetadata;
import com.flowforge.service.TestMetadataService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/tests")
public class TestMetadataController {
    private final TestMetadataService testMetadataService;

    public TestMetadataController(TestMetadataService testMetadataService) {
        this.testMetadataService = testMetadataService;
    }

    @PostMapping
    public TestMetadata createTest(@RequestBody TestMetadata testMetadata) {
        return testMetadataService.saveTest(testMetadata);
    }

    @GetMapping("/suite/{suiteId}")
    public List<TestMetadata> getTestsBySuiteId(@PathVariable Long suiteId) {
        return testMetadataService.getTestsBySuiteId(suiteId);
    }
}
