package com.flowforge.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ApplicationDTO {
    @NotBlank(message = "Name is required")
    @Size(max = 100, message = "Name must be less than 100 characters")
    private String name;

    @Size(max = 500, message = "Description must be less than 500 characters")
    private String description;

    @NotBlank(message = "Project ID is required")
    private String projectId;

    @NotBlank(message = "Access token is required")
    private String accessToken;

    @NotBlank(message = "GitLab instance URL is required")
    private String gitlabInstanceUrl;

    @Schema(accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getGitlabInstanceUrl() {
        return gitlabInstanceUrl;
    }

    public void setGitlabInstanceUrl(String gitlabInstanceUrl) {
        this.gitlabInstanceUrl = gitlabInstanceUrl;
    }
}
