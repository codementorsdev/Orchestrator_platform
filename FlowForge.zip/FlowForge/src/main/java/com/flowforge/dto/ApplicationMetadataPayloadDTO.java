package com.flowforge.dto;

import com.flowforge.entity.CustomDataMetadata;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class ApplicationMetadataPayloadDTO {
    private String appId;
    private String appName;
    private String appDescription;
    private Object customData;
    private List<SuiteDTO> suites;

    @Data
    public static class SuiteDTO {
        private String name;
        private String description;
        private List<String> tags;
        private Long startTime;
        private Long endTime;
        private Map<String, TestDTO> tests;
    }

    @Data
    public static class TestDTO {
        private String name;
        private String description;
        private List<String> tags;
        private Long startTime;
        private Long endTime;
        private List<LogDTO> logs;
    }

    @Data
    public static class LogDTO {
        private String message;
        private String status;
    }
}
