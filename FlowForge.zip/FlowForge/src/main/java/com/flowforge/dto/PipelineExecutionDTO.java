package com.flowforge.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public class PipelineExecutionDTO {
    @Schema(accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;
    @NotNull(message = "Flow execution ID is required")
    private Long flowExecutionId;

    @NotNull(message = "Pipeline ID is required")
    private Long pipelineId;

    @NotBlank(message = "Status is required")
    private String status;

    @NotNull(message = "Start time is required")
    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private String executionPayload;

    private String logs;

    public Long getFlowExecutionId() {
        return flowExecutionId;
    }

    public void setFlowExecutionId(Long flowExecutionId) {
        this.flowExecutionId = flowExecutionId;
    }

    public Long getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(Long pipelineId) {
        this.pipelineId = pipelineId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getExecutionPayload() {
        return executionPayload;
    }

    public void setExecutionPayload(String executionPayload) {
        this.executionPayload = executionPayload;
    }

    public String getLogs() {
        return logs;
    }

    public void setLogs(String logs) {
        this.logs = logs;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
