package com.flowforge.dto;

import jakarta.validation.constraints.NotNull;

public class PipelineExecutionEventDTO {
    @NotNull(message = "Pipeline execution ID is required")
    private Long pipelineExecutionId;

    public PipelineExecutionEventDTO() {
    }

    public PipelineExecutionEventDTO(Long pipelineExecutionId) {
        this.pipelineExecutionId = pipelineExecutionId;
    }

    public Long getPipelineExecutionId() {
        return pipelineExecutionId;
    }

    public void setPipelineExecutionId(Long pipelineExecutionId) {
        this.pipelineExecutionId = pipelineExecutionId;
    }
}
