package com.flowforge.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Application {

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    private String description;

    private String projectId;

    private String accessToken;
    private String gitlabInstanceUrl;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getGitlabInstanceUrl() {
        return gitlabInstanceUrl;
    }

    public void setGitlabInstanceUrl(String gitlabInstanceUrl) {
        this.gitlabInstanceUrl = gitlabInstanceUrl;
    }
}
