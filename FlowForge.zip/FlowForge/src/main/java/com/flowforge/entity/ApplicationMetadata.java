package com.flowforge.entity;

import jakarta.persistence.*;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.List;
import java.util.UUID;

@Data
@Entity
@Table(name = "applications")
public class ApplicationMetadata {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String appId;

    @Column(nullable = false)
    private String appName;

    private String appDescription;

    @Column(nullable = false)
    private UUID executionUuid;

    @JsonManagedReference
    @OneToMany(mappedBy = "applicationMetadata", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SuiteMetadata> suiteMetadata;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "custom_data_id")
    private CustomDataMetadata customData;
}
