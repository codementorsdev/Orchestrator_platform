package com.flowforge.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.util.UUID;

@Data
@Entity
@Table(name = "custom_data")
public class CustomDataMetadata {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private UUID executionUuid;

    @Column(columnDefinition = "TEXT")
    private String data;
}
