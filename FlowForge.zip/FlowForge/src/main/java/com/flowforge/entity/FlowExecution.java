package com.flowforge.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;


@Entity
public class FlowExecution {

    @Id
    @GeneratedValue
    private Long id;

    private Long flowId;

    private String status;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private UUID executionUuid;

    @OneToMany
    private List<PipelineExecution> pipelineExecutions;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFlowId() {
        return flowId;
    }

    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public UUID getExecutionUuid() {
        return executionUuid;
    }

    public void setExecutionUuid(UUID executionUuid) {
        this.executionUuid = executionUuid;
    }

    public List<PipelineExecution> getPipelineExecutions() {
        return pipelineExecutions;
    }

    public void setPipelineExecutions(List<PipelineExecution> pipelineExecutions) {
        this.pipelineExecutions = pipelineExecutions;
    }
}
