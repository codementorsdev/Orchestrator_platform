package com.flowforge.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
public class PipelineExecution {

    @Id
    @GeneratedValue
    private Long id;

    private Long flowExecutionId;

    private Long pipelineId;

    private String status;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private UUID executionUuid;

    @Lob
    private String executionPayload;

    @Lob
    private String logs;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFlowExecutionId() {
        return flowExecutionId;
    }

    public void setFlowExecutionId(Long flowExecutionId) {
        this.flowExecutionId = flowExecutionId;
    }

    public Long getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(Long pipelineId) {
        this.pipelineId = pipelineId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public UUID getExecutionUuid() {
        return executionUuid;
    }

    public void setExecutionUuid(UUID executionUuid) {
        this.executionUuid = executionUuid;
    }

    public String getExecutionPayload() {
        return executionPayload;
    }

    public void setExecutionPayload(String executionPayload) {
        this.executionPayload = executionPayload;
    }

    public String getLogs() {
        return logs;
    }

    public void setLogs(String logs) {
        this.logs = logs;
    }
}
