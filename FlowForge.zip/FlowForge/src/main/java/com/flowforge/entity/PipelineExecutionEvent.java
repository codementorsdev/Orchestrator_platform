package com.flowforge.entity;

import org.springframework.context.ApplicationEvent;


public class PipelineExecutionEvent extends ApplicationEvent {

    private Long pipelineExecutionId;

    public PipelineExecutionEvent(Object source, Long pipelineExecutionId) {
        super(source);
        this.pipelineExecutionId = pipelineExecutionId;
    }

    public Long getPipelineExecutionId() {
        return pipelineExecutionId;
    }
}
