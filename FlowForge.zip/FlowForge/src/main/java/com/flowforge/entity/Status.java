package com.flowforge.entity;

public enum Status {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}
