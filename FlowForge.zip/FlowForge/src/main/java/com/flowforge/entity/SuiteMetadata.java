package com.flowforge.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
@Entity
public class SuiteMetadata {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private UUID executionUuid;

    private String name;
    private String description;

    @ElementCollection
    private List<String> tags;

    private Long startTime;
    private Long endTime;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id")
    private ApplicationMetadata applicationMetadata;

    @JsonManagedReference
    @OneToMany(mappedBy = "suiteMetadata", cascade = CascadeType.ALL, orphanRemoval = true)
    @MapKey(name = "name")
    private Map<String, TestMetadata> tests;
}
