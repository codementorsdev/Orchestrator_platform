package com.flowforge.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import java.util.List;
import java.util.UUID;

@Data
@Entity
public class TestMetadata {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private UUID executionUuid;

    @Column(nullable = false)
    private String name;
    private String description;

    @ElementCollection
    private List<String> tags;

    private Long startTime;
    private Long endTime;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "suite_id")
    private SuiteMetadata suiteMetadata;

    @JsonManagedReference
    @OneToMany(mappedBy = "testMetadata", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LogMetadata> logMetadata;
}
