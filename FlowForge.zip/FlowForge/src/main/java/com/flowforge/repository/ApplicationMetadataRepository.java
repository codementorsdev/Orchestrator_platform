package com.flowforge.repository;

import com.flowforge.entity.ApplicationMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface ApplicationMetadataRepository extends JpaRepository<ApplicationMetadata, Long> {
    ApplicationMetadata findByAppId(String appId);
    List<ApplicationMetadata> findByExecutionUuid(UUID executionUuid);
}
