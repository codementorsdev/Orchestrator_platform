package com.flowforge.repository;

import com.flowforge.entity.CustomDataMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface CustomDataMetadataRepository extends JpaRepository<CustomDataMetadata, Long> {
    List<CustomDataMetadata> findByExecutionUuid(UUID executionUuid);
}
