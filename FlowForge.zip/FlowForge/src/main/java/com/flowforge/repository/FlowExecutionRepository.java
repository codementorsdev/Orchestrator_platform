package com.flowforge.repository;

import com.flowforge.entity.FlowExecution;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FlowExecutionRepository extends JpaRepository<FlowExecution, Long> {
    List<FlowExecution> findByFlowId(Long flowId);
}
