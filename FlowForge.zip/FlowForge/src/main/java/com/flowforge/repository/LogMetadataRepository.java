package com.flowforge.repository;

import com.flowforge.entity.LogMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface LogMetadataRepository extends JpaRepository<LogMetadata, Long> {
    List<LogMetadata> findByTestMetadata_Id(Long testId);
    List<LogMetadata> findByExecutionUuid(UUID executionUuid);
}
