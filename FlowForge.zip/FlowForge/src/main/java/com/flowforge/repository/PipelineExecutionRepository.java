package com.flowforge.repository;

import com.flowforge.entity.PipelineExecution;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface PipelineExecutionRepository extends JpaRepository<PipelineExecution, Long> {
    List<PipelineExecution> findByPipelineId(Long pipelineId);
    List<PipelineExecution> findByFlowExecutionId(Long flowExecutionId);
    List<PipelineExecution> findByExecutionUuid(UUID executionUuid);
}
