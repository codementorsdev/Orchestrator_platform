package com.flowforge.repository;

import com.flowforge.entity.SuiteMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface SuiteMetadataRepository extends JpaRepository<SuiteMetadata, Long> {
    List<SuiteMetadata> findByApplicationMetadata_Id(Long applicationId);
    List<SuiteMetadata> findByExecutionUuid(UUID executionUuid);
}
