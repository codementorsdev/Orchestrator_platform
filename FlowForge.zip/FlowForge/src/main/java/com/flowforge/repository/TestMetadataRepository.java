package com.flowforge.repository;

import com.flowforge.entity.TestMetadata;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

public interface TestMetadataRepository extends JpaRepository<TestMetadata, Long> {
    List<TestMetadata> findBySuiteMetadata_Id(Long suiteId);
    List<TestMetadata> findByExecutionUuid(UUID executionUuid);
}
