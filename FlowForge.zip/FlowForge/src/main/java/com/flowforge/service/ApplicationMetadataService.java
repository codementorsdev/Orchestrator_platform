package com.flowforge.service;

import com.flowforge.entity.SuiteMetadata;
import com.flowforge.entity.TestMetadata;
import com.flowforge.dto.ApplicationMetadataPayloadDTO;
import com.flowforge.entity.ApplicationMetadata;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowforge.entity.LogMetadata;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.flowforge.entity.CustomDataMetadata;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowforge.repository.ApplicationMetadataRepository;
import org.springframework.stereotype.Service;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.UUID;

@Service
public class ApplicationMetadataService {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final ApplicationMetadataRepository applicationMetadataRepository;
    private final SuiteMetadataService suiteMetadataService;
    private final TestMetadataService testMetadataService;
    private final LogMetadataService logMetadataService;

    public ApplicationMetadataService(ApplicationMetadataRepository applicationMetadataRepository, SuiteMetadataService suiteMetadataService, TestMetadataService testMetadataService, LogMetadataService logMetadataService) {
        this.applicationMetadataRepository = applicationMetadataRepository;
        this.suiteMetadataService = suiteMetadataService;
        this.testMetadataService = testMetadataService;
        this.logMetadataService = logMetadataService;
    }

    @Transactional
    public ApplicationMetadata saveApplication(ApplicationMetadata applicationMetadata) {
        return applicationMetadataRepository.save(applicationMetadata);
    }

    public ApplicationMetadata getApplicationById(Long id) {
        return applicationMetadataRepository.findById(id).orElse(null);
    }

    public ApplicationMetadata getApplicationByAppId(String appId) {
        return applicationMetadataRepository.findByAppId(appId);
    }

    public List<ApplicationMetadata> getAllApplications() {
        return applicationMetadataRepository.findAll();
    }

    @Transactional
    public ApplicationMetadata saveFullPayload(ApplicationMetadataPayloadDTO payloadDTO, UUID executionUuid) {
        String appId = payloadDTO.getAppId();
        ApplicationMetadata existingApplication = applicationMetadataRepository.findByAppId(appId);

        ApplicationMetadata applicationMetadata = mapToApplication(payloadDTO);
        applicationMetadata.setExecutionUuid(executionUuid);

        if (existingApplication != null) {
            // Update existing application
            applicationMetadata.setId(existingApplication.getId()); // Preserve the ID for updating
            applicationMetadata.setCustomData(existingApplication.getCustomData()); //Preserve custom data id
        }

        ApplicationMetadata savedApplicationMetadata = applicationMetadataRepository.save(applicationMetadata);

        if (applicationMetadata.getSuiteMetadata() != null) {
            for (SuiteMetadata suiteMetadata : applicationMetadata.getSuiteMetadata()) {
                suiteMetadata.setApplicationMetadata(savedApplicationMetadata);
                SuiteMetadata savedSuiteMetadata = suiteMetadataService.saveSuite(suiteMetadata);

                if (suiteMetadata.getTests() != null) {
                    for (TestMetadata testMetadata : suiteMetadata.getTests().values()) {
                        testMetadata.setSuiteMetadata(savedSuiteMetadata);
                        TestMetadata savedTestMetadata = testMetadataService.saveTest(testMetadata);

                        if (testMetadata.getLogMetadata() != null) {
                            for (LogMetadata logMetadata : testMetadata.getLogMetadata()) {
                                logMetadata.setTestMetadata(savedTestMetadata);
                                logMetadataService.saveLog(logMetadata);
                            }
                        }
                    }
                }
            }
        }

        return savedApplicationMetadata;
    }

    public ApplicationMetadataPayloadDTO getFullPayloadById(Long id) {
        ApplicationMetadata applicationMetadata = applicationMetadataRepository.findById(id).orElse(null);
        return applicationMetadata != null ? mapToPayloadDTO(applicationMetadata) : null;
    }

    private ApplicationMetadata mapToApplication(ApplicationMetadataPayloadDTO dto) {
        ApplicationMetadata applicationMetadata = new ApplicationMetadata();
        applicationMetadata.setAppId(dto.getAppId());
        applicationMetadata.setAppName(dto.getAppName());
        applicationMetadata.setAppDescription(dto.getAppDescription());

        CustomDataMetadata customDataMetadata = new CustomDataMetadata();
        try {
            String customDataJson = objectMapper.writeValueAsString(dto.getCustomData());
            customDataMetadata.setData(customDataJson);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            customDataMetadata.setData(null);
        }
        applicationMetadata.setCustomData(customDataMetadata);

        if (dto.getSuites() != null) {
            List<SuiteMetadata> suiteMetadata = dto.getSuites().stream()
                .map(suiteDTO -> {
                    SuiteMetadata suite = new SuiteMetadata();
                    suite.setName(suiteDTO.getName());
                    suite.setDescription(suiteDTO.getDescription());
                    suite.setTags(suiteDTO.getTags());
                    suite.setStartTime(suiteDTO.getStartTime());
                    suite.setEndTime(suiteDTO.getEndTime());
                    suite.setExecutionUuid(applicationMetadata.getExecutionUuid());

                    if (suiteDTO.getTests() != null) {
                        Map<String, TestMetadata> tests = suiteDTO.getTests().entrySet().stream()
                            .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                entry -> {
                                    ApplicationMetadataPayloadDTO.TestDTO testDTO = entry.getValue();
                                    TestMetadata testMetadata = new TestMetadata();
                                    testMetadata.setName(testDTO.getName());
                                    testMetadata.setDescription(testDTO.getDescription());
                                    testMetadata.setTags(testDTO.getTags());
                                    testMetadata.setStartTime(testDTO.getStartTime());
                                    testMetadata.setEndTime(testDTO.getEndTime());
                                    testMetadata.setExecutionUuid(applicationMetadata.getExecutionUuid());

                                    if (testDTO.getLogs() != null) {
                                        List<LogMetadata> logMetadata = testDTO.getLogs().stream()
                                            .map(logDTO -> {
                                                LogMetadata log = new LogMetadata();
                                                log.setMessage(logDTO.getMessage());
                                                log.setStatus(logDTO.getStatus());
                                                log.setExecutionUuid(applicationMetadata.getExecutionUuid());
                                                return log;
                                            })
                                            .collect(Collectors.toList());
                                        testMetadata.setLogMetadata(logMetadata);
                                    }
                                    return testMetadata;
                                }
                            ));
                        suite.setTests(tests);
                    }
                    return suite;
                })
                .collect(Collectors.toList());
            applicationMetadata.setSuiteMetadata(suiteMetadata);
        }

        return applicationMetadata;
    }

    private ApplicationMetadataPayloadDTO mapToPayloadDTO(ApplicationMetadata applicationMetadata) {
        ApplicationMetadataPayloadDTO dto = new ApplicationMetadataPayloadDTO();
        dto.setAppId(applicationMetadata.getAppId());
        dto.setAppName(applicationMetadata.getAppName());
        dto.setAppDescription(applicationMetadata.getAppDescription());
        try {
            Object customData = objectMapper.readValue(applicationMetadata.getCustomData().getData(), Object.class);
            dto.setCustomData(customData);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            dto.setCustomData(null);
        }

        if (applicationMetadata.getSuiteMetadata() != null) {
            List<ApplicationMetadataPayloadDTO.SuiteDTO> suiteDTOs = applicationMetadata.getSuiteMetadata().stream()
                .map(suite -> {
                    ApplicationMetadataPayloadDTO.SuiteDTO suiteDTO = new ApplicationMetadataPayloadDTO.SuiteDTO();
                    suiteDTO.setName(suite.getName());
                    suiteDTO.setDescription(suite.getDescription());
                    suiteDTO.setTags(suite.getTags());
                    suiteDTO.setStartTime(suite.getStartTime());
                    suiteDTO.setEndTime(suite.getEndTime());

                    if (suite.getTests() != null) {
                        Map<String, ApplicationMetadataPayloadDTO.TestDTO> testDTOs = suite.getTests().entrySet().stream()
                            .collect(Collectors.toMap(
                                entry -> entry.getKey(),
                                entry -> {
                                    TestMetadata testMetadata = entry.getValue();
                                    ApplicationMetadataPayloadDTO.TestDTO testDTO = new ApplicationMetadataPayloadDTO.TestDTO();
                                    testDTO.setName(testMetadata.getName());
                                    testDTO.setDescription(testMetadata.getDescription());
                                    testDTO.setTags(testMetadata.getTags());
                                    testDTO.setStartTime(testMetadata.getStartTime());
                                    testDTO.setEndTime(testMetadata.getEndTime());

                                    if (testMetadata.getLogMetadata() != null) {
                                        List<ApplicationMetadataPayloadDTO.LogDTO> logDTOs = testMetadata.getLogMetadata().stream()
                                            .map(log -> {
                                                ApplicationMetadataPayloadDTO.LogDTO logDTO = new ApplicationMetadataPayloadDTO.LogDTO();
                                                logDTO.setMessage(log.getMessage());
                                                logDTO.setStatus(log.getStatus());
                                                return logDTO;
                                            })
                                            .collect(Collectors.toList());
                                        testDTO.setLogs(logDTOs);
                                    }
                                    return testDTO;
                                }
                            ));
                        suiteDTO.setTests(testDTOs);
                    }
                    return suiteDTO;
                })
                .collect(Collectors.toList());
            dto.setSuites(suiteDTOs);
        }
        return dto;
    }
}
