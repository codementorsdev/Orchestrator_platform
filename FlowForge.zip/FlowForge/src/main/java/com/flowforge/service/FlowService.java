package com.flowforge.service;

import com.flowforge.dto.FlowDTO;
import com.flowforge.entity.Flow;
import com.flowforge.entity.Pipeline;
import com.flowforge.repository.FlowRepository;
import com.flowforge.repository.PipelineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FlowService {

    @Autowired
    private FlowRepository flowRepository;

    @Autowired
    private PipelineRepository pipelineRepository;

    public FlowDTO createFlow(FlowDTO flowDTO) {
        Flow flow = convertToEntity(flowDTO);
        Flow savedFlow = flowRepository.save(flow);
        return convertToDTO(savedFlow);
    }

    public List<FlowDTO> getAllFlows() {
        List<Flow> flows = flowRepository.findAll();
        return flows.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public FlowDTO getFlowById(Long id) {
        Flow flow = flowRepository.findById(id).orElse(null);
        return flow != null ? convertToDTO(flow) : null;
    }

    @Transactional
    public Flow getFlowWithPipelines(Long id) {
        Flow flow = flowRepository.findById(id).orElse(null);
        if (flow != null) {
            // Force initialization of pipelines collection
            flow.getPipelines().size();
        }
        return flow;
    }

    public FlowDTO updateFlow(Long id, FlowDTO flowDTO) {
        Flow existingFlow = flowRepository.findById(id).orElse(null);
        if (existingFlow != null) {
            Flow flow = convertToEntity(flowDTO);
            flow.setId(id);
            Flow updatedFlow = flowRepository.save(flow);
            return convertToDTO(updatedFlow);
        }
        return null;
    }

    public void deleteFlow(Long id) {
        flowRepository.deleteById(id);
    }

    public List<Pipeline> getPipelinesByFlowId(Long flowId) {
        Flow flow = flowRepository.findById(flowId).orElse(null);
        if (flow != null) {
            return flow.getPipelines();
        }
        return null;
    }

    public FlowDTO convertToDTO(Flow flow) {
        FlowDTO flowDTO = new FlowDTO();
        flowDTO.setId(flow.getId());
        flowDTO.setName(flow.getName());
        flowDTO.setDescription(flow.getDescription());
        //flowDTO.setPipelineIds(flow.getPipelines().stream().map(Pipeline::getId).collect(Collectors.toList()));
        flowDTO.setStatus(flow.getStatus());
        flowDTO.setCreatedAt(flow.getCreatedAt());
        flowDTO.setUpdatedAt(flow.getUpdatedAt());
        if (flow.getPipelines() != null) {
            flowDTO.setPipelineIds(flow.getPipelines().stream().map(Pipeline::getId).collect(Collectors.toList()));
        }
        return flowDTO;
    }

    public Flow convertToEntity(FlowDTO flowDTO) {
        Flow flow = new Flow();
        flow.setName(flowDTO.getName());
        flow.setDescription(flowDTO.getDescription());
        flow.setStatus(flowDTO.getStatus());
        flow.setCreatedAt(flowDTO.getCreatedAt());
        flow.setUpdatedAt(flowDTO.getUpdatedAt());
         if (flowDTO.getPipelineIds() != null) {
            List<Pipeline> pipelines = pipelineRepository.findAllById(flowDTO.getPipelineIds());
             for (Pipeline pipeline : pipelines) {
                System.out.println("Pipeline ID: " + pipeline.getId());
            }
            flow.setPipelines(pipelines);
        }
        return flow;
    }
}
