package com.flowforge.service;

import com.flowforge.entity.LogMetadata;
import com.flowforge.repository.LogMetadataRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class LogMetadataService {
    private final LogMetadataRepository logMetadataRepository;

    public LogMetadataService(LogMetadataRepository logMetadataRepository) {
        this.logMetadataRepository = logMetadataRepository;
    }

    @Transactional
    public LogMetadata saveLog(LogMetadata logMetadata) {
        return logMetadataRepository.save(logMetadata);
    }

    public List<LogMetadata> getLogsByTestId(Long testId) {
        return logMetadataRepository.findByTestMetadata_Id(testId);
    }
}
