package com.flowforge.service;

import com.flowforge.entity.PipelineExecutionEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class PipelineExecutionEventListener {

    @EventListener
    public void handlePipelineExecutionEvent(PipelineExecutionEvent event) {
        System.out.println("Received pipeline execution event for pipeline execution ID: " + event.getPipelineExecutionId());
        // TODO: Implement logic to update pipeline execution status and trigger next pipeline
    }
}
