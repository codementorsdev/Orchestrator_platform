package com.flowforge.service;

import com.flowforge.dto.PipelineExecutionDTO;
import com.flowforge.entity.Application;
import com.flowforge.entity.Pipeline;
import com.flowforge.entity.PipelineExecution;
import com.flowforge.repository.PipelineExecutionRepository;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.PipelineApi;
import org.gitlab4j.api.models.Variable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class PipelineExecutionService {

    private static final Logger logger = LoggerFactory.getLogger(PipelineExecutionService.class);

    @Autowired
    private PipelineExecutionRepository pipelineExecutionRepository;

    public PipelineExecution createPipelineExecution(PipelineExecution pipelineExecution) {
        return pipelineExecutionRepository.save(pipelineExecution);
    }

    public List<PipelineExecution> getAllPipelineExecutions() {
        return pipelineExecutionRepository.findAll();
    }

    public List<PipelineExecution> getAllPipelineExecutionsByFlowExecutionId(Long flowExecutionId) {
        return pipelineExecutionRepository.findByFlowExecutionId(flowExecutionId);
    }

    public List<PipelineExecution> getAllPipelineExecutionsByPipelineId(Long pipelineId) {
        return pipelineExecutionRepository.findByPipelineId(pipelineId);
    }

    public PipelineExecution getPipelineExecutionById(Long id) {
        return pipelineExecutionRepository.findById(id).orElse(null);
    }

    public PipelineExecution updatePipelineExecution(Long id, PipelineExecution pipelineExecution) {
        PipelineExecution existingPipelineExecution = pipelineExecutionRepository.findById(id).orElse(null);
        if (existingPipelineExecution != null) {
            pipelineExecution.setId(id);
            return pipelineExecutionRepository.save(pipelineExecution);
        }
        return null;
    }

    public void deletePipelineExecution(Long id) {
        pipelineExecutionRepository.deleteById(id);
    }

    public PipelineExecutionDTO convertToDTO(PipelineExecution pipelineExecution) {
        PipelineExecutionDTO dto = new PipelineExecutionDTO();
        dto.setId(pipelineExecution.getId());
        dto.setPipelineId(pipelineExecution.getPipelineId());
        dto.setFlowExecutionId(pipelineExecution.getFlowExecutionId());
        dto.setStatus(pipelineExecution.getStatus());
        dto.setStartTime(pipelineExecution.getStartTime());
        dto.setEndTime(pipelineExecution.getEndTime());
        dto.setExecutionPayload(pipelineExecution.getExecutionPayload());
        return dto;
    }

    public PipelineExecution convertToEntity(PipelineExecutionDTO dto) {
        PipelineExecution entity = new PipelineExecution();
        entity.setPipelineId(dto.getPipelineId());
        entity.setFlowExecutionId(dto.getFlowExecutionId());
        entity.setStatus(dto.getStatus());
        entity.setStartTime(dto.getStartTime());
        entity.setEndTime(dto.getEndTime());
        entity.setExecutionPayload(dto.getExecutionPayload());
        return entity;
    }

    @Async
    @Retryable(value = { GitLabApiException.class }, maxAttempts = 3, backoff = @Backoff(delay = 1000))
    public void triggerPipeline(Pipeline pipeline, UUID executionUuid) throws GitLabApiException {
        try {
            // Get the parent Application to access GitLab credentials
            Application application = pipeline.getApplication();
            if (application == null) {
                throw new IllegalStateException("Pipeline is not associated with an Application");
            }
            
            GitLabApi gitLabApi = new GitLabApi(application.getGitlabInstanceUrl(), application.getAccessToken());
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
    
            List<Variable> variables = new ArrayList<>();
            if (executionUuid != null) {
                Variable uuidVar = new Variable();
                uuidVar.setKey("EXECUTION_UUID");
                uuidVar.setValue(executionUuid.toString());
                variables.add(uuidVar);
            }
    
            pipelineApi.createPipeline(application.getProjectId(), pipeline.getBranch(), variables);
    
        } catch (GitLabApiException e) {
            logger.error("Error triggering pipeline", e);
            throw e;
        }
    }
}
