package com.flowforge.service;

import com.flowforge.dto.PipelineDTO;
import com.flowforge.entity.Application;
import com.flowforge.entity.Pipeline;
import com.flowforge.repository.PipelineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PipelineService {

    @Autowired
    private PipelineRepository pipelineRepository;

    @Autowired
    private ApplicationService applicationService;

    public PipelineDTO createPipeline(PipelineDTO pipelineDTO) {
        Pipeline pipeline = convertToEntity(pipelineDTO);
        
        // Ensure the Application is managed by fetching it first
        if (pipelineDTO.getApplicationId() != null) {
            Application application = applicationService.getApplicationEntityById(pipelineDTO.getApplicationId());
            if (application != null) {
                pipeline.setApplication(application);
            }
        }

        Pipeline savedPipeline = pipelineRepository.save(pipeline);
        return convertToDTO(savedPipeline);
    }

    public List<PipelineDTO> getAllPipelines() {
        List<Pipeline> pipelines = pipelineRepository.findAll();
        return pipelines.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public PipelineDTO getPipelineById(Long id) {
        Pipeline pipeline = pipelineRepository.findById(id).orElse(null);
        if (pipeline != null) {
            return convertToDTO(pipeline);
        }
        return null;
    }

    public PipelineDTO updatePipeline(Long id, PipelineDTO pipelineDTO) {
        Pipeline existingPipeline = pipelineRepository.findById(id).orElse(null);
        if (existingPipeline != null) {
            Pipeline pipeline = convertToEntity(pipelineDTO);
            pipeline.setId(id);
            Pipeline updatedPipeline = pipelineRepository.save(pipeline);
            return convertToDTO(updatedPipeline);
        }
        return null;
    }

    public void deletePipeline(Long id) {
        pipelineRepository.deleteById(id);
    }

    public PipelineDTO convertToDTO(Pipeline pipeline) {
        PipelineDTO pipelineDTO = new PipelineDTO();
        pipelineDTO.setId(pipeline.getId());
        pipelineDTO.setName(pipeline.getName());
        pipelineDTO.setDescription(pipeline.getDescription());
        pipelineDTO.setBranch(pipeline.getBranch());
        pipelineDTO.setExecutionSequence(pipeline.getExecutionSequence());
        if (pipeline.getApplication() != null) {
            pipelineDTO.setApplicationId(pipeline.getApplication().getId());
        }
        return pipelineDTO;
    }

    private Pipeline convertToEntity(PipelineDTO pipelineDTO) {
        Pipeline pipeline = new Pipeline();
        pipeline.setName(pipelineDTO.getName());
        pipeline.setDescription(pipelineDTO.getDescription());
        pipeline.setBranch(pipelineDTO.getBranch());
        pipeline.setExecutionSequence(pipelineDTO.getExecutionSequence());
        if (pipelineDTO.getApplicationId() != null) {
            // Get the managed Application entity directly from repository
            Application application = applicationService.getApplicationEntityById(pipelineDTO.getApplicationId());
            if (application != null) {
                pipeline.setApplication(application);
            }
        }
        return pipeline;
    }
}
