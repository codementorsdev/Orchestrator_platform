package com.flowforge.service;

import com.flowforge.entity.SuiteMetadata;
import com.flowforge.repository.SuiteMetadataRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class SuiteMetadataService {
    private final SuiteMetadataRepository suiteMetadataRepository;

    public SuiteMetadataService(SuiteMetadataRepository suiteMetadataRepository) {
        this.suiteMetadataRepository = suiteMetadataRepository;
    }

    @Transactional
    public SuiteMetadata saveSuite(SuiteMetadata suiteMetadata) {
        return suiteMetadataRepository.save(suiteMetadata);
    }

    public List<SuiteMetadata> getSuitesByApplicationId(Long applicationId) {
        return suiteMetadataRepository.findByApplicationMetadata_Id(applicationId);
    }
}
