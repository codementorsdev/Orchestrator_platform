package com.flowforge.service;

import com.flowforge.entity.TestMetadata;
import com.flowforge.repository.TestMetadataRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class TestMetadataService {
    private final TestMetadataRepository testMetadataRepository;

    public TestMetadataService(TestMetadataRepository testMetadataRepository) {
        this.testMetadataRepository = testMetadataRepository;
    }

    @Transactional
    public TestMetadata saveTest(TestMetadata testMetadata) {
        return testMetadataRepository.save(testMetadata);
    }

    public List<TestMetadata> getTestsBySuiteId(Long suiteId) {
        return testMetadataRepository.findBySuiteMetadata_Id(suiteId);
    }
}
