// Main application entry point
import { checkAuth, logout } from './auth.js';
import { initDashboard } from './dashboard.js';
import { initFlowConfig } from './flow.js';
import { initData } from './data.js';

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    // Initialize the data store
    initData();
    
    // Router function to handle page navigation
    const router = async () => {
        const app = document.getElementById('app');
        const path = window.location.pathname;
        
        // Check if user is authenticated
        const isAuthenticated = checkAuth();
        
        // If not on login or register page and not authenticated, redirect to login
        if (!path.includes('/pages/login.html') && !path.includes('/pages/register.html') && !isAuthenticated) {
            window.location.href = '/pages/login.html';
            return;
        }
        
        // If authenticated and on login or register page, redirect to dashboard
        if ((path.includes('/pages/login.html') || path.includes('/pages/register.html')) && isAuthenticated) {
            window.location.href = '/pages/dashboard.html';
            return;
        }
        
        // If path is root, redirect to dashboard
        if (path === '/' || path === '/index.html') {
            window.location.href = '/pages/dashboard.html';
            return;
        }
        
        // Setup logout event listeners if authenticated
        if (isAuthenticated) {
            const logoutLinks = document.querySelectorAll('.logout-link');
            logoutLinks.forEach(link => {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    logout();
                    window.location.href = '/pages/login.html';
                });
            });
        }
        
        // Initialize page-specific functionality
        if (path.includes('/pages/dashboard.html')) {
            initDashboard();
        } else if (path.includes('/pages/flow-config.html')) {
            initFlowConfig();
        }
    };
    
    // Initial route handling
    router();
    
    // Handle navigation events
    window.addEventListener('popstate', router);
});

// Function to display notification messages
export function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate the notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Remove the notification after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Function to format date
export function formatDate(date) {
    const d = new Date(date);
    return d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
}

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        border-radius: 6px;
        background-color: #f8f9fa;
        color: #333;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        opacity: 0;
        transform: translateY(-20px);
        transition: all 0.3s ease;
    }
    
    .notification.show {
        opacity: 1;
        transform: translateY(0);
    }
    
    .notification-info {
        background-color: #e3f2fd;
        color: #0d47a1;
    }
    
    .notification-success {
        background-color: #e8f5e9;
        color: #1b5e20;
    }
    
    .notification-warning {
        background-color: #fff3e0;
        color: #e65100;
    }
    
    .notification-error {
        background-color: #ffebee;
        color: #b71c1c;
    }
`;
document.head.appendChild(style);
