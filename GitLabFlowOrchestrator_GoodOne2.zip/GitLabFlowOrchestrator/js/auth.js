/**
 * Authentication Module
 * 
 * Handles user registration, login, logout, and authentication state.
 */

// Check if the user is authenticated
export function checkAuth() {
    return localStorage.getItem('authToken') !== null;
}

// Login function
export function login(email, password) {
    // In a real application, this would make an API call
    // For demo purposes, we'll use hardcoded values and local storage
    
    // For demo, accept any properly formatted email with any password
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return { success: false, message: "Invalid email format" };
    }
    
    if (password.length < 6) {
        return { success: false, message: "Password must be at least 6 characters" };
    }
    
    // Create a simple mock token
    const token = btoa(`${email}:${Date.now()}`);
    
    // Store auth data in local storage
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify({
        email,
        name: email.split('@')[0],
        avatar: email.substring(0, 2).toUpperCase()
    }));
    
    return { success: true };
}

// Register function
export function register(name, email, password, confirmPassword) {
    // In a real application, this would make an API call
    // For demo purposes, we'll use hardcoded values and local storage
    
    // Basic validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return { success: false, message: "Invalid email format" };
    }
    
    if (password.length < 6) {
        return { success: false, message: "Password must be at least 6 characters" };
    }
    
    if (password !== confirmPassword) {
        return { success: false, message: "Passwords do not match" };
    }
    
    if (!name || name.trim().length === 0) {
        return { success: false, message: "Name is required" };
    }
    
    // Create a simple mock token
    const token = btoa(`${email}:${Date.now()}`);
    
    // Store auth data in local storage
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify({
        email,
        name,
        avatar: name.substring(0, 2).toUpperCase()
    }));
    
    return { success: true };
}

// Logout function
export function logout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
}

// Get current user
export function getCurrentUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
}

// Initialize auth listeners for login page
export function initLoginForm() {
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) return;
    
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        const result = login(email, password);
        
        if (result.success) {
            window.location.href = '/pages/dashboard.html';
        } else {
            const errorElem = document.getElementById('loginError');
            errorElem.textContent = result.message;
            errorElem.style.display = 'block';
        }
    });
}

// Initialize auth listeners for register page
export function initRegisterForm() {
    const registerForm = document.getElementById('registerForm');
    if (!registerForm) return;
    
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        const result = register(name, email, password, confirmPassword);
        
        if (result.success) {
            window.location.href = '/pages/dashboard.html';
        } else {
            const errorElem = document.getElementById('registerError');
            errorElem.textContent = result.message;
            errorElem.style.display = 'block';
        }
    });
}

// Initialize both forms when the script loads
document.addEventListener('DOMContentLoaded', () => {
    initLoginForm();
    initRegisterForm();
});
