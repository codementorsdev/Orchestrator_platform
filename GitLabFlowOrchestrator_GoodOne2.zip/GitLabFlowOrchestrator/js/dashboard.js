/**
 * Dashboard Module
 * 
 * Handles the main dashboard view and interactions.
 */
import { getCurrentUser } from './auth.js';
import { getFlows, updateFlowStatus } from './data.js';
import { showNotification, formatDate } from './app.js';

// Initialize the dashboard
export function initDashboard() {
    // Set user info in the header
    setUserInfo();
    
    // Load and display flows
    displayFlows();
    
    // Initialize "Create New Flow" button
    const createFlowBtn = document.getElementById('createFlowBtn');
    if (createFlowBtn) {
        createFlowBtn.addEventListener('click', () => {
            window.location.href = '/pages/flow-config.html?new=true';
        });
    }
    
    // Initialize stats
    updateDashboardStats();
    
    // Setup polling for pipeline updates
    setupPolling();
}

// Set user information in the header
function setUserInfo() {
    const user = getCurrentUser();
    
    if (!user) return;
    
    const userNameElem = document.getElementById('userName');
    const userAvatarElem = document.getElementById('userAvatar');
    
    if (userNameElem) {
        userNameElem.textContent = user.name;
    }
    
    if (userAvatarElem) {
        userAvatarElem.textContent = user.avatar;
    }
}

// Display all flows on the dashboard
function displayFlows() {
    const flowsListElem = document.getElementById('flowsList');
    if (!flowsListElem) return;
    
    const flows = getFlows();
    
    if (flows.length === 0) {
        flowsListElem.innerHTML = `
            <div class="empty-state">
                <p>You don't have any flows yet. Create a new flow to get started.</p>
                <button id="emptyStateCreateBtn" class="btn">Create New Flow</button>
            </div>
        `;
        
        const emptyStateCreateBtn = document.getElementById('emptyStateCreateBtn');
        if (emptyStateCreateBtn) {
            emptyStateCreateBtn.addEventListener('click', () => {
                window.location.href = '/pages/flow-config.html?new=true';
            });
        }
        
        return;
    }
    
    // Sort flows by last updated date (newest first)
    flows.sort((a, b) => new Date(b.lastUpdated) - new Date(a.lastUpdated));
    
    flowsListElem.innerHTML = flows.map(flow => `
        <div class="flow-card">
            <div class="flow-header">
                <h3 class="flow-title">${flow.name}</h3>
                <span class="flow-status status-${flow.status.toLowerCase()}">${capitalizeFirstLetter(flow.status)}</span>
            </div>
            <div class="flow-details">
                <div class="flow-detail">
                    <span class="flow-detail-label">Apps:</span>
                    <span>${flow.applications.length}</span>
                </div>
                <div class="flow-detail">
                    <span class="flow-detail-label">Pipelines:</span>
                    <span>${countPipelines(flow)}</span>
                </div>
                <div class="flow-detail">
                    <span class="flow-detail-label">Last Run:</span>
                    <span>${flow.lastRun ? formatDate(flow.lastRun) : 'Never'}</span>
                </div>
                <div class="flow-detail">
                    <span class="flow-detail-label">Created:</span>
                    <span>${formatDate(flow.created)}</span>
                </div>
            </div>
            <div class="flow-actions">
                <button class="btn btn-secondary view-flow" data-id="${flow.id}">View</button>
                <button class="btn run-flow" data-id="${flow.id}" ${flow.status === 'RUNNING' ? 'disabled' : ''}>
                    ${flow.status === 'RUNNING' ? 'Running...' : 'Run Flow'}
                </button>
            </div>
        </div>
    `).join('');
    
    // Add event listeners to flow action buttons
    document.querySelectorAll('.view-flow').forEach(btn => {
        btn.addEventListener('click', () => {
            const flowId = btn.getAttribute('data-id');
            window.location.href = `/pages/flow-config.html?id=${flowId}`;
        });
    });
    
    document.querySelectorAll('.run-flow').forEach(btn => {
        btn.addEventListener('click', () => {
            const flowId = btn.getAttribute('data-id');
            runFlow(flowId);
        });
    });
}

// Run a flow
function runFlow(flowId) {
    // Get the flow
    const flows = getFlows();
    const flowIndex = flows.findIndex(f => f.id === flowId);
    
    if (flowIndex === -1) {
        showNotification('Flow not found', 'error');
        return;
    }
    
    // Update flow status to RUNNING
    flows[flowIndex].status = 'RUNNING';
    flows[flowIndex].lastRun = new Date().toISOString();
    flows[flowIndex].lastUpdated = new Date().toISOString();
    
    // Initialize all pipelines to WAITING
    flows[flowIndex].applications.forEach(app => {
        app.pipelines.forEach(pipeline => {
            pipeline.status = 'WAITING';
        });
    });
    
    // Start the first pipeline
    if (flows[flowIndex].applications.length > 0 && 
        flows[flowIndex].applications[0].pipelines.length > 0) {
        flows[flowIndex].applications[0].pipelines[0].status = 'RUNNING';
    }
    
    // Update storage
    updateFlowStatus(flows);
    
    // Update UI
    displayFlows();
    updateDashboardStats();
    
    showNotification('Flow started successfully', 'success');
}

// Helper to count total pipelines in a flow
function countPipelines(flow) {
    return flow.applications.reduce((count, app) => count + app.pipelines.length, 0);
}

// Update dashboard statistics
function updateDashboardStats() {
    const flows = getFlows();
    
    // Count statistics
    const totalFlows = flows.length;
    const runningFlows = flows.filter(f => f.status === 'RUNNING').length;
    const successFlows = flows.filter(f => f.status === 'SUCCESS').length;
    const failedFlows = flows.filter(f => f.status === 'FAILED').length;
    
    // Calculate total pipelines
    const totalPipelines = flows.reduce((count, flow) => count + countPipelines(flow), 0);
    
    // Update DOM
    const elemTotalFlows = document.getElementById('totalFlows');
    const elemRunningFlows = document.getElementById('runningFlows');
    const elemSuccessRate = document.getElementById('successRate');
    const elemTotalPipelines = document.getElementById('totalPipelines');
    
    if (elemTotalFlows) elemTotalFlows.textContent = totalFlows;
    if (elemRunningFlows) elemRunningFlows.textContent = runningFlows;
    
    if (elemSuccessRate) {
        const completedFlows = successFlows + failedFlows;
        const rate = completedFlows === 0 ? 0 : Math.round((successFlows / completedFlows) * 100);
        elemSuccessRate.textContent = `${rate}%`;
    }
    
    if (elemTotalPipelines) elemTotalPipelines.textContent = totalPipelines;
}

// Setup polling for pipeline updates
function setupPolling() {
    setInterval(() => {
        const flows = getFlows();
        let updated = false;
        
        // For each running flow, advance the pipeline execution
        flows.forEach(flow => {
            if (flow.status === 'RUNNING') {
                updated = advancePipelineExecution(flow) || updated;
            }
        });
        
        if (updated) {
            // Update storage
            updateFlowStatus(flows);
            
            // Update UI
            displayFlows();
            updateDashboardStats();
        }
    }, 3000); // Poll every 3 seconds
}

// Advance pipeline execution
function advancePipelineExecution(flow) {
    let updated = false;
    let allComplete = true;
    let hasFailure = false;
    
    // Loop through applications
    for (let i = 0; i < flow.applications.length; i++) {
        const app = flow.applications[i];
        let appComplete = true;
        
        // Loop through pipelines in application
        for (let j = 0; j < app.pipelines.length; j++) {
            const pipeline = app.pipelines[j];
            
            if (pipeline.status === 'RUNNING') {
                // Simulate pipeline execution (random success/failure)
                const success = Math.random() > 0.2; // 80% success rate
                
                if (success) {
                    pipeline.status = 'SUCCESS';
                } else {
                    pipeline.status = 'FAILED';
                    hasFailure = true;
                }
                
                updated = true;
                
                // If success and not the last pipeline in the app, start the next one
                if (success && j < app.pipelines.length - 1) {
                    app.pipelines[j + 1].status = 'RUNNING';
                    appComplete = false;
                    break;
                }
                
                // If failure, stop the flow
                if (!success) {
                    appComplete = false;
                    break;
                }
            } else if (pipeline.status === 'WAITING') {
                appComplete = false;
            }
        }
        
        // If app complete and not the last app, start the first pipeline of the next app
        if (appComplete && i < flow.applications.length - 1) {
            const nextApp = flow.applications[i + 1];
            if (nextApp.pipelines.length > 0 && !hasFailure) {
                nextApp.pipelines[0].status = 'RUNNING';
                allComplete = false;
                updated = true;
                break;
            }
        }
        
        if (!appComplete) {
            allComplete = false;
        }
    }
    
    // If all pipelines are complete, update flow status
    if (allComplete || hasFailure) {
        flow.status = hasFailure ? 'FAILED' : 'SUCCESS';
        flow.lastUpdated = new Date().toISOString();
        updated = true;
    }
    
    return updated;
}

// Helper to capitalize first letter
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}
