/**
 * Data Module
 * 
 * Manages application data using localStorage for persistence.
 */

// Mock data for initial setup
const mockFlows = [
    {
        id: 'flow1',
        name: 'Product Release Pipeline',
        description: 'Main product release flow including testing, building and deployment',
        applications: [
            {
                name: 'Backend API',
                token: 'glpat-XXXXXXXXXXXXXXXXXXXX',
                projectId: 'backend-api-123',
                pipelines: [
                    {
                        name: 'Run Tests',
                        branch: 'main',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Build',
                        branch: 'main',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Deploy to Staging',
                        branch: 'main',
                        status: 'SUCCESS'
                    }
                ]
            },
            {
                name: 'Frontend App',
                token: 'glpat-XXXXXXXXXXXXXXXXXXXX',
                projectId: 'frontend-app-456',
                pipelines: [
                    {
                        name: 'Run Tests',
                        branch: 'main',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Build',
                        branch: 'main',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Deploy to Staging',
                        branch: 'main',
                        status: 'SUCCESS'
                    }
                ]
            }
        ],
        status: 'SUCCESS',
        created: '2023-06-01T10:00:00.000Z',
        lastUpdated: '2023-06-10T14:30:00.000Z',
        lastRun: '2023-06-10T14:00:00.000Z'
    },
    {
        id: 'flow2',
        name: 'Nightly Build',
        description: 'Automated nightly build and test pipeline',
        applications: [
            {
                name: 'Core Service',
                token: 'glpat-XXXXXXXXXXXXXXXXXXXX',
                projectId: 'core-service-789',
                pipelines: [
                    {
                        name: 'Compile',
                        branch: 'develop',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Unit Tests',
                        branch: 'develop',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Integration Tests',
                        branch: 'develop',
                        status: 'FAILED'
                    }
                ]
            }
        ],
        status: 'FAILED',
        created: '2023-05-15T09:00:00.000Z',
        lastUpdated: '2023-06-15T02:30:00.000Z',
        lastRun: '2023-06-15T02:00:00.000Z'
    },
    {
        id: 'flow3',
        name: 'Microservices Deployment',
        description: 'Coordinated deployment of multiple microservices',
        applications: [
            {
                name: 'Auth Service',
                token: 'glpat-XXXXXXXXXXXXXXXXXXXX',
                projectId: 'auth-svc-123',
                pipelines: [
                    {
                        name: 'Build',
                        branch: 'master',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Deploy',
                        branch: 'master',
                        status: 'SUCCESS'
                    }
                ]
            },
            {
                name: 'User Service',
                token: 'glpat-XXXXXXXXXXXXXXXXXXXX',
                projectId: 'user-svc-456',
                pipelines: [
                    {
                        name: 'Build',
                        branch: 'master',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Deploy',
                        branch: 'master',
                        status: 'SUCCESS'
                    }
                ]
            },
            {
                name: 'Payment Service',
                token: 'glpat-XXXXXXXXXXXXXXXXXXXX',
                projectId: 'payment-svc-789',
                pipelines: [
                    {
                        name: 'Build',
                        branch: 'master',
                        status: 'SUCCESS'
                    },
                    {
                        name: 'Deploy',
                        branch: 'master',
                        status: 'SUCCESS'
                    }
                ]
            }
        ],
        status: 'SUCCESS',
        created: '2023-06-05T11:00:00.000Z',
        lastUpdated: '2023-06-12T09:45:00.000Z',
        lastRun: '2023-06-12T09:30:00.000Z'
    }
];

// Initialize data store
export function initData() {
    // Check if flows already exist in localStorage
    if (!localStorage.getItem('flows')) {
        // Initialize with mock data
        localStorage.setItem('flows', JSON.stringify(mockFlows));
    }
}

// Get all flows
export function getFlows() {
    const flowsJson = localStorage.getItem('flows');
    return flowsJson ? JSON.parse(flowsJson) : [];
}

// Get a specific flow by ID
export function getFlowById(id) {
    const flows = getFlows();
    return flows.find(flow => flow.id === id) || null;
}

// Save a new flow
export function saveFlow(flow) {
    const flows = getFlows();
    flows.push(flow);
    localStorage.setItem('flows', JSON.stringify(flows));
}

// Update an existing flow
export function updateFlow(updatedFlow) {
    const flows = getFlows();
    const index = flows.findIndex(flow => flow.id === updatedFlow.id);
    
    if (index !== -1) {
        flows[index] = updatedFlow;
        localStorage.setItem('flows', JSON.stringify(flows));
        return true;
    }
    
    return false;
}

// Delete a flow
export function deleteFlow(id) {
    const flows = getFlows();
    const filteredFlows = flows.filter(flow => flow.id !== id);
    
    if (filteredFlows.length !== flows.length) {
        localStorage.setItem('flows', JSON.stringify(filteredFlows));
        return true;
    }
    
    return false;
}

// Update flow statuses (used for real-time updates)
export function updateFlowStatus(updatedFlows) {
    localStorage.setItem('flows', JSON.stringify(updatedFlows));
}
