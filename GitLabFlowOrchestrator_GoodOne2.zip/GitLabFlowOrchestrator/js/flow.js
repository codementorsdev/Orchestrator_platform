/**
 * Flow Configuration Module
 * 
 * Handles creation, editing, and configuration of flows.
 */
import { getCurrentUser } from './auth.js';
import { getFlows, getFlowById, saveFlow, updateFlow } from './data.js';
import { showNotification } from './app.js';

let currentFlow = null;
let isNewFlow = false;

// Initialize the flow configuration page
export function initFlowConfig() {
    // Set user info in the header
    setUserInfo();
    
    // Check if we're creating a new flow or editing an existing one
    const urlParams = new URLSearchParams(window.location.search);
    const flowId = urlParams.get('id');
    isNewFlow = urlParams.get('new') === 'true';
    
    if (isNewFlow) {
        // Initialize a new flow
        currentFlow = createEmptyFlow();
        setupFlowConfigPage();
    } else if (flowId) {
        // Load existing flow
        currentFlow = getFlowById(flowId);
        if (currentFlow) {
            setupFlowConfigPage();
        } else {
            showNotification('Flow not found', 'error');
            setTimeout(() => {
                window.location.href = '/pages/dashboard.html';
            }, 2000);
        }
    } else {
        // No valid flow, redirect to dashboard
        window.location.href = '/pages/dashboard.html';
    }
}

// Set user information in the header
function setUserInfo() {
    const user = getCurrentUser();
    
    if (!user) return;
    
    const userNameElem = document.getElementById('userName');
    const userAvatarElem = document.getElementById('userAvatar');
    
    if (userNameElem) {
        userNameElem.textContent = user.name;
    }
    
    if (userAvatarElem) {
        userAvatarElem.textContent = user.avatar;
    }
}

// Setup the flow configuration page
function setupFlowConfigPage() {
    // Set page title
    const pageTitleElem = document.getElementById('pageTitle');
    if (pageTitleElem) {
        pageTitleElem.textContent = isNewFlow ? 'Create New Flow' : 'Edit Flow';
    }
    
    // Fill form fields with flow data
    const flowNameInput = document.getElementById('flowName');
    const flowDescriptionInput = document.getElementById('flowDescription');
    
    if (flowNameInput) {
        flowNameInput.value = currentFlow.name;
    }
    
    if (flowDescriptionInput) {
        flowDescriptionInput.value = currentFlow.description;
    }
    
    // Display applications
    renderApplications();
    
    // Setup add application button
    const addAppBtn = document.getElementById('addAppBtn');
    if (addAppBtn) {
        addAppBtn.addEventListener('click', addApplication);
    }
    
    // Setup save flow button
    const saveFlowBtn = document.getElementById('saveFlowBtn');
    if (saveFlowBtn) {
        saveFlowBtn.addEventListener('click', saveFlowConfig);
    }
    
    // Setup cancel button
    const cancelBtn = document.getElementById('cancelBtn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            window.location.href = '/pages/dashboard.html';
        });
    }
}

// Create an empty flow structure
function createEmptyFlow() {
    return {
        id: generateId(),
        name: '',
        description: '',
        applications: [],
        status: 'WAITING',
        created: new Date().toISOString(),
        lastUpdated: new Date().toISOString(),
        lastRun: null
    };
}

// Render applications
function renderApplications() {
    const appsContainerElem = document.getElementById('applicationsContainer');
    if (!appsContainerElem) return;
    
    if (currentFlow.applications.length === 0) {
        appsContainerElem.innerHTML = `
            <div class="empty-state">
                <p>No applications added yet. Add an application to get started.</p>
            </div>
        `;
        return;
    }
    
    appsContainerElem.innerHTML = currentFlow.applications.map((app, appIndex) => `
        <div class="card application-card" data-app-index="${appIndex}">
            <div class="card-header">
                <h3 class="card-title">Application #${appIndex + 1}: ${app.name}</h3>
                <button type="button" class="btn btn-danger remove-app-btn" data-app-index="${appIndex}">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
            <div class="form-section">
                <div class="form-row">
                    <div class="form-column">
                        <div class="form-group">
                            <label for="appName${appIndex}">Application Name</label>
                            <input type="text" id="appName${appIndex}" class="form-control app-name" value="${app.name}" required>
                        </div>
                    </div>
                    <div class="form-column">
                        <div class="form-group">
                            <label for="appToken${appIndex}">Access Token</label>
                            <input type="password" id="appToken${appIndex}" class="form-control app-token" value="${app.token}" required>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-column">
                        <div class="form-group">
                            <label for="appProjectId${appIndex}">Project ID</label>
                            <input type="text" id="appProjectId${appIndex}" class="form-control app-project-id" value="${app.projectId}" required>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="form-section">
                <h4 class="form-section-title">Pipelines</h4>
                <div class="pipeline-config-list" id="pipelinesList${appIndex}">
                    ${app.pipelines.map((pipeline, pipeIndex) => `
                        <div class="pipeline-config-item" data-pipe-index="${pipeIndex}">
                            <button type="button" class="remove-pipeline" data-app-index="${appIndex}" data-pipe-index="${pipeIndex}">
                                <i class="fas fa-times"></i>
                            </button>
                            <div class="form-row">
                                <div class="form-column">
                                    <div class="form-group">
                                        <label for="pipeName${appIndex}_${pipeIndex}">Pipeline Name</label>
                                        <input type="text" id="pipeName${appIndex}_${pipeIndex}" class="form-control pipe-name" value="${pipeline.name}" required>
                                    </div>
                                </div>
                                <div class="form-column">
                                    <div class="form-group">
                                        <label for="pipeBranch${appIndex}_${pipeIndex}">Branch</label>
                                        <input type="text" id="pipeBranch${appIndex}_${pipeIndex}" class="form-control pipe-branch" value="${pipeline.branch}" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-column">
                                    <div class="form-group">
                                        <label for="pipeOrder${appIndex}_${pipeIndex}">Execution Order</label>
                                        <input type="number" id="pipeOrder${appIndex}_${pipeIndex}" class="form-control pipe-order" value="${pipeIndex + 1}" min="1" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <button type="button" class="btn add-pipeline-btn" data-app-index="${appIndex}">
                    <i class="fas fa-plus"></i> Add Pipeline
                </button>
            </div>
        </div>
    `).join('');
    
    // Setup event listeners for application actions
    setupApplicationEventListeners();
}

// Setup event listeners for application actions
function setupApplicationEventListeners() {
    // Remove application buttons
    document.querySelectorAll('.remove-app-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const appIndex = parseInt(e.currentTarget.getAttribute('data-app-index'));
            removeApplication(appIndex);
        });
    });
    
    // Add pipeline buttons
    document.querySelectorAll('.add-pipeline-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const appIndex = parseInt(e.currentTarget.getAttribute('data-app-index'));
            addPipeline(appIndex);
        });
    });
    
    // Remove pipeline buttons
    document.querySelectorAll('.remove-pipeline').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const appIndex = parseInt(e.currentTarget.getAttribute('data-app-index'));
            const pipeIndex = parseInt(e.currentTarget.getAttribute('data-pipe-index'));
            removePipeline(appIndex, pipeIndex);
        });
    });
    
    // Listen for input changes
    document.querySelectorAll('.app-name, .app-token, .app-project-id').forEach(input => {
        input.addEventListener('change', updateAppData);
    });
    
    document.querySelectorAll('.pipe-name, .pipe-branch, .pipe-order').forEach(input => {
        input.addEventListener('change', updatePipelineData);
    });
}

// Add a new application
function addApplication() {
    currentFlow.applications.push({
        name: `New Application ${currentFlow.applications.length + 1}`,
        token: '',
        projectId: '',
        pipelines: []
    });
    
    renderApplications();
    showNotification('Application added', 'success');
}

// Remove an application
function removeApplication(appIndex) {
    if (confirm('Are you sure you want to remove this application?')) {
        currentFlow.applications.splice(appIndex, 1);
        renderApplications();
        showNotification('Application removed', 'success');
    }
}

// Add a new pipeline to an application
function addPipeline(appIndex) {
    const app = currentFlow.applications[appIndex];
    if (!app) return;
    
    app.pipelines.push({
        name: `Pipeline ${app.pipelines.length + 1}`,
        branch: 'main',
        status: 'WAITING'
    });
    
    renderApplications();
    showNotification('Pipeline added', 'success');
}

// Remove a pipeline from an application
function removePipeline(appIndex, pipeIndex) {
    const app = currentFlow.applications[appIndex];
    if (!app) return;
    
    app.pipelines.splice(pipeIndex, 1);
    renderApplications();
    showNotification('Pipeline removed', 'success');
}

// Update application data when input changes
function updateAppData(e) {
    const appCard = e.target.closest('.application-card');
    if (!appCard) return;
    
    const appIndex = parseInt(appCard.getAttribute('data-app-index'));
    const app = currentFlow.applications[appIndex];
    if (!app) return;
    
    if (e.target.classList.contains('app-name')) {
        app.name = e.target.value;
    } else if (e.target.classList.contains('app-token')) {
        app.token = e.target.value;
    } else if (e.target.classList.contains('app-project-id')) {
        app.projectId = e.target.value;
    }
}

// Update pipeline data when input changes
function updatePipelineData(e) {
    const pipelineItem = e.target.closest('.pipeline-config-item');
    if (!pipelineItem) return;
    
    const appCard = e.target.closest('.application-card');
    if (!appCard) return;
    
    const appIndex = parseInt(appCard.getAttribute('data-app-index'));
    const pipeIndex = parseInt(pipelineItem.getAttribute('data-pipe-index'));
    
    const app = currentFlow.applications[appIndex];
    if (!app) return;
    
    const pipeline = app.pipelines[pipeIndex];
    if (!pipeline) return;
    
    if (e.target.classList.contains('pipe-name')) {
        pipeline.name = e.target.value;
    } else if (e.target.classList.contains('pipe-branch')) {
        pipeline.branch = e.target.value;
    } else if (e.target.classList.contains('pipe-order')) {
        // Handle reordering of pipelines
        const newOrder = parseInt(e.target.value) - 1;
        if (newOrder !== pipeIndex && newOrder >= 0 && newOrder < app.pipelines.length) {
            const pipelineToMove = app.pipelines.splice(pipeIndex, 1)[0];
            app.pipelines.splice(newOrder, 0, pipelineToMove);
            renderApplications();
        }
    }
}

// Save flow configuration
function saveFlowConfig() {
    // Get and validate flow name
    const flowNameInput = document.getElementById('flowName');
    const flowDescriptionInput = document.getElementById('flowDescription');
    
    if (!flowNameInput.value.trim()) {
        showNotification('Flow name is required', 'error');
        flowNameInput.focus();
        return;
    }
    
    // Update flow data
    currentFlow.name = flowNameInput.value.trim();
    currentFlow.description = flowDescriptionInput.value.trim();
    currentFlow.lastUpdated = new Date().toISOString();
    
    // Validate applications
    if (currentFlow.applications.length === 0) {
        showNotification('Add at least one application', 'error');
        return;
    }
    
    for (const app of currentFlow.applications) {
        if (!app.name.trim() || !app.projectId.trim() || !app.token.trim()) {
            showNotification('All application fields are required', 'error');
            return;
        }
        
        if (app.pipelines.length === 0) {
            showNotification(`Add at least one pipeline to ${app.name}`, 'error');
            return;
        }
        
        for (const pipeline of app.pipelines) {
            if (!pipeline.name.trim() || !pipeline.branch.trim()) {
                showNotification('All pipeline fields are required', 'error');
                return;
            }
        }
    }
    
    // Save the flow
    if (isNewFlow) {
        saveFlow(currentFlow);
        showNotification('Flow created successfully', 'success');
    } else {
        updateFlow(currentFlow);
        showNotification('Flow updated successfully', 'success');
    }
    
    // Redirect to dashboard
    setTimeout(() => {
        window.location.href = '/pages/dashboard.html';
    }, 1000);
}

// Generate a random ID
function generateId() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}
