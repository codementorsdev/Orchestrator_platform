/**
 * Utility Module
 * 
 * Contains helper functions used throughout the application.
 */

// Generate a unique ID
export function generateUniqueId() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Format a date for display
export function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
}

// Check if a string is empty or only whitespace
export function isEmpty(str) {
    return !str || str.trim() === '';
}

// Validate email format
export function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Debounce function to limit how often a function can be called
export function debounce(func, wait) {
    let timeout;
    
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Create a DOM element with attributes and children
export function createElement(tag, attributes = {}, children = []) {
    const element = document.createElement(tag);
    
    // Set attributes
    Object.entries(attributes).forEach(([key, value]) => {
        if (key === 'className') {
            element.className = value;
        } else if (key === 'textContent') {
            element.textContent = value;
        } else {
            element.setAttribute(key, value);
        }
    });
    
    // Append children
    children.forEach(child => {
        if (typeof child === 'string') {
            element.appendChild(document.createTextNode(child));
        } else {
            element.appendChild(child);
        }
    });
    
    return element;
}

// Truncate a string to a specified length
export function truncateString(str, length = 100) {
    if (!str) return '';
    if (str.length <= length) return str;
    return str.substring(0, length) + '...';
}

// Toggle element visibility
export function toggleElementVisibility(element, isVisible) {
    if (!element) return;
    
    if (isVisible) {
        element.style.display = '';
    } else {
        element.style.display = 'none';
    }
}

// Get URL parameters
export function getUrlParams() {
    const params = {};
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    
    for (const [key, value] of urlParams.entries()) {
        params[key] = value;
    }
    
    return params;
}

// Deep clone an object
export function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}
