package com.gitlab.pipelineorchestrator.config;

import com.gitlab.pipelineorchestrator.dto.RegistrationRequest;
import com.gitlab.pipelineorchestrator.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * Initialize test data for development environment
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataInitializer {

    private final UserService userService;
    private final Environment environment;

    @Bean
    public CommandLineRunner initData() {
        return args -> {
            try {
                // Create test user if it doesn't exist
                if (userService.findByUsername("admin").isEmpty()) {
                    log.info("Creating test admin user");
                    RegistrationRequest testUser = new RegistrationRequest();
                    testUser.setName("Admin User");
                    testUser.setUsername("admin");
                    testUser.setEmail("admin@example.com");
                    testUser.setPassword("password123");
                    testUser.setConfirmPassword("password123");
                    userService.registerUser(testUser);
                    log.info("Test admin user created successfully");
                }
                
                // Create a regular test user if it doesn't exist
                if (userService.findByUsername("user").isEmpty()) {
                    log.info("Creating test regular user");
                    RegistrationRequest regularUser = new RegistrationRequest();
                    regularUser.setName("Test User");
                    regularUser.setUsername("user");
                    regularUser.setEmail("user@example.com");
                    regularUser.setPassword("password123");
                    regularUser.setConfirmPassword("password123");
                    userService.registerUser(regularUser);
                    log.info("Test regular user created successfully");
                }
                
            } catch (Exception e) {
                log.error("Error creating test users", e);
            }
        };
    }
}