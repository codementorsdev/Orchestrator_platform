package com.gitlab.pipelineorchestrator.controller;

import com.gitlab.pipelineorchestrator.dto.DashboardStats;
import com.gitlab.pipelineorchestrator.model.User;
import com.gitlab.pipelineorchestrator.service.FlowService;
import com.gitlab.pipelineorchestrator.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final FlowService flowService;
    private final UserService userService;

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        // Get the current user
        User user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Get dashboard statistics
        DashboardStats stats = flowService.getDashboardStats(user);
        
        // Get the user's flows
        model.addAttribute("flows", flowService.findByOwner(user));
        model.addAttribute("stats", stats);
        model.addAttribute("user", user);
        
        return "dashboard";
    }
}