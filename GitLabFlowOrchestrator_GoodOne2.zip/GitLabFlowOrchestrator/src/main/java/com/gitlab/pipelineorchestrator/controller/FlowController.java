package com.gitlab.pipelineorchestrator.controller;

import com.gitlab.pipelineorchestrator.model.Flow;
import com.gitlab.pipelineorchestrator.model.User;
import com.gitlab.pipelineorchestrator.service.FlowService;
import com.gitlab.pipelineorchestrator.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/flows")
@RequiredArgsConstructor
public class FlowController {

    private final FlowService flowService;
    private final UserService userService;

    @GetMapping("/new")
    public String createFlowForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        model.addAttribute("flow", new Flow());
        model.addAttribute("user", user);
        
        return "flow-form";
    }
    
    @GetMapping("/{id}/edit")
    public String editFlowForm(@PathVariable Long id, 
                               @AuthenticationPrincipal UserDetails userDetails,
                               Model model) {
        Flow flow = flowService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
        
        User user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Check if the flow belongs to the current user
        if (!flow.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You don't have permission to edit this flow");
        }
        
        model.addAttribute("flow", flow);
        model.addAttribute("user", user);
        
        return "flow-form";
    }
    
    @PostMapping("")
    public String createFlow(@Valid @ModelAttribute Flow flow,
                             BindingResult result,
                             @AuthenticationPrincipal UserDetails userDetails,
                             RedirectAttributes redirectAttributes,
                             Model model) {
        if (result.hasErrors()) {
            User user = userService.findByUsername(userDetails.getUsername())
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
            model.addAttribute("user", user);
            return "flow-form";
        }
        
        User owner = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        flowService.createFlow(flow, owner);
        redirectAttributes.addFlashAttribute("successMessage", "Flow created successfully");
        
        return "redirect:/dashboard";
    }
    
    @PostMapping("/{id}")
    public String updateFlow(@PathVariable Long id,
                             @Valid @ModelAttribute Flow flow,
                             BindingResult result,
                             @AuthenticationPrincipal UserDetails userDetails,
                             RedirectAttributes redirectAttributes,
                             Model model) {
        if (result.hasErrors()) {
            User user = userService.findByUsername(userDetails.getUsername())
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
            model.addAttribute("user", user);
            return "flow-form";
        }
        
        User user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Check if the flow belongs to the current user
        Flow existingFlow = flowService.findById(flow.getId())
                .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
        
        if (!existingFlow.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You don't have permission to update this flow");
        }
        
        flowService.updateFlow(flow);
        redirectAttributes.addFlashAttribute("successMessage", "Flow updated successfully");
        
        return "redirect:/dashboard";
    }
    
    @PostMapping("/{id}/run")
    public String runFlow(@PathVariable Long id,
                          @AuthenticationPrincipal UserDetails userDetails,
                          RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Check if the flow belongs to the current user
        Flow flow = flowService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
        
        if (!flow.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You don't have permission to run this flow");
        }
        
        flowService.runFlow(id);
        redirectAttributes.addFlashAttribute("successMessage", "Flow execution started");
        
        return "redirect:/dashboard";
    }
    
    @GetMapping("/{id}/delete")
    public String deleteFlow(@PathVariable Long id,
                             @AuthenticationPrincipal UserDetails userDetails,
                             RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Check if the flow belongs to the current user
        Flow flow = flowService.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
        
        if (!flow.getOwner().getId().equals(user.getId())) {
            throw new IllegalArgumentException("You don't have permission to delete this flow");
        }
        
        flowService.deleteFlow(id);
        redirectAttributes.addFlashAttribute("successMessage", "Flow deleted successfully");
        
        return "redirect:/dashboard";
    }
}