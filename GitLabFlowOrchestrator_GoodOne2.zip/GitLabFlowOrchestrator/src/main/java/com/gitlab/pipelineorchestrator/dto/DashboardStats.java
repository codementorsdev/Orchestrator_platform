package com.gitlab.pipelineorchestrator.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStats {
    private long totalFlows;
    private long activeFlows;
    private long pendingPipelines;
    private long totalPipelines;
    private long totalApplications;
    private int successRate;
}