package com.gitlab.pipelineorchestrator.repository;

import com.gitlab.pipelineorchestrator.model.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
}