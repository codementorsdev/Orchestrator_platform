package com.gitlab.pipelineorchestrator.repository;

import com.gitlab.pipelineorchestrator.model.Flow;
import com.gitlab.pipelineorchestrator.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FlowRepository extends JpaRepository<Flow, Long> {
    List<Flow> findByOwnerOrderByUpdatedAtDesc(User owner);
}