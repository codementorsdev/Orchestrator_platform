package com.gitlab.pipelineorchestrator.repository;

import com.gitlab.pipelineorchestrator.model.Pipeline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PipelineRepository extends JpaRepository<Pipeline, Long> {
    
    @Query("SELECT p FROM Pipeline p JOIN p.application a JOIN a.flow f " +
           "WHERE f.id = :flowId " +
           "ORDER BY a.executionOrder, p.executionOrder")
    List<Pipeline> findAllByFlowIdOrderByApplicationAndExecutionOrder(@Param("flowId") Long flowId);
}