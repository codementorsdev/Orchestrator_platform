package com.gitlab.pipelineorchestrator.service;

import com.gitlab.pipelineorchestrator.dto.DashboardStats;
import com.gitlab.pipelineorchestrator.model.Flow;
import com.gitlab.pipelineorchestrator.model.User;

import java.util.List;
import java.util.Optional;

public interface FlowService {
    List<Flow> findByOwner(User owner);
    Optional<Flow> findById(Long id);
    Flow createFlow(Flow flow, User owner);
    Flow updateFlow(Flow flow);
    void deleteFlow(Long id);
    DashboardStats getDashboardStats(User user);
    Flow runFlow(Long id);
    Flow getFlowStatus(Long id);
}