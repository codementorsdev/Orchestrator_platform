package com.gitlab.pipelineorchestrator.service;

import org.gitlab4j.api.models.Pipeline;

import java.util.Optional;

public interface GitLabService {
    boolean testConnection(String projectId, String accessToken);
    Integer triggerPipeline(String projectId, String branch, String accessToken);
    Optional<Pipeline> getPipelineStatus(String projectId, Integer pipelineId, String accessToken);
}