package com.gitlab.pipelineorchestrator.service;

import com.gitlab.pipelineorchestrator.dto.RegistrationRequest;
import com.gitlab.pipelineorchestrator.model.User;

import java.util.Optional;

public interface UserService {
    User registerUser(RegistrationRequest registrationRequest) throws Exception;
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    Optional<User> findById(Long id);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}