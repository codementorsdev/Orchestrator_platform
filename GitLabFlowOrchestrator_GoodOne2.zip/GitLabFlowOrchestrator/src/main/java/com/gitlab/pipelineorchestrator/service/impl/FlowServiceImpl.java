package com.gitlab.pipelineorchestrator.service.impl;

import com.gitlab.pipelineorchestrator.dto.DashboardStats;
import com.gitlab.pipelineorchestrator.model.Application;
import com.gitlab.pipelineorchestrator.model.Flow;
import com.gitlab.pipelineorchestrator.model.Pipeline;
import com.gitlab.pipelineorchestrator.model.User;
import com.gitlab.pipelineorchestrator.repository.FlowRepository;
import com.gitlab.pipelineorchestrator.repository.PipelineRepository;
import com.gitlab.pipelineorchestrator.service.FlowService;
import com.gitlab.pipelineorchestrator.service.GitLabService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FlowServiceImpl implements FlowService {

    private final FlowRepository flowRepository;
    private final PipelineRepository pipelineRepository;
    private final GitLabService gitLabService;

    @Override
    public List<Flow> findByOwner(User owner) {
        return flowRepository.findByOwnerOrderByUpdatedAtDesc(owner);
    }

    @Override
    public Optional<Flow> findById(Long id) {
        return flowRepository.findById(id);
    }

    @Override
    @Transactional
    public Flow createFlow(Flow flow, User owner) {
        flow.setOwner(owner);
        flow.setStatus(Flow.FlowStatus.WAITING);
        
        // Set bidirectional relationships
        if (flow.getApplications() != null) {
            for (Application app : flow.getApplications()) {
                app.setFlow(flow);
                
                if (app.getPipelines() != null) {
                    for (Pipeline pipeline : app.getPipelines()) {
                        pipeline.setApplication(app);
                        pipeline.setStatus(Pipeline.PipelineStatus.WAITING);
                    }
                }
            }
        }
        
        return flowRepository.save(flow);
    }

    @Override
    @Transactional
    public Flow updateFlow(Flow flow) {
        Flow existingFlow = flowRepository.findById(flow.getId())
                .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
        
        existingFlow.setName(flow.getName());
        existingFlow.setDescription(flow.getDescription());
        
        // Clear existing applications and add updated ones
        existingFlow.getApplications().clear();
        
        if (flow.getApplications() != null) {
            for (Application app : flow.getApplications()) {
                app.setFlow(existingFlow);
                existingFlow.getApplications().add(app);
                
                if (app.getPipelines() != null) {
                    for (Pipeline pipeline : app.getPipelines()) {
                        pipeline.setApplication(app);
                        pipeline.setStatus(Pipeline.PipelineStatus.WAITING);
                    }
                }
            }
        }
        
        return flowRepository.save(existingFlow);
    }

    @Override
    @Transactional
    public void deleteFlow(Long id) {
        flowRepository.deleteById(id);
    }

    @Override
    public DashboardStats getDashboardStats(User user) {
        List<Flow> userFlows = flowRepository.findByOwnerOrderByUpdatedAtDesc(user);
        
        long totalFlows = userFlows.size();
        long activeFlows = userFlows.stream()
                .filter(flow -> flow.getStatus() == Flow.FlowStatus.RUNNING)
                .count();
        
        long completedFlows = userFlows.stream()
                .filter(flow -> flow.getStatus() == Flow.FlowStatus.SUCCESS || 
                               flow.getStatus() == Flow.FlowStatus.FAILED)
                .count();
        
        long successFlows = userFlows.stream()
                .filter(flow -> flow.getStatus() == Flow.FlowStatus.SUCCESS)
                .count();
        
        int successRate = completedFlows > 0 
                ? (int) ((double) successFlows / completedFlows * 100) 
                : 0;
        
        long totalPipelines = userFlows.stream()
                .flatMap(flow -> flow.getApplications().stream())
                .flatMap(app -> app.getPipelines().stream())
                .count();

        long pendingPipelines = userFlows.stream()
                .flatMap(flow -> flow.getApplications().stream())
                .flatMap(app -> app.getPipelines().stream())
                .filter(pipeline -> pipeline.getStatus() == Pipeline.PipelineStatus.WAITING ||
                                   pipeline.getStatus() == Pipeline.PipelineStatus.RUNNING)
                .count();
        
        long totalApplications = userFlows.stream()
                .flatMap(flow -> flow.getApplications().stream())
                .count();
        
        return DashboardStats.builder()
                .totalFlows(totalFlows)
                .activeFlows(activeFlows)
                .pendingPipelines(pendingPipelines)
                .totalPipelines(totalPipelines)
                .totalApplications(totalApplications)
                .successRate(successRate)
                .build();
    }

    @Override
    @Transactional
    public Flow runFlow(Long id) {
        Flow flow = flowRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
        
        // Only run if the flow is not already running
        if (flow.getStatus() == Flow.FlowStatus.RUNNING) {
            return flow;
        }
        
        flow.setStatus(Flow.FlowStatus.RUNNING);
        flow.setLastRun(LocalDateTime.now());
        
        // Reset all pipeline statuses
        for (Application app : flow.getApplications()) {
            for (Pipeline pipeline : app.getPipelines()) {
                pipeline.setStatus(Pipeline.PipelineStatus.WAITING);
                pipeline.setGitlabPipelineId(null);
                pipeline.setStartedAt(null);
                pipeline.setCompletedAt(null);
            }
        }
        
        Flow savedFlow = flowRepository.save(flow);
        
        // Start the flow execution asynchronously
        executeFlow(savedFlow.getId());
        
        return savedFlow;
    }

    @Override
    public Flow getFlowStatus(Long id) {
        return flowRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
    }
    
    @Async
    @Transactional
    public void executeFlow(Long flowId) {
        try {
            Flow flow = flowRepository.findById(flowId)
                    .orElseThrow(() -> new IllegalArgumentException("Flow not found"));
            
            // Get all pipelines ordered by application and execution order
            List<Pipeline> allPipelines = pipelineRepository.findAllByFlowIdOrderByApplicationAndExecutionOrder(flowId);
            
            for (Pipeline pipeline : allPipelines) {
                try {
                    // Update pipeline status to running
                    pipeline.setStatus(Pipeline.PipelineStatus.RUNNING);
                    pipeline.setStartedAt(LocalDateTime.now());
                    pipelineRepository.save(pipeline);
                    
                    // Trigger GitLab pipeline
                    Application app = pipeline.getApplication();
                    Integer gitlabPipelineId = gitLabService.triggerPipeline(
                            app.getProjectId(),
                            pipeline.getBranch(),
                            app.getAccessToken()
                    );
                    
                    if (gitlabPipelineId == null) {
                        pipeline.setStatus(Pipeline.PipelineStatus.FAILED);
                        pipeline.setCompletedAt(LocalDateTime.now());
                        pipelineRepository.save(pipeline);
                        
                        flow.setStatus(Flow.FlowStatus.FAILED);
                        flowRepository.save(flow);
                        return;
                    }
                    
                    pipeline.setGitlabPipelineId(gitlabPipelineId);
                    pipelineRepository.save(pipeline);
                    
                    // Poll for pipeline status
                    boolean pipelineCompleted = false;
                    int maxRetries = 60; // 5 min timeout (5s * 60)
                    int retry = 0;
                    
                    while (!pipelineCompleted && retry < maxRetries) {
                        Thread.sleep(5000); // 5 second polling interval
                        
                        Optional<org.gitlab4j.api.models.Pipeline> gitlabPipeline = 
                                gitLabService.getPipelineStatus(app.getProjectId(), gitlabPipelineId, app.getAccessToken());
                        
                        if (gitlabPipeline.isPresent()) {
                            org.gitlab4j.api.models.PipelineStatus status = gitlabPipeline.get().getStatus();
                            String statusName = status != null ? status.toString() : "";
                            
                            if ("SUCCESS".equalsIgnoreCase(statusName)) {
                                pipeline.setStatus(Pipeline.PipelineStatus.SUCCESS);
                                pipeline.setCompletedAt(LocalDateTime.now());
                                pipelineRepository.save(pipeline);
                                pipelineCompleted = true;
                            } else if ("FAILED".equalsIgnoreCase(statusName) || 
                                      "CANCELED".equalsIgnoreCase(statusName)) {
                                pipeline.setStatus("FAILED".equalsIgnoreCase(statusName) 
                                        ? Pipeline.PipelineStatus.FAILED 
                                        : Pipeline.PipelineStatus.CANCELED);
                                pipeline.setCompletedAt(LocalDateTime.now());
                                pipelineRepository.save(pipeline);
                                
                                flow.setStatus(Flow.FlowStatus.FAILED);
                                flowRepository.save(flow);
                                return;
                            } else if ("SKIPPED".equalsIgnoreCase(statusName)) {
                                pipeline.setStatus(Pipeline.PipelineStatus.SKIPPED);
                                pipeline.setCompletedAt(LocalDateTime.now());
                                pipelineRepository.save(pipeline);
                                pipelineCompleted = true;
                            }
                        }
                        
                        retry++;
                    }
                    
                    // If we timed out waiting for the pipeline
                    if (!pipelineCompleted) {
                        pipeline.setStatus(Pipeline.PipelineStatus.FAILED);
                        pipeline.setCompletedAt(LocalDateTime.now());
                        pipelineRepository.save(pipeline);
                        
                        flow.setStatus(Flow.FlowStatus.FAILED);
                        flowRepository.save(flow);
                        return;
                    }
                    
                } catch (Exception e) {
                    log.error("Error executing pipeline", e);
                    pipeline.setStatus(Pipeline.PipelineStatus.FAILED);
                    pipeline.setCompletedAt(LocalDateTime.now());
                    pipelineRepository.save(pipeline);
                    
                    flow.setStatus(Flow.FlowStatus.FAILED);
                    flowRepository.save(flow);
                    return;
                }
            }
            
            // All pipelines completed successfully
            flow.setStatus(Flow.FlowStatus.SUCCESS);
            flowRepository.save(flow);
            
        } catch (Exception e) {
            log.error("Error executing flow", e);
            
            Flow flow = flowRepository.findById(flowId).orElse(null);
            if (flow != null) {
                flow.setStatus(Flow.FlowStatus.FAILED);
                flowRepository.save(flow);
            }
        }
    }
}