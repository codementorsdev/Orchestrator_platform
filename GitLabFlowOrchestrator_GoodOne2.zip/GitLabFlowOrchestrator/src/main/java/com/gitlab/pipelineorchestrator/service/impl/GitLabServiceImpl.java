package com.gitlab.pipelineorchestrator.service.impl;

import com.gitlab.pipelineorchestrator.service.GitLabService;
import lombok.extern.slf4j.Slf4j;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Pipeline;
import org.gitlab4j.api.models.Project;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class GitLabServiceImpl implements GitLabService {

    @Override
    public boolean testConnection(String projectId, String accessToken) {
        try {
            GitLabApi gitLabApi = new GitLabApi(GitLabApi.ApiVersion.V4, "https://gitlab.com", accessToken);
            Project project = gitLabApi.getProjectApi().getProject(projectId);
            return project != null;
        } catch (GitLabApiException e) {
            log.error("Failed to connect to GitLab", e);
            return false;
        }
    }

    @Override
    public Integer triggerPipeline(String projectId, String branch, String accessToken) {
        try {
            GitLabApi gitLabApi = new GitLabApi(GitLabApi.ApiVersion.V4, "https://gitlab.com", accessToken);
            Pipeline pipeline = gitLabApi.getPipelineApi().createPipeline(projectId, branch);
            return pipeline.getId().intValue();
        } catch (GitLabApiException e) {
            log.error("Failed to trigger pipeline", e);
            return null;
        }
    }

    @Override
    public Optional<Pipeline> getPipelineStatus(String projectId, Integer pipelineId, String accessToken) {
        try {
            GitLabApi gitLabApi = new GitLabApi(GitLabApi.ApiVersion.V4, "https://gitlab.com", accessToken);
            Pipeline pipeline = gitLabApi.getPipelineApi().getPipeline(projectId, pipelineId);
            return Optional.of(pipeline);
        } catch (GitLabApiException e) {
            log.error("Failed to get pipeline status", e);
            return Optional.empty();
        }
    }
}