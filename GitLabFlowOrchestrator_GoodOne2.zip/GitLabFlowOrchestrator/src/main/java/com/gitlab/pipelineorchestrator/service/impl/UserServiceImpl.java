package com.gitlab.pipelineorchestrator.service.impl;

import com.gitlab.pipelineorchestrator.dto.RegistrationRequest;
import com.gitlab.pipelineorchestrator.model.User;
import com.gitlab.pipelineorchestrator.repository.UserRepository;
import com.gitlab.pipelineorchestrator.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public User registerUser(RegistrationRequest registrationRequest) throws Exception {
        if (userRepository.existsByUsername(registrationRequest.getUsername())) {
            throw new Exception("Username already exists");
        }
        
        if (userRepository.existsByEmail(registrationRequest.getEmail())) {
            throw new Exception("Email already exists");
        }
        
        if (!registrationRequest.getPassword().equals(registrationRequest.getConfirmPassword())) {
            throw new Exception("Passwords do not match");
        }
        
        User user = new User();
        user.setUsername(registrationRequest.getUsername());
        user.setName(registrationRequest.getName());
        user.setEmail(registrationRequest.getEmail());
        user.setPassword(passwordEncoder.encode(registrationRequest.getPassword()));
        
        return userRepository.save(user);
    }

    @Override
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }

    @Override
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
}