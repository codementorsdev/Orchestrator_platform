// Authentication related functions

function initLoginForm() {
    const form = document.querySelector('form');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            // Form submission is handled by Spring Security
            // This is just for any additional client-side validation if needed
        });
    }
}

// Initialize the login form when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initLoginForm();
});