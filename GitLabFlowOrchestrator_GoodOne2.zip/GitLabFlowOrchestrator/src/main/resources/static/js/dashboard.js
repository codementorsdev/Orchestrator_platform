// Dashboard related functionality

function initDashboard() {
    setupStartFlowButtons();
    setupSidebar();
}

function setupStartFlowButtons() {
    const startFlowButtons = document.querySelectorAll('.start-flow-btn');
    
    startFlowButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const flowId = this.getAttribute('data-flow-id');
            
            if (flowId) {
                // Create a form to submit
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = `/flows/${flowId}/run`;
                
                // Add CSRF token if needed
                const csrfToken = document.querySelector('meta[name="_csrf"]');
                const csrfHeader = document.querySelector('meta[name="_csrf_header"]');
                
                if (csrfToken && csrfHeader) {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = csrfHeader.content;
                    input.value = csrfToken.content;
                    form.appendChild(input);
                }
                
                document.body.appendChild(form);
                form.submit();
            }
        });
    });
}

function setupSidebar() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.app-container').classList.toggle('sidebar-collapsed');
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initDashboard();
});