// Flow configuration functionality

function initFlowConfig() {
    setupAddApplication();
    setupAddPipeline();
    setupRemovePipeline();
    setupRemoveApplication();
    setupSidebar();
}

function setupAddApplication() {
    const addAppBtn = document.getElementById('addAppBtn');
    
    if (addAppBtn) {
        addAppBtn.addEventListener('click', function() {
            const appContainer = document.getElementById('applicationsContainer');
            const appCount = document.querySelectorAll('.app-card').length;
            
            // Create a template for a new application
            const appTemplate = `
                <div class="app-card" id="app-${appCount}">
                    <div class="app-header">
                        <h3 class="app-title">Application <span class="app-number">${appCount + 1}</span></h3>
                        <button type="button" class="btn-icon remove-app" data-index="${appCount}">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <div class="app-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="applications[${appCount}].name">Application Name</label>
                                <input type="text" id="applications${appCount}.name" name="applications[${appCount}].name" class="form-control app-name" placeholder="Enter application name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="applications[${appCount}].projectId">GitLab Project ID</label>
                                <input type="text" id="applications${appCount}.projectId" name="applications[${appCount}].projectId" class="form-control" placeholder="GitLab project ID" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="applications[${appCount}].accessToken">Access Token</label>
                                <input type="password" id="applications${appCount}.accessToken" name="applications[${appCount}].accessToken" class="form-control" placeholder="GitLab access token" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="applications[${appCount}].branch">Branch</label>
                                <input type="text" id="applications${appCount}.branch" name="applications[${appCount}].branch" class="form-control" placeholder="e.g. main" required>
                            </div>
                        </div>
                        
                        <div class="pipelines-section">
                            <div class="section-header">
                                <h4>Pipelines</h4>
                                <button type="button" class="btn btn-sm btn-outline add-pipeline" data-app-index="${appCount}">
                                    <i class="fas fa-plus"></i> Add Pipeline
                                </button>
                            </div>
                            
                            <div class="pipelines-container" id="pipelines-container-${appCount}">
                                <div class="empty-pipelines-message" style="display: block;">
                                    <p>No pipelines added yet. Click "Add Pipeline" to add one.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Insert the new application
            const emptyAppsMessage = document.querySelector('.empty-apps-message');
            if (emptyAppsMessage) {
                emptyAppsMessage.style.display = 'none';
            }
            
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = appTemplate;
            appContainer.appendChild(tempDiv.firstElementChild);
            
            // Refresh event listeners
            setupRemoveApplication();
            setupAddPipeline();
        });
    }
}

function setupAddPipeline() {
    document.querySelectorAll('.add-pipeline').forEach(button => {
        button.addEventListener('click', function() {
            const appIndex = this.getAttribute('data-app-index');
            const pipelineContainer = document.getElementById(`pipelines-container-${appIndex}`);
            const pipelineCount = pipelineContainer.querySelectorAll('.pipeline-item').length;
            
            // Create a template for a new pipeline
            const pipelineTemplate = `
                <div class="pipeline-item" id="app-${appIndex}-pipeline-${pipelineCount}">
                    <div class="pipeline-header">
                        <h5 class="pipeline-number">Pipeline <span>${pipelineCount + 1}</span></h5>
                        <button type="button" class="btn-icon remove-pipeline" data-app-index="${appIndex}" data-pipe-index="${pipelineCount}">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="applications[${appIndex}].pipelines[${pipelineCount}].name">Name</label>
                            <input type="text" id="applications${appIndex}.pipelines${pipelineCount}.name" name="applications[${appIndex}].pipelines[${pipelineCount}].name" class="form-control" placeholder="Pipeline name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="applications[${appIndex}].pipelines[${pipelineCount}].executionOrder">Execution Order</label>
                            <input type="number" id="applications${appIndex}.pipelines${pipelineCount}.executionOrder" name="applications[${appIndex}].pipelines[${pipelineCount}].executionOrder" class="form-control" min="1" value="${pipelineCount + 1}" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="applications[${appIndex}].pipelines[${pipelineCount}].variables">Variables (JSON)</label>
                        <textarea id="applications${appIndex}.pipelines${pipelineCount}.variables" name="applications[${appIndex}].pipelines[${pipelineCount}].variables" class="form-control" rows="2" placeholder='{"key": "value"}'></textarea>
                    </div>
                </div>
            `;
            
            // Hide empty message
            const emptyPipelinesMessage = pipelineContainer.querySelector('.empty-pipelines-message');
            if (emptyPipelinesMessage) {
                emptyPipelinesMessage.style.display = 'none';
            }
            
            // Add the pipeline
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = pipelineTemplate;
            pipelineContainer.appendChild(tempDiv.firstElementChild);
            
            // Refresh event listeners
            setupRemovePipeline();
        });
    });
}

function setupRemovePipeline() {
    document.querySelectorAll('.remove-pipeline').forEach(button => {
        button.addEventListener('click', function() {
            const appIndex = this.getAttribute('data-app-index');
            const pipeIndex = this.getAttribute('data-pipe-index');
            const pipelineItem = document.getElementById(`app-${appIndex}-pipeline-${pipeIndex}`);
            
            if (pipelineItem) {
                pipelineItem.remove();
                
                // Re-index remaining pipelines
                const pipelineContainer = document.getElementById(`pipelines-container-${appIndex}`);
                const remainingPipelines = pipelineContainer.querySelectorAll('.pipeline-item');
                
                if (remainingPipelines.length === 0) {
                    const emptyMessage = pipelineContainer.querySelector('.empty-pipelines-message');
                    if (emptyMessage) {
                        emptyMessage.style.display = 'block';
                    }
                } else {
                    // Update pipeline numbers and indices
                    remainingPipelines.forEach((pipeline, idx) => {
                        const numberSpan = pipeline.querySelector('.pipeline-number span');
                        if (numberSpan) {
                            numberSpan.textContent = idx + 1;
                        }
                        
                        // Update form field names
                        pipeline.querySelectorAll('input, textarea').forEach(input => {
                            const name = input.getAttribute('name');
                            if (name) {
                                const newName = name.replace(/pipelines\[\d+\]/, `pipelines[${idx}]`);
                                input.setAttribute('name', newName);
                            }
                        });
                    });
                }
            }
        });
    });
}

function setupRemoveApplication() {
    document.querySelectorAll('.remove-app').forEach(button => {
        button.addEventListener('click', function() {
            const appIndex = this.getAttribute('data-index');
            const appCard = document.getElementById(`app-${appIndex}`);
            
            if (appCard) {
                appCard.remove();
                
                // Re-index remaining applications
                const appContainer = document.getElementById('applicationsContainer');
                const remainingApps = appContainer.querySelectorAll('.app-card');
                
                if (remainingApps.length === 0) {
                    const emptyMessage = document.querySelector('.empty-apps-message');
                    if (emptyMessage) {
                        emptyMessage.style.display = 'block';
                    }
                } else {
                    // Update app numbers and indices
                    remainingApps.forEach((app, idx) => {
                        app.id = `app-${idx}`;
                        const numberSpan = app.querySelector('.app-number');
                        if (numberSpan) {
                            numberSpan.textContent = idx + 1;
                        }
                        
                        // Update buttons
                        const removeBtn = app.querySelector('.remove-app');
                        if (removeBtn) {
                            removeBtn.setAttribute('data-index', idx);
                        }
                        
                        const addPipelineBtn = app.querySelector('.add-pipeline');
                        if (addPipelineBtn) {
                            addPipelineBtn.setAttribute('data-app-index', idx);
                        }
                        
                        // Update pipeline container id
                        const pipelineContainer = app.querySelector('.pipelines-container');
                        if (pipelineContainer) {
                            pipelineContainer.id = `pipelines-container-${idx}`;
                        }
                        
                        // Update form field names for the app
                        app.querySelectorAll('input').forEach(input => {
                            const name = input.getAttribute('name');
                            if (name) {
                                const newName = name.replace(/applications\[\d+\]/, `applications[${idx}]`);
                                input.setAttribute('name', newName);
                            }
                        });
                        
                        // Update pipelines
                        const pipelines = app.querySelectorAll('.pipeline-item');
                        pipelines.forEach((pipeline, pipeIdx) => {
                            pipeline.id = `app-${idx}-pipeline-${pipeIdx}`;
                            
                            // Update remove buttons
                            const pipeRemoveBtn = pipeline.querySelector('.remove-pipeline');
                            if (pipeRemoveBtn) {
                                pipeRemoveBtn.setAttribute('data-app-index', idx);
                                pipeRemoveBtn.setAttribute('data-pipe-index', pipeIdx);
                            }
                            
                            // Update form field names for pipelines
                            pipeline.querySelectorAll('input, textarea').forEach(input => {
                                const name = input.getAttribute('name');
                                if (name) {
                                    const newName = name.replace(/applications\[\d+\]\.pipelines\[\d+\]/, `applications[${idx}].pipelines[${pipeIdx}]`);
                                    input.setAttribute('name', newName);
                                }
                            });
                        });
                    });
                }
            }
        });
    });
}

function setupSidebar() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.app-container').classList.toggle('sidebar-collapsed');
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initFlowConfig();
});