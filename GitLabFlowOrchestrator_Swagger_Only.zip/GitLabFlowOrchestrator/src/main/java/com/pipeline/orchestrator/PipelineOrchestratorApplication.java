package com.pipeline.orchestrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for the Pipeline Orchestrator.
 * This application orchestrates and monitors sequential GitLab pipeline executions.
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
public class PipelineOrchestratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(PipelineOrchestratorApplication.class, args);
    }
}
