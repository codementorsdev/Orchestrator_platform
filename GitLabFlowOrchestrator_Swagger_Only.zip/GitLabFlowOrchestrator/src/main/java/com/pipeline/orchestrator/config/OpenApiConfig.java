package com.pipeline.orchestrator.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Configuration for OpenAPI documentation.
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI pipelineOrchestratorOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Pipeline Orchestrator API")
                        .description("API for orchestrating and monitoring sequential GitLab pipeline executions across multiple applications")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("Pipeline Orchestrator Team")
                                .email("support@pipelineorchestrator.com"))
                        .license(new License()
                                .name("Apache 2.0")
                                .url("https://www.apache.org/licenses/LICENSE-2.0")))
                .servers(List.of(
                        new Server()
                                .url("http://localhost:5000")
                                .description("Local development server")
                ));
    }
}
