package com.pipeline.orchestrator.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * Configuration for webhook settings.
 */
@Component
@Configuration
public class WebhookConfig {

    @Value("${app.webhook.global-secret:changeit}")
    private String globalWebhookSecret;
    
    @Value("${app.webhook.verify-gitlab-token:true}")
    private boolean verifyGitlabToken;
    
    @Value("${app.webhook.verify-gitlab-url:true}")
    private boolean verifyGitlabUrl;

    /**
     * Gets the global webhook secret.
     *
     * @return The global webhook secret
     */
    public String getGlobalWebhookSecret() {
        return globalWebhookSecret;
    }

    /**
     * Checks if GitLab token verification is enabled.
     *
     * @return True if GitLab token verification is enabled
     */
    public boolean isVerifyGitlabToken() {
        return verifyGitlabToken;
    }

    /**
     * Checks if GitLab URL verification is enabled.
     *
     * @return True if GitLab URL verification is enabled
     */
    public boolean isVerifyGitlabUrl() {
        return verifyGitlabUrl;
    }
}