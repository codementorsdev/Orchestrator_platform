package com.pipeline.orchestrator.controller;

import com.pipeline.orchestrator.model.Application;
import com.pipeline.orchestrator.service.ApplicationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing Application entities.
 */
@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
@Tag(name = "Application", description = "Application management endpoints")
public class ApplicationController {

    private final ApplicationService applicationService;

    @GetMapping
    @Operation(summary = "Get all applications", description = "Retrieves a list of all defined applications")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of applications"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<Application>> getAllApplications() {
        return ResponseEntity.ok(applicationService.getAllApplications());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get application by ID", description = "Retrieves a specific application by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved the application"),
        @ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<Application> getApplicationById(
            @Parameter(description = "ID of the application to retrieve", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(applicationService.getApplicationById(id));
    }

    @PostMapping
    @Operation(summary = "Create a new application", description = "Creates a new application with the provided details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Application created successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<Application> createApplication(
            @Parameter(description = "Application object to be created", required = true, schema = @Schema(implementation = Application.class))
            @Valid @RequestBody Application application) {
        return new ResponseEntity<>(applicationService.createApplication(application), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an application", description = "Updates an existing application with the provided details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Application updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<Application> updateApplication(
            @Parameter(description = "ID of the application to update", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated application object", required = true, schema = @Schema(implementation = Application.class))
            @Valid @RequestBody Application application) {
        return ResponseEntity.ok(applicationService.updateApplication(id, application));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an application", description = "Deletes an application with the specified ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Application deleted successfully"),
        @ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<Void> deleteApplication(
            @Parameter(description = "ID of the application to delete", required = true)
            @PathVariable Long id) {
        applicationService.deleteApplication(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/name/{name}")
    @Operation(summary = "Get application by name", description = "Retrieves a specific application by its name")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved the application"),
        @ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<Application> getApplicationByName(
            @Parameter(description = "Name of the application to retrieve", required = true)
            @PathVariable String name) {
        return ResponseEntity.ok(applicationService.getApplicationByName(name));
    }

    @GetMapping("/search")
    @Operation(summary = "Search applications", description = "Searches for applications by name containing the given string")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of applications")
    })
    public ResponseEntity<List<Application>> searchApplications(
            @Parameter(description = "Name fragment to search for", required = true)
            @RequestParam String name) {
        return ResponseEntity.ok(applicationService.searchApplications(name));
    }
}
