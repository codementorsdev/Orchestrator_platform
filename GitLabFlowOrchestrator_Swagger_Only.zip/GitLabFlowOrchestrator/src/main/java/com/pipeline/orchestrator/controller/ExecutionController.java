package com.pipeline.orchestrator.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.pipeline.orchestrator.config.WebhookConfig;
import com.pipeline.orchestrator.dto.ExecutionMetricsDTO;
import com.pipeline.orchestrator.model.ExecutionMetrics;
import com.pipeline.orchestrator.model.Flow;
import com.pipeline.orchestrator.model.Pipeline;
import com.pipeline.orchestrator.service.ExecutionService;
import com.pipeline.orchestrator.service.FlowService;
import com.pipeline.orchestrator.service.PipelineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * REST controller for handling pipeline execution metrics.
 */
@RestController
@RequestMapping("/api/executions")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Execution", description = "Pipeline execution metrics endpoints")
public class ExecutionController {

    private final ExecutionService executionService;
    private final PipelineService pipelineService;
    private final FlowService flowService;
    private final WebhookConfig webhookConfig;
    private final ObjectMapper objectMapper;

    @PostMapping("/metrics")
    @Operation(summary = "Record execution metrics", description = "Records pipeline execution metrics and forwards payload to the next pipeline in sequence if any")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Metrics recorded successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<ExecutionMetrics> recordMetrics(
            @Parameter(description = "Pipeline ID", required = true)
            @RequestParam Long pipelineId,
            @Parameter(description = "Execution metrics payload", required = true, schema = @Schema(implementation = ExecutionMetricsDTO.class))
            @Valid @RequestBody ExecutionMetricsDTO metrics) {
        return new ResponseEntity<>(executionService.recordMetrics(pipelineId, metrics), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all execution metrics", description = "Retrieves all pipeline execution metrics")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of execution metrics"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<ExecutionMetrics>> getAllExecutionMetrics() {
        return ResponseEntity.ok(executionService.getAllExecutionMetrics());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get execution metrics by ID", description = "Retrieves specific execution metrics by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved execution metrics"),
        @ApiResponse(responseCode = "404", description = "Execution metrics not found")
    })
    public ResponseEntity<ExecutionMetrics> getExecutionMetricsById(
            @Parameter(description = "ID of the execution metrics to retrieve", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(executionService.getExecutionMetricsById(id));
    }

    @GetMapping("/pipeline/{pipelineId}")
    @Operation(summary = "Get execution metrics by pipeline ID", description = "Retrieves execution metrics for a specific pipeline")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of execution metrics"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<List<ExecutionMetrics>> getExecutionMetricsByPipelineId(
            @Parameter(description = "ID of the pipeline", required = true)
            @PathVariable Long pipelineId) {
        return ResponseEntity.ok(executionService.getExecutionMetricsByPipelineId(pipelineId));
    }

    @GetMapping("/flow/{flowId}")
    @Operation(summary = "Get execution metrics by flow ID", description = "Retrieves execution metrics for a specific flow")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of execution metrics"),
        @ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<List<ExecutionMetrics>> getExecutionMetricsByFlowId(
            @Parameter(description = "ID of the flow", required = true)
            @PathVariable Long flowId) {
        return ResponseEntity.ok(executionService.getExecutionMetricsByFlowId(flowId));
    }

    @GetMapping("/app/{appId}")
    @Operation(summary = "Get execution metrics by app ID", description = "Retrieves execution metrics for a specific application by its app ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of execution metrics")
    })
    public ResponseEntity<List<ExecutionMetrics>> getExecutionMetricsByAppId(
            @Parameter(description = "ID of the application", required = true)
            @PathVariable String appId) {
        return ResponseEntity.ok(executionService.getExecutionMetricsByAppId(appId));
    }

    @GetMapping("/date-range")
    @Operation(summary = "Get execution metrics by date range", description = "Retrieves execution metrics created within a specified date range")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of execution metrics"),
        @ApiResponse(responseCode = "400", description = "Invalid date format")
    })
    public ResponseEntity<List<ExecutionMetrics>> getExecutionMetricsByDateRange(
            @Parameter(description = "Start date (format: yyyy-MM-dd'T'HH:mm:ss)", required = true)
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @Parameter(description = "End date (format: yyyy-MM-dd'T'HH:mm:ss)", required = true)
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        return ResponseEntity.ok(executionService.getExecutionMetricsByDateRange(startDate, endDate));
    }
    
    @PostMapping("/test/webhook")
    @Operation(summary = "Test GitLab webhook", description = "Sends a simulated webhook payload to test pipeline execution handling")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Test webhook processed successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<String> testGitLabWebhook(
            @Parameter(description = "Pipeline ID", required = true)
            @RequestParam Long pipelineId,
            @Parameter(description = "Pipeline status (success, failed, cancelled, running, pending, skipped)", required = true)
            @RequestParam String status) {
        
        log.info("Processing test webhook for pipeline ID: {} with status: {}", pipelineId, status);
        
        try {
            // Get the pipeline
            Pipeline pipeline = pipelineService.getPipelineById(pipelineId);
            
            // Generate a test GitLab pipeline ID if one doesn't exist
            Long gitlabPipelineId = pipeline.getGitlabPipelineId();
            if (gitlabPipelineId == null) {
                gitlabPipelineId = 100000L + pipelineId; // Just a dummy ID for testing
                pipeline.setGitlabPipelineId(gitlabPipelineId);
                pipelineService.updatePipeline(pipelineId, pipeline);
            }
            
            // Create a basic test payload with the requested status
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode objectAttrNode = objectMapper.createObjectNode();
            objectAttrNode.put("id", gitlabPipelineId);
            objectAttrNode.put("status", status);
            
            ObjectNode projectNode = objectMapper.createObjectNode();
            projectNode.put("id", pipeline.getApplication().getProjectId());
            projectNode.put("name", pipeline.getApplication().getName());
            projectNode.put("web_url", pipeline.getGitlabInstanceUrl() + "/" + pipeline.getApplication().getProjectId());
            
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("object_kind", "pipeline");
            payload.set("object_attributes", objectAttrNode);
            payload.set("project", projectNode);
            
            // Create a test request to the webhook endpoint
            return handleGitLabWebhook(gitlabPipelineId, pipelineId, null, payload);
            
        } catch (Exception e) {
            log.error("Error processing test webhook", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing test webhook: " + e.getMessage());
        }
    }
    
    @PostMapping("/webhook/gitlab")
    @Operation(summary = "GitLab webhook endpoint", description = "Receives pipeline status updates from GitLab via webhook")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Webhook processed successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid webhook payload"),
        @ApiResponse(responseCode = "401", description = "Unauthorized webhook request"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<String> handleGitLabWebhook(
            @Parameter(description = "GitLab pipeline ID", required = true)
            @RequestParam Long gitlabPipelineId,
            @Parameter(description = "Pipeline orchestrator pipeline ID", required = true)
            @RequestParam Long pipelineId,
            @Parameter(description = "GitLab webhook secret token", required = false)
            @RequestHeader(value = "X-Gitlab-Token", required = false) String secretToken,
            @Parameter(description = "GitLab webhook payload", required = true)
            @RequestBody JsonNode payload) {
        
        log.info("Received GitLab webhook for pipelineId: {}, gitlabPipelineId: {}", pipelineId, gitlabPipelineId);
        
        try {
            // Get the pipeline
            Pipeline pipeline = pipelineService.getPipelineById(pipelineId);
            
            // Verify webhook secret token if required
            if (webhookConfig.isVerifyGitlabToken()) {
                // First check application-specific token
                String appToken = pipeline.getApplication().getAccessToken();
                String expectedToken = (appToken != null && !appToken.isEmpty()) 
                    ? appToken 
                    : webhookConfig.getGlobalWebhookSecret();
                
                if (secretToken == null || !secretToken.equals(expectedToken)) {
                    log.error("Invalid webhook token");
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid webhook token");
                }
            }
            
            // Verify GitLab instance URL matches if required
            if (webhookConfig.isVerifyGitlabUrl()) {
                String gitlabUrl = payload.path("project").path("web_url").asText();
                if (gitlabUrl != null && !gitlabUrl.isEmpty() && 
                    !gitlabUrl.startsWith(pipeline.getGitlabInstanceUrl())) {
                    log.error("GitLab instance URL mismatch: expected {}, got {}", 
                            pipeline.getGitlabInstanceUrl(), gitlabUrl);
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("GitLab instance URL mismatch");
                }
            }
            
            // Get the pipeline status from the webhook payload
            String status = payload.path("object_attributes").path("status").asText();
            log.info("GitLab pipeline status: {}", status);
            
            // Verify pipeline matches
            if (pipeline.getGitlabPipelineId() == null || !pipeline.getGitlabPipelineId().equals(gitlabPipelineId)) {
                log.error("GitLab pipeline ID mismatch: expected {}, got {}", 
                        pipeline.getGitlabPipelineId(), gitlabPipelineId);
                return ResponseEntity.badRequest().body("GitLab pipeline ID mismatch");
            }
            
            // Map GitLab status to our pipeline status
            Pipeline.ExecutionStatus pipelineStatus;
            switch (status) {
                case "success":
                    pipelineStatus = Pipeline.ExecutionStatus.SUCCESS;
                    break;
                case "failed":
                    pipelineStatus = Pipeline.ExecutionStatus.FAILED;
                    break;
                case "canceled":
                    pipelineStatus = Pipeline.ExecutionStatus.CANCELLED;
                    break;
                case "running":
                    pipelineStatus = Pipeline.ExecutionStatus.RUNNING;
                    break;
                case "pending":
                    pipelineStatus = Pipeline.ExecutionStatus.PENDING;
                    break;
                case "skipped":
                    pipelineStatus = Pipeline.ExecutionStatus.SKIPPED;
                    break;
                default:
                    log.warn("Unknown GitLab pipeline status: {}, defaulting to FAILED", status);
                    pipelineStatus = Pipeline.ExecutionStatus.FAILED;
            }
            
            // Update the pipeline status
            pipelineService.updatePipelineStatus(pipelineId, pipelineStatus);
            
            // Process successful execution if needed
            if (pipelineStatus == Pipeline.ExecutionStatus.SUCCESS) {
                // Create a basic execution metrics DTO with just the custom data from GitLab
                ExecutionMetricsDTO metricsDTO = ExecutionMetricsDTO.builder()
                        .appId(pipeline.getApplication().getProjectId())
                        .appName(pipeline.getApplication().getName())
                        .appDescription(pipeline.getApplication().getDescription())
                        .customData(payload)
                        .build();
                
                // Record metrics and trigger next pipeline in sequence if any
                ExecutionMetrics savedMetrics = executionService.recordMetrics(pipelineId, metricsDTO);
                log.info("Successfully processed metrics for pipeline: {}", pipelineId);
                
                // Check if this is the last pipeline in the flow
                if (pipeline.getFlow() != null) {
                    Pipeline nextPipeline = pipelineService.findNextPipeline(
                            pipeline.getFlow().getId(), 
                            pipeline.getExecutionSequence()
                    );
                    
                    if (nextPipeline == null) {
                        // This was the last pipeline, check if the flow can be completed
                        executionService.completeFlowExecution(pipeline.getFlow().getId());
                    }
                }
            } else if (pipelineStatus == Pipeline.ExecutionStatus.FAILED || 
                       pipelineStatus == Pipeline.ExecutionStatus.CANCELLED || 
                       pipelineStatus == Pipeline.ExecutionStatus.SKIPPED) {
                // If the flow exists, update its status to failed
                if (pipeline.getFlow() != null) {
                    log.warn("Pipeline {} failed or was cancelled, marking flow {} as failed", 
                            pipelineId, pipeline.getFlow().getId());
                    flowService.updateFlowStatus(pipeline.getFlow().getId(), 
                            pipelineStatus == Pipeline.ExecutionStatus.FAILED ? Flow.ExecutionStatus.FAILED : 
                            pipelineStatus == Pipeline.ExecutionStatus.CANCELLED ? Flow.ExecutionStatus.CANCELLED : 
                            Flow.ExecutionStatus.FAILED);
                }
            }
            
            return ResponseEntity.ok("Webhook processed successfully");
            
        } catch (Exception e) {
            log.error("Error processing GitLab webhook", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing webhook: " + e.getMessage());
        }
    }
}
