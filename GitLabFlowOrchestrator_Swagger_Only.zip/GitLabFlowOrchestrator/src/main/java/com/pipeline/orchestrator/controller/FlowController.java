package com.pipeline.orchestrator.controller;

import com.pipeline.orchestrator.model.Flow;
import com.pipeline.orchestrator.service.FlowService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing Flow entities.
 */
@RestController
@RequestMapping("/api/flows")
@RequiredArgsConstructor
@Tag(name = "Flow", description = "Flow management endpoints")
public class FlowController {

    private final FlowService flowService;

    @GetMapping
    @Operation(summary = "Get all flows", description = "Retrieves a list of all defined flows")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of flows"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<Flow>> getAllFlows() {
        return ResponseEntity.ok(flowService.getAllFlows());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get flow by ID", description = "Retrieves a specific flow by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved the flow"),
        @ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<Flow> getFlowById(
            @Parameter(description = "ID of the flow to retrieve", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(flowService.getFlowById(id));
    }

    @PostMapping
    @Operation(summary = "Create a new flow", description = "Creates a new flow with the provided details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Flow created successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<Flow> createFlow(
            @Parameter(description = "Flow object to be created", required = true, schema = @Schema(implementation = Flow.class))
            @Valid @RequestBody Flow flow) {
        return new ResponseEntity<>(flowService.createFlow(flow), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a flow", description = "Updates an existing flow with the provided details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Flow updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<Flow> updateFlow(
            @Parameter(description = "ID of the flow to update", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated flow object", required = true, schema = @Schema(implementation = Flow.class))
            @Valid @RequestBody Flow flow) {
        return ResponseEntity.ok(flowService.updateFlow(id, flow));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a flow", description = "Deletes a flow with the specified ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Flow deleted successfully"),
        @ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<Void> deleteFlow(
            @Parameter(description = "ID of the flow to delete", required = true)
            @PathVariable Long id) {
        flowService.deleteFlow(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/trigger")
    @Operation(summary = "Trigger a flow execution", description = "Starts the execution of a flow by triggering the first pipeline in the sequence")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "202", description = "Flow execution triggered successfully"),
        @ApiResponse(responseCode = "404", description = "Flow not found or no pipelines configured"),
        @ApiResponse(responseCode = "500", description = "Error triggering flow execution")
    })
    public ResponseEntity<String> triggerFlow(
            @Parameter(description = "ID of the flow to trigger", required = true)
            @PathVariable Long id) {
        flowService.triggerFlow(id);
        return new ResponseEntity<>("Flow execution triggered successfully", HttpStatus.ACCEPTED);
    }

    @GetMapping("/status/{status}")
    @Operation(summary = "Get flows by status", description = "Retrieves flows with a specific execution status")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of flows"),
        @ApiResponse(responseCode = "400", description = "Invalid status value")
    })
    public ResponseEntity<List<Flow>> getFlowsByStatus(
            @Parameter(description = "Status to filter by", required = true)
            @PathVariable Flow.ExecutionStatus status) {
        return ResponseEntity.ok(flowService.getFlowsByStatus(status));
    }

    @PostMapping("/{id}/cancel")
    @Operation(summary = "Cancel a flow execution", description = "Cancels the execution of an in-progress flow")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Flow execution cancelled successfully"),
        @ApiResponse(responseCode = "400", description = "Flow is not in progress"),
        @ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<String> cancelFlow(
            @Parameter(description = "ID of the flow to cancel", required = true)
            @PathVariable Long id) {
        flowService.cancelFlow(id);
        return ResponseEntity.ok("Flow execution cancelled successfully");
    }
}
