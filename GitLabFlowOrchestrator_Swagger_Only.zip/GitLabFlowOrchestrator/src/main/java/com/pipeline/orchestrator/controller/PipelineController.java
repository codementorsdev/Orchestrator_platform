package com.pipeline.orchestrator.controller;

import com.pipeline.orchestrator.dto.PipelineCreateDTO;
import com.pipeline.orchestrator.model.Application;
import com.pipeline.orchestrator.model.Flow;
import com.pipeline.orchestrator.model.Pipeline;
import com.pipeline.orchestrator.service.ApplicationService;
import com.pipeline.orchestrator.service.FlowService;
import com.pipeline.orchestrator.service.PipelineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing Pipeline entities.
 */
@RestController
@RequestMapping("/api/pipelines")
@RequiredArgsConstructor
@Tag(name = "Pipeline", description = "Pipeline management endpoints")
public class PipelineController {

    private final PipelineService pipelineService;
    private final FlowService flowService;
    private final ApplicationService applicationService;

    @GetMapping
    @Operation(summary = "Get all pipelines", description = "Retrieves a list of all defined pipelines")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of pipelines"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<Pipeline>> getAllPipelines() {
        return ResponseEntity.ok(pipelineService.getAllPipelines());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get pipeline by ID", description = "Retrieves a specific pipeline by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved the pipeline"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<Pipeline> getPipelineById(
            @Parameter(description = "ID of the pipeline to retrieve", required = true)
            @PathVariable Long id) {
        return ResponseEntity.ok(pipelineService.getPipelineById(id));
    }

    @PostMapping
    @Operation(summary = "Create a new pipeline", description = "Creates a new pipeline with the provided details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Pipeline created successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<Pipeline> createPipeline(
            @Parameter(description = "Pipeline object to be created", required = true, schema = @Schema(implementation = PipelineCreateDTO.class))
            @Valid @RequestBody PipelineCreateDTO pipelineDTO) {
        
        // Create new pipeline instance and set basic properties
        Pipeline pipeline = new Pipeline();
        pipeline.setName(pipelineDTO.getName());
        pipeline.setDescription(pipelineDTO.getDescription());
        pipeline.setBranch(pipelineDTO.getBranch());
        pipeline.setExecutionSequence(pipelineDTO.getExecutionSequence());
        pipeline.setGitlabInstanceUrl(pipelineDTO.getGitlabInstanceUrl());
        pipeline.setGitlabPipelineId(pipelineDTO.getGitlabPipelineId());
        
        // Set flow if provided
        if (pipelineDTO.getFlowId() != null) {
            Flow flow = flowService.getFlowById(pipelineDTO.getFlowId());
            pipeline.setFlow(flow);
        }
        
        // Set application if provided
        if (pipelineDTO.getApplicationId() != null) {
            Application application = applicationService.getApplicationById(pipelineDTO.getApplicationId());
            pipeline.setApplication(application);
        }
        
        return new ResponseEntity<>(pipelineService.createPipeline(pipeline), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a pipeline", description = "Updates an existing pipeline with the provided details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Pipeline updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<Pipeline> updatePipeline(
            @Parameter(description = "ID of the pipeline to update", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated pipeline object", required = true, schema = @Schema(implementation = PipelineCreateDTO.class))
            @Valid @RequestBody PipelineCreateDTO pipelineDTO) {
        
        // Get existing pipeline
        Pipeline existingPipeline = pipelineService.getPipelineById(id);
        
        // Update basic properties
        existingPipeline.setName(pipelineDTO.getName());
        existingPipeline.setDescription(pipelineDTO.getDescription());
        existingPipeline.setBranch(pipelineDTO.getBranch());
        existingPipeline.setExecutionSequence(pipelineDTO.getExecutionSequence());
        existingPipeline.setGitlabInstanceUrl(pipelineDTO.getGitlabInstanceUrl());
        
        // Update GitLab Pipeline ID if provided
        if (pipelineDTO.getGitlabPipelineId() != null) {
            existingPipeline.setGitlabPipelineId(pipelineDTO.getGitlabPipelineId());
        }
        
        // Update flow if provided
        if (pipelineDTO.getFlowId() != null) {
            Flow flow = flowService.getFlowById(pipelineDTO.getFlowId());
            existingPipeline.setFlow(flow);
        } else {
            existingPipeline.setFlow(null);
        }
        
        // Update application if provided
        if (pipelineDTO.getApplicationId() != null) {
            Application application = applicationService.getApplicationById(pipelineDTO.getApplicationId());
            existingPipeline.setApplication(application);
        } else {
            existingPipeline.setApplication(null);
        }
        
        return ResponseEntity.ok(pipelineService.updatePipeline(id, existingPipeline));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a pipeline", description = "Deletes a pipeline with the specified ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Pipeline deleted successfully"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<Void> deletePipeline(
            @Parameter(description = "ID of the pipeline to delete", required = true)
            @PathVariable Long id) {
        pipelineService.deletePipeline(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/flow/{flowId}")
    @Operation(summary = "Get pipelines by flow ID", description = "Retrieves all pipelines associated with a specific flow")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of pipelines"),
        @ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<List<Pipeline>> getPipelinesByFlowId(
            @Parameter(description = "ID of the flow", required = true)
            @PathVariable Long flowId) {
        return ResponseEntity.ok(pipelineService.getPipelinesByFlowId(flowId));
    }

    @GetMapping("/application/{applicationId}")
    @Operation(summary = "Get pipelines by application ID", description = "Retrieves all pipelines linked to a specific application")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list of pipelines"),
        @ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<List<Pipeline>> getPipelinesByApplicationId(
            @Parameter(description = "ID of the application", required = true)
            @PathVariable Long applicationId) {
        return ResponseEntity.ok(pipelineService.getPipelinesByApplicationId(applicationId));
    }

    @PostMapping("/{id}/trigger")
    @Operation(summary = "Trigger a pipeline execution", description = "Triggers the execution of a specific pipeline in GitLab")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "202", description = "Pipeline execution triggered successfully"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found"),
        @ApiResponse(responseCode = "500", description = "Error triggering pipeline execution")
    })
    public ResponseEntity<String> triggerPipeline(
            @Parameter(description = "ID of the pipeline to trigger", required = true)
            @PathVariable Long id) {
        pipelineService.triggerPipeline(id);
        return new ResponseEntity<>("Pipeline execution triggered successfully", HttpStatus.ACCEPTED);
    }
    
    @PostMapping("/{id}/set-gitlab-pipeline-id")
    @Operation(summary = "Set GitLab pipeline ID", description = "Sets the GitLab pipeline ID for a specific pipeline")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "GitLab pipeline ID set successfully"),
        @ApiResponse(responseCode = "404", description = "Pipeline not found"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<Pipeline> setGitLabPipelineId(
            @Parameter(description = "ID of the pipeline", required = true)
            @PathVariable Long id,
            @Parameter(description = "GitLab pipeline ID", required = true)
            @RequestParam Long gitlabPipelineId) {
        
        Pipeline pipeline = pipelineService.getPipelineById(id);
        pipeline.setGitlabPipelineId(gitlabPipelineId);
        return ResponseEntity.ok(pipelineService.updatePipeline(id, pipeline));
    }
}
