package com.pipeline.orchestrator.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * DTO for receiving execution metrics from pipeline executions.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExecutionMetricsDTO {

    private String appId;
    private String appName;
    private String appDescription;
    private List<TestSuiteDTO> suites;
    private JsonNode customData;

    /**
     * DTO for test suite data.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TestSuiteDTO {
        private String name;
        private String description;
        private List<String> tags;
        private Long startTime;
        private Long endTime;
        private Map<String, TestDTO> tests;
    }

    /**
     * DTO for test data.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TestDTO {
        private String name;
        private String description;
        private List<String> tags;
        private Long startTime;
        private Long endTime;
        private List<LogDTO> logs;
    }

    /**
     * DTO for log data.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LogDTO {
        private String message;
        private String status;
    }
}
