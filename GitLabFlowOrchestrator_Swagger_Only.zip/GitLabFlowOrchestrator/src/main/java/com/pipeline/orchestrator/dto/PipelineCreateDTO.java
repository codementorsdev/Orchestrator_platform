package com.pipeline.orchestrator.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for creating pipeline entities.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PipelineCreateDTO {

    @NotBlank(message = "Name is required")
    private String name;
    
    private String description;
    
    @NotBlank(message = "Branch is required")
    private String branch;
    
    @NotNull(message = "Execution sequence is required")
    private Integer executionSequence;
    
    @NotBlank(message = "GitLab instance URL is required")
    private String gitlabInstanceUrl;
    
    private Long flowId;
    
    private Long applicationId;
    
    private Long gitlabPipelineId;
}