package com.pipeline.orchestrator.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity representing an application linked to one or more pipelines.
 */
@Entity
@Table(name = "applications")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name;

    @Column(length = 1000)
    private String description;

    @Column(name = "project_id", nullable = false)
    private String projectId;

    @Column(name = "access_token", nullable = false)
    private String accessToken;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "application", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference(value = "application-pipeline")
    private List<Pipeline> pipelines = new ArrayList<>();

    /**
     * Add a pipeline to this application.
     * This method ensures the bidirectional relationship is maintained.
     *
     * @param pipeline The pipeline to add to this application
     */
    public void addPipeline(Pipeline pipeline) {
        pipelines.add(pipeline);
        pipeline.setApplication(this);
    }

    /**
     * Remove a pipeline from this application.
     * This method ensures the bidirectional relationship is maintained.
     *
     * @param pipeline The pipeline to remove from this application
     */
    public void removePipeline(Pipeline pipeline) {
        pipelines.remove(pipeline);
        pipeline.setApplication(null);
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
