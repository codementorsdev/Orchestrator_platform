package com.pipeline.orchestrator.model;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity for storing execution metrics received from pipeline executions.
 */
@Entity
@Table(name = "execution_metrics")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExecutionMetrics {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "app_name", nullable = false)
    private String appName;

    @Column(name = "app_description", length = 1000)
    private String appDescription;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "execution_time")
    private LocalDateTime executionTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pipeline_id")
    private Pipeline pipeline;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flow_id")
    private Flow flow;

    @Column(name = "forwarded_to_pipeline_id")
    private Long forwardedToPipelineId;

    @Column(name = "forwarded_at")
    private LocalDateTime forwardedAt;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "execution_metrics_id")
    private List<TestSuite> suites = new ArrayList<>();

    @Column(name = "custom_data", columnDefinition = "json")
    @JdbcTypeCode(SqlTypes.JSON)
    private JsonNode customData;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        executionTime = LocalDateTime.now();
    }
}
