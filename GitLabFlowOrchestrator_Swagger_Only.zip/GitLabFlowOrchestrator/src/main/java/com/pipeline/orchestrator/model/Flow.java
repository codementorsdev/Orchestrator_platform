package com.pipeline.orchestrator.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity representing a flow of pipeline executions.
 * A flow contains multiple pipelines that need to be executed sequentially.
 */
@Entity
@Table(name = "flows")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Flow {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(length = 1000)
    private String description;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "is_active")
    private boolean active;

    @Column(name = "execution_status")
    @Enumerated(EnumType.STRING)
    private ExecutionStatus status;

    @OneToMany(mappedBy = "flow", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference(value = "flow-pipeline")
    private List<Pipeline> pipelines = new ArrayList<>();

    /**
     * Add a pipeline to this flow.
     * This method ensures the bidirectional relationship is maintained.
     *
     * @param pipeline The pipeline to add to this flow
     */
    public void addPipeline(Pipeline pipeline) {
        pipelines.add(pipeline);
        pipeline.setFlow(this);
    }

    /**
     * Remove a pipeline from this flow.
     * This method ensures the bidirectional relationship is maintained.
     *
     * @param pipeline The pipeline to remove from this flow
     */
    public void removePipeline(Pipeline pipeline) {
        pipelines.remove(pipeline);
        pipeline.setFlow(null);
    }

    /**
     * Status of flow execution.
     */
    public enum ExecutionStatus {
        NOT_STARTED,
        IN_PROGRESS,
        COMPLETED,
        FAILED,
        CANCELLED
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (status == null) {
            status = ExecutionStatus.NOT_STARTED;
        }
        active = true;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
