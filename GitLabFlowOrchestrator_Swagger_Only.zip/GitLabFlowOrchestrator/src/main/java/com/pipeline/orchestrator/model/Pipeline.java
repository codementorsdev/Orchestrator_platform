package com.pipeline.orchestrator.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Entity representing a pipeline configuration for GitLab.
 */
@Entity
@Table(name = "pipelines")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Pipeline {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private String branch;

    @Column(name = "execution_sequence", nullable = false)
    private Integer executionSequence;

    @Column(name = "gitlab_instance_url", nullable = false)
    private String gitlabInstanceUrl;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flow_id")
    @JsonBackReference(value = "flow-pipeline")
    private Flow flow;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id")
    @JsonBackReference(value = "application-pipeline")
    private Application application;

    @Column(name = "last_execution_status")
    @Enumerated(EnumType.STRING)
    private ExecutionStatus lastExecutionStatus;

    @Column(name = "last_execution_time")
    private LocalDateTime lastExecutionTime;

    @Column(name = "gitlab_pipeline_id")
    private Long gitlabPipelineId;

    /**
     * Status of pipeline execution.
     */
    public enum ExecutionStatus {
        NOT_STARTED,
        PENDING,
        RUNNING,
        SUCCESS,
        FAILED,
        CANCELLED,
        SKIPPED
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        lastExecutionStatus = ExecutionStatus.NOT_STARTED;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
