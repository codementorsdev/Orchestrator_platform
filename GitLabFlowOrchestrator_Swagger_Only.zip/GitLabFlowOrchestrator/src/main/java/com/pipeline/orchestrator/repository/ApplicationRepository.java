package com.pipeline.orchestrator.repository;

import com.pipeline.orchestrator.model.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Application entity.
 */
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {

    /**
     * Finds an application by its name.
     *
     * @param name The name of the application
     * @return The application, if found
     */
    Optional<Application> findByName(String name);

    /**
     * Finds applications by name containing the given string (case-insensitive).
     *
     * @param name The name fragment to search for
     * @return List of applications with names containing the given string
     */
    List<Application> findByNameContainingIgnoreCase(String name);

    /**
     * Finds applications by project ID.
     *
     * @param projectId The GitLab project ID
     * @return List of applications with the given project ID
     */
    List<Application> findByProjectId(String projectId);
}
