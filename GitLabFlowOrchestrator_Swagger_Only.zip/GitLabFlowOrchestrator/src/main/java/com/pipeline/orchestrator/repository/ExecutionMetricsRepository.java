package com.pipeline.orchestrator.repository;

import com.pipeline.orchestrator.model.ExecutionMetrics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Repository interface for ExecutionMetrics entity.
 */
@Repository
public interface ExecutionMetricsRepository extends JpaRepository<ExecutionMetrics, Long> {

    /**
     * Finds execution metrics for a specific pipeline.
     *
     * @param pipelineId The ID of the pipeline
     * @return List of execution metrics for the pipeline
     */
    List<ExecutionMetrics> findByPipelineId(Long pipelineId);

    /**
     * Finds execution metrics for a specific flow.
     *
     * @param flowId The ID of the flow
     * @return List of execution metrics for the flow
     */
    List<ExecutionMetrics> findByFlowId(Long flowId);

    /**
     * Finds execution metrics for a specific application by app ID.
     *
     * @param appId The ID of the application
     * @return List of execution metrics for the application
     */
    List<ExecutionMetrics> findByAppId(String appId);

    /**
     * Finds the latest execution metrics for a specific pipeline.
     *
     * @param pipelineId The ID of the pipeline
     * @return The most recent execution metrics for the pipeline, if any
     */
    @Query("SELECT em FROM ExecutionMetrics em WHERE em.pipeline.id = :pipelineId ORDER BY em.executionTime DESC")
    List<ExecutionMetrics> findLatestByPipelineId(@Param("pipelineId") Long pipelineId);

    /**
     * Finds execution metrics created within a time range.
     *
     * @param startTime The start of the time range
     * @param endTime The end of the time range
     * @return List of execution metrics created within the time range
     */
    List<ExecutionMetrics> findByCreatedAtBetween(LocalDateTime startTime, LocalDateTime endTime);
}
