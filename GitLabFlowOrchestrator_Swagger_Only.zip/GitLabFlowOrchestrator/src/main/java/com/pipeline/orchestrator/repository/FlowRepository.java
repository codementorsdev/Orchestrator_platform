package com.pipeline.orchestrator.repository;

import com.pipeline.orchestrator.model.Flow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for Flow entity.
 */
@Repository
public interface FlowRepository extends JpaRepository<Flow, Long> {

    /**
     * Finds all active flows.
     *
     * @return List of active flows
     */
    List<Flow> findByActiveTrue();

    /**
     * Finds flows by status.
     *
     * @param status The execution status to filter by
     * @return List of flows with the given status
     */
    List<Flow> findByStatus(Flow.ExecutionStatus status);

    /**
     * Finds flows by name containing the given string (case-insensitive).
     *
     * @param name The name fragment to search for
     * @return List of flows with names containing the given string
     */
    List<Flow> findByNameContainingIgnoreCase(String name);

    /**
     * Finds flows that are in progress.
     *
     * @return List of flows with in progress status
     */
    @Query("SELECT f FROM Flow f WHERE f.status = 'IN_PROGRESS' AND f.active = true")
    List<Flow> findInProgressFlows();
}
