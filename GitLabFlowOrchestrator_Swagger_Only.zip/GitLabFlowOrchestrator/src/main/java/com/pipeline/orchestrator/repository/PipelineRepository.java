package com.pipeline.orchestrator.repository;

import com.pipeline.orchestrator.model.Pipeline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Pipeline entity.
 */
@Repository
public interface PipelineRepository extends JpaRepository<Pipeline, Long> {

    /**
     * Finds all pipelines belonging to a flow, ordered by execution sequence.
     *
     * @param flowId The ID of the flow
     * @return List of pipelines belonging to the flow
     */
    @Query("SELECT p FROM Pipeline p WHERE p.flow.id = :flowId ORDER BY p.executionSequence")
    List<Pipeline> findByFlowIdOrderByExecutionSequence(@Param("flowId") Long flowId);

    /**
     * Finds all pipelines linked to an application.
     *
     * @param applicationId The ID of the application
     * @return List of pipelines linked to the application
     */
    List<Pipeline> findByApplicationId(Long applicationId);

    /**
     * Finds the next pipeline to execute in a flow.
     *
     * @param flowId The ID of the flow
     * @param currentSequence The execution sequence of the current pipeline
     * @return The next pipeline in the sequence, if any
     */
    @Query("SELECT p FROM Pipeline p WHERE p.flow.id = :flowId AND p.executionSequence > :currentSequence ORDER BY p.executionSequence ASC")
    List<Pipeline> findNextPipelineInFlow(@Param("flowId") Long flowId, @Param("currentSequence") Integer currentSequence);

    /**
     * Finds the first pipeline in a flow's execution sequence.
     *
     * @param flowId The ID of the flow
     * @return The first pipeline in the sequence, if any
     */
    Optional<Pipeline> findFirstByFlowIdOrderByExecutionSequenceAsc(Long flowId);
}
