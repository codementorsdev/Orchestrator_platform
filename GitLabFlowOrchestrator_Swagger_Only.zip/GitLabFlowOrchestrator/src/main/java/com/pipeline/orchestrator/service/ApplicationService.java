package com.pipeline.orchestrator.service;

import com.pipeline.orchestrator.model.Application;
import com.pipeline.orchestrator.repository.ApplicationRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Service class for managing Application entities.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicationRepository applicationRepository;

    /**
     * Retrieves all applications.
     *
     * @return List of all applications
     */
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    /**
     * Retrieves an application by its ID.
     *
     * @param id The ID of the application to retrieve
     * @return The requested application
     * @throws EntityNotFoundException if the application is not found
     */
    public Application getApplicationById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Application not found with id: " + id));
    }

    /**
     * Creates a new application.
     *
     * @param application The application to create
     * @return The created application
     */
    @Transactional
    public Application createApplication(Application application) {
        log.info("Creating new application: {}", application.getName());
        return applicationRepository.save(application);
    }

    /**
     * Updates an existing application.
     *
     * @param id The ID of the application to update
     * @param applicationDetails The updated application details
     * @return The updated application
     * @throws EntityNotFoundException if the application is not found
     */
    @Transactional
    public Application updateApplication(Long id, Application applicationDetails) {
        Application application = getApplicationById(id);
        
        application.setName(applicationDetails.getName());
        application.setDescription(applicationDetails.getDescription());
        application.setProjectId(applicationDetails.getProjectId());
        application.setAccessToken(applicationDetails.getAccessToken());
        
        log.info("Updating application with id: {}", id);
        return applicationRepository.save(application);
    }

    /**
     * Deletes an application.
     *
     * @param id The ID of the application to delete
     * @throws EntityNotFoundException if the application is not found
     */
    @Transactional
    public void deleteApplication(Long id) {
        Application application = getApplicationById(id);
        
        log.info("Deleting application with id: {}", id);
        applicationRepository.delete(application);
    }

    /**
     * Retrieves an application by its name.
     *
     * @param name The name of the application to retrieve
     * @return The requested application
     * @throws EntityNotFoundException if the application is not found
     */
    public Application getApplicationByName(String name) {
        return applicationRepository.findByName(name)
                .orElseThrow(() -> new EntityNotFoundException("Application not found with name: " + name));
    }

    /**
     * Searches for applications by name.
     *
     * @param name The name fragment to search for
     * @return List of applications with names containing the given string
     */
    public List<Application> searchApplications(String name) {
        return applicationRepository.findByNameContainingIgnoreCase(name);
    }
}
