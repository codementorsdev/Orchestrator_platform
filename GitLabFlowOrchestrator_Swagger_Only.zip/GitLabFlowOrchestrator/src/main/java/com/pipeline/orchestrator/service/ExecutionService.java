package com.pipeline.orchestrator.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.pipeline.orchestrator.dto.ExecutionMetricsDTO;
import com.pipeline.orchestrator.model.*;
import com.pipeline.orchestrator.repository.ExecutionMetricsRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Service class for managing execution metrics and pipeline orchestration.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ExecutionService {

    private final ExecutionMetricsRepository executionMetricsRepository;
    private final PipelineService pipelineService;
    private final FlowService flowService;
    private final GitLabService gitLabService;

    /**
     * Records execution metrics for a pipeline and forwards payload to the next pipeline in sequence if any.
     *
     * @param pipelineId The ID of the pipeline that generated the metrics
     * @param metricsDTO The execution metrics data
     * @return The saved execution metrics
     * @throws EntityNotFoundException if the pipeline is not found
     */
    @Transactional
    public ExecutionMetrics recordMetrics(Long pipelineId, ExecutionMetricsDTO metricsDTO) {
        // Get the pipeline that generated these metrics
        Pipeline pipeline = pipelineService.getPipelineById(pipelineId);
        
        // Mark the pipeline as successfully completed
        pipelineService.updatePipelineStatus(pipelineId, Pipeline.ExecutionStatus.SUCCESS);
        
        // Create and save execution metrics
        ExecutionMetrics metrics = mapDtoToEntity(metricsDTO);
        metrics.setPipeline(pipeline);
        
        // If the pipeline belongs to a flow, set the flow reference and check for next pipeline
        if (pipeline.getFlow() != null) {
            metrics.setFlow(pipeline.getFlow());
            
            // Find the next pipeline in the flow's sequence
            Pipeline nextPipeline = pipelineService.findNextPipeline(
                    pipeline.getFlow().getId(), 
                    pipeline.getExecutionSequence()
            );
            
            // Save the metrics first to get an ID
            ExecutionMetrics savedMetrics = executionMetricsRepository.save(metrics);
            
            if (nextPipeline != null) {
                // Forward the metrics payload to the next pipeline
                forwardPayloadToNextPipeline(nextPipeline, metricsDTO.getCustomData());
                
                // Record that the metrics were forwarded
                savedMetrics.setForwardedToPipelineId(nextPipeline.getId());
                savedMetrics.setForwardedAt(LocalDateTime.now());
                savedMetrics = executionMetricsRepository.save(savedMetrics);
            } else {
                // This was the last pipeline in the flow
                flowService.updateFlowStatus(pipeline.getFlow().getId(), Flow.ExecutionStatus.COMPLETED);
            }
            
            return savedMetrics;
        } else {
            // Pipeline is not part of a flow
            return executionMetricsRepository.save(metrics);
        }
    }

    /**
     * Forwards payload to the next pipeline in the sequence.
     *
     * @param nextPipeline The next pipeline to trigger
     * @param payload The payload to forward
     */
    private void forwardPayloadToNextPipeline(Pipeline nextPipeline, JsonNode payload) {
        try {
            // Mark the next pipeline as pending
            pipelineService.updatePipelineStatus(nextPipeline.getId(), Pipeline.ExecutionStatus.PENDING);
            
            // Get the application linked to the next pipeline
            Application application = nextPipeline.getApplication();
            if (application == null) {
                throw new IllegalStateException("Next pipeline is not linked to an application");
            }
            
            // Forward the payload to the next pipeline
            Long gitlabPipelineId = gitLabService.forwardPayloadToPipeline(
                    nextPipeline.getGitlabInstanceUrl(),
                    application.getProjectId(),
                    application.getAccessToken(),
                    nextPipeline.getBranch(),
                    payload
            );
            
            // Update the pipeline with the GitLab pipeline ID
            nextPipeline.setGitlabPipelineId(gitlabPipelineId);
            nextPipeline.setLastExecutionStatus(Pipeline.ExecutionStatus.RUNNING);
            nextPipeline.setLastExecutionTime(LocalDateTime.now());
            
            log.info("Forwarded payload to next pipeline id: {} (gitlabPipelineId: {})", 
                    nextPipeline.getId(), gitlabPipelineId);
        } catch (Exception e) {
            // Mark the next pipeline and flow as failed
            pipelineService.updatePipelineStatus(nextPipeline.getId(), Pipeline.ExecutionStatus.FAILED);
            if (nextPipeline.getFlow() != null) {
                flowService.updateFlowStatus(nextPipeline.getFlow().getId(), Flow.ExecutionStatus.FAILED);
            }
            
            log.error("Failed to forward payload to next pipeline id: {}", nextPipeline.getId(), e);
            throw new RuntimeException("Failed to forward payload to next pipeline: " + e.getMessage(), e);
        }
    }

    /**
     * Maps an ExecutionMetricsDTO to an ExecutionMetrics entity.
     *
     * @param dto The DTO to map
     * @return The mapped entity
     */
    private ExecutionMetrics mapDtoToEntity(ExecutionMetricsDTO dto) {
        ExecutionMetrics metrics = new ExecutionMetrics();
        metrics.setAppId(dto.getAppId());
        metrics.setAppName(dto.getAppName());
        metrics.setAppDescription(dto.getAppDescription());
        metrics.setCustomData(dto.getCustomData());
        
        // Map test suites
        List<TestSuite> suites = new ArrayList<>();
        if (dto.getSuites() != null) {
            for (ExecutionMetricsDTO.TestSuiteDTO suiteDTO : dto.getSuites()) {
                TestSuite suite = new TestSuite();
                suite.setName(suiteDTO.getName());
                suite.setDescription(suiteDTO.getDescription());
                suite.setTags(suiteDTO.getTags());
                suite.setStartTime(suiteDTO.getStartTime());
                suite.setEndTime(suiteDTO.getEndTime());
                
                // Map tests
                List<Test> tests = new ArrayList<>();
                if (suiteDTO.getTests() != null) {
                    suiteDTO.getTests().forEach((testKey, testDTO) -> {
                        Test test = new Test();
                        test.setName(testDTO.getName());
                        test.setDescription(testDTO.getDescription());
                        test.setTags(testDTO.getTags());
                        test.setStartTime(testDTO.getStartTime());
                        test.setEndTime(testDTO.getEndTime());
                        
                        // Map logs
                        List<Log> logs = new ArrayList<>();
                        if (testDTO.getLogs() != null) {
                            for (ExecutionMetricsDTO.LogDTO logDTO : testDTO.getLogs()) {
                                Log log = new Log();
                                log.setMessage(logDTO.getMessage());
                                log.setStatus(Log.LogStatus.valueOf(logDTO.getStatus()));
                                logs.add(log);
                            }
                        }
                        test.setLogs(logs);
                        tests.add(test);
                    });
                }
                suite.setTests(tests);
                suites.add(suite);
            }
        }
        metrics.setSuites(suites);
        
        return metrics;
    }

    /**
     * Retrieves all execution metrics.
     *
     * @return List of all execution metrics
     */
    public List<ExecutionMetrics> getAllExecutionMetrics() {
        return executionMetricsRepository.findAll();
    }

    /**
     * Retrieves execution metrics by ID.
     *
     * @param id The ID of the execution metrics to retrieve
     * @return The requested execution metrics
     * @throws EntityNotFoundException if the execution metrics are not found
     */
    public ExecutionMetrics getExecutionMetricsById(Long id) {
        return executionMetricsRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Execution metrics not found with id: " + id));
    }

    /**
     * Retrieves execution metrics for a specific pipeline.
     *
     * @param pipelineId The ID of the pipeline
     * @return List of execution metrics for the pipeline
     */
    public List<ExecutionMetrics> getExecutionMetricsByPipelineId(Long pipelineId) {
        // Verify pipeline exists
        pipelineService.getPipelineById(pipelineId);
        
        return executionMetricsRepository.findByPipelineId(pipelineId);
    }

    /**
     * Retrieves execution metrics for a specific flow.
     *
     * @param flowId The ID of the flow
     * @return List of execution metrics for the flow
     */
    public List<ExecutionMetrics> getExecutionMetricsByFlowId(Long flowId) {
        // Verify flow exists
        flowService.getFlowById(flowId);
        
        return executionMetricsRepository.findByFlowId(flowId);
    }

    /**
     * Retrieves execution metrics for a specific application by app ID.
     *
     * @param appId The ID of the application
     * @return List of execution metrics for the application
     */
    public List<ExecutionMetrics> getExecutionMetricsByAppId(String appId) {
        return executionMetricsRepository.findByAppId(appId);
    }

    /**
     * Retrieves execution metrics created within a time range.
     *
     * @param startDate The start of the time range
     * @param endDate The end of the time range
     * @return List of execution metrics created within the time range
     */
    public List<ExecutionMetrics> getExecutionMetricsByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return executionMetricsRepository.findByCreatedAtBetween(startDate, endDate);
    }
    
    /**
     * Updates a flow's status to completed when all pipelines have been executed successfully.
     *
     * @param flowId The ID of the flow to update
     */
    @Transactional
    public void completeFlowExecution(Long flowId) {
        Flow flow = flowService.getFlowById(flowId);
        
        // Check if this is really the last pipeline
        List<Pipeline> pipelines = pipelineService.getPipelinesByFlowId(flowId);
        boolean allCompleted = true;
        
        for (Pipeline p : pipelines) {
            if (p.getLastExecutionStatus() != Pipeline.ExecutionStatus.SUCCESS &&
                p.getLastExecutionStatus() != Pipeline.ExecutionStatus.SKIPPED) {
                allCompleted = false;
                break;
            }
        }
        
        if (allCompleted) {
            flowService.updateFlowStatus(flowId, Flow.ExecutionStatus.COMPLETED);
            log.info("Flow execution completed successfully: {}", flowId);
        } else {
            log.warn("Not all pipelines in flow {} have completed successfully", flowId);
        }
    }
}
