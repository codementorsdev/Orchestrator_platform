package com.pipeline.orchestrator.service;

import com.pipeline.orchestrator.model.Flow;
import com.pipeline.orchestrator.model.Pipeline;
import com.pipeline.orchestrator.repository.FlowRepository;
import com.pipeline.orchestrator.repository.PipelineRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service class for managing Flow entities.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class FlowService {

    private final FlowRepository flowRepository;
    private final PipelineRepository pipelineRepository;
    private final PipelineService pipelineService;

    /**
     * Retrieves all flows.
     *
     * @return List of all flows
     */
    public List<Flow> getAllFlows() {
        return flowRepository.findAll();
    }

    /**
     * Retrieves a flow by its ID.
     *
     * @param id The ID of the flow to retrieve
     * @return The requested flow
     * @throws EntityNotFoundException if the flow is not found
     */
    public Flow getFlowById(Long id) {
        return flowRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Flow not found with id: " + id));
    }

    /**
     * Creates a new flow.
     *
     * @param flow The flow to create
     * @return The created flow
     */
    @Transactional
    public Flow createFlow(Flow flow) {
        log.info("Creating new flow: {}", flow.getName());
        return flowRepository.save(flow);
    }

    /**
     * Updates an existing flow.
     *
     * @param id The ID of the flow to update
     * @param flowDetails The updated flow details
     * @return The updated flow
     * @throws EntityNotFoundException if the flow is not found
     */
    @Transactional
    public Flow updateFlow(Long id, Flow flowDetails) {
        Flow flow = getFlowById(id);
        
        flow.setName(flowDetails.getName());
        flow.setDescription(flowDetails.getDescription());
        flow.setActive(flowDetails.isActive());
        
        log.info("Updating flow with id: {}", id);
        return flowRepository.save(flow);
    }

    /**
     * Deletes a flow.
     *
     * @param id The ID of the flow to delete
     * @throws EntityNotFoundException if the flow is not found
     */
    @Transactional
    public void deleteFlow(Long id) {
        Flow flow = getFlowById(id);
        
        if (flow.getStatus() == Flow.ExecutionStatus.IN_PROGRESS) {
            throw new IllegalStateException("Cannot delete a flow that is currently in progress");
        }
        
        log.info("Deleting flow with id: {}", id);
        flowRepository.delete(flow);
    }

    /**
     * Retrieves flows by status.
     *
     * @param status The execution status to filter by
     * @return List of flows with the given status
     */
    public List<Flow> getFlowsByStatus(Flow.ExecutionStatus status) {
        return flowRepository.findByStatus(status);
    }

    /**
     * Triggers the execution of a flow by starting the first pipeline in the sequence.
     *
     * @param id The ID of the flow to trigger
     * @throws EntityNotFoundException if the flow is not found
     * @throws IllegalStateException if the flow has no pipelines or is already in progress
     */
    @Transactional
    public void triggerFlow(Long id) {
        Flow flow = getFlowById(id);
        
        if (flow.getStatus() == Flow.ExecutionStatus.IN_PROGRESS) {
            throw new IllegalStateException("Flow is already in progress");
        }
        
        Optional<Pipeline> firstPipeline = pipelineRepository.findFirstByFlowIdOrderByExecutionSequenceAsc(id);
        
        if (firstPipeline.isEmpty()) {
            throw new IllegalStateException("Flow has no pipelines configured");
        }
        
        flow.setStatus(Flow.ExecutionStatus.IN_PROGRESS);
        flowRepository.save(flow);
        
        log.info("Triggering execution of flow id: {} with first pipeline id: {}", id, firstPipeline.get().getId());
        pipelineService.triggerPipeline(firstPipeline.get().getId());
    }

    /**
     * Cancels the execution of a flow.
     *
     * @param id The ID of the flow to cancel
     * @throws EntityNotFoundException if the flow is not found
     * @throws IllegalStateException if the flow is not in progress
     */
    @Transactional
    public void cancelFlow(Long id) {
        Flow flow = getFlowById(id);
        
        if (flow.getStatus() != Flow.ExecutionStatus.IN_PROGRESS) {
            throw new IllegalStateException("Flow is not in progress");
        }
        
        flow.setStatus(Flow.ExecutionStatus.CANCELLED);
        flowRepository.save(flow);
        
        log.info("Cancelled execution of flow id: {}", id);
    }

    /**
     * Updates a flow's status after pipeline execution.
     *
     * @param flowId The ID of the flow to update
     * @param status The new status
     */
    @Transactional
    public void updateFlowStatus(Long flowId, Flow.ExecutionStatus status) {
        Flow flow = getFlowById(flowId);
        flow.setStatus(status);
        flowRepository.save(flow);
        
        log.info("Updated flow id: {} with status: {}", flowId, status);
    }
}
