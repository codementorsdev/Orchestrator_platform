package com.pipeline.orchestrator.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.PipelineApi;
import org.gitlab4j.api.models.Pipeline;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Service class for interacting with GitLab API.
 * 
 * This service provides methods to:
 * 1. Trigger pipelines in GitLab projects
 * 2. Check pipeline status
 * 3. Forward execution metrics to subsequent pipelines
 * 
 * WebHook Configuration:
 * To set up GitLab webhooks for automatic pipeline status updates:
 * 1. In GitLab, go to your project settings -> Webhooks
 * 2. Set URL to: [your-api-host]/api/executions/webhook/gitlab?gitlabPipelineId=${CI_PIPELINE_ID}&pipelineId=[pipeline-id]
 * 3. Select Pipeline events trigger
 * 4. Optional: Set a secret token for additional security
 * 5. Add webhook
 * 
 * The webhook payload will be processed by the ExecutionController which will:
 * - Update the pipeline status in the orchestrator
 * - Record execution metrics for successful pipelines
 * - Trigger the next pipeline in the sequence (if any)
 * - Update the flow status based on the pipeline result
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class GitLabService {

    private final ObjectMapper objectMapper;
    private final Map<String, GitLabApi> gitLabApiCache = new HashMap<>();

    /**
     * Triggers a pipeline in GitLab.
     *
     * @param gitlabInstanceUrl The URL of the GitLab instance
     * @param projectId The ID of the GitLab project
     * @param accessToken The access token for GitLab API
     * @param branch The branch to run the pipeline on
     * @return The ID of the created GitLab pipeline
     * @throws RuntimeException if there is an error triggering the pipeline
     */
    public Long triggerPipeline(String gitlabInstanceUrl, String projectId, String accessToken, String branch) {
        try {
            GitLabApi gitLabApi = getGitLabApi(gitlabInstanceUrl, accessToken);
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            
            // Trigger the pipeline on the specified branch
            Pipeline pipeline = pipelineApi.createPipeline(projectId, branch);
            
            log.info("Triggered GitLab pipeline for project: {}, branch: {}, pipelineId: {}", 
                    projectId, branch, pipeline.getId());
            
            return pipeline.getId();
        } catch (GitLabApiException e) {
            log.error("Error triggering GitLab pipeline for project: {}, branch: {}", projectId, branch, e);
            throw new RuntimeException("Failed to trigger GitLab pipeline: " + e.getMessage(), e);
        }
    }

    /**
     * Gets the status of a pipeline in GitLab.
     *
     * @param gitlabInstanceUrl The URL of the GitLab instance
     * @param projectId The ID of the GitLab project
     * @param accessToken The access token for GitLab API
     * @param pipelineId The ID of the GitLab pipeline
     * @return The status of the pipeline
     * @throws RuntimeException if there is an error getting the pipeline status
     */
    public String getPipelineStatus(String gitlabInstanceUrl, String projectId, String accessToken, Long pipelineId) {
        try {
            GitLabApi gitLabApi = getGitLabApi(gitlabInstanceUrl, accessToken);
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            
            // Get the pipeline by ID
            Pipeline pipeline = pipelineApi.getPipeline(projectId, pipelineId);
            
            log.info("GitLab pipeline status for project: {}, pipelineId: {}, status: {}", 
                    projectId, pipelineId, pipeline.getStatus());
            
            return pipeline.getStatus().toString();
        } catch (GitLabApiException e) {
            log.error("Error getting GitLab pipeline status for project: {}, pipelineId: {}", 
                    projectId, pipelineId, e);
            throw new RuntimeException("Failed to get GitLab pipeline status: " + e.getMessage(), e);
        }
    }

    /**
     * Forwards payload to a GitLab pipeline.
     *
     * @param gitlabInstanceUrl The URL of the GitLab instance
     * @param projectId The ID of the GitLab project
     * @param accessToken The access token for GitLab API
     * @param branch The branch to run the pipeline on
     * @param payload The payload to forward to the pipeline
     * @return The ID of the created GitLab pipeline
     * @throws RuntimeException if there is an error forwarding the payload
     */
    public Long forwardPayloadToPipeline(String gitlabInstanceUrl, String projectId, String accessToken, 
                                        String branch, JsonNode payload) {
        try {
            GitLabApi gitLabApi = getGitLabApi(gitlabInstanceUrl, accessToken);
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            
            // Convert payload to variables format expected by GitLab
            Map<String, String> variables = new HashMap<>();
            variables.put("PAYLOAD", objectMapper.writeValueAsString(payload));
            
            // Trigger the pipeline with variables
            Pipeline pipeline = pipelineApi.createPipeline(projectId, branch, variables);
            
            log.info("Forwarded payload to GitLab pipeline for project: {}, branch: {}, pipelineId: {}", 
                    projectId, branch, pipeline.getId());
            
            return pipeline.getId();
        } catch (Exception e) {
            log.error("Error forwarding payload to GitLab pipeline for project: {}, branch: {}", 
                    projectId, branch, e);
            throw new RuntimeException("Failed to forward payload to GitLab pipeline: " + e.getMessage(), e);
        }
    }

    /**
     * Gets or creates a GitLabApi instance for the given URL and token.
     *
     * @param gitlabInstanceUrl The URL of the GitLab instance
     * @param accessToken The access token for GitLab API
     * @return A GitLabApi instance
     */
    private GitLabApi getGitLabApi(String gitlabInstanceUrl, String accessToken) {
        String cacheKey = gitlabInstanceUrl + "-" + accessToken;
        if (!gitLabApiCache.containsKey(cacheKey)) {
            GitLabApi gitLabApi = new GitLabApi(gitlabInstanceUrl, accessToken);
            gitLabApiCache.put(cacheKey, gitLabApi);
        }
        return gitLabApiCache.get(cacheKey);
    }
}
