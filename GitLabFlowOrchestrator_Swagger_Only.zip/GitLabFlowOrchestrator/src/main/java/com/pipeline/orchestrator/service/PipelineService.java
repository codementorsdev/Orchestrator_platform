package com.pipeline.orchestrator.service;

import com.pipeline.orchestrator.model.Application;
import com.pipeline.orchestrator.model.Flow;
import com.pipeline.orchestrator.model.Pipeline;
import com.pipeline.orchestrator.repository.ApplicationRepository;
import com.pipeline.orchestrator.repository.FlowRepository;
import com.pipeline.orchestrator.repository.PipelineRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service class for managing Pipeline entities.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class PipelineService {

    private final PipelineRepository pipelineRepository;
    private final FlowRepository flowRepository;
    private final ApplicationRepository applicationRepository;
    private final GitLabService gitLabService;

    /**
     * Retrieves all pipelines.
     *
     * @return List of all pipelines
     */
    public List<Pipeline> getAllPipelines() {
        return pipelineRepository.findAll();
    }

    /**
     * Retrieves a pipeline by its ID.
     *
     * @param id The ID of the pipeline to retrieve
     * @return The requested pipeline
     * @throws EntityNotFoundException if the pipeline is not found
     */
    public Pipeline getPipelineById(Long id) {
        return pipelineRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Pipeline not found with id: " + id));
    }

    /**
     * Creates a new pipeline.
     *
     * @param pipeline The pipeline to create
     * @return The created pipeline
     * @throws EntityNotFoundException if the referenced flow or application is not found
     */
    @Transactional
    public Pipeline createPipeline(Pipeline pipeline) {
        if (pipeline.getFlow() != null && pipeline.getFlow().getId() != null) {
            Flow flow = flowRepository.findById(pipeline.getFlow().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Flow not found with id: " + pipeline.getFlow().getId()));
            pipeline.setFlow(flow);
        }
        
        if (pipeline.getApplication() != null && pipeline.getApplication().getId() != null) {
            Application application = applicationRepository.findById(pipeline.getApplication().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with id: " + pipeline.getApplication().getId()));
            pipeline.setApplication(application);
        }
        
        log.info("Creating new pipeline: {}", pipeline.getName());
        return pipelineRepository.save(pipeline);
    }

    /**
     * Updates an existing pipeline.
     *
     * @param id The ID of the pipeline to update
     * @param pipelineDetails The updated pipeline details
     * @return The updated pipeline
     * @throws EntityNotFoundException if the pipeline, flow, or application is not found
     */
    @Transactional
    public Pipeline updatePipeline(Long id, Pipeline pipelineDetails) {
        Pipeline pipeline = getPipelineById(id);
        
        pipeline.setName(pipelineDetails.getName());
        pipeline.setDescription(pipelineDetails.getDescription());
        pipeline.setBranch(pipelineDetails.getBranch());
        pipeline.setExecutionSequence(pipelineDetails.getExecutionSequence());
        pipeline.setGitlabInstanceUrl(pipelineDetails.getGitlabInstanceUrl());
        pipeline.setGitlabPipelineId(pipelineDetails.getGitlabPipelineId());
        
        if (pipelineDetails.getFlow() != null && pipelineDetails.getFlow().getId() != null) {
            Flow flow = flowRepository.findById(pipelineDetails.getFlow().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Flow not found with id: " + pipelineDetails.getFlow().getId()));
            pipeline.setFlow(flow);
        }
        
        if (pipelineDetails.getApplication() != null && pipelineDetails.getApplication().getId() != null) {
            Application application = applicationRepository.findById(pipelineDetails.getApplication().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Application not found with id: " + pipelineDetails.getApplication().getId()));
            pipeline.setApplication(application);
        }
        
        log.info("Updating pipeline with id: {}", id);
        return pipelineRepository.save(pipeline);
    }

    /**
     * Deletes a pipeline.
     *
     * @param id The ID of the pipeline to delete
     * @throws EntityNotFoundException if the pipeline is not found
     */
    @Transactional
    public void deletePipeline(Long id) {
        Pipeline pipeline = getPipelineById(id);
        
        log.info("Deleting pipeline with id: {}", id);
        pipelineRepository.delete(pipeline);
    }

    /**
     * Retrieves all pipelines for a specific flow, ordered by execution sequence.
     *
     * @param flowId The ID of the flow
     * @return List of pipelines for the flow
     */
    public List<Pipeline> getPipelinesByFlowId(Long flowId) {
        // Verify flow exists
        if (!flowRepository.existsById(flowId)) {
            throw new EntityNotFoundException("Flow not found with id: " + flowId);
        }
        
        return pipelineRepository.findByFlowIdOrderByExecutionSequence(flowId);
    }

    /**
     * Retrieves all pipelines linked to a specific application.
     *
     * @param applicationId The ID of the application
     * @return List of pipelines linked to the application
     */
    public List<Pipeline> getPipelinesByApplicationId(Long applicationId) {
        // Verify application exists
        if (!applicationRepository.existsById(applicationId)) {
            throw new EntityNotFoundException("Application not found with id: " + applicationId);
        }
        
        return pipelineRepository.findByApplicationId(applicationId);
    }

    /**
     * Triggers the execution of a pipeline in GitLab.
     *
     * @param id The ID of the pipeline to trigger
     * @throws EntityNotFoundException if the pipeline is not found
     */
    @Transactional
    public void triggerPipeline(Long id) {
        Pipeline pipeline = getPipelineById(id);
        
        if (pipeline.getApplication() == null) {
            throw new IllegalStateException("Pipeline is not linked to an application");
        }
        
        // Update pipeline status to pending
        pipeline.setLastExecutionStatus(Pipeline.ExecutionStatus.PENDING);
        pipeline.setLastExecutionTime(LocalDateTime.now());
        pipelineRepository.save(pipeline);
        
        // Trigger the GitLab pipeline
        Long gitlabPipelineId = gitLabService.triggerPipeline(
                pipeline.getGitlabInstanceUrl(),
                pipeline.getApplication().getProjectId(),
                pipeline.getApplication().getAccessToken(),
                pipeline.getBranch()
        );
        
        // Store the GitLab pipeline ID for reference
        pipeline.setGitlabPipelineId(gitlabPipelineId);
        pipeline.setLastExecutionStatus(Pipeline.ExecutionStatus.RUNNING);
        pipelineRepository.save(pipeline);
        
        log.info("Triggered pipeline id: {} in GitLab (gitlabPipelineId: {})", id, gitlabPipelineId);
    }

    /**
     * Finds the next pipeline to execute in a flow.
     *
     * @param flowId The ID of the flow
     * @param currentSequence The execution sequence of the current pipeline
     * @return The next pipeline in the sequence, if any
     */
    public Pipeline findNextPipeline(Long flowId, Integer currentSequence) {
        List<Pipeline> nextPipelines = pipelineRepository.findNextPipelineInFlow(flowId, currentSequence);
        return nextPipelines.isEmpty() ? null : nextPipelines.get(0);
    }

    /**
     * Updates a pipeline's execution status.
     *
     * @param pipelineId The ID of the pipeline
     * @param status The new execution status
     */
    @Transactional
    public void updatePipelineStatus(Long pipelineId, Pipeline.ExecutionStatus status) {
        Pipeline pipeline = getPipelineById(pipelineId);
        pipeline.setLastExecutionStatus(status);
        pipeline.setLastExecutionTime(LocalDateTime.now());
        pipelineRepository.save(pipeline);
        
        log.info("Updated pipeline id: {} with status: {}", pipelineId, status);
    }
}
