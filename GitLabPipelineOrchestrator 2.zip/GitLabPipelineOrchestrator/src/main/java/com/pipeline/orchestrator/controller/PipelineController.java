package com.pipeline.orchestrator.controller;

import com.pipeline.orchestrator.model.Pipeline;
import com.pipeline.orchestrator.service.PipelineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;

@RestController
@RequestMapping("/api/pipelines")
public class PipelineController {

    private final PipelineService pipelineService;
    
    @Autowired
    public PipelineController(PipelineService pipelineService) {
        this.pipelineService = pipelineService;
    }
    
    @GetMapping
    public ResponseEntity<List<Pipeline>> getAllPipelines() {
        List<Pipeline> pipelines = pipelineService.getAllPipelines();
        return new ResponseEntity<>(pipelines, HttpStatus.OK);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> getPipelineById(@PathVariable Long id) {
        Optional<Pipeline> pipeline = pipelineService.getPipelineById(id);
        if (pipeline.isPresent()) {
            return new ResponseEntity<>(pipeline.get(), HttpStatus.OK);
        } else {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Pipeline not found with id: " + id);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
    
    @PostMapping
    public ResponseEntity<Pipeline> createPipeline(@RequestBody Pipeline pipeline) {
        Pipeline savedPipeline = pipelineService.savePipeline(pipeline);
        return new ResponseEntity<>(savedPipeline, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<?> updatePipeline(@PathVariable Long id, @RequestBody Pipeline pipelineDetails) {
        Optional<Pipeline> pipelineData = pipelineService.getPipelineById(id);
        if (pipelineData.isPresent()) {
            Pipeline pipeline = pipelineData.get();
            pipeline.setName(pipelineDetails.getName());
            pipeline.setDescription(pipelineDetails.getDescription());
            pipeline.setGitlabProjectId(pipelineDetails.getGitlabProjectId());
            pipeline.setStatus(pipelineDetails.getStatus());
            
            return new ResponseEntity<>(pipelineService.savePipeline(pipeline), HttpStatus.OK);
        } else {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Pipeline not found with id: " + id);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePipeline(@PathVariable Long id) {
        Optional<Pipeline> pipeline = pipelineService.getPipelineById(id);
        if (pipeline.isPresent()) {
            pipelineService.deletePipeline(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Pipeline deleted successfully");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Pipeline not found with id: " + id);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
}
