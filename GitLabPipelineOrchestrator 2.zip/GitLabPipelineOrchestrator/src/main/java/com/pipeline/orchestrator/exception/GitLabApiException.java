package com.pipeline.orchestrator.exception;

/**
 * Exception thrown when there is an error with the GitLab API.
 */
public class GitLabApiException extends RuntimeException {

    public GitLabApiException(String message) {
        super(message);
    }

    public GitLabApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
