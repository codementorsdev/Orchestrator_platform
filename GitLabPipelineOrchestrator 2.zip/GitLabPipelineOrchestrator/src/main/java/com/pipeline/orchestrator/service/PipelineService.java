package com.pipeline.orchestrator.service;

import com.pipeline.orchestrator.model.Pipeline;
import com.pipeline.orchestrator.repository.PipelineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class PipelineService {

    private final PipelineRepository pipelineRepository;
    
    @Autowired
    public PipelineService(PipelineRepository pipelineRepository) {
        this.pipelineRepository = pipelineRepository;
    }
    
    public List<Pipeline> getAllPipelines() {
        return pipelineRepository.findAll();
    }
    
    public Optional<Pipeline> getPipelineById(Long id) {
        return pipelineRepository.findById(id);
    }
    
    public Pipeline savePipeline(Pipeline pipeline) {
        return pipelineRepository.save(pipeline);
    }
    
    public void deletePipeline(Long id) {
        pipelineRepository.deleteById(id);
    }
}
