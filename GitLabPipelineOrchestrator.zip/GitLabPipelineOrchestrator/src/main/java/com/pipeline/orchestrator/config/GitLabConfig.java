package com.pipeline.orchestrator.config;

import org.gitlab4j.api.GitLabApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for GitLab API integration.
 * Creates and configures the GitLabApi client.
 */
@Configuration
public class GitLabConfig {
    
    private static final Logger logger = LoggerFactory.getLogger(GitLabConfig.class);
    
    @Value("${gitlab.api.url}")
    private String gitlabApiUrl;
    
    @Value("${gitlab.api.token}")
    private String gitlabApiToken;
    
    @Value("${gitlab.api.timeout:30}")
    private int gitlabApiTimeout;
    
    /**
     * Creates and configures the GitLabApi client bean.
     *
     * @return Configured GitLabApi instance
     */
    @Bean
    public GitLabApi gitLabApi() {
        logger.info("Initializing GitLabApi with URL: {}", gitlabApiUrl);
        
        // Create GitLabApi with personal access token
        GitLabApi gitLabApi = new GitLabApi(gitlabApiUrl, gitlabApiToken);
        
        // No direct connection timeout setting in the current version
        logger.debug("Using default GitLab API timeouts");
        
        return gitLabApi;
    }
}
