package com.pipeline.orchestrator.controller;

import com.pipeline.orchestrator.model.PipelineConfig;
import com.pipeline.orchestrator.model.dto.PipelineConfigDto;
import com.pipeline.orchestrator.service.GitLabService;
import com.pipeline.orchestrator.service.PipelineConfigService;
import jakarta.validation.Valid;
import org.gitlab4j.api.models.Project;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for pipeline configuration management.
 */
@Controller
@RequestMapping("/config")
public class PipelineConfigController {

    private static final Logger logger = LoggerFactory.getLogger(PipelineConfigController.class);
    
    private final PipelineConfigService pipelineConfigService;
    private final GitLabService gitLabService;

    @Autowired
    public PipelineConfigController(PipelineConfigService pipelineConfigService, GitLabService gitLabService) {
        this.pipelineConfigService = pipelineConfigService;
        this.gitLabService = gitLabService;
    }

    /**
     * Show list of all pipeline configurations
     */
    @GetMapping
    public String listPipelineConfigs(Model model) {
        logger.debug("Displaying list of pipeline configurations");
        List<PipelineConfig> configs = pipelineConfigService.getAllPipelineConfigs();
        model.addAttribute("pipelineConfigs", configs);
        return "pipeline-config";
    }

    /**
     * Show form to create a new pipeline configuration
     */
    @GetMapping("/new")
    public String newPipelineConfigForm(Model model) {
        logger.debug("Displaying form to create new pipeline configuration");
        model.addAttribute("pipelineConfigDto", new PipelineConfigDto());
        model.addAttribute("isEdit", false);
        return "pipeline-config :: config-form";
    }

    /**
     * Show form to edit an existing pipeline configuration
     */
    @GetMapping("/{id}/edit")
    public String editPipelineConfigForm(@PathVariable Long id, Model model) {
        logger.debug("Displaying form to edit pipeline configuration with ID: {}", id);
        PipelineConfig pipelineConfig = pipelineConfigService.getPipelineConfigById(id);
        PipelineConfigDto pipelineConfigDto = pipelineConfigService.convertToDto(pipelineConfig);
        
        model.addAttribute("pipelineConfigDto", pipelineConfigDto);
        model.addAttribute("isEdit", true);
        
        // Get available dependencies (exclude current pipeline and its dependents)
        List<PipelineConfig> availableDependencies = pipelineConfigService.getAvailableDependencies(id);
        model.addAttribute("availableDependencies", availableDependencies);
        
        return "pipeline-config :: config-form";
    }

    /**
     * Create a new pipeline configuration
     */
    @PostMapping
    public String createPipelineConfig(@Valid @ModelAttribute PipelineConfigDto pipelineConfigDto,
                                     BindingResult bindingResult,
                                     RedirectAttributes redirectAttributes) {
        logger.info("Creating new pipeline configuration: {}", pipelineConfigDto.getName());
        
        if (bindingResult.hasErrors()) {
            logger.warn("Validation errors in pipeline configuration form");
            return "pipeline-config :: config-form";
        }
        
        PipelineConfig pipelineConfig = pipelineConfigService.createPipelineConfig(pipelineConfigDto);
        
        redirectAttributes.addFlashAttribute("successMessage", 
                "Pipeline configuration '" + pipelineConfig.getName() + "' created successfully");
        
        return "redirect:/config";
    }

    /**
     * Update an existing pipeline configuration
     */
    @PostMapping("/{id}")
    public String updatePipelineConfig(@PathVariable Long id,
                                     @Valid @ModelAttribute PipelineConfigDto pipelineConfigDto,
                                     BindingResult bindingResult,
                                     RedirectAttributes redirectAttributes) {
        logger.info("Updating pipeline configuration with ID: {}", id);
        
        if (bindingResult.hasErrors()) {
            logger.warn("Validation errors in pipeline configuration form");
            return "pipeline-config :: config-form";
        }
        
        PipelineConfig pipelineConfig = pipelineConfigService.updatePipelineConfig(id, pipelineConfigDto);
        
        redirectAttributes.addFlashAttribute("successMessage", 
                "Pipeline configuration '" + pipelineConfig.getName() + "' updated successfully");
        
        return "redirect:/config";
    }

    /**
     * Delete a pipeline configuration
     */
    @PostMapping("/{id}/delete")
    public String deletePipelineConfig(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        logger.info("Deleting pipeline configuration with ID: {}", id);
        
        try {
            // Check if any pipeline depends on this one
            if (pipelineConfigService.hasDependents(id)) {
                redirectAttributes.addFlashAttribute("errorMessage", 
                        "Cannot delete pipeline configuration because other pipelines depend on it");
                return "redirect:/config";
            }
            
            pipelineConfigService.deletePipelineConfig(id);
            
            redirectAttributes.addFlashAttribute("successMessage", "Pipeline configuration deleted successfully");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to delete pipeline configuration: " + e.getMessage());
        }
        
        return "redirect:/config";
    }

    /**
     * Get available projects from GitLab
     */
    @GetMapping("/gitlab/projects")
    @ResponseBody
    public ResponseEntity<List<Project>> getGitLabProjects() {
        logger.debug("Getting list of GitLab projects");
        List<Project> projects = gitLabService.getAllProjects();
        return ResponseEntity.ok(projects);
    }

    /**
     * Get branches for a specific project from GitLab
     */
    @GetMapping("/gitlab/projects/{projectId}/branches")
    @ResponseBody
    public ResponseEntity<List<String>> getProjectBranches(@PathVariable Integer projectId) {
        logger.debug("Getting list of branches for project ID: {}", projectId);
        List<String> branches = gitLabService.getProjectBranches(projectId);
        return ResponseEntity.ok(branches);
    }

    /**
     * Get list of available dependencies for a pipeline
     */
    @GetMapping("/{id}/available-dependencies")
    @ResponseBody
    public ResponseEntity<List<PipelineConfigDto>> getAvailableDependencies(@PathVariable Long id) {
        logger.debug("Getting available dependencies for pipeline ID: {}", id);
        List<PipelineConfig> availableDependencies = pipelineConfigService.getAvailableDependencies(id);
        List<PipelineConfigDto> dependencyDtos = availableDependencies.stream()
                .map(pipelineConfigService::convertToDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(dependencyDtos);
    }
}
