package com.pipeline.orchestrator.controller;

import com.pipeline.orchestrator.model.PipelineConfig;
import com.pipeline.orchestrator.model.PipelineRun;
import com.pipeline.orchestrator.model.dto.PipelineRunDto;
import com.pipeline.orchestrator.service.PipelineConfigService;
import com.pipeline.orchestrator.service.PipelineOrchestrationService;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

/**
 * Controller for pipeline run operations and monitoring.
 */
@Controller
@RequestMapping("/pipelines")
public class PipelineRunController {

    private static final Logger logger = LoggerFactory.getLogger(PipelineRunController.class);
    
    private final PipelineOrchestrationService pipelineOrchestrationService;
    private final PipelineConfigService pipelineConfigService;

    @Autowired
    public PipelineRunController(PipelineOrchestrationService pipelineOrchestrationService,
                               PipelineConfigService pipelineConfigService) {
        this.pipelineOrchestrationService = pipelineOrchestrationService;
        this.pipelineConfigService = pipelineConfigService;
    }

    /**
     * Show pipeline monitoring page
     */
    @GetMapping
    public String showPipelineMonitor(Model model,
                                    @RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "10") int size) {
        logger.debug("Displaying pipeline monitor page");
        
        Pageable pageable = PageRequest.of(page, size);
        Page<PipelineRunDto> pipelineRuns = pipelineOrchestrationService.getAllPipelineRuns(pageable);
        
        model.addAttribute("pipelineRuns", pipelineRuns);
        model.addAttribute("pipelineConfigs", pipelineConfigService.getActivePipelineConfigs());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", pipelineRuns.getTotalPages());
        
        return "pipeline-monitor";
    }

    /**
     * Load more pipeline runs for pagination
     */
    @GetMapping("/load-more")
    public String loadMorePipelineRuns(Model model,
                                     @RequestParam(defaultValue = "0") int page,
                                     @RequestParam(defaultValue = "10") int size,
                                     @RequestParam(required = false) Long configId) {
        logger.debug("Loading more pipeline runs, page: {}, size: {}, configId: {}", page, size, configId);
        
        Pageable pageable = PageRequest.of(page, size);
        Page<PipelineRunDto> pipelineRuns;
        
        if (configId != null) {
            pipelineRuns = pipelineOrchestrationService.getPipelineRunsByConfigId(configId, pageable);
        } else {
            pipelineRuns = pipelineOrchestrationService.getAllPipelineRuns(pageable);
        }
        
        model.addAttribute("pipelineRuns", pipelineRuns);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", pipelineRuns.getTotalPages());
        
        return "pipeline-monitor :: pipeline-runs";
    }

    /**
     * Filter pipeline runs by configuration
     */
    @GetMapping("/filter")
    public String filterPipelineRuns(Model model,
                                   @RequestParam Long configId,
                                   @RequestParam(defaultValue = "0") int page,
                                   @RequestParam(defaultValue = "10") int size) {
        logger.debug("Filtering pipeline runs by config ID: {}", configId);
        
        Pageable pageable = PageRequest.of(page, size);
        Page<PipelineRunDto> pipelineRuns = pipelineOrchestrationService.getPipelineRunsByConfigId(configId, pageable);
        
        model.addAttribute("pipelineRuns", pipelineRuns);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", pipelineRuns.getTotalPages());
        model.addAttribute("configId", configId);
        
        return "pipeline-monitor :: pipeline-runs";
    }

    /**
     * Trigger a pipeline run for a specific configuration
     */
    @PostMapping("/trigger/{configId}")
    public String triggerPipeline(@PathVariable Long configId, RedirectAttributes redirectAttributes) {
        logger.info("Triggering pipeline for config ID: {}", configId);
        
        try {
            PipelineRun pipelineRun = pipelineOrchestrationService.triggerPipeline(configId);
            redirectAttributes.addFlashAttribute("successMessage", 
                    "Pipeline triggered successfully with ID: " + pipelineRun.getId());
        } catch (Exception e) {
            logger.error("Error triggering pipeline for config ID: {}", configId, e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to trigger pipeline: " + e.getMessage());
        }
        
        return "redirect:/pipelines";
    }

    /**
     * Trigger all root pipelines
     */
    @PostMapping("/trigger-all")
    public String triggerAllPipelines(RedirectAttributes redirectAttributes) {
        logger.info("Triggering all root pipelines");
        
        try {
            List<PipelineRun> pipelineRuns = pipelineOrchestrationService.triggerRootPipelines();
            redirectAttributes.addFlashAttribute("successMessage", 
                    "Triggered " + pipelineRuns.size() + " pipelines successfully");
        } catch (Exception e) {
            logger.error("Error triggering root pipelines", e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to trigger pipelines: " + e.getMessage());
        }
        
        return "redirect:/pipelines";
    }

    /**
     * Retry a failed pipeline
     */
    @PostMapping("/{runId}/retry")
    public String retryPipeline(@PathVariable Long runId, RedirectAttributes redirectAttributes) {
        logger.info("Retrying pipeline run with ID: {}", runId);
        
        try {
            PipelineRun pipelineRun = pipelineOrchestrationService.retryPipeline(runId);
            redirectAttributes.addFlashAttribute("successMessage", 
                    "Pipeline retry initiated for run ID: " + pipelineRun.getId());
        } catch (Exception e) {
            logger.error("Error retrying pipeline run with ID: {}", runId, e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to retry pipeline: " + e.getMessage());
        }
        
        return "redirect:/pipelines";
    }

    /**
     * Cancel a running pipeline
     */
    @PostMapping("/{runId}/cancel")
    public String cancelPipeline(@PathVariable Long runId, RedirectAttributes redirectAttributes) {
        logger.info("Cancelling pipeline run with ID: {}", runId);
        
        try {
            PipelineRun pipelineRun = pipelineOrchestrationService.cancelPipeline(runId);
            redirectAttributes.addFlashAttribute("successMessage", 
                    "Pipeline cancelled for run ID: " + pipelineRun.getId());
        } catch (Exception e) {
            logger.error("Error cancelling pipeline run with ID: {}", runId, e);
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to cancel pipeline: " + e.getMessage());
        }
        
        return "redirect:/pipelines";
    }

    /**
     * Get details of a specific pipeline run
     */
    @GetMapping("/{runId}")
    @ResponseBody
    public ResponseEntity<PipelineRunDto> getPipelineRun(@PathVariable Long runId) {
        logger.debug("Getting details for pipeline run with ID: {}", runId);
        
        try {
            PipelineRun pipelineRun = pipelineOrchestrationService.getPipelineRun(runId);
            PipelineRunDto pipelineRunDto = pipelineOrchestrationService.convertToDto(pipelineRun);
            return ResponseEntity.ok(pipelineRunDto);
        } catch (EntityNotFoundException e) {
            logger.warn("Pipeline run not found with ID: {}", runId);
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            logger.error("Error retrieving pipeline run with ID: {}", runId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
