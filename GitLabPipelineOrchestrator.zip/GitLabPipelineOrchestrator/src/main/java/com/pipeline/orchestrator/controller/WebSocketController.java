package com.pipeline.orchestrator.controller;

import com.pipeline.orchestrator.model.dto.PipelineRunDto;
import com.pipeline.orchestrator.service.PipelineOrchestrationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

/**
 * Controller for WebSocket communication.
 */
@Controller
public class WebSocketController {

    private static final Logger logger = LoggerFactory.getLogger(WebSocketController.class);
    
    private final PipelineOrchestrationService pipelineOrchestrationService;

    @Autowired
    public WebSocketController(PipelineOrchestrationService pipelineOrchestrationService) {
        this.pipelineOrchestrationService = pipelineOrchestrationService;
    }

    /**
     * Handle request for latest pipeline runs data.
     * Client sends a message to /app/request-pipeline-data and receives the latest data.
     * 
     * @return Page of latest pipeline runs
     */
    @MessageMapping("/request-pipeline-data")
    @SendTo("/topic/pipeline-data")
    public Page<PipelineRunDto> getPipelineData() {
        logger.debug("Received WebSocket request for latest pipeline data");
        
        // Get first page of pipeline runs with 10 items
        return pipelineOrchestrationService.getAllPipelineRuns(PageRequest.of(0, 10));
    }

    /**
     * Handle request for pipeline runs for a specific configuration.
     * 
     * @param configId Pipeline configuration ID
     * @return Page of pipeline runs for the specified configuration
     */
    @MessageMapping("/request-pipeline-data-by-config")
    @SendTo("/topic/pipeline-data")
    public Page<PipelineRunDto> getPipelineDataByConfig(Long configId) {
        logger.debug("Received WebSocket request for pipeline data for config ID: {}", configId);
        
        // Get first page of pipeline runs for the specified configuration
        return pipelineOrchestrationService.getPipelineRunsByConfigId(configId, PageRequest.of(0, 10));
    }
}
