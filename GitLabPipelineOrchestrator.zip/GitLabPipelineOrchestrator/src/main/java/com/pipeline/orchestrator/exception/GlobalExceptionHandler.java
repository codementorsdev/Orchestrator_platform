package com.pipeline.orchestrator.exception;

import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler for the application.
 * Handles exceptions and returns appropriate responses.
 */
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handle GitLab API exceptions
     */
    @ExceptionHandler(GitLabApiException.class)
    public Object handleGitLabApiException(GitLabApiException ex) {
        logger.error("GitLab API exception occurred", ex);
        
        if (isApiRequest()) {
            // API response
            Map<String, Object> response = new HashMap<>();
            response.put("error", true);
            response.put("message", ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
        } else {
            // Web response
            ModelAndView modelAndView = new ModelAndView("error");
            modelAndView.addObject("errorMessage", "GitLab API Error: " + ex.getMessage());
            modelAndView.addObject("errorStatus", HttpStatus.SERVICE_UNAVAILABLE.value());
            modelAndView.addObject("errorTitle", "GitLab API Error");
            return modelAndView;
        }
    }

    /**
     * Handle entity not found exceptions
     */
    @ExceptionHandler(EntityNotFoundException.class)
    public Object handleEntityNotFoundException(EntityNotFoundException ex) {
        logger.error("Entity not found exception occurred", ex);
        
        if (isApiRequest()) {
            // API response
            Map<String, Object> response = new HashMap<>();
            response.put("error", true);
            response.put("message", ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } else {
            // Web response
            ModelAndView modelAndView = new ModelAndView("error");
            modelAndView.addObject("errorMessage", ex.getMessage());
            modelAndView.addObject("errorStatus", HttpStatus.NOT_FOUND.value());
            modelAndView.addObject("errorTitle", "Resource Not Found");
            return modelAndView;
        }
    }

    /**
     * Handle illegal state exceptions
     */
    @ExceptionHandler(IllegalStateException.class)
    public Object handleIllegalStateException(IllegalStateException ex) {
        logger.error("Illegal state exception occurred", ex);
        
        if (isApiRequest()) {
            // API response
            Map<String, Object> response = new HashMap<>();
            response.put("error", true);
            response.put("message", ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } else {
            // Web response
            ModelAndView modelAndView = new ModelAndView("error");
            modelAndView.addObject("errorMessage", ex.getMessage());
            modelAndView.addObject("errorStatus", HttpStatus.BAD_REQUEST.value());
            modelAndView.addObject("errorTitle", "Invalid Operation");
            return modelAndView;
        }
    }

    /**
     * Handle all other exceptions
     */
    @ExceptionHandler(Exception.class)
    public Object handleGenericException(Exception ex) {
        // Skip specific exceptions that are handled by other methods
        if (ex instanceof GitLabApiException || 
            ex instanceof EntityNotFoundException || 
            ex instanceof IllegalStateException) {
            throw (RuntimeException) ex;
        }
        
        logger.error("Unexpected exception occurred", ex);
        
        if (isApiRequest()) {
            // API response
            Map<String, Object> response = new HashMap<>();
            response.put("error", true);
            response.put("message", "An unexpected error occurred: " + ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            // Web response
            ModelAndView modelAndView = new ModelAndView("error");
            modelAndView.addObject("errorMessage", "An unexpected error occurred: " + ex.getMessage());
            modelAndView.addObject("errorStatus", HttpStatus.INTERNAL_SERVER_ERROR.value());
            modelAndView.addObject("errorTitle", "Server Error");
            return modelAndView;
        }
    }
    
    /**
     * Helper method to determine if the current request is an API request
     * This is used to route exceptions to either the API or web UI handlers
     */
    private boolean isApiRequest() {
        try {
            org.springframework.web.context.request.RequestAttributes requestAttributes = 
                org.springframework.web.context.request.RequestContextHolder.getRequestAttributes();
            if (requestAttributes instanceof org.springframework.web.context.request.ServletRequestAttributes) {
                jakarta.servlet.http.HttpServletRequest request = 
                    ((org.springframework.web.context.request.ServletRequestAttributes) requestAttributes).getRequest();
                
                // Check if it's an API request based on Accept header or path
                String acceptHeader = request.getHeader("Accept");
                String path = request.getRequestURI();
                
                return (acceptHeader != null && acceptHeader.contains("application/json")) || 
                       (path != null && path.startsWith("/api/"));
            }
        } catch (Exception e) {
            logger.warn("Error determining if request is API request", e);
        }
        return false;
    }
}
