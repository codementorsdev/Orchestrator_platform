package com.pipeline.orchestrator.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Entity representing a GitLab pipeline configuration.
 * Contains information about the project, branch, and dependencies.
 */
@Entity
@Table(name = "pipeline_configs")
public class PipelineConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Pipeline name is required")
    @Column(nullable = false)
    private String name;

    @NotNull(message = "Project ID is required")
    @Column(nullable = false)
    private Integer projectId;

    @NotBlank(message = "Project name is required")
    @Column(nullable = false)
    private String projectName;

    @NotBlank(message = "Branch name is required")
    @Column(nullable = false)
    private String branchName;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false)
    private Integer orderIndex;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "pipeline_dependencies",
        joinColumns = @JoinColumn(name = "pipeline_id"),
        inverseJoinColumns = @JoinColumn(name = "dependency_id")
    )
    private List<PipelineConfig> dependencies = new ArrayList<>();

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    @Column(nullable = false)
    private boolean active = true;

    // Default constructor required by JPA
    public PipelineConfig() {
    }

    // Constructor with required fields
    public PipelineConfig(String name, Integer projectId, String projectName, String branchName, Integer orderIndex) {
        this.name = name;
        this.projectId = projectId;
        this.projectName = projectName;
        this.branchName = branchName;
        this.orderIndex = orderIndex;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getOrderIndex() {
        return orderIndex;
    }

    public void setOrderIndex(Integer orderIndex) {
        this.orderIndex = orderIndex;
    }

    public List<PipelineConfig> getDependencies() {
        return dependencies;
    }

    public void setDependencies(List<PipelineConfig> dependencies) {
        this.dependencies = dependencies;
    }

    public void addDependency(PipelineConfig dependency) {
        this.dependencies.add(dependency);
    }

    public void removeDependency(PipelineConfig dependency) {
        this.dependencies.remove(dependency);
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PipelineConfig that = (PipelineConfig) o;
        return id != null && Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

    @Override
    public String toString() {
        return "PipelineConfig{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", projectId=" + projectId +
                ", projectName='" + projectName + '\'' +
                ", branchName='" + branchName + '\'' +
                ", orderIndex=" + orderIndex +
                ", active=" + active +
                '}';
    }
}
