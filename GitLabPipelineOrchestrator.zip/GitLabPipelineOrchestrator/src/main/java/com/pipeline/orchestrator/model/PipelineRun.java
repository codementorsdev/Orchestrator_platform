package com.pipeline.orchestrator.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Entity representing a pipeline run instance.
 * Records information about the execution of a pipeline configuration.
 */
@Entity
@Table(name = "pipeline_runs")
public class PipelineRun {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "pipeline_config_id", nullable = false)
    private PipelineConfig pipelineConfig;

    @Column(nullable = false)
    private Integer gitlabPipelineId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PipelineStatus status;

    @Column
    private String statusDetail;

    @Column(nullable = false)
    private LocalDateTime startTime;

    @Column
    private LocalDateTime endTime;

    @Column
    private Integer runOrder;

    @Column
    private String webUrl;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    // Default constructor required by JPA
    public PipelineRun() {
    }

    // Constructor with required fields
    public PipelineRun(PipelineConfig pipelineConfig, Integer gitlabPipelineId, PipelineStatus status, LocalDateTime startTime, Integer runOrder) {
        this.pipelineConfig = pipelineConfig;
        this.gitlabPipelineId = gitlabPipelineId;
        this.status = status;
        this.startTime = startTime;
        this.runOrder = runOrder;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PipelineConfig getPipelineConfig() {
        return pipelineConfig;
    }

    public void setPipelineConfig(PipelineConfig pipelineConfig) {
        this.pipelineConfig = pipelineConfig;
    }

    public Integer getGitlabPipelineId() {
        return gitlabPipelineId;
    }

    public void setGitlabPipelineId(Integer gitlabPipelineId) {
        this.gitlabPipelineId = gitlabPipelineId;
    }

    public PipelineStatus getStatus() {
        return status;
    }

    public void setStatus(PipelineStatus status) {
        this.status = status;
    }

    public String getStatusDetail() {
        return statusDetail;
    }

    public void setStatusDetail(String statusDetail) {
        this.statusDetail = statusDetail;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Integer getRunOrder() {
        return runOrder;
    }

    public void setRunOrder(Integer runOrder) {
        this.runOrder = runOrder;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Calculate the duration of the pipeline run
     * @return Duration in seconds or null if the pipeline is still running
     */
    @Transient
    public Long getDurationInSeconds() {
        if (endTime == null) {
            return null;
        }
        return java.time.Duration.between(startTime, endTime).getSeconds();
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PipelineRun that = (PipelineRun) o;
        return id != null && Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

    @Override
    public String toString() {
        return "PipelineRun{" +
                "id=" + id +
                ", pipelineConfig=" + pipelineConfig.getName() +
                ", gitlabPipelineId=" + gitlabPipelineId +
                ", status=" + status +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", runOrder=" + runOrder +
                '}';
    }
}
