package com.pipeline.orchestrator.model;

/**
 * Enum representing different possible statuses of a pipeline run.
 */
public enum PipelineStatus {
    PENDING("Pending"),
    RUNNING("Running"),
    SUCCESS("Success"),
    FAILED("Failed"),
    CANCELED("Canceled"),
    SKIPPED("Skipped"),
    MANUAL("Manual"),
    WAITING("Waiting for Dependencies"),
    ERROR("Error");

    private final String displayName;

    PipelineStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    /**
     * Map GitLab pipeline status to our internal status
     * 
     * @param gitlabStatus the status string from GitLab API
     * @return corresponding PipelineStatus
     */
    public static PipelineStatus fromGitLabStatus(String gitlabStatus) {
        if (gitlabStatus == null) {
            return ERROR;
        }
        
        return switch (gitlabStatus.toLowerCase()) {
            case "pending" -> PENDING;
            case "running" -> RUNNING;
            case "success" -> SUCCESS;
            case "failed" -> FAILED;
            case "canceled" -> CANCELED;
            case "skipped" -> SKIPPED;
            case "manual" -> MANUAL;
            default -> ERROR;
        };
    }
    
    /**
     * Map GitLab pipeline status to our internal status
     * 
     * @param gitlabStatus the GitLab API status object
     * @return corresponding PipelineStatus
     */
    public static PipelineStatus fromGitLabStatus(org.gitlab4j.api.models.PipelineStatus gitlabStatus) {
        if (gitlabStatus == null) {
            return ERROR;
        }
        
        return fromGitLabStatus(gitlabStatus.toString());
    }

    /**
     * Check if this status represents a terminal state
     * 
     * @return true if this is a terminal state
     */
    public boolean isTerminal() {
        return this == SUCCESS || this == FAILED || this == CANCELED || this == SKIPPED || this == ERROR;
    }

    /**
     * Check if this status represents a successful completion
     * 
     * @return true if this is a success state
     */
    public boolean isSuccess() {
        return this == SUCCESS;
    }
}
