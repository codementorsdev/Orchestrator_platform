package com.pipeline.orchestrator.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Transfer Object for PipelineConfig entity.
 * Used for create/update operations in the UI.
 */
public class PipelineConfigDto {

    private Long id;

    @NotBlank(message = "Pipeline name is required")
    private String name;

    @NotNull(message = "Project ID is required")
    @Positive(message = "Project ID must be positive")
    private Integer projectId;

    @NotBlank(message = "Project name is required")
    private String projectName;

    @NotBlank(message = "Branch name is required")
    private String branchName;

    private String description;

    @NotNull(message = "Order index is required")
    private Integer orderIndex;

    private List<Long> dependencyIds = new ArrayList<>();

    private boolean active = true;

    // Default constructor
    public PipelineConfigDto() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getOrderIndex() {
        return orderIndex;
    }

    public void setOrderIndex(Integer orderIndex) {
        this.orderIndex = orderIndex;
    }

    public List<Long> getDependencyIds() {
        return dependencyIds;
    }

    public void setDependencyIds(List<Long> dependencyIds) {
        this.dependencyIds = dependencyIds;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "PipelineConfigDto{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", projectId=" + projectId +
                ", projectName='" + projectName + '\'' +
                ", branchName='" + branchName + '\'' +
                ", orderIndex=" + orderIndex +
                ", dependencyIds=" + dependencyIds +
                ", active=" + active +
                '}';
    }
}
