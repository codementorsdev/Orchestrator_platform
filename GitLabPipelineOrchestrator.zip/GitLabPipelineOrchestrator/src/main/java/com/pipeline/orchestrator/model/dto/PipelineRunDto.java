package com.pipeline.orchestrator.model.dto;

import com.pipeline.orchestrator.model.PipelineStatus;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Data Transfer Object for PipelineRun entity.
 * Used for displaying run information in the UI.
 */
public class PipelineRunDto {

    private Long id;
    private Long pipelineConfigId;
    private String pipelineName;
    private String projectName;
    private Integer gitlabPipelineId;
    private PipelineStatus status;
    private String statusDetail;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Long durationInSeconds;
    private Integer runOrder;
    private String webUrl;
    private String branchName;

    // Default constructor
    public PipelineRunDto() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPipelineConfigId() {
        return pipelineConfigId;
    }

    public void setPipelineConfigId(Long pipelineConfigId) {
        this.pipelineConfigId = pipelineConfigId;
    }

    public String getPipelineName() {
        return pipelineName;
    }

    public void setPipelineName(String pipelineName) {
        this.pipelineName = pipelineName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getGitlabPipelineId() {
        return gitlabPipelineId;
    }

    public void setGitlabPipelineId(Integer gitlabPipelineId) {
        this.gitlabPipelineId = gitlabPipelineId;
    }

    public PipelineStatus getStatus() {
        return status;
    }

    public void setStatus(PipelineStatus status) {
        this.status = status;
    }

    public String getStatusDetail() {
        return statusDetail;
    }

    public void setStatusDetail(String statusDetail) {
        this.statusDetail = statusDetail;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Long getDurationInSeconds() {
        return durationInSeconds;
    }

    public void setDurationInSeconds(Long durationInSeconds) {
        this.durationInSeconds = durationInSeconds;
    }

    public Integer getRunOrder() {
        return runOrder;
    }

    public void setRunOrder(Integer runOrder) {
        this.runOrder = runOrder;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    /**
     * Format the start time for display
     * @return Formatted start time string
     */
    public String getFormattedStartTime() {
        if (startTime == null) {
            return "N/A";
        }
        return startTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    /**
     * Format the end time for display
     * @return Formatted end time string
     */
    public String getFormattedEndTime() {
        if (endTime == null) {
            return "N/A";
        }
        return endTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    /**
     * Format the duration for display
     * @return Formatted duration string
     */
    public String getFormattedDuration() {
        if (durationInSeconds == null) {
            return "Running";
        }
        
        long hours = durationInSeconds / 3600;
        long minutes = (durationInSeconds % 3600) / 60;
        long seconds = durationInSeconds % 60;
        
        if (hours > 0) {
            return String.format("%dh %dm %ds", hours, minutes, seconds);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, seconds);
        } else {
            return String.format("%ds", seconds);
        }
    }

    /**
     * Get CSS class for the status
     * @return CSS class name
     */
    public String getStatusClass() {
        if (status == null) {
            return "bg-secondary";
        }
        
        return switch (status) {
            case SUCCESS -> "bg-success";
            case FAILED -> "bg-danger";
            case RUNNING -> "bg-primary";
            case PENDING, WAITING -> "bg-warning";
            case CANCELED, SKIPPED -> "bg-secondary";
            case MANUAL -> "bg-info";
            case ERROR -> "bg-danger";
            default -> "bg-secondary";
        };
    }

    @Override
    public String toString() {
        return "PipelineRunDto{" +
                "id=" + id +
                ", pipelineName='" + pipelineName + '\'' +
                ", gitlabPipelineId=" + gitlabPipelineId +
                ", status=" + status +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", runOrder=" + runOrder +
                '}';
    }
}
