package com.pipeline.orchestrator.model.dto;

import com.pipeline.orchestrator.model.PipelineStatus;

/**
 * Data Transfer Object for pipeline status updates sent via WebSocket.
 */
public class PipelineStatusUpdateDto {

    private Long pipelineRunId;
    private PipelineStatus status;
    private String statusDetail;
    private String formattedDuration;
    private String formattedEndTime;

    // Default constructor
    public PipelineStatusUpdateDto() {
    }

    // Constructor with fields
    public PipelineStatusUpdateDto(Long pipelineRunId, PipelineStatus status, String statusDetail,
                                 String formattedDuration, String formattedEndTime) {
        this.pipelineRunId = pipelineRunId;
        this.status = status;
        this.statusDetail = statusDetail;
        this.formattedDuration = formattedDuration;
        this.formattedEndTime = formattedEndTime;
    }

    // Getters and Setters
    public Long getPipelineRunId() {
        return pipelineRunId;
    }

    public void setPipelineRunId(Long pipelineRunId) {
        this.pipelineRunId = pipelineRunId;
    }

    public PipelineStatus getStatus() {
        return status;
    }

    public void setStatus(PipelineStatus status) {
        this.status = status;
    }

    public String getStatusDetail() {
        return statusDetail;
    }

    public void setStatusDetail(String statusDetail) {
        this.statusDetail = statusDetail;
    }

    public String getFormattedDuration() {
        return formattedDuration;
    }

    public void setFormattedDuration(String formattedDuration) {
        this.formattedDuration = formattedDuration;
    }

    public String getFormattedEndTime() {
        return formattedEndTime;
    }

    public void setFormattedEndTime(String formattedEndTime) {
        this.formattedEndTime = formattedEndTime;
    }

    /**
     * Get CSS class for the status
     * @return CSS class name
     */
    public String getStatusClass() {
        if (status == null) {
            return "bg-secondary";
        }
        
        return switch (status) {
            case SUCCESS -> "bg-success";
            case FAILED -> "bg-danger";
            case RUNNING -> "bg-primary";
            case PENDING, WAITING -> "bg-warning";
            case CANCELED, SKIPPED -> "bg-secondary";
            case MANUAL -> "bg-info";
            case ERROR -> "bg-danger";
            default -> "bg-secondary";
        };
    }

    @Override
    public String toString() {
        return "PipelineStatusUpdateDto{" +
                "pipelineRunId=" + pipelineRunId +
                ", status=" + status +
                ", statusDetail='" + statusDetail + '\'' +
                '}';
    }
}
