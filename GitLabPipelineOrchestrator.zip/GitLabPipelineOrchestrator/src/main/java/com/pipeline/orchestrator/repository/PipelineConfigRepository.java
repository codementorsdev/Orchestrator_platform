package com.pipeline.orchestrator.repository;

import com.pipeline.orchestrator.model.PipelineConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for accessing and manipulating PipelineConfig entities.
 */
@Repository
public interface PipelineConfigRepository extends JpaRepository<PipelineConfig, Long> {

    /**
     * Find all active pipeline configurations ordered by their order index
     * 
     * @return List of active pipeline configurations
     */
    List<PipelineConfig> findByActiveIsTrueOrderByOrderIndexAsc();

    /**
     * Find all pipeline configurations ordered by their order index
     * 
     * @return List of all pipeline configurations
     */
    List<PipelineConfig> findAllByOrderByOrderIndexAsc();
    
    /**
     * Find pipeline configurations that have no dependencies
     * 
     * @return List of pipeline configurations with no dependencies
     */
    @Query("SELECT p FROM PipelineConfig p WHERE p.active = true AND SIZE(p.dependencies) = 0 ORDER BY p.orderIndex ASC")
    List<PipelineConfig> findRootPipelines();
    
    /**
     * Find all active pipeline configurations that are not in the provided list of IDs
     * Useful for getting available dependencies for a pipeline
     * 
     * @param excludedIds List of pipeline IDs to exclude
     * @return List of available pipelines that can be dependencies
     */
    @Query("SELECT p FROM PipelineConfig p WHERE p.active = true AND p.id NOT IN :excludedIds ORDER BY p.orderIndex ASC")
    List<PipelineConfig> findAvailableDependencies(List<Long> excludedIds);

    /**
     * Check if any pipeline depends on the pipeline with the given ID
     * 
     * @param pipelineId ID of the pipeline to check
     * @return true if any pipeline depends on this one
     */
    @Query("SELECT CASE WHEN COUNT(p) > 0 THEN true ELSE false END FROM PipelineConfig p JOIN p.dependencies d WHERE d.id = :pipelineId")
    boolean hasDependents(Long pipelineId);
}
