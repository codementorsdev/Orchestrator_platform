package com.pipeline.orchestrator.repository;

import com.pipeline.orchestrator.model.PipelineRun;
import com.pipeline.orchestrator.model.PipelineStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for accessing and manipulating PipelineRun entities.
 */
@Repository
public interface PipelineRunRepository extends JpaRepository<PipelineRun, Long> {

    /**
     * Find all pipeline runs for a specific pipeline configuration
     * 
     * @param pipelineConfigId ID of the pipeline configuration
     * @param pageable Pagination information
     * @return Page of pipeline runs
     */
    Page<PipelineRun> findByPipelineConfigIdOrderByStartTimeDesc(Long pipelineConfigId, Pageable pageable);

    /**
     * Find all pipeline runs, ordered by start time descending
     * 
     * @param pageable Pagination information
     * @return Page of pipeline runs
     */
    Page<PipelineRun> findAllByOrderByStartTimeDesc(Pageable pageable);

    /**
     * Find all pipeline runs with a specific status
     * 
     * @param status Status to filter by
     * @return List of pipeline runs with the given status
     */
    List<PipelineRun> findByStatus(PipelineStatus status);

    /**
     * Find all non-terminal pipeline runs (those that are still in progress)
     * 
     * @return List of active pipeline runs
     */
    @Query("SELECT pr FROM PipelineRun pr WHERE pr.status IN ('PENDING', 'RUNNING', 'WAITING', 'MANUAL')")
    List<PipelineRun> findActivePipelineRuns();

    /**
     * Find the most recent run for a pipeline configuration
     * 
     * @param pipelineConfigId ID of the pipeline configuration
     * @return Optional containing the most recent run, if any
     */
    Optional<PipelineRun> findFirstByPipelineConfigIdOrderByStartTimeDesc(Long pipelineConfigId);

    /**
     * Find pipeline runs that started after a certain time
     * 
     * @param startTime Time threshold
     * @return List of pipeline runs that started after the given time
     */
    List<PipelineRun> findByStartTimeAfter(LocalDateTime startTime);

    /**
     * Find pipeline runs for a specific GitLab pipeline ID
     * 
     * @param gitlabPipelineId GitLab's pipeline ID
     * @return Optional containing the pipeline run, if any
     */
    Optional<PipelineRun> findByGitlabPipelineId(Integer gitlabPipelineId);
}
