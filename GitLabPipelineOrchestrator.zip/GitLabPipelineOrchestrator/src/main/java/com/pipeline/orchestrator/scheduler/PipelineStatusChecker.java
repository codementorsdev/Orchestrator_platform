package com.pipeline.orchestrator.scheduler;

import com.pipeline.orchestrator.service.PipelineOrchestrationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Scheduler for checking pipeline statuses and triggering dependent pipelines.
 */
@Component
public class PipelineStatusChecker {

    private static final Logger logger = LoggerFactory.getLogger(PipelineStatusChecker.class);
    
    private final PipelineOrchestrationService pipelineOrchestrationService;

    @Autowired
    public PipelineStatusChecker(PipelineOrchestrationService pipelineOrchestrationService) {
        this.pipelineOrchestrationService = pipelineOrchestrationService;
    }

    /**
     * Periodically check pipeline statuses and update them from GitLab.
     * Runs every 30 seconds.
     */
    @Scheduled(fixedRate = 30000)
    public void updatePipelineStatuses() {
        logger.debug("Scheduled task: updating pipeline statuses");
        try {
            pipelineOrchestrationService.updatePipelineStatuses();
        } catch (Exception e) {
            logger.error("Error during scheduled pipeline status update", e);
        }
    }

    /**
     * Periodically check for completed pipelines and trigger dependent pipelines.
     * Runs every 45 seconds.
     */
    @Scheduled(fixedRate = 45000)
    public void checkPipelinesAndTriggerDependents() {
        logger.debug("Scheduled task: checking pipelines and triggering dependents");
        try {
            pipelineOrchestrationService.checkPipelinesAndTriggerDependents();
        } catch (Exception e) {
            logger.error("Error during scheduled pipeline dependency check", e);
        }
    }
}
