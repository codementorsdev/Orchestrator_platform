package com.pipeline.orchestrator.service;

import org.gitlab4j.api.models.Pipeline;
import org.gitlab4j.api.models.Project;
import java.util.List;

/**
 * Service interface for GitLab API operations.
 */
public interface GitLabService {

    /**
     * Get a list of all projects the authenticated user has access to
     * 
     * @return List of GitLab projects
     */
    List<Project> getAllProjects();

    /**
     * Get a specific project by ID
     * 
     * @param projectId GitLab project ID
     * @return Project information
     */
    Project getProject(Integer projectId);

    /**
     * Get a list of branches for a project
     * 
     * @param projectId GitLab project ID
     * @return List of branch names
     */
    List<String> getProjectBranches(Integer projectId);

    /**
     * Trigger a pipeline in a specific project and branch
     * 
     * @param projectId GitLab project ID
     * @param branchName Branch name
     * @return Pipeline object containing the created pipeline info
     */
    Pipeline triggerPipeline(Integer projectId, String branchName);

    /**
     * Get a specific pipeline by ID
     * 
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @return Pipeline information
     */
    Pipeline getPipeline(Integer projectId, Integer pipelineId);

    /**
     * Get the URL for a pipeline in the GitLab web interface
     * 
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @return Web URL for the pipeline
     */
    String getPipelineWebUrl(Integer projectId, Integer pipelineId);

    /**
     * Cancel a running pipeline
     * 
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @return Updated pipeline information
     */
    Pipeline cancelPipeline(Integer projectId, Integer pipelineId);

    /**
     * Retry a failed pipeline
     * 
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @return Updated pipeline information
     */
    Pipeline retryPipeline(Integer projectId, Integer pipelineId);
}
