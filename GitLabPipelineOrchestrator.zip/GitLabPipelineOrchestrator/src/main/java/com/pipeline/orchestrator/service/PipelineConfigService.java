package com.pipeline.orchestrator.service;

import com.pipeline.orchestrator.model.PipelineConfig;
import com.pipeline.orchestrator.model.dto.PipelineConfigDto;

import java.util.List;

/**
 * Service interface for managing pipeline configurations.
 */
public interface PipelineConfigService {

    /**
     * Get all pipeline configurations
     * 
     * @return List of all pipeline configs
     */
    List<PipelineConfig> getAllPipelineConfigs();

    /**
     * Get all active pipeline configurations
     * 
     * @return List of active pipeline configs
     */
    List<PipelineConfig> getActivePipelineConfigs();

    /**
     * Get a specific pipeline configuration by ID
     * 
     * @param id Pipeline config ID
     * @return Pipeline configuration
     */
    PipelineConfig getPipelineConfigById(Long id);

    /**
     * Create a new pipeline configuration
     * 
     * @param pipelineConfigDto DTO containing pipeline configuration data
     * @return Created pipeline configuration
     */
    PipelineConfig createPipelineConfig(PipelineConfigDto pipelineConfigDto);

    /**
     * Update an existing pipeline configuration
     * 
     * @param id Pipeline config ID
     * @param pipelineConfigDto DTO containing updated pipeline configuration data
     * @return Updated pipeline configuration
     */
    PipelineConfig updatePipelineConfig(Long id, PipelineConfigDto pipelineConfigDto);

    /**
     * Delete a pipeline configuration
     * 
     * @param id Pipeline config ID
     */
    void deletePipelineConfig(Long id);

    /**
     * Get pipeline configurations that have no dependencies (root pipelines)
     * 
     * @return List of root pipeline configurations
     */
    List<PipelineConfig> getRootPipelines();

    /**
     * Get available pipeline configurations that can be dependencies for a given pipeline
     * 
     * @param pipelineId Pipeline config ID
     * @return List of available pipeline configurations
     */
    List<PipelineConfig> getAvailableDependencies(Long pipelineId);

    /**
     * Check if a pipeline has any dependents
     * 
     * @param pipelineId Pipeline config ID
     * @return true if any pipeline depends on this one
     */
    boolean hasDependents(Long pipelineId);

    /**
     * Convert a pipeline config entity to a DTO
     * 
     * @param pipelineConfig Pipeline config entity
     * @return Pipeline config DTO
     */
    PipelineConfigDto convertToDto(PipelineConfig pipelineConfig);
}
