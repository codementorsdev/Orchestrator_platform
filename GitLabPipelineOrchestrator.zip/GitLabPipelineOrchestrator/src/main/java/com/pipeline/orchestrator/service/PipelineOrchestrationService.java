package com.pipeline.orchestrator.service;

import com.pipeline.orchestrator.model.PipelineRun;
import com.pipeline.orchestrator.model.dto.PipelineRunDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * Service interface for orchestrating and monitoring pipeline runs.
 */
public interface PipelineOrchestrationService {

    /**
     * Trigger execution of all root pipelines
     * 
     * @return List of created pipeline runs
     */
    List<PipelineRun> triggerRootPipelines();

    /**
     * Trigger execution of a specific pipeline
     * 
     * @param pipelineConfigId Pipeline config ID
     * @return Created pipeline run
     */
    PipelineRun triggerPipeline(Long pipelineConfigId);

    /**
     * Retry a failed pipeline run
     * 
     * @param pipelineRunId Pipeline run ID
     * @return Updated pipeline run
     */
    PipelineRun retryPipeline(Long pipelineRunId);

    /**
     * Cancel a running pipeline
     * 
     * @param pipelineRunId Pipeline run ID
     * @return Updated pipeline run
     */
    PipelineRun cancelPipeline(Long pipelineRunId);

    /**
     * Get a pipeline run by ID
     * 
     * @param pipelineRunId Pipeline run ID
     * @return Pipeline run
     */
    PipelineRun getPipelineRun(Long pipelineRunId);

    /**
     * Get all pipeline runs with pagination
     * 
     * @param pageable Pagination information
     * @return Page of pipeline runs
     */
    Page<PipelineRunDto> getAllPipelineRuns(Pageable pageable);

    /**
     * Get pipeline runs for a specific pipeline configuration
     * 
     * @param pipelineConfigId Pipeline config ID
     * @param pageable Pagination information
     * @return Page of pipeline runs
     */
    Page<PipelineRunDto> getPipelineRunsByConfigId(Long pipelineConfigId, Pageable pageable);

    /**
     * Check for pipeline runs that have completed and trigger their dependent pipelines
     */
    void checkPipelinesAndTriggerDependents();

    /**
     * Update the status of active pipeline runs from GitLab
     */
    void updatePipelineStatuses();

    /**
     * Convert a pipeline run entity to a DTO
     * 
     * @param pipelineRun Pipeline run entity
     * @return Pipeline run DTO
     */
    PipelineRunDto convertToDto(PipelineRun pipelineRun);
}
