package com.pipeline.orchestrator.service.impl;

import com.pipeline.orchestrator.model.PipelineConfig;
import com.pipeline.orchestrator.model.dto.PipelineConfigDto;
import com.pipeline.orchestrator.repository.PipelineConfigRepository;
import com.pipeline.orchestrator.service.PipelineConfigService;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of pipeline configuration service.
 */
@Service
public class PipelineConfigServiceImpl implements PipelineConfigService {

    private static final Logger logger = LoggerFactory.getLogger(PipelineConfigServiceImpl.class);
    
    private final PipelineConfigRepository pipelineConfigRepository;

    @Autowired
    public PipelineConfigServiceImpl(PipelineConfigRepository pipelineConfigRepository) {
        this.pipelineConfigRepository = pipelineConfigRepository;
    }

    @Override
    public List<PipelineConfig> getAllPipelineConfigs() {
        logger.debug("Getting all pipeline configurations");
        return pipelineConfigRepository.findAllByOrderByOrderIndexAsc();
    }

    @Override
    public List<PipelineConfig> getActivePipelineConfigs() {
        logger.debug("Getting active pipeline configurations");
        return pipelineConfigRepository.findByActiveIsTrueOrderByOrderIndexAsc();
    }

    @Override
    public PipelineConfig getPipelineConfigById(Long id) {
        logger.debug("Getting pipeline configuration with ID: {}", id);
        return pipelineConfigRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Pipeline configuration not found with ID: " + id));
    }

    @Override
    @Transactional
    public PipelineConfig createPipelineConfig(PipelineConfigDto pipelineConfigDto) {
        logger.info("Creating new pipeline configuration: {}", pipelineConfigDto.getName());
        
        PipelineConfig pipelineConfig = new PipelineConfig();
        mapDtoToEntity(pipelineConfigDto, pipelineConfig);
        
        // Set creation timestamp
        pipelineConfig.setCreatedAt(LocalDateTime.now());
        pipelineConfig.setUpdatedAt(LocalDateTime.now());
        
        // Save the pipeline config first without dependencies
        PipelineConfig savedConfig = pipelineConfigRepository.save(pipelineConfig);
        
        // Set dependencies if any
        if (pipelineConfigDto.getDependencyIds() != null && !pipelineConfigDto.getDependencyIds().isEmpty()) {
            setDependencies(savedConfig, pipelineConfigDto.getDependencyIds());
            savedConfig = pipelineConfigRepository.save(savedConfig);
        }
        
        logger.info("Created pipeline configuration with ID: {}", savedConfig.getId());
        return savedConfig;
    }

    @Override
    @Transactional
    public PipelineConfig updatePipelineConfig(Long id, PipelineConfigDto pipelineConfigDto) {
        logger.info("Updating pipeline configuration with ID: {}", id);
        
        PipelineConfig existingConfig = getPipelineConfigById(id);
        mapDtoToEntity(pipelineConfigDto, existingConfig);
        
        // Update timestamp
        existingConfig.setUpdatedAt(LocalDateTime.now());
        
        // Update dependencies
        if (pipelineConfigDto.getDependencyIds() != null) {
            existingConfig.getDependencies().clear();
            setDependencies(existingConfig, pipelineConfigDto.getDependencyIds());
        }
        
        PipelineConfig updatedConfig = pipelineConfigRepository.save(existingConfig);
        logger.info("Updated pipeline configuration with ID: {}", updatedConfig.getId());
        return updatedConfig;
    }

    @Override
    @Transactional
    public void deletePipelineConfig(Long id) {
        logger.info("Deleting pipeline configuration with ID: {}", id);
        
        // Check if any pipeline depends on this one
        if (hasDependents(id)) {
            throw new IllegalStateException("Cannot delete pipeline configuration with ID: " + id 
                    + " because other pipelines depend on it");
        }
        
        PipelineConfig pipelineConfig = getPipelineConfigById(id);
        
        // Clear dependencies
        pipelineConfig.getDependencies().clear();
        pipelineConfigRepository.save(pipelineConfig);
        
        // Delete the pipeline config
        pipelineConfigRepository.delete(pipelineConfig);
        logger.info("Deleted pipeline configuration with ID: {}", id);
    }

    @Override
    public List<PipelineConfig> getRootPipelines() {
        logger.debug("Getting root pipeline configurations");
        return pipelineConfigRepository.findRootPipelines();
    }

    @Override
    public List<PipelineConfig> getAvailableDependencies(Long pipelineId) {
        logger.debug("Getting available dependencies for pipeline ID: {}", pipelineId);
        
        // A pipeline cannot depend on itself
        List<Long> excludedIds = new ArrayList<>();
        excludedIds.add(pipelineId);
        
        // Also need to exclude pipelines that would create circular dependencies
        // This is a simplified approach - for a full solution we'd need to check the entire dependency graph
        return pipelineConfigRepository.findAvailableDependencies(excludedIds);
    }

    @Override
    public boolean hasDependents(Long pipelineId) {
        logger.debug("Checking if pipeline ID: {} has dependents", pipelineId);
        return pipelineConfigRepository.hasDependents(pipelineId);
    }

    @Override
    public PipelineConfigDto convertToDto(PipelineConfig pipelineConfig) {
        PipelineConfigDto dto = new PipelineConfigDto();
        dto.setId(pipelineConfig.getId());
        dto.setName(pipelineConfig.getName());
        dto.setProjectId(pipelineConfig.getProjectId());
        dto.setProjectName(pipelineConfig.getProjectName());
        dto.setBranchName(pipelineConfig.getBranchName());
        dto.setDescription(pipelineConfig.getDescription());
        dto.setOrderIndex(pipelineConfig.getOrderIndex());
        dto.setActive(pipelineConfig.isActive());
        
        // Set dependency IDs
        if (pipelineConfig.getDependencies() != null) {
            dto.setDependencyIds(pipelineConfig.getDependencies().stream()
                    .map(PipelineConfig::getId)
                    .collect(Collectors.toList()));
        }
        
        return dto;
    }

    /**
     * Helper method to map DTO data to entity
     */
    private void mapDtoToEntity(PipelineConfigDto dto, PipelineConfig entity) {
        entity.setName(dto.getName());
        entity.setProjectId(dto.getProjectId());
        entity.setProjectName(dto.getProjectName());
        entity.setBranchName(dto.getBranchName());
        entity.setDescription(dto.getDescription());
        entity.setOrderIndex(dto.getOrderIndex());
        entity.setActive(dto.isActive());
    }

    /**
     * Helper method to set dependencies from a list of dependency IDs
     */
    private void setDependencies(PipelineConfig pipelineConfig, List<Long> dependencyIds) {
        if (dependencyIds != null) {
            for (Long dependencyId : dependencyIds) {
                // Skip if trying to add itself as a dependency
                if (pipelineConfig.getId() != null && pipelineConfig.getId().equals(dependencyId)) {
                    logger.warn("Attempting to add pipeline as its own dependency, skipping: {}", dependencyId);
                    continue;
                }
                
                pipelineConfigRepository.findById(dependencyId).ifPresent(pipelineConfig::addDependency);
            }
        }
    }
}
