package com.pipeline.orchestrator.service.impl;

import com.pipeline.orchestrator.model.PipelineConfig;
import com.pipeline.orchestrator.model.PipelineRun;
import com.pipeline.orchestrator.model.PipelineStatus;
import com.pipeline.orchestrator.model.dto.PipelineRunDto;
import com.pipeline.orchestrator.model.dto.PipelineStatusUpdateDto;
import com.pipeline.orchestrator.repository.PipelineConfigRepository;
import com.pipeline.orchestrator.repository.PipelineRunRepository;
import com.pipeline.orchestrator.service.GitLabService;
import com.pipeline.orchestrator.service.PipelineOrchestrationService;
import jakarta.persistence.EntityNotFoundException;
import org.gitlab4j.api.models.Pipeline;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Implementation of pipeline orchestration service.
 */
@Service
public class PipelineOrchestrationServiceImpl implements PipelineOrchestrationService {

    private static final Logger logger = LoggerFactory.getLogger(PipelineOrchestrationServiceImpl.class);
    
    private final PipelineConfigRepository pipelineConfigRepository;
    private final PipelineRunRepository pipelineRunRepository;
    private final GitLabService gitLabService;
    private final SimpMessagingTemplate messagingTemplate;

    @Autowired
    public PipelineOrchestrationServiceImpl(
            PipelineConfigRepository pipelineConfigRepository,
            PipelineRunRepository pipelineRunRepository,
            GitLabService gitLabService,
            SimpMessagingTemplate messagingTemplate) {
        this.pipelineConfigRepository = pipelineConfigRepository;
        this.pipelineRunRepository = pipelineRunRepository;
        this.gitLabService = gitLabService;
        this.messagingTemplate = messagingTemplate;
    }

    @Override
    @Transactional
    public List<PipelineRun> triggerRootPipelines() {
        logger.info("Triggering all root pipelines");
        List<PipelineConfig> rootPipelines = pipelineConfigRepository.findRootPipelines();
        List<PipelineRun> pipelineRuns = new ArrayList<>();
        
        for (PipelineConfig pipelineConfig : rootPipelines) {
            try {
                PipelineRun pipelineRun = triggerPipelineInternal(pipelineConfig);
                pipelineRuns.add(pipelineRun);
            } catch (Exception e) {
                logger.error("Failed to trigger pipeline for config ID: {}", pipelineConfig.getId(), e);
            }
        }
        
        logger.info("Triggered {} root pipelines", pipelineRuns.size());
        return pipelineRuns;
    }

    @Override
    @Transactional
    public PipelineRun triggerPipeline(Long pipelineConfigId) {
        logger.info("Triggering pipeline for config ID: {}", pipelineConfigId);
        PipelineConfig pipelineConfig = pipelineConfigRepository.findById(pipelineConfigId)
                .orElseThrow(() -> new EntityNotFoundException("Pipeline configuration not found with ID: " + pipelineConfigId));
        
        return triggerPipelineInternal(pipelineConfig);
    }

    /**
     * Internal method to trigger a pipeline execution
     */
    private PipelineRun triggerPipelineInternal(PipelineConfig pipelineConfig) {
        // Check if all dependencies have completed successfully
        if (!areDependenciesSatisfied(pipelineConfig)) {
            logger.info("Dependencies not satisfied for pipeline ID: {}, setting status to WAITING", pipelineConfig.getId());
            
            // Create a waiting pipeline run
            PipelineRun waitingRun = new PipelineRun();
            waitingRun.setPipelineConfig(pipelineConfig);
            waitingRun.setGitlabPipelineId(-1); // Placeholder ID for waiting pipelines
            waitingRun.setStatus(PipelineStatus.WAITING);
            waitingRun.setStartTime(LocalDateTime.now());
            waitingRun.setStatusDetail("Waiting for dependencies to complete");
            
            // Determine run order
            Integer runOrder = determineRunOrder();
            waitingRun.setRunOrder(runOrder);
            
            PipelineRun savedRun = pipelineRunRepository.save(waitingRun);
            logger.info("Created waiting pipeline run with ID: {} for config ID: {}", savedRun.getId(), pipelineConfig.getId());
            
            // Send update via WebSocket
            sendStatusUpdate(savedRun);
            
            return savedRun;
        }
        
        // All dependencies are satisfied, trigger the pipeline in GitLab
        logger.info("Triggering GitLab pipeline for project ID: {} on branch: {}", 
                pipelineConfig.getProjectId(), pipelineConfig.getBranchName());
        
        Pipeline gitlabPipeline = gitLabService.triggerPipeline(
                pipelineConfig.getProjectId(), 
                pipelineConfig.getBranchName());
        
        // Create and save the pipeline run
        PipelineRun pipelineRun = new PipelineRun();
        pipelineRun.setPipelineConfig(pipelineConfig);
        pipelineRun.setGitlabPipelineId(gitlabPipeline.getId().intValue());
        pipelineRun.setStatus(PipelineStatus.fromGitLabStatus(gitlabPipeline.getStatus()));
        pipelineRun.setStartTime(LocalDateTime.now());
        
        // Get and set the pipeline web URL
        String webUrl = gitLabService.getPipelineWebUrl(pipelineConfig.getProjectId(), gitlabPipeline.getId().intValue());
        pipelineRun.setWebUrl(webUrl);
        
        // Determine run order
        Integer runOrder = determineRunOrder();
        pipelineRun.setRunOrder(runOrder);
        
        PipelineRun savedRun = pipelineRunRepository.save(pipelineRun);
        logger.info("Created pipeline run with ID: {} for GitLab pipeline ID: {} with status: {}", 
                savedRun.getId(), gitlabPipeline.getId(), gitlabPipeline.getStatus());
        
        // Send update via WebSocket
        sendStatusUpdate(savedRun);
        
        return savedRun;
    }

    @Override
    @Transactional
    public PipelineRun retryPipeline(Long pipelineRunId) {
        logger.info("Retrying pipeline run with ID: {}", pipelineRunId);
        
        PipelineRun pipelineRun = getPipelineRun(pipelineRunId);
        
        // Only failed pipelines can be retried
        if (pipelineRun.getStatus() != PipelineStatus.FAILED && pipelineRun.getStatus() != PipelineStatus.ERROR) {
            throw new IllegalStateException("Cannot retry pipeline run with status: " + pipelineRun.getStatus());
        }
        
        // Retry in GitLab if it's a real GitLab pipeline
        if (pipelineRun.getGitlabPipelineId() > 0) {
            Pipeline retriedPipeline = gitLabService.retryPipeline(
                    pipelineRun.getPipelineConfig().getProjectId(),
                    pipelineRun.getGitlabPipelineId());
            
            pipelineRun.setStatus(PipelineStatus.fromGitLabStatus(retriedPipeline.getStatus()));
            pipelineRun.setEndTime(null);
            pipelineRun.setUpdatedAt(LocalDateTime.now());
            
            PipelineRun savedRun = pipelineRunRepository.save(pipelineRun);
            logger.info("Retried pipeline run with ID: {}, new status: {}", savedRun.getId(), savedRun.getStatus());
            
            // Send update via WebSocket
            sendStatusUpdate(savedRun);
            
            return savedRun;
        } else {
            // For waiting pipelines, just trigger a new pipeline
            return triggerPipeline(pipelineRun.getPipelineConfig().getId());
        }
    }

    @Override
    @Transactional
    public PipelineRun cancelPipeline(Long pipelineRunId) {
        logger.info("Cancelling pipeline run with ID: {}", pipelineRunId);
        
        PipelineRun pipelineRun = getPipelineRun(pipelineRunId);
        
        // Only running or pending pipelines can be canceled
        if (pipelineRun.getStatus() != PipelineStatus.RUNNING && pipelineRun.getStatus() != PipelineStatus.PENDING) {
            throw new IllegalStateException("Cannot cancel pipeline run with status: " + pipelineRun.getStatus());
        }
        
        // Cancel in GitLab if it's a real GitLab pipeline
        if (pipelineRun.getGitlabPipelineId() > 0) {
            Pipeline canceledPipeline = gitLabService.cancelPipeline(
                    pipelineRun.getPipelineConfig().getProjectId(),
                    pipelineRun.getGitlabPipelineId());
            
            pipelineRun.setStatus(PipelineStatus.CANCELED);
            pipelineRun.setEndTime(LocalDateTime.now());
            pipelineRun.setUpdatedAt(LocalDateTime.now());
            
            PipelineRun savedRun = pipelineRunRepository.save(pipelineRun);
            logger.info("Cancelled pipeline run with ID: {}", savedRun.getId());
            
            // Send update via WebSocket
            sendStatusUpdate(savedRun);
            
            return savedRun;
        } else {
            // For waiting pipelines, just mark as canceled
            pipelineRun.setStatus(PipelineStatus.CANCELED);
            pipelineRun.setEndTime(LocalDateTime.now());
            pipelineRun.setUpdatedAt(LocalDateTime.now());
            
            PipelineRun savedRun = pipelineRunRepository.save(pipelineRun);
            logger.info("Cancelled waiting pipeline run with ID: {}", savedRun.getId());
            
            // Send update via WebSocket
            sendStatusUpdate(savedRun);
            
            return savedRun;
        }
    }

    @Override
    public PipelineRun getPipelineRun(Long pipelineRunId) {
        logger.debug("Getting pipeline run with ID: {}", pipelineRunId);
        return pipelineRunRepository.findById(pipelineRunId)
                .orElseThrow(() -> new EntityNotFoundException("Pipeline run not found with ID: " + pipelineRunId));
    }

    @Override
    public Page<PipelineRunDto> getAllPipelineRuns(Pageable pageable) {
        logger.debug("Getting all pipeline runs with pagination");
        return pipelineRunRepository.findAllByOrderByStartTimeDesc(pageable)
                .map(this::convertToDto);
    }

    @Override
    public Page<PipelineRunDto> getPipelineRunsByConfigId(Long pipelineConfigId, Pageable pageable) {
        logger.debug("Getting pipeline runs for config ID: {} with pagination", pipelineConfigId);
        return pipelineRunRepository.findByPipelineConfigIdOrderByStartTimeDesc(pipelineConfigId, pageable)
                .map(this::convertToDto);
    }

    @Override
    @Transactional
    public void checkPipelinesAndTriggerDependents() {
        logger.debug("Checking completed pipelines and triggering dependents");
        
        // Get all active pipeline runs
        List<PipelineRun> activePipelineRuns = pipelineRunRepository.findActivePipelineRuns();
        
        for (PipelineRun pipelineRun : activePipelineRuns) {
            // Update the status from GitLab for running pipelines
            if (pipelineRun.getStatus() == PipelineStatus.RUNNING || pipelineRun.getStatus() == PipelineStatus.PENDING) {
                try {
                    updatePipelineRunStatus(pipelineRun);
                } catch (Exception e) {
                    logger.error("Failed to update status for pipeline run ID: {}", pipelineRun.getId(), e);
                }
            }
            // Check if waiting pipelines can now run because their dependencies are satisfied
            else if (pipelineRun.getStatus() == PipelineStatus.WAITING) {
                try {
                    if (areDependenciesSatisfied(pipelineRun.getPipelineConfig())) {
                        logger.info("Dependencies now satisfied for pipeline run ID: {}, triggering", pipelineRun.getId());
                        
                        // Trigger the GitLab pipeline
                        Pipeline gitlabPipeline = gitLabService.triggerPipeline(
                                pipelineRun.getPipelineConfig().getProjectId(), 
                                pipelineRun.getPipelineConfig().getBranchName());
                        
                        // Update the pipeline run with the GitLab pipeline ID
                        pipelineRun.setGitlabPipelineId(gitlabPipeline.getId().intValue());
                        pipelineRun.setStatus(PipelineStatus.fromGitLabStatus(gitlabPipeline.getStatus()));
                        
                        // Get and set the pipeline web URL
                        String webUrl = gitLabService.getPipelineWebUrl(
                                pipelineRun.getPipelineConfig().getProjectId(), 
                                gitlabPipeline.getId().intValue());
                        pipelineRun.setWebUrl(webUrl);
                        
                        pipelineRunRepository.save(pipelineRun);
                        
                        // Send update via WebSocket
                        sendStatusUpdate(pipelineRun);
                    }
                } catch (Exception e) {
                    logger.error("Failed to trigger waiting pipeline run ID: {}", pipelineRun.getId(), e);
                }
            }
        }
    }

    @Override
    @Transactional
    public void updatePipelineStatuses() {
        logger.debug("Updating status of active pipeline runs");
        
        List<PipelineRun> activePipelineRuns = pipelineRunRepository.findActivePipelineRuns();
        
        for (PipelineRun pipelineRun : activePipelineRuns) {
            // Skip waiting pipelines, they're handled in checkPipelinesAndTriggerDependents
            if (pipelineRun.getStatus() == PipelineStatus.WAITING) {
                continue;
            }
            
            try {
                updatePipelineRunStatus(pipelineRun);
            } catch (Exception e) {
                logger.error("Failed to update status for pipeline run ID: {}", pipelineRun.getId(), e);
            }
        }
    }

    @Override
    public PipelineRunDto convertToDto(PipelineRun pipelineRun) {
        PipelineRunDto dto = new PipelineRunDto();
        dto.setId(pipelineRun.getId());
        dto.setPipelineConfigId(pipelineRun.getPipelineConfig().getId());
        dto.setPipelineName(pipelineRun.getPipelineConfig().getName());
        dto.setProjectName(pipelineRun.getPipelineConfig().getProjectName());
        dto.setGitlabPipelineId(pipelineRun.getGitlabPipelineId());
        dto.setStatus(pipelineRun.getStatus());
        dto.setStatusDetail(pipelineRun.getStatusDetail());
        dto.setStartTime(pipelineRun.getStartTime());
        dto.setEndTime(pipelineRun.getEndTime());
        dto.setDurationInSeconds(pipelineRun.getDurationInSeconds());
        dto.setRunOrder(pipelineRun.getRunOrder());
        dto.setWebUrl(pipelineRun.getWebUrl());
        dto.setBranchName(pipelineRun.getPipelineConfig().getBranchName());
        
        return dto;
    }

    /**
     * Update the status of a pipeline run from GitLab
     */
    private void updatePipelineRunStatus(PipelineRun pipelineRun) {
        // Skip if not a real GitLab pipeline
        if (pipelineRun.getGitlabPipelineId() <= 0) {
            return;
        }
        
        try {
            Pipeline gitlabPipeline = gitLabService.getPipeline(
                    pipelineRun.getPipelineConfig().getProjectId(),
                    pipelineRun.getGitlabPipelineId());
            
            PipelineStatus newStatus = PipelineStatus.fromGitLabStatus(gitlabPipeline.getStatus());
            
            // If status has changed
            if (pipelineRun.getStatus() != newStatus) {
                logger.info("Status changed for pipeline run ID: {} from {} to {}", 
                        pipelineRun.getId(), pipelineRun.getStatus(), newStatus);
                
                pipelineRun.setStatus(newStatus);
                
                // Set end time if terminal status
                if (newStatus.isTerminal()) {
                    pipelineRun.setEndTime(LocalDateTime.now());
                }
                
                pipelineRunRepository.save(pipelineRun);
                
                // Send update via WebSocket
                sendStatusUpdate(pipelineRun);
                
                // If pipeline completed successfully, check and trigger dependent pipelines
                if (newStatus.isSuccess()) {
                    triggerDependentPipelines(pipelineRun.getPipelineConfig());
                }
            }
        } catch (Exception e) {
            logger.error("Error updating pipeline status for run ID: {}", pipelineRun.getId(), e);
        }
    }

    /**
     * Trigger pipelines that depend on the completed pipeline
     */
    private void triggerDependentPipelines(PipelineConfig completedPipeline) {
        logger.info("Checking for dependent pipelines to trigger for config ID: {}", completedPipeline.getId());
        
        // Get all active pipeline configs
        List<PipelineConfig> allPipelines = pipelineConfigRepository.findByActiveIsTrueOrderByOrderIndexAsc();
        
        // Find pipelines that depend on the completed pipeline
        List<PipelineConfig> dependentPipelines = allPipelines.stream()
                .filter(pipeline -> pipeline.getDependencies().contains(completedPipeline))
                .collect(Collectors.toList());
        
        logger.info("Found {} pipelines that depend on config ID: {}", dependentPipelines.size(), completedPipeline.getId());
        
        // For each dependent pipeline, check if a waiting run exists or create a new one
        for (PipelineConfig dependentPipeline : dependentPipelines) {
            try {
                // Check if there's a waiting run for this pipeline
                List<PipelineRun> waitingRuns = pipelineRunRepository.findByStatus(PipelineStatus.WAITING).stream()
                        .filter(run -> run.getPipelineConfig().getId().equals(dependentPipeline.getId()))
                        .collect(Collectors.toList());
                
                if (!waitingRuns.isEmpty()) {
                    // Check if all dependencies are now satisfied
                    if (areDependenciesSatisfied(dependentPipeline)) {
                        logger.info("Dependencies satisfied for waiting pipeline run, triggering for config ID: {}", 
                                dependentPipeline.getId());
                        
                        // Use the first waiting run (there should be only one)
                        PipelineRun waitingRun = waitingRuns.get(0);
                        
                        // Trigger the GitLab pipeline
                        Pipeline gitlabPipeline = gitLabService.triggerPipeline(
                                dependentPipeline.getProjectId(), 
                                dependentPipeline.getBranchName());
                        
                        // Update the waiting run
                        waitingRun.setGitlabPipelineId(gitlabPipeline.getId().intValue());
                        waitingRun.setStatus(PipelineStatus.fromGitLabStatus(gitlabPipeline.getStatus()));
                        waitingRun.setStatusDetail(null);
                        
                        // Get and set the pipeline web URL
                        String webUrl = gitLabService.getPipelineWebUrl(
                                dependentPipeline.getProjectId(), 
                                gitlabPipeline.getId().intValue());
                        waitingRun.setWebUrl(webUrl);
                        
                        pipelineRunRepository.save(waitingRun);
                        
                        // Send update via WebSocket
                        sendStatusUpdate(waitingRun);
                    }
                } else {
                    // No waiting run exists, create a new one (either waiting or running)
                    triggerPipelineInternal(dependentPipeline);
                }
            } catch (Exception e) {
                logger.error("Failed to trigger dependent pipeline for config ID: {}", dependentPipeline.getId(), e);
            }
        }
    }

    /**
     * Check if all dependencies for a pipeline have completed successfully
     */
    private boolean areDependenciesSatisfied(PipelineConfig pipelineConfig) {
        // Get all dependencies
        List<PipelineConfig> dependencies = pipelineConfig.getDependencies();
        
        // No dependencies means all are satisfied
        if (dependencies.isEmpty()) {
            return true;
        }
        
        // Check each dependency for a successful run
        for (PipelineConfig dependency : dependencies) {
            Optional<PipelineRun> latestRun = pipelineRunRepository.findFirstByPipelineConfigIdOrderByStartTimeDesc(dependency.getId());
            
            // If no run exists for a dependency, or the latest run wasn't successful, dependencies are not satisfied
            if (latestRun.isEmpty() || !latestRun.get().getStatus().isSuccess()) {
                return false;
            }
        }
        
        // All dependencies have successful runs
        return true;
    }

    /**
     * Determine the run order for a new pipeline run
     */
    private Integer determineRunOrder() {
        return (int) (pipelineRunRepository.count() + 1);
    }

    /**
     * Send a status update via WebSocket
     */
    private void sendStatusUpdate(PipelineRun pipelineRun) {
        PipelineStatusUpdateDto updateDto = new PipelineStatusUpdateDto();
        updateDto.setPipelineRunId(pipelineRun.getId());
        updateDto.setStatus(pipelineRun.getStatus());
        updateDto.setStatusDetail(pipelineRun.getStatusDetail());
        
        // Format duration and end time
        if (pipelineRun.getEndTime() != null) {
            updateDto.setFormattedEndTime(pipelineRun.getEndTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            
            if (pipelineRun.getStartTime() != null) {
                long durationSeconds = java.time.Duration.between(pipelineRun.getStartTime(), pipelineRun.getEndTime()).getSeconds();
                updateDto.setFormattedDuration(formatDuration(durationSeconds));
            }
        } else {
            updateDto.setFormattedEndTime("Running");
            updateDto.setFormattedDuration("Running");
        }
        
        // Send to topic
        messagingTemplate.convertAndSend("/topic/pipeline-updates", updateDto);
    }

    /**
     * Format duration in seconds to a readable string
     */
    private String formatDuration(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        
        if (hours > 0) {
            return String.format("%dh %dm %ds", hours, minutes, secs);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, secs);
        } else {
            return String.format("%ds", secs);
        }
    }
}
