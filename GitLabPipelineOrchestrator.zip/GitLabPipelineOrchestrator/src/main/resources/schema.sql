-- This file contains initial schema setup for PostgreSQL

-- Pipeline Config Table
CREATE TABLE IF NOT EXISTS pipeline_configs (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    project_id INTEGER NOT NULL,
    project_name VARCHAR(255) NOT NULL,
    branch_name VARCHAR(255) NOT NULL,
    description TEXT,
    order_index INTEGER NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL
);

-- Pipeline Dependencies Join Table
CREATE TABLE IF NOT EXISTS pipeline_dependencies (
    pipeline_id BIGINT NOT NULL,
    dependency_id BIGINT NOT NULL,
    PRIMARY KEY (pipeline_id, dependency_id),
    CONSTRAINT fk_pipeline_id FOREIGN KEY (pipeline_id) REFERENCES pipeline_configs(id),
    CONSTRAINT fk_dependency_id FOREIGN KEY (dependency_id) REFERENCES pipeline_configs(id),
    CONSTRAINT pipeline_dependency_not_self CHECK (pipeline_id != dependency_id)
);

-- Pipeline Run Table
CREATE TABLE IF NOT EXISTS pipeline_runs (
    id SERIAL PRIMARY KEY,
    pipeline_config_id BIGINT NOT NULL REFERENCES pipeline_configs(id),
    gitlab_pipeline_id INTEGER NOT NULL,
    status VARCHAR(50) NOT NULL,
    status_detail VARCHAR(255),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    run_order INTEGER,
    web_url VARCHAR(255),
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    CONSTRAINT unique_gitlab_pipeline_id UNIQUE (gitlab_pipeline_id)
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_pipeline_configs_active ON pipeline_configs(active);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_status ON pipeline_runs(status);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_config_id ON pipeline_runs(pipeline_config_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_start_time ON pipeline_runs(start_time DESC);
