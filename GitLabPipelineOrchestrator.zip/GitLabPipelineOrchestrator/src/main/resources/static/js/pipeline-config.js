/**
 * JavaScript for pipeline configuration management
 */
$(document).ready(function() {
    // Global variables
    let projects = [];
    let branches = [];
    
    // Initialize event handlers
    initEventHandlers();
    
    /**
     * Initialize all event handlers
     */
    function initEventHandlers() {
        // Add pipeline button click
        $('#btnAddPipeline').on('click', function() {
            loadPipelineForm();
        });
        
        // Edit pipeline button click (using event delegation)
        $(document).on('click', '.btn-edit-pipeline', function() {
            const pipelineId = $(this).data('id');
            loadPipelineForm(pipelineId);
        });
        
        // Delete pipeline form submit (using event delegation)
        $(document).on('submit', '.delete-pipeline-form', function(e) {
            if (!confirm('Are you sure you want to delete this pipeline configuration?')) {
                e.preventDefault();
            }
        });
        
        // Project selection change
        $(document).on('change', '#projectId', function() {
            const projectId = $(this).val();
            if (projectId) {
                const selectedProject = projects.find(p => p.id == projectId);
                if (selectedProject) {
                    $('#projectName').val(selectedProject.name);
                }
                loadBranches(projectId);
            } else {
                $('#projectName').val('');
                $('#branchName').empty().append('<option value="">Select a branch</option>');
            }
        });
        
        // Dependency select change
        $(document).on('change', '#dependencySelect', function() {
            const dependencyId = $(this).val();
            if (dependencyId) {
                const dependencyName = $(this).find('option:selected').text();
                addDependency(dependencyId, dependencyName);
                $(this).val(''); // Reset select
            }
        });
        
        // Remove dependency button click
        $(document).on('click', '.btn-remove-dependency', function() {
            $(this).closest('.selected-dependency').remove();
        });
    }
    
    /**
     * Load the pipeline configuration form
     * @param {number} pipelineId - Pipeline ID for editing, or undefined for new pipeline
     */
    function loadPipelineForm(pipelineId) {
        const url = pipelineId ? `/config/${pipelineId}/edit` : '/config/new';
        
        $('#pipelineModalLabel').text(pipelineId ? 'Edit Pipeline Configuration' : 'Add Pipeline Configuration');
        
        // Show loading indicator
        $('#formContainer').html('<div class="text-center py-4"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">Loading form...</p></div>');
        
        // Show modal
        const pipelineModal = new bootstrap.Modal(document.getElementById('pipelineModal'));
        pipelineModal.show();
        
        // Load form content
        $.ajax({
            url: url,
            method: 'GET',
            success: function(response) {
                $('#formContainer').html(response);
                
                // Load projects if it's a new form or we don't have projects yet
                if (!pipelineId || projects.length === 0) {
                    loadProjects();
                } else {
                    // For edit form, set the selected project and load branches
                    const projectId = $('#projectId').val();
                    if (projectId) {
                        loadBranches(projectId);
                    }
                }
            },
            error: function(xhr) {
                $('#formContainer').html('<div class="alert alert-danger">Failed to load form. Please try again.</div>');
                console.error('Error loading form:', xhr);
            }
        });
    }
    
    /**
     * Load GitLab projects
     */
    function loadProjects() {
        $.ajax({
            url: '/config/gitlab/projects',
            method: 'GET',
            beforeSend: function() {
                $('#projectId').prop('disabled', true);
                $('#projectId').html('<option value="">Loading projects...</option>');
            },
            success: function(data) {
                projects = data;
                
                // Populate project dropdown
                $('#projectId').empty().append('<option value="">Select a project</option>');
                projects.forEach(function(project) {
                    const option = $('<option></option>')
                        .val(project.id)
                        .text(`${project.name} (${project.pathWithNamespace})`);
                    
                    // If we're editing, select the current project
                    if ($('#projectId').data('value') == project.id) {
                        option.prop('selected', true);
                    }
                    
                    $('#projectId').append(option);
                });
                
                // If a project is already selected (in edit mode), load its branches
                const selectedProjectId = $('#projectId').val();
                if (selectedProjectId) {
                    loadBranches(selectedProjectId);
                }
            },
            error: function(xhr) {
                console.error('Error loading projects:', xhr);
                $('#projectId').html('<option value="">Failed to load projects</option>');
            },
            complete: function() {
                $('#projectId').prop('disabled', false);
            }
        });
    }
    
    /**
     * Load branches for a project
     * @param {number} projectId - GitLab project ID
     */
    function loadBranches(projectId) {
        $.ajax({
            url: `/config/gitlab/projects/${projectId}/branches`,
            method: 'GET',
            beforeSend: function() {
                $('#branchName').prop('disabled', true);
                $('#branchName').html('<option value="">Loading branches...</option>');
            },
            success: function(data) {
                branches = data;
                
                // Populate branch dropdown
                $('#branchName').empty().append('<option value="">Select a branch</option>');
                branches.forEach(function(branch) {
                    const option = $('<option></option>')
                        .val(branch)
                        .text(branch);
                    
                    // If we're editing, select the current branch
                    if ($('#branchName').data('value') == branch) {
                        option.prop('selected', true);
                    }
                    
                    $('#branchName').append(option);
                });
            },
            error: function(xhr) {
                console.error('Error loading branches:', xhr);
                $('#branchName').html('<option value="">Failed to load branches</option>');
            },
            complete: function() {
                $('#branchName').prop('disabled', false);
            }
        });
    }
    
    /**
     * Add a dependency to the list
     * @param {number} id - Dependency pipeline ID
     * @param {string} name - Dependency pipeline name
     */
    function addDependency(id, name) {
        // Check if this dependency is already selected
        const existingDep = $(`#selectedDependencies input[value="${id}"]`);
        if (existingDep.length > 0) {
            return; // Already added
        }
        
        const dependencyHtml = `
            <div class="selected-dependency mb-1">
                <input type="hidden" name="dependencyIds" value="${id}">
                <span class="badge bg-primary me-1">${name}</span>
                <button type="button" class="btn btn-sm btn-outline-danger btn-remove-dependency">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        $('#selectedDependencies').append(dependencyHtml);
    }
});
