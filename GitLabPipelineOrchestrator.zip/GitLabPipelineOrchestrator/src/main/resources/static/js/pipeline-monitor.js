/**
 * JavaScript for pipeline monitoring page
 */
$(document).ready(function() {
    // Current filter state
    let currentPage = 0;
    let currentConfigId = '';
    
    // Initialize event handlers
    initEventHandlers();
    
    /**
     * Initialize all event handlers
     */
    function initEventHandlers() {
        // Refresh button click
        $('#btnRefresh').on('click', function() {
            refreshPipelineData();
        });
        
        // Config filter change
        $('#configFilter').on('change', function() {
            currentConfigId = $(this).val();
            currentPage = 0;
            if (currentConfigId) {
                filterByConfig(currentConfigId);
            } else {
                loadPipelineRuns(0);
            }
        });
        
        // Pagination click (using event delegation)
        $(document).on('click', '.pagination .page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page !== undefined && page !== currentPage) {
                currentPage = page;
                if (currentConfigId) {
                    filterByConfig(currentConfigId);
                } else {
                    loadPipelineRuns(page);
                }
            }
        });
        
        // View details button click (using event delegation)
        $(document).on('click', '.btn-view-details', function() {
            const pipelineId = $(this).data('id');
            loadPipelineDetails(pipelineId);
        });
    }
    
    /**
     * Load pipeline runs with pagination
     * @param {number} page - Page number (0-based)
     */
    function loadPipelineRuns(page) {
        $.ajax({
            url: `/pipelines/load-more?page=${page}`,
            method: 'GET',
            beforeSend: function() {
                $('#pipeline-runs-container').addClass('loading');
            },
            success: function(response) {
                $('#pipeline-runs-container').html(response);
                currentPage = page;
            },
            error: function(xhr) {
                console.error('Error loading pipeline runs:', xhr);
                $('#pipeline-runs-container').html('<div class="alert alert-danger">Failed to load pipeline runs. Please try again.</div>');
            },
            complete: function() {
                $('#pipeline-runs-container').removeClass('loading');
            }
        });
    }
    
    /**
     * Filter pipeline runs by configuration
     * @param {number} configId - Pipeline configuration ID
     */
    function filterByConfig(configId) {
        $.ajax({
            url: `/pipelines/filter?configId=${configId}&page=${currentPage}`,
            method: 'GET',
            beforeSend: function() {
                $('#pipeline-runs-container').addClass('loading');
            },
            success: function(response) {
                $('#pipeline-runs-container').html(response);
            },
            error: function(xhr) {
                console.error('Error filtering pipeline runs:', xhr);
                $('#pipeline-runs-container').html('<div class="alert alert-danger">Failed to filter pipeline runs. Please try again.</div>');
            },
            complete: function() {
                $('#pipeline-runs-container').removeClass('loading');
            }
        });
    }
    
    /**
     * Load details for a specific pipeline run
     * @param {number} pipelineId - Pipeline run ID
     */
    function loadPipelineDetails(pipelineId) {
        // Reset and show modal
        $('#pipelineDetails').html(`
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p>Loading pipeline details...</p>
            </div>
        `);
        
        const detailsModal = new bootstrap.Modal(document.getElementById('pipelineDetailsModal'));
        detailsModal.show();
        
        // Fetch pipeline details
        $.ajax({
            url: `/pipelines/${pipelineId}`,
            method: 'GET',
            success: function(data) {
                renderPipelineDetails(data);
            },
            error: function(xhr) {
                console.error('Error loading pipeline details:', xhr);
                $('#pipelineDetails').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> Failed to load pipeline details.
                    </div>
                `);
            }
        });
    }
    
    /**
     * Render pipeline details in the modal
     * @param {Object} pipeline - Pipeline run data
     */
    function renderPipelineDetails(pipeline) {
        const detailsHtml = `
            <div class="card mb-3">
                <div class="card-header bg-light">
                    <h5 class="mb-0">${pipeline.pipelineName}</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Status</h6>
                            <span class="badge ${pipeline.statusClass}">${pipeline.status.displayName}</span>
                            ${pipeline.statusDetail ? `<p class="text-muted small mt-1">${pipeline.statusDetail}</p>` : ''}
                        </div>
                        <div class="col-md-6">
                            <h6>GitLab Pipeline ID</h6>
                            <p>${pipeline.gitlabPipelineId > 0 ? pipeline.gitlabPipelineId : 'N/A'}</p>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Project</h6>
                            <p>${pipeline.projectName}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Branch</h6>
                            <p>${pipeline.branchName}</p>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Start Time</h6>
                            <p>${pipeline.formattedStartTime}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>End Time</h6>
                            <p>${pipeline.formattedEndTime}</p>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Duration</h6>
                            <p>${pipeline.formattedDuration}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Run Order</h6>
                            <p>${pipeline.runOrder || 'N/A'}</p>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between">
                        <div>
                            ${pipeline.webUrl ? `<a href="${pipeline.webUrl}" target="_blank" class="btn btn-sm btn-primary">
                                <i class="fas fa-external-link-alt"></i> Open in GitLab
                            </a>` : ''}
                        </div>
                        <div>
                            ${pipeline.status.name === 'FAILED' || pipeline.status.name === 'ERROR' ? 
                                `<form action="/pipelines/${pipeline.id}/retry" method="post" class="d-inline">
                                    <button type="submit" class="btn btn-sm btn-warning">
                                        <i class="fas fa-redo"></i> Retry
                                    </button>
                                </form>` : ''}
                            
                            ${pipeline.status.name === 'RUNNING' || pipeline.status.name === 'PENDING' ? 
                                `<form action="/pipelines/${pipeline.id}/cancel" method="post" class="d-inline">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-stop-circle"></i> Cancel
                                    </button>
                                </form>` : ''}
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('#pipelineDetails').html(detailsHtml);
    }
    
    /**
     * Refresh pipeline data
     */
    function refreshPipelineData() {
        if (currentConfigId) {
            filterByConfig(currentConfigId);
        } else {
            loadPipelineRuns(currentPage);
        }
    }
    
    /**
     * Update a specific pipeline run row with new status
     * @param {Object} updateData - Pipeline status update data
     */
    function updatePipelineStatus(updateData) {
        const pipelineRow = $(`#pipeline-run-${updateData.pipelineRunId}`);
        if (pipelineRow.length > 0) {
            // Update status badge
            const statusCell = pipelineRow.find('td:nth-child(5)');
            statusCell.html(`
                <span class="badge ${updateData.statusClass}">${updateData.status.displayName}</span>
                ${updateData.statusDetail ? `<small class="d-block text-muted">${updateData.statusDetail}</small>` : ''}
            `);
            
            // Update duration
            pipelineRow.find('td:nth-child(7)').text(updateData.formattedDuration);
            
            // Update action buttons based on new status
            const actionsCell = pipelineRow.find('td:last-child');
            const viewDetailsBtn = actionsCell.find('.btn-view-details').clone();
            const gitlabLink = actionsCell.find('a[target="_blank"]').clone();
            
            actionsCell.empty().append(viewDetailsBtn);
            if (gitlabLink.length > 0) {
                actionsCell.append(gitlabLink);
            }
            
            // Add retry button for failed pipelines
            if (updateData.status.name === 'FAILED' || updateData.status.name === 'ERROR') {
                actionsCell.append(`
                    <form action="/pipelines/${updateData.pipelineRunId}/retry" method="post" class="d-inline">
                        <button type="submit" class="btn btn-outline-warning btn-sm" title="Retry Pipeline">
                            <i class="fas fa-redo"></i>
                        </button>
                    </form>
                `);
            }
            
            // Add cancel button for running pipelines
            if (updateData.status.name === 'RUNNING' || updateData.status.name === 'PENDING') {
                actionsCell.append(`
                    <form action="/pipelines/${updateData.pipelineRunId}/cancel" method="post" class="d-inline">
                        <button type="submit" class="btn btn-outline-danger btn-sm" title="Cancel Pipeline">
                            <i class="fas fa-stop-circle"></i>
                        </button>
                    </form>
                `);
            }
        }
    }
    
    // Make updatePipelineStatus function available globally
    window.updatePipelineStatus = updatePipelineStatus;
});
