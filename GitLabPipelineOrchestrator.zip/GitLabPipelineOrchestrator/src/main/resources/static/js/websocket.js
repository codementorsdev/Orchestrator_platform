/**
 * WebSocket communication for real-time pipeline updates
 */
$(document).ready(function() {
    // WebSocket variables
    let stompClient = null;
    let connected = false;
    
    // Connect to WebSocket
    connectWebSocket();
    
    /**
     * Connect to WebSocket server
     */
    function connectWebSocket() {
        // Create a new SockJS object pointing to the endpoint
        const socket = new SockJS('/ws-pipeline');
        
        // Create a STOMP client over the SockJS connection
        stompClient = Stomp.over(socket);
        
        // Disable debug messages
        stompClient.debug = null;
        
        // Connect to the server
        stompClient.connect({}, function(frame) {
            connected = true;
            console.log('Connected to WebSocket: ' + frame);
            updateConnectionStatus(true);
            
            // Subscribe to pipeline status updates
            stompClient.subscribe('/topic/pipeline-updates', function(message) {
                const updateData = JSON.parse(message.body);
                console.log('Received pipeline update:', updateData);
                
                // Update the pipeline status in the UI
                if (window.updatePipelineStatus) {
                    window.updatePipelineStatus(updateData);
                }
            });
            
            // Subscribe to full pipeline data updates
            stompClient.subscribe('/topic/pipeline-data', function(message) {
                const pipelineData = JSON.parse(message.body);
                console.log('Received complete pipeline data');
                
                // TODO: Handle full pipeline data refresh if needed
            });
            
            // Request initial pipeline data
            requestPipelineData();
        }, function(error) {
            // Connection error handler
            console.error('Error connecting to WebSocket:', error);
            connected = false;
            updateConnectionStatus(false);
            
            // Try to reconnect after a delay
            setTimeout(connectWebSocket, 5000);
        });
        
        // Handle WebSocket disconnection
        socket.onclose = function() {
            console.log('WebSocket connection closed');
            connected = false;
            updateConnectionStatus(false);
            
            // Try to reconnect after a delay
            setTimeout(connectWebSocket, 5000);
        };
    }
    
    /**
     * Update the connection status indicator in the UI
     * @param {boolean} isConnected - Whether the connection is established
     */
    function updateConnectionStatus(isConnected) {
        const statusDot = $('#connectionStatus .status-dot');
        const statusText = $('#connectionStatusText');
        
        if (isConnected) {
            statusDot.removeClass('disconnected').addClass('connected');
            statusText.text('Connected');
        } else {
            statusDot.removeClass('connected').addClass('disconnected');
            statusText.text('Disconnected - Reconnecting...');
        }
    }
    
    /**
     * Request pipeline data from the server
     */
    function requestPipelineData() {
        if (connected && stompClient) {
            stompClient.send('/app/request-pipeline-data', {}, {});
        }
    }
    
    /**
     * Request pipeline data for a specific configuration
     * @param {number} configId - Pipeline configuration ID
     */
    function requestPipelineDataByConfig(configId) {
        if (connected && stompClient) {
            stompClient.send('/app/request-pipeline-data-by-config', {}, JSON.stringify(configId));
        }
    }
    
    // Handle window unload to properly disconnect
    $(window).on('beforeunload', function() {
        if (stompClient !== null) {
            stompClient.disconnect();
        }
    });
    
    // Make functions available globally
    window.requestPipelineData = requestPipelineData;
    window.requestPipelineDataByConfig = requestPipelineDataByConfig;
});
