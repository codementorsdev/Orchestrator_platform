#!/bin/bash

export JAVA_HOME=/nix/store/2vwkssqpzykk37r996cafq7x63imf4sp-openjdk-21+35
export PATH=$JAVA_HOME/bin:$PATH

echo "JAVA_HOME is set to $JAVA_HOME"
echo "Java version:"
java -version

# Run the Spring Boot application
./mvnw spring-boot:run