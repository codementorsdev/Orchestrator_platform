package com.gitlab.pipeline.flow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for GitLab Pipeline Flow Management
 * This application provides an API for managing sequential GitLab pipelines organized as flows
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
public class GitlabPipelineFlowApplication {

    public static void main(String[] args) {
        SpringApplication.run(GitlabPipelineFlowApplication.class, args);
    }
}
