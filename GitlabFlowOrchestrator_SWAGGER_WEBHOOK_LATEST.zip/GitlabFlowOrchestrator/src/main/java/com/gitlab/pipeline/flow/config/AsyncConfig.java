package com.gitlab.pipeline.flow.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Configuration for asynchronous execution
 */
@Configuration
@EnableAsync
public class AsyncConfig {
    
    @Value("${async.executor.corePoolSize:10}")
    private int corePoolSize;
    
    @Value("${async.executor.maxPoolSize:50}")
    private int maxPoolSize;
    
    @Value("${async.executor.queueCapacity:100}")
    private int queueCapacity;
    
    @Value("${async.executor.threadNamePrefix:gitlab-pipeline-async-}")
    private String threadNamePrefix;
    
    /**
     * Creates an executor for asynchronous execution of pipelines
     *
     * @return Executor
     */
    @Bean(name = "taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix(threadNamePrefix);
        executor.initialize();
        return executor;
    }
}
