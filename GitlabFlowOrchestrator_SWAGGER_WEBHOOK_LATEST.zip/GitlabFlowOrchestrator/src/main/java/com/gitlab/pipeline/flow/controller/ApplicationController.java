package com.gitlab.pipeline.flow.controller;

import com.gitlab.pipeline.flow.dto.ApiResponse;
import com.gitlab.pipeline.flow.dto.ApplicationDto;
import com.gitlab.pipeline.flow.service.ApplicationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Application operations
 */
@RestController
@RequestMapping("/applications")
@RequiredArgsConstructor
@Tag(name = "Application", description = "Application management APIs")
public class ApplicationController {
    
    private final ApplicationService applicationService;
    
    @PostMapping
    @Operation(summary = "Create a new application", description = "Creates a new application with the provided details")
    public ResponseEntity<ApiResponse<ApplicationDto>> createApplication(
            @Parameter(description = "Application details", required = true)
            @Valid @RequestBody ApplicationDto applicationDto) {
        
        ApplicationDto createdApplication = applicationService.createApplication(applicationDto);
        return new ResponseEntity<>(
                ApiResponse.success("Application created successfully", createdApplication),
                HttpStatus.CREATED
        );
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get application by ID", description = "Retrieves an application by its ID")
    public ResponseEntity<ApiResponse<ApplicationDto>> getApplicationById(
            @Parameter(description = "Application ID", required = true)
            @PathVariable Long id) {
        
        ApplicationDto applicationDto = applicationService.getApplicationById(id);
        return ResponseEntity.ok(
                ApiResponse.success("Application retrieved successfully", applicationDto)
        );
    }
    
    @GetMapping("/name/{name}")
    @Operation(summary = "Get application by name", description = "Retrieves an application by its name")
    public ResponseEntity<ApiResponse<ApplicationDto>> getApplicationByName(
            @Parameter(description = "Application name", required = true)
            @PathVariable String name) {
        
        ApplicationDto applicationDto = applicationService.getApplicationByName(name);
        return ResponseEntity.ok(
                ApiResponse.success("Application retrieved successfully", applicationDto)
        );
    }
    
    @GetMapping
    @Operation(summary = "Get all applications", description = "Retrieves all applications")
    public ResponseEntity<ApiResponse<List<ApplicationDto>>> getAllApplications() {
        List<ApplicationDto> applications = applicationService.getAllApplications();
        return ResponseEntity.ok(
                ApiResponse.success("Applications retrieved successfully", applications)
        );
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Update application", description = "Updates an existing application")
    public ResponseEntity<ApiResponse<ApplicationDto>> updateApplication(
            @Parameter(description = "Application ID", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated application details", required = true)
            @Valid @RequestBody ApplicationDto applicationDto) {
        
        ApplicationDto updatedApplication = applicationService.updateApplication(id, applicationDto);
        return ResponseEntity.ok(
                ApiResponse.success("Application updated successfully", updatedApplication)
        );
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete application", description = "Deletes an application by its ID")
    public ResponseEntity<ApiResponse<Void>> deleteApplication(
            @Parameter(description = "Application ID", required = true)
            @PathVariable Long id) {
        
        applicationService.deleteApplication(id);
        return ResponseEntity.ok(
                ApiResponse.success("Application deleted successfully", null)
        );
    }
}
