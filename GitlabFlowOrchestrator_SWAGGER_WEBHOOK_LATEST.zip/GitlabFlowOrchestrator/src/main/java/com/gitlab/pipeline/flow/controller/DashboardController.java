package com.gitlab.pipeline.flow.controller;

import com.gitlab.pipeline.flow.dto.ApiResponse;
import com.gitlab.pipeline.flow.dto.DashboardMetricsDto;
import com.gitlab.pipeline.flow.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for dashboard metrics
 */
@RestController
@RequestMapping("/dashboard")
@RequiredArgsConstructor
@Tag(name = "Dashboard", description = "Dashboard metrics API")
public class DashboardController {
    
    private final DashboardService dashboardService;
    
    @GetMapping("/metrics")
    @Operation(summary = "Get dashboard metrics", description = "Retrieves metrics for the dashboard")
    public ResponseEntity<ApiResponse<DashboardMetricsDto>> getDashboardMetrics() {
        DashboardMetricsDto metrics = dashboardService.getDashboardMetrics();
        return ResponseEntity.ok(
                ApiResponse.success("Dashboard metrics retrieved successfully", metrics)
        );
    }
}
