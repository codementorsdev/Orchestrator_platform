package com.gitlab.pipeline.flow.controller;

import com.gitlab.pipeline.flow.dto.ApiResponse;
import com.gitlab.pipeline.flow.dto.ExecutionMetricsDto;
import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.service.ExecutionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for flow and pipeline execution
 */
@RestController
@RequestMapping("/executions")
@RequiredArgsConstructor
@Tag(name = "Execution", description = "Flow and Pipeline execution APIs")
public class ExecutionController {
    
    private final ExecutionService executionService;
    
    @PostMapping("/flows/{flowId}")
    @Operation(summary = "Execute a flow", description = "Triggers execution of a flow")
    public ResponseEntity<ApiResponse<Long>> executeFlow(
            @Parameter(description = "Flow ID", required = true)
            @PathVariable Long flowId) {
        
        Long executionId = executionService.executeFlow(flowId);
        return ResponseEntity.ok(
                ApiResponse.success("Flow execution triggered successfully", executionId)
        );
    }
    
    @GetMapping("/flows/{flowExecutionId}/status")
    @Operation(summary = "Get flow execution status", description = "Retrieves the status of a flow execution")
    public ResponseEntity<ApiResponse<ExecutionStatus>> getFlowExecutionStatus(
            @Parameter(description = "Flow execution ID", required = true)
            @PathVariable Long flowExecutionId) {
        
        ExecutionStatus status = executionService.getFlowExecutionStatus(flowExecutionId);
        return ResponseEntity.ok(
                ApiResponse.success("Flow execution status retrieved successfully", status)
        );
    }
    
    @GetMapping("/pipelines/{pipelineExecutionId}/status")
    @Operation(summary = "Get pipeline execution status", description = "Retrieves the status of a pipeline execution")
    public ResponseEntity<ApiResponse<ExecutionStatus>> getPipelineExecutionStatus(
            @Parameter(description = "Pipeline execution ID", required = true)
            @PathVariable Long pipelineExecutionId) {
        
        ExecutionStatus status = executionService.getPipelineExecutionStatus(pipelineExecutionId);
        return ResponseEntity.ok(
                ApiResponse.success("Pipeline execution status retrieved successfully", status)
        );
    }
    
    @GetMapping("/pipelines/{pipelineExecutionId}/metrics")
    @Operation(summary = "Get pipeline execution metrics", description = "Retrieves the execution metrics of a pipeline")
    public ResponseEntity<ApiResponse<ExecutionMetricsDto>> getPipelineExecutionMetrics(
            @Parameter(description = "Pipeline execution ID", required = true)
            @PathVariable Long pipelineExecutionId) {
        
        ExecutionMetricsDto metrics = executionService.getPipelineExecutionMetrics(pipelineExecutionId);
        return ResponseEntity.ok(
                ApiResponse.success("Pipeline execution metrics retrieved successfully", metrics)
        );
    }
}
