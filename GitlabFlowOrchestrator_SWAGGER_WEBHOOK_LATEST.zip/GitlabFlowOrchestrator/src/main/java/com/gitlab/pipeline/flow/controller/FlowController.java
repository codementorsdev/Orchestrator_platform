package com.gitlab.pipeline.flow.controller;

import com.gitlab.pipeline.flow.dto.ApiResponse;
import com.gitlab.pipeline.flow.dto.FlowDto;
import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.service.FlowService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Flow operations
 */
@RestController
@RequestMapping("/flows")
@RequiredArgsConstructor
@Tag(name = "Flow", description = "Flow management APIs")
public class FlowController {
    
    private final FlowService flowService;
    
    @PostMapping
    @Operation(summary = "Create a new flow", description = "Creates a new flow with the provided details")
    public ResponseEntity<ApiResponse<FlowDto>> createFlow(
            @Parameter(description = "Flow details", required = true)
            @Valid @RequestBody FlowDto flowDto) {
        
        FlowDto createdFlow = flowService.createFlow(flowDto);
        return new ResponseEntity<>(
                ApiResponse.success("Flow created successfully", createdFlow),
                HttpStatus.CREATED
        );
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get flow by ID", description = "Retrieves a flow by its ID")
    public ResponseEntity<ApiResponse<FlowDto>> getFlowById(
            @Parameter(description = "Flow ID", required = true)
            @PathVariable Long id) {
        
        FlowDto flowDto = flowService.getFlowById(id);
        return ResponseEntity.ok(
                ApiResponse.success("Flow retrieved successfully", flowDto)
        );
    }
    
    @GetMapping("/name/{name}")
    @Operation(summary = "Get flow by name", description = "Retrieves a flow by its name")
    public ResponseEntity<ApiResponse<FlowDto>> getFlowByName(
            @Parameter(description = "Flow name", required = true)
            @PathVariable String name) {
        
        FlowDto flowDto = flowService.getFlowByName(name);
        return ResponseEntity.ok(
                ApiResponse.success("Flow retrieved successfully", flowDto)
        );
    }
    
    @GetMapping
    @Operation(summary = "Get all flows", description = "Retrieves all flows")
    public ResponseEntity<ApiResponse<List<FlowDto>>> getAllFlows() {
        List<FlowDto> flows = flowService.getAllFlows();
        return ResponseEntity.ok(
                ApiResponse.success("Flows retrieved successfully", flows)
        );
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Update flow", description = "Updates an existing flow")
    public ResponseEntity<ApiResponse<FlowDto>> updateFlow(
            @Parameter(description = "Flow ID", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated flow details", required = true)
            @Valid @RequestBody FlowDto flowDto) {
        
        FlowDto updatedFlow = flowService.updateFlow(id, flowDto);
        return ResponseEntity.ok(
                ApiResponse.success("Flow updated successfully", updatedFlow)
        );
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete flow", description = "Deletes a flow by its ID")
    public ResponseEntity<ApiResponse<Void>> deleteFlow(
            @Parameter(description = "Flow ID", required = true)
            @PathVariable Long id) {
        
        flowService.deleteFlow(id);
        return ResponseEntity.ok(
                ApiResponse.success("Flow deleted successfully", null)
        );
    }
    
    @GetMapping("/{id}/status")
    @Operation(summary = "Get flow status", description = "Retrieves the status of a flow")
    public ResponseEntity<ApiResponse<ExecutionStatus>> getFlowStatus(
            @Parameter(description = "Flow ID", required = true)
            @PathVariable Long id) {
        
        ExecutionStatus status = flowService.getFlowStatus(id);
        return ResponseEntity.ok(
                ApiResponse.success("Flow status retrieved successfully", status)
        );
    }
}
