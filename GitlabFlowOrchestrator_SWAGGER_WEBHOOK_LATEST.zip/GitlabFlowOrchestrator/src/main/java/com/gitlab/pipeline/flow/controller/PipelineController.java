package com.gitlab.pipeline.flow.controller;

import com.gitlab.pipeline.flow.dto.ApiResponse;
import com.gitlab.pipeline.flow.dto.PipelineDto;
import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.service.PipelineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Pipeline operations
 */
@RestController
@RequestMapping("/pipelines")
@RequiredArgsConstructor
@Tag(name = "Pipeline", description = "Pipeline management APIs")
public class PipelineController {
    
    private final PipelineService pipelineService;
    
    @PostMapping
    @Operation(summary = "Create a new pipeline", description = "Creates a new pipeline with the provided details")
    public ResponseEntity<ApiResponse<PipelineDto>> createPipeline(
            @Parameter(description = "Pipeline details", required = true)
            @Valid @RequestBody PipelineDto pipelineDto) {
        
        PipelineDto createdPipeline = pipelineService.createPipeline(pipelineDto);
        return new ResponseEntity<>(
                ApiResponse.success("Pipeline created successfully", createdPipeline),
                HttpStatus.CREATED
        );
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get pipeline by ID", description = "Retrieves a pipeline by its ID")
    public ResponseEntity<ApiResponse<PipelineDto>> getPipelineById(
            @Parameter(description = "Pipeline ID", required = true)
            @PathVariable Long id) {
        
        PipelineDto pipelineDto = pipelineService.getPipelineById(id);
        return ResponseEntity.ok(
                ApiResponse.success("Pipeline retrieved successfully", pipelineDto)
        );
    }
    
    @GetMapping
    @Operation(summary = "Get all pipelines", description = "Retrieves all pipelines")
    public ResponseEntity<ApiResponse<List<PipelineDto>>> getAllPipelines() {
        List<PipelineDto> pipelines = pipelineService.getAllPipelines();
        return ResponseEntity.ok(
                ApiResponse.success("Pipelines retrieved successfully", pipelines)
        );
    }
    
    @GetMapping("/flow/{flowId}")
    @Operation(summary = "Get pipelines by flow ID", description = "Retrieves all pipelines for a specific flow")
    public ResponseEntity<ApiResponse<List<PipelineDto>>> getPipelinesByFlowId(
            @Parameter(description = "Flow ID", required = true)
            @PathVariable Long flowId) {
        
        List<PipelineDto> pipelines = pipelineService.getPipelinesByFlowId(flowId);
        return ResponseEntity.ok(
                ApiResponse.success("Pipelines retrieved successfully", pipelines)
        );
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Update pipeline", description = "Updates an existing pipeline")
    public ResponseEntity<ApiResponse<PipelineDto>> updatePipeline(
            @Parameter(description = "Pipeline ID", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated pipeline details", required = true)
            @Valid @RequestBody PipelineDto pipelineDto) {
        
        PipelineDto updatedPipeline = pipelineService.updatePipeline(id, pipelineDto);
        return ResponseEntity.ok(
                ApiResponse.success("Pipeline updated successfully", updatedPipeline)
        );
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete pipeline", description = "Deletes a pipeline by its ID")
    public ResponseEntity<ApiResponse<Void>> deletePipeline(
            @Parameter(description = "Pipeline ID", required = true)
            @PathVariable Long id) {
        
        pipelineService.deletePipeline(id);
        return ResponseEntity.ok(
                ApiResponse.success("Pipeline deleted successfully", null)
        );
    }
    
    @GetMapping("/status")
    @Operation(summary = "Get pipeline status", description = "Retrieves the status of a pipeline within a flow")
    public ResponseEntity<ApiResponse<ExecutionStatus>> getPipelineStatus(
            @Parameter(description = "Flow execution ID", required = true)
            @RequestParam Long flowExecutionId,
            @Parameter(description = "Pipeline ID", required = true)
            @RequestParam Long pipelineId) {
        
        ExecutionStatus status = pipelineService.getPipelineStatus(flowExecutionId, pipelineId);
        return ResponseEntity.ok(
                ApiResponse.success("Pipeline status retrieved successfully", status)
        );
    }
}
