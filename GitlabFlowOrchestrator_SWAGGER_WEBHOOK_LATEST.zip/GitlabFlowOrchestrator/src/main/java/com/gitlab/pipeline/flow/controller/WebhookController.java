package com.gitlab.pipeline.flow.controller;

import com.gitlab.pipeline.flow.dto.ApiResponse;
import com.gitlab.pipeline.flow.dto.ExecutionMetricsDto;
import com.gitlab.pipeline.flow.service.ExecutionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for webhook endpoints
 */
@RestController
@RequestMapping("/webhooks")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Webhooks", description = "Webhook endpoints for receiving pipeline execution metrics")
public class WebhookController {
    
    private final ExecutionService executionService;
    
    @PostMapping("/gitlab")
    @Operation(summary = "GitLab webhook", description = "Receives pipeline execution metrics from GitLab")
    public ResponseEntity<ApiResponse<Void>> gitlabWebhook(
            @Parameter(description = "GitLab pipeline ID", required = true)
            @RequestParam String pipelineId,
            @Parameter(description = "Execution metrics", required = true)
            @RequestBody ExecutionMetricsDto metricsDto) {
        
        log.info("Received webhook from GitLab for pipeline: {}", pipelineId);
        
        try {
            executionService.processPipelineMetrics(pipelineId, metricsDto);
            return ResponseEntity.ok(
                    ApiResponse.success("Pipeline metrics processed successfully", null)
            );
        } catch (Exception e) {
            log.error("Error processing pipeline metrics", e);
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Failed to process pipeline metrics: " + e.getMessage()));
        }
    }
}
