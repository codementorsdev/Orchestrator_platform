package com.gitlab.pipeline.flow.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for dashboard metrics
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardMetricsDto {
    private long totalApplications;
    private long totalPipelines;
    private long totalFlows;
    private long flowsExecuted;
    private long flowsPassed;
    private long flowsFailed;
    private long flowsPending;
    private long flowsRunning;
}
