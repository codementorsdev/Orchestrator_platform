package com.gitlab.pipeline.flow.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DTO for capturing execution metrics from pipeline
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExecutionMetricsDto {
    private String appId;
    private String appName;
    private String appDescription;
    private List<TestSuiteDto> suites = new ArrayList<>();
    private Map<String, String> customData = new HashMap<>();

    /**
     * DTO for test suite
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TestSuiteDto {
        private String name;
        private String description;
        private List<String> tags = new ArrayList<>();
        private Long startTime;
        private Long endTime;
        private Map<String, TestDto> tests = new HashMap<>();
    }

    /**
     * DTO for test
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TestDto {
        private String name;
        private String description;
        private List<String> tags = new ArrayList<>();
        private Long startTime;
        private Long endTime;
        private List<LogDto> logs = new ArrayList<>();
    }

    /**
     * DTO for log
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LogDto {
        private String message;
        private String status;
    }
}
