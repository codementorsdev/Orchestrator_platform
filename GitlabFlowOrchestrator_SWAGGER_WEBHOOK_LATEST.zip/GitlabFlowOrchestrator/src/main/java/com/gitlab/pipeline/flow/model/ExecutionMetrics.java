package com.gitlab.pipeline.flow.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Entity representing execution metrics from a pipeline run
 */
@Entity
@Table(name = "execution_metrics")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExecutionMetrics {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String appId;
    
    private String appName;
    
    private String appDescription;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "metrics_id")
    private List<TestSuite> suites = new ArrayList<>();

    @ElementCollection
    @CollectionTable(name = "execution_metrics_custom_data", 
                     joinColumns = @JoinColumn(name = "metrics_id"))
    @MapKeyColumn(name = "data_key")
    @Column(name = "data_value")
    private Map<String, String> customData = new HashMap<>();

    @OneToOne(mappedBy = "metrics")
    private PipelineExecution pipelineExecution;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
