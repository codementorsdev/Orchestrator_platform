package com.gitlab.pipeline.flow.model;

/**
 * Enum representing possible execution statuses for flows and pipelines
 */
public enum ExecutionStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELED,
    SKIPPED
}
