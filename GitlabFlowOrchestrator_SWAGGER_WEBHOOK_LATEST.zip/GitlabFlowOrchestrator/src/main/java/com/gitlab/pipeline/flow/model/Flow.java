package com.gitlab.pipeline.flow.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Entity representing a flow which contains multiple pipelines to be executed sequentially
 */
@Entity
@Table(name = "flows")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Flow {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @OneToMany(mappedBy = "flow", cascade = CascadeType.ALL, orphanRemoval = true)
    // Ordering is handled programmatically
    private List<Pipeline> pipelines = new ArrayList<>();

    @OneToMany(mappedBy = "flow", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FlowExecution> executions = new ArrayList<>();

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
    
    /**
     * Get pipelines sorted by execution sequence
     * 
     * @return List of pipelines sorted by execution sequence
     */
    public List<Pipeline> getSortedPipelines() {
        List<Pipeline> sortedList = new ArrayList<>(pipelines);
        sortedList.sort(Comparator.comparing(Pipeline::getExecutionSequence));
        return sortedList;
    }
}
