package com.gitlab.pipeline.flow.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Entity representing an execution of a flow
 */
@Entity
@Table(name = "flow_executions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlowExecution {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "flow_id", nullable = false)
    private Flow flow;

    @Enumerated(EnumType.STRING)
    private ExecutionStatus status;

    private LocalDateTime startTime;
    
    private LocalDateTime endTime;

    @OneToMany(mappedBy = "flowExecution", cascade = CascadeType.ALL, orphanRemoval = true)
    // Ordering is handled programmatically
    private List<PipelineExecution> pipelineExecutions = new ArrayList<>();

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
    
    /**
     * Get pipeline executions sorted by their pipeline's execution sequence
     * 
     * @return List of pipeline executions sorted by pipeline execution sequence
     */
    public List<PipelineExecution> getSortedPipelineExecutions() {
        List<PipelineExecution> sortedList = new ArrayList<>(pipelineExecutions);
        sortedList.sort(Comparator.comparing(pe -> pe.getPipeline().getExecutionSequence()));
        return sortedList;
    }
}
