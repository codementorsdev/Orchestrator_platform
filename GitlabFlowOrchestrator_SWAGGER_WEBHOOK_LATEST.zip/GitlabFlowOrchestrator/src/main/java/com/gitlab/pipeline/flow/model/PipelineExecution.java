package com.gitlab.pipeline.flow.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * Entity representing an execution of a pipeline
 */
@Entity
@Table(name = "pipeline_executions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PipelineExecution {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pipeline_id", nullable = false)
    private Pipeline pipeline;

    @ManyToOne
    @JoinColumn(name = "flow_execution_id", nullable = false)
    private FlowExecution flowExecution;

    @Enumerated(EnumType.STRING)
    private ExecutionStatus status;

    private String gitlabPipelineId;

    private LocalDateTime startTime;
    
    private LocalDateTime endTime;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "metrics_id")
    private ExecutionMetrics metrics;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
