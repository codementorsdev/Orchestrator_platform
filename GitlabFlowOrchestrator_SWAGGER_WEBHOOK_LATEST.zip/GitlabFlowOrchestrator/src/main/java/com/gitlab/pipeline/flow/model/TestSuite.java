package com.gitlab.pipeline.flow.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Entity representing a test suite within execution metrics
 */
@Entity
@Table(name = "test_suites")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestSuite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    
    private String description;
    
    @ElementCollection
    @CollectionTable(name = "test_suite_tags", joinColumns = @JoinColumn(name = "suite_id"))
    @Column(name = "tag")
    private List<String> tags = new ArrayList<>();
    
    private Long startTime;
    
    private Long endTime;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "suite_id")
    @MapKey(name = "name")
    private Map<String, Test> tests = new HashMap<>();
}
