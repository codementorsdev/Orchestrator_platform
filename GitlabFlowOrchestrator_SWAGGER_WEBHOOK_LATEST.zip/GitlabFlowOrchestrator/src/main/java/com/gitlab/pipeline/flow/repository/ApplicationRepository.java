package com.gitlab.pipeline.flow.repository;

import com.gitlab.pipeline.flow.model.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for Application entity
 */
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    
    /**
     * Find application by name
     *
     * @param name Application name
     * @return Optional containing the application if found
     */
    Optional<Application> findByName(String name);
    
    /**
     * Check if an application exists by name
     *
     * @param name Application name
     * @return true if application exists, false otherwise
     */
    boolean existsByName(String name);
}
