package com.gitlab.pipeline.flow.repository;

import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.model.Flow;
import com.gitlab.pipeline.flow.model.FlowExecution;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for FlowExecution entity
 */
@Repository
public interface FlowExecutionRepository extends JpaRepository<FlowExecution, Long> {
    
    /**
     * Find flow executions by flow
     *
     * @param flow Flow to get executions for
     * @return List of flow executions
     */
    List<FlowExecution> findByFlow(Flow flow);
    
    /**
     * Find flow executions by flow id
     *
     * @param flowId Flow ID to get executions for
     * @return List of flow executions
     */
    List<FlowExecution> findByFlowId(Long flowId);
    
    /**
     * Find flow executions by status
     *
     * @param status Execution status to filter by
     * @return List of flow executions
     */
    List<FlowExecution> findByStatus(ExecutionStatus status);
    
    /**
     * Count flow executions by status
     *
     * @param status Execution status to count
     * @return Count of flow executions with specified status
     */
    long countByStatus(ExecutionStatus status);
    
    /**
     * Count all completed flow executions
     *
     * @return Count of completed flow executions
     */
    @Query("SELECT COUNT(fe) FROM FlowExecution fe WHERE fe.status = 'COMPLETED'")
    long countCompleted();
    
    /**
     * Count all failed flow executions
     *
     * @return Count of failed flow executions
     */
    @Query("SELECT COUNT(fe) FROM FlowExecution fe WHERE fe.status = 'FAILED'")
    long countFailed();
}
