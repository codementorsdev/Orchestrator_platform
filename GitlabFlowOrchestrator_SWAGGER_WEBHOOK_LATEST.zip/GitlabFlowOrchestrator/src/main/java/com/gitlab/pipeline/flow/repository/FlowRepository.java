package com.gitlab.pipeline.flow.repository;

import com.gitlab.pipeline.flow.model.Flow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for Flow entity
 */
@Repository
public interface FlowRepository extends JpaRepository<Flow, Long> {
    
    /**
     * Find flow by name
     *
     * @param name Flow name
     * @return Optional containing the flow if found
     */
    Optional<Flow> findByName(String name);
    
    /**
     * Check if a flow exists by name
     *
     * @param name Flow name
     * @return true if flow exists, false otherwise
     */
    boolean existsByName(String name);
}
