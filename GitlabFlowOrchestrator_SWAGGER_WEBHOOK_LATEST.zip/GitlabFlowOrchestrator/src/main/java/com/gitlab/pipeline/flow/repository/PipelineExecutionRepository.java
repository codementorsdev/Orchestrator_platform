package com.gitlab.pipeline.flow.repository;

import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.model.FlowExecution;
import com.gitlab.pipeline.flow.model.Pipeline;
import com.gitlab.pipeline.flow.model.PipelineExecution;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for PipelineExecution entity
 */
@Repository
public interface PipelineExecutionRepository extends JpaRepository<PipelineExecution, Long> {
    
    /**
     * Find pipeline executions by flow execution
     *
     * @param flowExecution Flow execution to get pipeline executions for
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByFlowExecution(FlowExecution flowExecution);
    
    /**
     * Find pipeline executions by flow execution id
     *
     * @param flowExecutionId Flow execution ID to get pipeline executions for
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByFlowExecutionId(Long flowExecutionId);
    
    /**
     * Find pipeline executions by pipeline
     *
     * @param pipeline Pipeline to get executions for
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByPipeline(Pipeline pipeline);
    
    /**
     * Find pipeline executions by pipeline id
     *
     * @param pipelineId Pipeline ID to get executions for
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByPipelineId(Long pipelineId);
    
    /**
     * Find pipeline execution by GitLab pipeline ID
     *
     * @param gitlabPipelineId GitLab pipeline ID
     * @return Optional containing the pipeline execution if found
     */
    Optional<PipelineExecution> findByGitlabPipelineId(String gitlabPipelineId);
    
    /**
     * Find pipeline executions by status
     *
     * @param status Execution status to filter by
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByStatus(ExecutionStatus status);
    
    /**
     * Find pipeline executions by flow execution and status
     *
     * @param flowExecution Flow execution to filter by
     * @param status Execution status to filter by
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByFlowExecutionAndStatus(FlowExecution flowExecution, ExecutionStatus status);
}
