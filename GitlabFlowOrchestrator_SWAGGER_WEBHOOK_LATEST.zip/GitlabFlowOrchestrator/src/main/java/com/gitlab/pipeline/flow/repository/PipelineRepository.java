package com.gitlab.pipeline.flow.repository;

import com.gitlab.pipeline.flow.model.Flow;
import com.gitlab.pipeline.flow.model.Pipeline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for Pipeline entity
 */
@Repository
public interface PipelineRepository extends JpaRepository<Pipeline, Long> {
    
    /**
     * Find pipelines by flow ordered by execution sequence
     *
     * @param flow Flow to get pipelines for
     * @return List of pipelines ordered by execution sequence
     */
    List<Pipeline> findByFlowOrderByExecutionSequenceAsc(Flow flow);
    
    /**
     * Find pipelines by flow id ordered by execution sequence
     *
     * @param flowId Flow ID to get pipelines for
     * @return List of pipelines ordered by execution sequence
     */
    List<Pipeline> findByFlowIdOrderByExecutionSequenceAsc(Long flowId);
}
