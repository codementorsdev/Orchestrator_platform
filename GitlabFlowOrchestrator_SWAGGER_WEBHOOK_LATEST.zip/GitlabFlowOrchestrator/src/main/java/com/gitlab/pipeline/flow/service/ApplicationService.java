package com.gitlab.pipeline.flow.service;

import com.gitlab.pipeline.flow.dto.ApplicationDto;

import java.util.List;

/**
 * Service interface for Application operations
 */
public interface ApplicationService {
    
    /**
     * Create a new application
     *
     * @param applicationDto Application data
     * @return Created application
     */
    ApplicationDto createApplication(ApplicationDto applicationDto);
    
    /**
     * Get application by ID
     *
     * @param id Application ID
     * @return Application data
     */
    ApplicationDto getApplicationById(Long id);
    
    /**
     * Get application by name
     *
     * @param name Application name
     * @return Application data
     */
    ApplicationDto getApplicationByName(String name);
    
    /**
     * Get all applications
     *
     * @return List of all applications
     */
    List<ApplicationDto> getAllApplications();
    
    /**
     * Update application
     *
     * @param id Application ID
     * @param applicationDto Updated application data
     * @return Updated application
     */
    ApplicationDto updateApplication(Long id, ApplicationDto applicationDto);
    
    /**
     * Delete application by ID
     *
     * @param id Application ID
     */
    void deleteApplication(Long id);
}
