package com.gitlab.pipeline.flow.service;

import com.gitlab.pipeline.flow.dto.DashboardMetricsDto;

/**
 * Service interface for dashboard operations
 */
public interface DashboardService {
    
    /**
     * Get dashboard metrics
     *
     * @return Dashboard metrics
     */
    DashboardMetricsDto getDashboardMetrics();
}
