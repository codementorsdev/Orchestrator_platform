package com.gitlab.pipeline.flow.service;

import com.gitlab.pipeline.flow.dto.ExecutionMetricsDto;
import com.gitlab.pipeline.flow.model.ExecutionStatus;

/**
 * Service interface for pipeline execution operations
 */
public interface ExecutionService {
    
    /**
     * Execute a flow
     *
     * @param flowId Flow ID to execute
     * @return Flow execution ID
     */
    Long executeFlow(Long flowId);
    
    /**
     * Get flow execution status
     *
     * @param flowExecutionId Flow execution ID
     * @return Execution status
     */
    ExecutionStatus getFlowExecutionStatus(Long flowExecutionId);
    
    /**
     * Get pipeline execution status
     *
     * @param pipelineExecutionId Pipeline execution ID
     * @return Execution status
     */
    ExecutionStatus getPipelineExecutionStatus(Long pipelineExecutionId);
    
    /**
     * Process pipeline execution metrics
     *
     * @param gitlabPipelineId GitLab pipeline ID
     * @param metricsDto Execution metrics
     */
    void processPipelineMetrics(String gitlabPipelineId, ExecutionMetricsDto metricsDto);
    
    /**
     * Get pipeline execution metrics
     *
     * @param pipelineExecutionId Pipeline execution ID
     * @return Execution metrics
     */
    ExecutionMetricsDto getPipelineExecutionMetrics(Long pipelineExecutionId);
}
