package com.gitlab.pipeline.flow.service;

import com.gitlab.pipeline.flow.dto.FlowDto;
import com.gitlab.pipeline.flow.model.ExecutionStatus;

import java.util.List;

/**
 * Service interface for Flow operations
 */
public interface FlowService {
    
    /**
     * Create a new flow
     *
     * @param flowDto Flow data
     * @return Created flow
     */
    FlowDto createFlow(FlowDto flowDto);
    
    /**
     * Get flow by ID
     *
     * @param id Flow ID
     * @return Flow data
     */
    FlowDto getFlowById(Long id);
    
    /**
     * Get flow by name
     *
     * @param name Flow name
     * @return Flow data
     */
    FlowDto getFlowByName(String name);
    
    /**
     * Get all flows
     *
     * @return List of all flows
     */
    List<FlowDto> getAllFlows();
    
    /**
     * Update flow
     *
     * @param id Flow ID
     * @param flowDto Updated flow data
     * @return Updated flow
     */
    FlowDto updateFlow(Long id, FlowDto flowDto);
    
    /**
     * Delete flow by ID
     *
     * @param id Flow ID
     */
    void deleteFlow(Long id);
    
    /**
     * Get flow status
     *
     * @param id Flow ID
     * @return Execution status
     */
    ExecutionStatus getFlowStatus(Long id);
}
