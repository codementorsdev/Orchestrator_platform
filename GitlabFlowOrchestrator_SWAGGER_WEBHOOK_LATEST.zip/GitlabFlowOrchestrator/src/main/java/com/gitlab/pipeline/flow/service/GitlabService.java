package com.gitlab.pipeline.flow.service;

import com.gitlab.pipeline.flow.model.Application;
import com.gitlab.pipeline.flow.model.Pipeline;
import com.gitlab.pipeline.flow.model.PipelineExecution;

/**
 * Service interface for GitLab operations
 */
public interface GitlabService {
    
    /**
     * Trigger a GitLab pipeline
     *
     * @param pipeline Pipeline to trigger
     * @param pipelineExecution Pipeline execution to update
     * @param payloadJson Previous execution metrics payload (null for first pipeline)
     * @return GitLab pipeline ID
     */
    String triggerPipeline(Pipeline pipeline, PipelineExecution pipelineExecution, String payloadJson);
    
    /**
     * Check the status of a GitLab pipeline
     *
     * @param application Application linked to the pipeline
     * @param gitlabPipelineId GitLab pipeline ID
     * @return true if pipeline completed successfully, false otherwise
     */
    boolean isPipelineComplete(Application application, String gitlabPipelineId);
    
    /**
     * Check if a GitLab pipeline failed
     *
     * @param application Application linked to the pipeline
     * @param gitlabPipelineId GitLab pipeline ID
     * @return true if pipeline failed, false otherwise
     */
    boolean isPipelineFailed(Application application, String gitlabPipelineId);
    
    /**
     * Get GitLab pipeline status
     *
     * @param application Application linked to the pipeline
     * @param gitlabPipelineId GitLab pipeline ID
     * @return Pipeline status
     */
    String getPipelineStatus(Application application, String gitlabPipelineId);
}
