package com.gitlab.pipeline.flow.service;

import com.gitlab.pipeline.flow.dto.PipelineDto;
import com.gitlab.pipeline.flow.model.ExecutionStatus;

import java.util.List;

/**
 * Service interface for Pipeline operations
 */
public interface PipelineService {
    
    /**
     * Create a new pipeline
     *
     * @param pipelineDto Pipeline data
     * @return Created pipeline
     */
    PipelineDto createPipeline(PipelineDto pipelineDto);
    
    /**
     * Get pipeline by ID
     *
     * @param id Pipeline ID
     * @return Pipeline data
     */
    PipelineDto getPipelineById(Long id);
    
    /**
     * Get all pipelines
     *
     * @return List of all pipelines
     */
    List<PipelineDto> getAllPipelines();
    
    /**
     * Get pipelines by flow ID
     *
     * @param flowId Flow ID
     * @return List of pipelines in the flow
     */
    List<PipelineDto> getPipelinesByFlowId(Long flowId);
    
    /**
     * Update pipeline
     *
     * @param id Pipeline ID
     * @param pipelineDto Updated pipeline data
     * @return Updated pipeline
     */
    PipelineDto updatePipeline(Long id, PipelineDto pipelineDto);
    
    /**
     * Delete pipeline by ID
     *
     * @param id Pipeline ID
     */
    void deletePipeline(Long id);
    
    /**
     * Get pipeline status within a flow
     *
     * @param flowExecutionId Flow execution ID
     * @param pipelineId Pipeline ID
     * @return Execution status
     */
    ExecutionStatus getPipelineStatus(Long flowExecutionId, Long pipelineId);
}
