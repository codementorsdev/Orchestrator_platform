package com.gitlab.pipeline.flow.service.impl;

import com.gitlab.pipeline.flow.dto.ApplicationDto;
import com.gitlab.pipeline.flow.exception.ApiException;
import com.gitlab.pipeline.flow.exception.ResourceNotFoundException;
import com.gitlab.pipeline.flow.model.Application;
import com.gitlab.pipeline.flow.repository.ApplicationRepository;
import com.gitlab.pipeline.flow.service.ApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of ApplicationService
 */
@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {
    
    private final ApplicationRepository applicationRepository;
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public ApplicationDto createApplication(ApplicationDto applicationDto) {
        // Check if application with same name already exists
        if (applicationRepository.existsByName(applicationDto.getName())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Application with name '" + applicationDto.getName() + "' already exists");
        }
        
        Application application = convertToEntity(applicationDto);
        Application savedApplication = applicationRepository.save(application);
        
        return convertToDto(savedApplication);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public ApplicationDto getApplicationById(Long id) {
        Application application = applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", id));
        
        return convertToDto(application);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public ApplicationDto getApplicationByName(String name) {
        Application application = applicationRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Application", "name", name));
        
        return convertToDto(application);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDto> getAllApplications() {
        return applicationRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public ApplicationDto updateApplication(Long id, ApplicationDto applicationDto) {
        Application application = applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", id));
        
        // Check if name is being changed and if new name is already in use
        if (!application.getName().equals(applicationDto.getName()) && 
                applicationRepository.existsByName(applicationDto.getName())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Application with name '" + applicationDto.getName() + "' already exists");
        }
        
        application.setName(applicationDto.getName());
        application.setDescription(applicationDto.getDescription());
        application.setProjectId(applicationDto.getProjectId());
        application.setAccessToken(applicationDto.getAccessToken());
        
        Application updatedApplication = applicationRepository.save(application);
        
        return convertToDto(updatedApplication);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void deleteApplication(Long id) {
        if (!applicationRepository.existsById(id)) {
            throw new ResourceNotFoundException("Application", "id", id);
        }
        
        applicationRepository.deleteById(id);
    }
    
    /**
     * Convert Application entity to ApplicationDto
     *
     * @param application Application entity
     * @return ApplicationDto
     */
    private ApplicationDto convertToDto(Application application) {
        return ApplicationDto.builder()
                .id(application.getId())
                .name(application.getName())
                .description(application.getDescription())
                .projectId(application.getProjectId())
                .accessToken(application.getAccessToken())
                .build();
    }
    
    /**
     * Convert ApplicationDto to Application entity
     *
     * @param applicationDto ApplicationDto
     * @return Application entity
     */
    private Application convertToEntity(ApplicationDto applicationDto) {
        return Application.builder()
                .name(applicationDto.getName())
                .description(applicationDto.getDescription())
                .projectId(applicationDto.getProjectId())
                .accessToken(applicationDto.getAccessToken())
                .build();
    }
}
