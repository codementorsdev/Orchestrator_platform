package com.gitlab.pipeline.flow.service.impl;

import com.gitlab.pipeline.flow.dto.DashboardMetricsDto;
import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.repository.ApplicationRepository;
import com.gitlab.pipeline.flow.repository.FlowExecutionRepository;
import com.gitlab.pipeline.flow.repository.FlowRepository;
import com.gitlab.pipeline.flow.repository.PipelineRepository;
import com.gitlab.pipeline.flow.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of DashboardService
 */
@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {
    
    private final ApplicationRepository applicationRepository;
    private final PipelineRepository pipelineRepository;
    private final FlowRepository flowRepository;
    private final FlowExecutionRepository flowExecutionRepository;
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public DashboardMetricsDto getDashboardMetrics() {
        long totalApplications = applicationRepository.count();
        long totalPipelines = pipelineRepository.count();
        long totalFlows = flowRepository.count();
        
        long flowsExecuted = flowExecutionRepository.count();
        long flowsPassed = flowExecutionRepository.countByStatus(ExecutionStatus.COMPLETED);
        long flowsFailed = flowExecutionRepository.countByStatus(ExecutionStatus.FAILED);
        long flowsPending = flowExecutionRepository.countByStatus(ExecutionStatus.PENDING);
        long flowsRunning = flowExecutionRepository.countByStatus(ExecutionStatus.RUNNING);
        
        return DashboardMetricsDto.builder()
                .totalApplications(totalApplications)
                .totalPipelines(totalPipelines)
                .totalFlows(totalFlows)
                .flowsExecuted(flowsExecuted)
                .flowsPassed(flowsPassed)
                .flowsFailed(flowsFailed)
                .flowsPending(flowsPending)
                .flowsRunning(flowsRunning)
                .build();
    }
}
