package com.gitlab.pipeline.flow.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gitlab.pipeline.flow.dto.ExecutionMetricsDto;
import com.gitlab.pipeline.flow.exception.ResourceNotFoundException;
import com.gitlab.pipeline.flow.model.*;
import com.gitlab.pipeline.flow.repository.FlowExecutionRepository;
import com.gitlab.pipeline.flow.repository.FlowRepository;
import com.gitlab.pipeline.flow.repository.PipelineExecutionRepository;
import com.gitlab.pipeline.flow.repository.PipelineRepository;
import com.gitlab.pipeline.flow.service.ExecutionService;
import com.gitlab.pipeline.flow.service.GitlabService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Implementation of ExecutionService
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ExecutionServiceImpl implements ExecutionService {
    
    private final FlowRepository flowRepository;
    private final PipelineRepository pipelineRepository;
    private final FlowExecutionRepository flowExecutionRepository;
    private final PipelineExecutionRepository pipelineExecutionRepository;
    private final GitlabService gitlabService;
    private final ObjectMapper objectMapper;
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public Long executeFlow(Long flowId) {
        Flow flow = flowRepository.findById(flowId)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", flowId));
        
        List<Pipeline> pipelines = pipelineRepository.findByFlowOrderByExecutionSequenceAsc(flow);
        
        if (pipelines.isEmpty()) {
            throw new IllegalStateException("Cannot execute flow with no pipelines");
        }
        
        // Create flow execution
        FlowExecution flowExecution = FlowExecution.builder()
                .flow(flow)
                .status(ExecutionStatus.RUNNING)
                .startTime(LocalDateTime.now())
                .build();
        
        FlowExecution savedFlowExecution = flowExecutionRepository.save(flowExecution);
        
        // Create pipeline executions
        List<PipelineExecution> pipelineExecutions = new ArrayList<>();
        for (Pipeline pipeline : pipelines) {
            PipelineExecution pipelineExecution = PipelineExecution.builder()
                    .pipeline(pipeline)
                    .flowExecution(savedFlowExecution)
                    .status(ExecutionStatus.PENDING)
                    .build();
            
            pipelineExecutions.add(pipelineExecutionRepository.save(pipelineExecution));
        }
        
        // Start the first pipeline
        startNextPipeline(savedFlowExecution.getId());
        
        return savedFlowExecution.getId();
    }
    
    /**
     * Start the next pipeline in the flow
     *
     * @param flowExecutionId Flow execution ID
     */
    @Async
    @Transactional
    public void startNextPipeline(Long flowExecutionId) {
        FlowExecution flowExecution = flowExecutionRepository.findById(flowExecutionId)
                .orElseThrow(() -> new ResourceNotFoundException("FlowExecution", "id", flowExecutionId));
        
        // Check if flow is already completed or failed
        if (flowExecution.getStatus() == ExecutionStatus.COMPLETED || 
                flowExecution.getStatus() == ExecutionStatus.FAILED) {
            return;
        }
        
        // Get all pipelines for this flow, ordered by execution sequence
        List<Pipeline> flowPipelines = pipelineRepository.findByFlowOrderByExecutionSequenceAsc(flowExecution.getFlow());
        List<PipelineExecution> pipelineExecutions = pipelineExecutionRepository.findByFlowExecution(flowExecution);
        
        // Find the next pending pipeline
        Optional<PipelineExecution> nextPendingExecution = pipelineExecutions.stream()
                .filter(pe -> pe.getStatus() == ExecutionStatus.PENDING)
                .min(Comparator.comparing(pe -> pe.getPipeline().getExecutionSequence()));
        
        if (nextPendingExecution.isPresent()) {
            PipelineExecution pipelineExecution = nextPendingExecution.get();
            Pipeline pipeline = pipelineExecution.getPipeline();
            
            // Get the payload from the last completed pipeline execution, if any
            String payloadJson = null;
            Optional<PipelineExecution> previousCompletedExecution = pipelineExecutions.stream()
                    .filter(pe -> pe.getStatus() == ExecutionStatus.COMPLETED)
                    .max(Comparator.comparing(pe -> pe.getPipeline().getExecutionSequence()));
            
            if (previousCompletedExecution.isPresent() && previousCompletedExecution.get().getMetrics() != null) {
                try {
                    // Convert metrics to JSON
                    ExecutionMetrics metrics = previousCompletedExecution.get().getMetrics();
                    ExecutionMetricsDto metricsDto = convertMetricsToDto(metrics);
                    payloadJson = objectMapper.writeValueAsString(metricsDto);
                } catch (Exception e) {
                    log.error("Failed to serialize metrics to JSON", e);
                }
            }
            
            try {
                // Update status to running
                pipelineExecution.setStatus(ExecutionStatus.RUNNING);
                pipelineExecution.setStartTime(LocalDateTime.now());
                
                // Trigger the pipeline in GitLab
                String gitlabPipelineId = gitlabService.triggerPipeline(pipeline, pipelineExecution, payloadJson);
                pipelineExecution.setGitlabPipelineId(gitlabPipelineId);
                
                pipelineExecutionRepository.save(pipelineExecution);
                
                log.info("Started pipeline execution: {} for flow execution: {}", 
                        pipelineExecution.getId(), flowExecutionId);
            } catch (Exception e) {
                log.error("Failed to start pipeline execution", e);
                
                // Mark as failed
                pipelineExecution.setStatus(ExecutionStatus.FAILED);
                pipelineExecution.setEndTime(LocalDateTime.now());
                pipelineExecutionRepository.save(pipelineExecution);
                
                // Mark flow as failed
                flowExecution.setStatus(ExecutionStatus.FAILED);
                flowExecution.setEndTime(LocalDateTime.now());
                flowExecutionRepository.save(flowExecution);
            }
        } else {
            // No more pending pipelines, check if all pipelines completed successfully
            boolean allCompleted = pipelineExecutions.stream()
                    .allMatch(pe -> pe.getStatus() == ExecutionStatus.COMPLETED);
            
            if (allCompleted) {
                flowExecution.setStatus(ExecutionStatus.COMPLETED);
                flowExecution.setEndTime(LocalDateTime.now());
                flowExecutionRepository.save(flowExecution);
                
                log.info("Flow execution completed successfully: {}", flowExecutionId);
            }
        }
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public ExecutionStatus getFlowExecutionStatus(Long flowExecutionId) {
        FlowExecution flowExecution = flowExecutionRepository.findById(flowExecutionId)
                .orElseThrow(() -> new ResourceNotFoundException("FlowExecution", "id", flowExecutionId));
        
        return flowExecution.getStatus();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public ExecutionStatus getPipelineExecutionStatus(Long pipelineExecutionId) {
        PipelineExecution pipelineExecution = pipelineExecutionRepository.findById(pipelineExecutionId)
                .orElseThrow(() -> new ResourceNotFoundException("PipelineExecution", "id", pipelineExecutionId));
        
        return pipelineExecution.getStatus();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void processPipelineMetrics(String gitlabPipelineId, ExecutionMetricsDto metricsDto) {
        PipelineExecution pipelineExecution = pipelineExecutionRepository.findByGitlabPipelineId(gitlabPipelineId)
                .orElseThrow(() -> new ResourceNotFoundException("PipelineExecution", "gitlabPipelineId", gitlabPipelineId));
        
        // Save metrics
        ExecutionMetrics metrics = convertDtoToMetrics(metricsDto);
        pipelineExecution.setMetrics(metrics);
        
        // Update pipeline execution status
        pipelineExecution.setStatus(ExecutionStatus.COMPLETED);
        pipelineExecution.setEndTime(LocalDateTime.now());
        
        pipelineExecutionRepository.save(pipelineExecution);
        
        // Start next pipeline
        startNextPipeline(pipelineExecution.getFlowExecution().getId());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public ExecutionMetricsDto getPipelineExecutionMetrics(Long pipelineExecutionId) {
        PipelineExecution pipelineExecution = pipelineExecutionRepository.findById(pipelineExecutionId)
                .orElseThrow(() -> new ResourceNotFoundException("PipelineExecution", "id", pipelineExecutionId));
        
        if (pipelineExecution.getMetrics() == null) {
            return null;
        }
        
        return convertMetricsToDto(pipelineExecution.getMetrics());
    }
    
    /**
     * Scheduled job to check status of running pipelines
     */
    @Scheduled(fixedRate = 30000) // Check every 30 seconds
    @Transactional
    public void checkRunningPipelines() {
        log.debug("Checking status of running pipelines");
        
        List<PipelineExecution> runningPipelines = pipelineExecutionRepository.findByStatus(ExecutionStatus.RUNNING);
        
        for (PipelineExecution pipelineExecution : runningPipelines) {
            // Skip if there's no GitLab pipeline ID
            if (pipelineExecution.getGitlabPipelineId() == null || pipelineExecution.getGitlabPipelineId().isEmpty()) {
                continue;
            }
            
            Application application = pipelineExecution.getPipeline().getApplication();
            
            try {
                if (gitlabService.isPipelineComplete(application, pipelineExecution.getGitlabPipelineId())) {
                    // If the webhook didn't process this pipeline (which it should have), mark it as completed
                    if (pipelineExecution.getStatus() == ExecutionStatus.RUNNING) {
                        pipelineExecution.setStatus(ExecutionStatus.COMPLETED);
                        pipelineExecution.setEndTime(LocalDateTime.now());
                        pipelineExecutionRepository.save(pipelineExecution);
                        
                        log.info("Marked pipeline execution as completed: {}", pipelineExecution.getId());
                        
                        // Start next pipeline
                        startNextPipeline(pipelineExecution.getFlowExecution().getId());
                    }
                } else if (gitlabService.isPipelineFailed(application, pipelineExecution.getGitlabPipelineId())) {
                    // Mark as failed
                    pipelineExecution.setStatus(ExecutionStatus.FAILED);
                    pipelineExecution.setEndTime(LocalDateTime.now());
                    pipelineExecutionRepository.save(pipelineExecution);
                    
                    // Mark flow as failed
                    FlowExecution flowExecution = pipelineExecution.getFlowExecution();
                    flowExecution.setStatus(ExecutionStatus.FAILED);
                    flowExecution.setEndTime(LocalDateTime.now());
                    flowExecutionRepository.save(flowExecution);
                    
                    log.info("Marked pipeline execution as failed: {}", pipelineExecution.getId());
                }
            } catch (Exception e) {
                log.error("Failed to check pipeline status: {}", pipelineExecution.getGitlabPipelineId(), e);
            }
        }
    }
    
    /**
     * Convert ExecutionMetricsDto to ExecutionMetrics entity
     *
     * @param dto ExecutionMetricsDto
     * @return ExecutionMetrics entity
     */
    private ExecutionMetrics convertDtoToMetrics(ExecutionMetricsDto dto) {
        ExecutionMetrics metrics = ExecutionMetrics.builder()
                .appId(dto.getAppId())
                .appName(dto.getAppName())
                .appDescription(dto.getAppDescription())
                .customData(dto.getCustomData() != null ? new HashMap<>(dto.getCustomData()) : new HashMap<>())
                .build();
        
        List<TestSuite> suites = new ArrayList<>();
        if (dto.getSuites() != null) {
            for (ExecutionMetricsDto.TestSuiteDto suiteDto : dto.getSuites()) {
                TestSuite suite = TestSuite.builder()
                        .name(suiteDto.getName())
                        .description(suiteDto.getDescription())
                        .tags(suiteDto.getTags() != null ? new ArrayList<>(suiteDto.getTags()) : new ArrayList<>())
                        .startTime(suiteDto.getStartTime())
                        .endTime(suiteDto.getEndTime())
                        .tests(new HashMap<>())
                        .build();
                
                if (suiteDto.getTests() != null) {
                    for (Map.Entry<String, ExecutionMetricsDto.TestDto> entry : suiteDto.getTests().entrySet()) {
                        ExecutionMetricsDto.TestDto testDto = entry.getValue();
                        Test test = Test.builder()
                                .name(testDto.getName())
                                .description(testDto.getDescription())
                                .tags(testDto.getTags() != null ? new ArrayList<>(testDto.getTags()) : new ArrayList<>())
                                .startTime(testDto.getStartTime())
                                .endTime(testDto.getEndTime())
                                .logs(new ArrayList<>())
                                .build();
                        
                        if (testDto.getLogs() != null) {
                            for (ExecutionMetricsDto.LogDto logDto : testDto.getLogs()) {
                                Log log = Log.builder()
                                        .message(logDto.getMessage())
                                        .status(logDto.getStatus())
                                        .build();
                                
                                test.getLogs().add(log);
                            }
                        }
                        
                        suite.getTests().put(entry.getKey(), test);
                    }
                }
                
                suites.add(suite);
            }
        }
        
        metrics.setSuites(suites);
        
        return metrics;
    }
    
    /**
     * Convert ExecutionMetrics entity to ExecutionMetricsDto
     *
     * @param metrics ExecutionMetrics entity
     * @return ExecutionMetricsDto
     */
    private ExecutionMetricsDto convertMetricsToDto(ExecutionMetrics metrics) {
        ExecutionMetricsDto dto = ExecutionMetricsDto.builder()
                .appId(metrics.getAppId())
                .appName(metrics.getAppName())
                .appDescription(metrics.getAppDescription())
                .customData(metrics.getCustomData() != null ? new HashMap<>(metrics.getCustomData()) : new HashMap<>())
                .build();
        
        List<ExecutionMetricsDto.TestSuiteDto> suiteDtos = new ArrayList<>();
        if (metrics.getSuites() != null) {
            for (TestSuite suite : metrics.getSuites()) {
                ExecutionMetricsDto.TestSuiteDto suiteDto = ExecutionMetricsDto.TestSuiteDto.builder()
                        .name(suite.getName())
                        .description(suite.getDescription())
                        .tags(suite.getTags() != null ? new ArrayList<>(suite.getTags()) : new ArrayList<>())
                        .startTime(suite.getStartTime())
                        .endTime(suite.getEndTime())
                        .tests(new HashMap<>())
                        .build();
                
                if (suite.getTests() != null) {
                    for (Map.Entry<String, Test> entry : suite.getTests().entrySet()) {
                        Test test = entry.getValue();
                        ExecutionMetricsDto.TestDto testDto = ExecutionMetricsDto.TestDto.builder()
                                .name(test.getName())
                                .description(test.getDescription())
                                .tags(test.getTags() != null ? new ArrayList<>(test.getTags()) : new ArrayList<>())
                                .startTime(test.getStartTime())
                                .endTime(test.getEndTime())
                                .logs(new ArrayList<>())
                                .build();
                        
                        if (test.getLogs() != null) {
                            for (Log log : test.getLogs()) {
                                ExecutionMetricsDto.LogDto logDto = ExecutionMetricsDto.LogDto.builder()
                                        .message(log.getMessage())
                                        .status(log.getStatus())
                                        .build();
                                
                                testDto.getLogs().add(logDto);
                            }
                        }
                        
                        suiteDto.getTests().put(entry.getKey(), testDto);
                    }
                }
                
                suiteDtos.add(suiteDto);
            }
        }
        
        dto.setSuites(suiteDtos);
        
        return dto;
    }
}
