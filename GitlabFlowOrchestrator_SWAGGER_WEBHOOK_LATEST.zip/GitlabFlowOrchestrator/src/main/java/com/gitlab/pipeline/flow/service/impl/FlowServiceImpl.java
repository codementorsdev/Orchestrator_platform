package com.gitlab.pipeline.flow.service.impl;

import com.gitlab.pipeline.flow.dto.FlowDto;
import com.gitlab.pipeline.flow.dto.PipelineDto;
import com.gitlab.pipeline.flow.exception.ApiException;
import com.gitlab.pipeline.flow.exception.ResourceNotFoundException;
import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.model.Flow;
import com.gitlab.pipeline.flow.model.FlowExecution;
import com.gitlab.pipeline.flow.model.Pipeline;
import com.gitlab.pipeline.flow.repository.FlowExecutionRepository;
import com.gitlab.pipeline.flow.repository.FlowRepository;
import com.gitlab.pipeline.flow.service.FlowService;
import com.gitlab.pipeline.flow.service.PipelineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Implementation of FlowService
 */
@Service
@RequiredArgsConstructor
public class FlowServiceImpl implements FlowService {
    
    private final FlowRepository flowRepository;
    private final FlowExecutionRepository flowExecutionRepository;
    private final PipelineService pipelineService;
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public FlowDto createFlow(FlowDto flowDto) {
        // Check if flow with same name already exists
        if (flowRepository.existsByName(flowDto.getName())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Flow with name '" + flowDto.getName() + "' already exists");
        }
        
        Flow flow = convertToEntity(flowDto);
        Flow savedFlow = flowRepository.save(flow);
        
        // Now that flow is saved, create the pipelines
        if (!flowDto.getPipelines().isEmpty()) {
            for (PipelineDto pipelineDto : flowDto.getPipelines()) {
                pipelineDto.setFlowId(savedFlow.getId());
                pipelineService.createPipeline(pipelineDto);
            }
        }
        
        // Reload flow to get the pipelines
        Flow reloadedFlow = flowRepository.findById(savedFlow.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", savedFlow.getId()));
        
        return convertToDto(reloadedFlow);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public FlowDto getFlowById(Long id) {
        Flow flow = flowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", id));
        
        return convertToDto(flow);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public FlowDto getFlowByName(String name) {
        Flow flow = flowRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "name", name));
        
        return convertToDto(flow);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<FlowDto> getAllFlows() {
        return flowRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public FlowDto updateFlow(Long id, FlowDto flowDto) {
        Flow flow = flowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", id));
        
        // Check if name is being changed and if new name is already in use
        if (!flow.getName().equals(flowDto.getName()) && 
                flowRepository.existsByName(flowDto.getName())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Flow with name '" + flowDto.getName() + "' already exists");
        }
        
        flow.setName(flowDto.getName());
        flow.setDescription(flowDto.getDescription());
        
        Flow updatedFlow = flowRepository.save(flow);
        
        // Handle pipeline updates if provided
        if (flowDto.getPipelines() != null && !flowDto.getPipelines().isEmpty()) {
            // Get existing pipelines
            List<PipelineDto> existingPipelines = pipelineService.getPipelinesByFlowId(id);
            
            // Delete pipelines that are not in the updated list
            for (PipelineDto existingPipeline : existingPipelines) {
                boolean found = false;
                for (PipelineDto updatedPipeline : flowDto.getPipelines()) {
                    if (updatedPipeline.getId() != null && updatedPipeline.getId().equals(existingPipeline.getId())) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    pipelineService.deletePipeline(existingPipeline.getId());
                }
            }
            
            // Update or create pipelines
            for (PipelineDto pipelineDto : flowDto.getPipelines()) {
                pipelineDto.setFlowId(id);
                if (pipelineDto.getId() != null) {
                    pipelineService.updatePipeline(pipelineDto.getId(), pipelineDto);
                } else {
                    pipelineService.createPipeline(pipelineDto);
                }
            }
        }
        
        // Reload flow to get updated pipelines
        Flow reloadedFlow = flowRepository.findById(updatedFlow.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", updatedFlow.getId()));
        
        return convertToDto(reloadedFlow);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void deleteFlow(Long id) {
        if (!flowRepository.existsById(id)) {
            throw new ResourceNotFoundException("Flow", "id", id);
        }
        
        flowRepository.deleteById(id);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public ExecutionStatus getFlowStatus(Long id) {
        Flow flow = flowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", id));
        
        List<FlowExecution> executions = flowExecutionRepository.findByFlow(flow);
        
        if (executions.isEmpty()) {
            return ExecutionStatus.PENDING;
        }
        
        // Get the most recent execution
        executions.sort(Comparator.comparing(FlowExecution::getCreatedAt).reversed());
        return executions.get(0).getStatus();
    }
    
    /**
     * Convert Flow entity to FlowDto
     *
     * @param flow Flow entity
     * @return FlowDto
     */
    private FlowDto convertToDto(Flow flow) {
        List<PipelineDto> pipelineDtos = flow.getPipelines().stream()
                .sorted(Comparator.comparing(Pipeline::getExecutionSequence))
                .map(pipeline -> PipelineDto.builder()
                        .id(pipeline.getId())
                        .name(pipeline.getName())
                        .description(pipeline.getDescription())
                        .branch(pipeline.getBranch())
                        .executionSequence(pipeline.getExecutionSequence())
                        .gitlabInstanceUrl(pipeline.getGitlabInstanceUrl())
                        .applicationId(pipeline.getApplication().getId())
                        .applicationName(pipeline.getApplication().getName())
                        .flowId(flow.getId())
                        .build())
                .collect(Collectors.toList());
        
        return FlowDto.builder()
                .id(flow.getId())
                .name(flow.getName())
                .description(flow.getDescription())
                .pipelines(pipelineDtos)
                .build();
    }
    
    /**
     * Convert FlowDto to Flow entity
     *
     * @param flowDto FlowDto
     * @return Flow entity
     */
    private Flow convertToEntity(FlowDto flowDto) {
        return Flow.builder()
                .name(flowDto.getName())
                .description(flowDto.getDescription())
                .build();
    }
}
