package com.gitlab.pipeline.flow.service.impl;

import com.gitlab.pipeline.flow.model.Application;
import com.gitlab.pipeline.flow.model.Pipeline;
import com.gitlab.pipeline.flow.model.PipelineExecution;
import com.gitlab.pipeline.flow.service.GitlabService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Job;
import org.gitlab4j.api.models.ProjectHook;
import org.gitlab4j.api.models.Variable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Implementation of GitlabService
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class GitlabServiceImpl implements GitlabService {
    
    @Value("${server.port:8000}")
    private int serverPort;
    
    @Value("${server.servlet.context-path:/api}")
    private String contextPath;
    
    private final Map<String, GitLabApi> gitLabApiCache = new ConcurrentHashMap<>();
    
    /**
     * {@inheritDoc}
     */
    @Override
    public String triggerPipeline(Pipeline pipeline, PipelineExecution pipelineExecution, String payloadJson) {
        Application application = pipeline.getApplication();
        GitLabApi gitLabApi = getGitLabApi(application, pipeline.getGitlabInstanceUrl());
        
        try {
            // Ensure webhook is set up for the project
            setupWebhook(gitLabApi, application);
            
            // Create/update variable for the payload if provided
            if (StringUtils.hasText(payloadJson)) {
                try {
                    Variable variable = new Variable();
                    variable.setKey("PIPELINE_EXECUTION_PAYLOAD");
                    variable.setValue(payloadJson);
                    
                    gitLabApi.getProjectApi().updateVariable(
                            application.getProjectId(),
                            variable.getKey(),
                            variable.getValue(),
                            false,
                            "all"
                    );
                } catch (GitLabApiException e) {
                    // Variable doesn't exist, create it
                    if (e.getHttpStatus() == 404) {
                        Variable variable = new Variable();
                        variable.setKey("PIPELINE_EXECUTION_PAYLOAD");
                        variable.setValue(payloadJson);
                        variable.setProtected(false);
                        
                        gitLabApi.getProjectApi().createVariable(
                                application.getProjectId(),
                                variable.getKey(),
                                variable.getValue(),
                                false,
                                "all"
                        );
                    } else {
                        throw e;
                    }
                }
            }
            
            // Trigger the pipeline
            org.gitlab4j.api.models.Pipeline gitlabPipeline = gitLabApi.getPipelineApi().createPipeline(
                    application.getProjectId(),
                    pipeline.getBranch()
            );
            
            return String.valueOf(gitlabPipeline.getId());
        } catch (GitLabApiException e) {
            log.error("Failed to trigger GitLab pipeline", e);
            throw new RuntimeException("Failed to trigger GitLab pipeline: " + e.getMessage(), e);
        }
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isPipelineComplete(Application application, String gitlabPipelineId) {
        try {
            String status = getPipelineStatus(application, gitlabPipelineId);
            return "success".equalsIgnoreCase(status);
        } catch (Exception e) {
            log.error("Failed to check pipeline status", e);
            return false;
        }
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isPipelineFailed(Application application, String gitlabPipelineId) {
        try {
            String status = getPipelineStatus(application, gitlabPipelineId);
            return "failed".equalsIgnoreCase(status) || "canceled".equalsIgnoreCase(status);
        } catch (Exception e) {
            log.error("Failed to check pipeline status", e);
            return true;
        }
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public String getPipelineStatus(Application application, String gitlabPipelineId) {
        GitLabApi gitLabApi = getGitLabApi(application, null);
        
        try {
            org.gitlab4j.api.models.Pipeline pipeline = gitLabApi.getPipelineApi().getPipeline(
                    application.getProjectId(),
                    Long.parseLong(gitlabPipelineId)
            );
            
            return pipeline.getStatus().toString();
        } catch (GitLabApiException e) {
            log.error("Failed to get pipeline status", e);
            throw new RuntimeException("Failed to get pipeline status: " + e.getMessage(), e);
        }
    }
    
    /**
     * Get or create a GitLabApi instance for the application
     *
     * @param application Application to get GitLabApi for
     * @param gitlabInstanceUrl GitLab instance URL (optional, can be null)
     * @return GitLabApi instance
     */
    private GitLabApi getGitLabApi(Application application, String gitlabInstanceUrl) {
        String cacheKey = application.getId() + ":" + (gitlabInstanceUrl != null ? gitlabInstanceUrl : "default");
        
        return gitLabApiCache.computeIfAbsent(cacheKey, k -> {
            String hostUrl = gitlabInstanceUrl != null && !gitlabInstanceUrl.isEmpty() ?
                    gitlabInstanceUrl : "https://gitlab.com";
            
            return new GitLabApi(hostUrl, application.getAccessToken());
        });
    }
    
    /**
     * Set up a webhook for the project to report back pipeline status
     *
     * @param gitLabApi GitLabApi instance
     * @param application Application to set up webhook for
     * @throws GitLabApiException if an error occurs
     */
    private void setupWebhook(GitLabApi gitLabApi, Application application) throws GitLabApiException {
        List<ProjectHook> hooks = gitLabApi.getProjectApi().getHooks(application.getProjectId());
        String webhookUrl = determineWebhookUrl();
        
        // Check if webhook already exists
        for (ProjectHook hook : hooks) {
            if (hook.getUrl().equals(webhookUrl)) {
                // Webhook exists, ensure it has the right events
                if (!hook.getPipelineEvents()) {
                    hook.setPipelineEvents(true);
                    gitLabApi.getProjectApi().modifyHook(hook);
                }
                return;
            }
        }
        
        // Create a new webhook
        ProjectHook hook = new ProjectHook();
        hook.setUrl(webhookUrl);
        hook.setPipelineEvents(true);
        hook.setJobEvents(true);
        hook.setPushEvents(false);
        hook.setIssuesEvents(false);
        hook.setMergeRequestsEvents(false);
        hook.setTagPushEvents(false);
        hook.setNoteEvents(false);
        hook.setConfidentialIssuesEvents(false);
        hook.setConfidentialNoteEvents(false);
        hook.setWikiPageEvents(false);
        hook.setReleasesEvents(false);
        
        gitLabApi.getProjectApi().addHook(application.getProjectId(), hook.getUrl(), 
                hook.getPipelineEvents(), hook.getJobEvents(), hook.getPushEvents());
    }
    
    /**
     * Determine the webhook URL to use
     *
     * @return Webhook URL
     */
    private String determineWebhookUrl() {
        // Use server's public URL if available
        // In a real implementation, this would be configurable or determined dynamically
        // For this example, we'll use a simple approach
        String serverUrl = "http://localhost:" + serverPort;
        String endpoint = contextPath + "/webhooks/gitlab";
        
        return serverUrl + endpoint;
    }
}
