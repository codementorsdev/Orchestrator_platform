package com.gitlab.pipeline.flow.service.impl;

import com.gitlab.pipeline.flow.dto.PipelineDto;
import com.gitlab.pipeline.flow.exception.ApiException;
import com.gitlab.pipeline.flow.exception.ResourceNotFoundException;
import com.gitlab.pipeline.flow.model.Application;
import com.gitlab.pipeline.flow.model.ExecutionStatus;
import com.gitlab.pipeline.flow.model.Flow;
import com.gitlab.pipeline.flow.model.Pipeline;
import com.gitlab.pipeline.flow.model.FlowExecution;
import com.gitlab.pipeline.flow.model.PipelineExecution;
import com.gitlab.pipeline.flow.repository.ApplicationRepository;
import com.gitlab.pipeline.flow.repository.FlowExecutionRepository;
import com.gitlab.pipeline.flow.repository.FlowRepository;
import com.gitlab.pipeline.flow.repository.PipelineExecutionRepository;
import com.gitlab.pipeline.flow.repository.PipelineRepository;
import com.gitlab.pipeline.flow.service.PipelineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of PipelineService
 */
@Service
@RequiredArgsConstructor
public class PipelineServiceImpl implements PipelineService {
    
    private final PipelineRepository pipelineRepository;
    private final ApplicationRepository applicationRepository;
    private final FlowRepository flowRepository;
    private final FlowExecutionRepository flowExecutionRepository;
    private final PipelineExecutionRepository pipelineExecutionRepository;
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public PipelineDto createPipeline(PipelineDto pipelineDto) {
        // Check if application exists
        Application application = applicationRepository.findById(pipelineDto.getApplicationId())
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", pipelineDto.getApplicationId()));
        
        // Check if flow exists if flowId is provided
        Flow flow = null;
        if (pipelineDto.getFlowId() != null) {
            flow = flowRepository.findById(pipelineDto.getFlowId())
                    .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", pipelineDto.getFlowId()));
        }
        
        Pipeline pipeline = convertToEntity(pipelineDto, application, flow);
        Pipeline savedPipeline = pipelineRepository.save(pipeline);
        
        return convertToDto(savedPipeline);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public PipelineDto getPipelineById(Long id) {
        Pipeline pipeline = pipelineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline", "id", id));
        
        return convertToDto(pipeline);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<PipelineDto> getAllPipelines() {
        return pipelineRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public List<PipelineDto> getPipelinesByFlowId(Long flowId) {
        Flow flow = flowRepository.findById(flowId)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", flowId));
        
        return pipelineRepository.findByFlowOrderByExecutionSequenceAsc(flow).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public PipelineDto updatePipeline(Long id, PipelineDto pipelineDto) {
        Pipeline pipeline = pipelineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline", "id", id));
        
        // Check if application exists
        Application application = applicationRepository.findById(pipelineDto.getApplicationId())
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", pipelineDto.getApplicationId()));
        
        pipeline.setName(pipelineDto.getName());
        pipeline.setDescription(pipelineDto.getDescription());
        pipeline.setBranch(pipelineDto.getBranch());
        pipeline.setExecutionSequence(pipelineDto.getExecutionSequence());
        pipeline.setGitlabInstanceUrl(pipelineDto.getGitlabInstanceUrl());
        pipeline.setApplication(application);
        
        // Update flow if provided and changed
        if (pipelineDto.getFlowId() != null && 
                (pipeline.getFlow() == null || !pipeline.getFlow().getId().equals(pipelineDto.getFlowId()))) {
            Flow flow = flowRepository.findById(pipelineDto.getFlowId())
                    .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", pipelineDto.getFlowId()));
            pipeline.setFlow(flow);
        }
        
        Pipeline updatedPipeline = pipelineRepository.save(pipeline);
        
        return convertToDto(updatedPipeline);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void deletePipeline(Long id) {
        if (!pipelineRepository.existsById(id)) {
            throw new ResourceNotFoundException("Pipeline", "id", id);
        }
        
        pipelineRepository.deleteById(id);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional(readOnly = true)
    public ExecutionStatus getPipelineStatus(Long flowExecutionId, Long pipelineId) {
        FlowExecution flowExecution = flowExecutionRepository.findById(flowExecutionId)
                .orElseThrow(() -> new ResourceNotFoundException("FlowExecution", "id", flowExecutionId));
        
        Pipeline pipeline = pipelineRepository.findById(pipelineId)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline", "id", pipelineId));
        
        List<PipelineExecution> pipelineExecutions = pipelineExecutionRepository.findByFlowExecutionAndStatus(
                flowExecution,
                ExecutionStatus.COMPLETED
        );
        
        for (PipelineExecution execution : pipelineExecutions) {
            if (execution.getPipeline().getId().equals(pipelineId)) {
                return execution.getStatus();
            }
        }
        
        // Check if there is a pipeline execution with a status other than COMPLETED
        List<PipelineExecution> allPipelineExecutions = pipelineExecutionRepository.findByFlowExecution(flowExecution);
        for (PipelineExecution execution : allPipelineExecutions) {
            if (execution.getPipeline().getId().equals(pipelineId)) {
                return execution.getStatus();
            }
        }
        
        return ExecutionStatus.PENDING;
    }
    
    /**
     * Convert Pipeline entity to PipelineDto
     *
     * @param pipeline Pipeline entity
     * @return PipelineDto
     */
    private PipelineDto convertToDto(Pipeline pipeline) {
        PipelineDto pipelineDto = PipelineDto.builder()
                .id(pipeline.getId())
                .name(pipeline.getName())
                .description(pipeline.getDescription())
                .branch(pipeline.getBranch())
                .executionSequence(pipeline.getExecutionSequence())
                .gitlabInstanceUrl(pipeline.getGitlabInstanceUrl())
                .applicationId(pipeline.getApplication().getId())
                .applicationName(pipeline.getApplication().getName())
                .build();
        
        if (pipeline.getFlow() != null) {
            pipelineDto.setFlowId(pipeline.getFlow().getId());
        }
        
        return pipelineDto;
    }
    
    /**
     * Convert PipelineDto to Pipeline entity
     *
     * @param pipelineDto PipelineDto
     * @param application Application entity
     * @param flow Flow entity (can be null)
     * @return Pipeline entity
     */
    private Pipeline convertToEntity(PipelineDto pipelineDto, Application application, Flow flow) {
        return Pipeline.builder()
                .name(pipelineDto.getName())
                .description(pipelineDto.getDescription())
                .branch(pipelineDto.getBranch())
                .executionSequence(pipelineDto.getExecutionSequence())
                .gitlabInstanceUrl(pipelineDto.getGitlabInstanceUrl())
                .application(application)
                .flow(flow)
                .build();
    }
}
