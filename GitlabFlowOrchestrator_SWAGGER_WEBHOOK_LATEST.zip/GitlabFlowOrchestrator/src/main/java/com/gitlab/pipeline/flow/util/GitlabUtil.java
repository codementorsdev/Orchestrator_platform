package com.gitlab.pipeline.flow.util;

import com.gitlab.pipeline.flow.model.ExecutionStatus;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Pipeline;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * Utility class for GitLab operations
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class GitlabUtil {
    
    /**
     * Convert GitLab pipeline status to ExecutionStatus
     *
     * @param gitlabStatus GitLab pipeline status
     * @return ExecutionStatus
     */
    public static ExecutionStatus convertGitlabStatus(String gitlabStatus) {
        if (gitlabStatus == null) {
            return ExecutionStatus.PENDING;
        }
        
        return switch (gitlabStatus.toLowerCase()) {
            case "running", "pending", "created" -> ExecutionStatus.RUNNING;
            case "success" -> ExecutionStatus.COMPLETED;
            case "failed", "canceled" -> ExecutionStatus.FAILED;
            case "skipped" -> ExecutionStatus.SKIPPED;
            default -> ExecutionStatus.PENDING;
        };
    }
    
    /**
     * Convert Pipeline object status to ExecutionStatus
     *
     * @param pipeline GitLab Pipeline object
     * @return ExecutionStatus
     */
    public static ExecutionStatus convertPipelineStatus(Pipeline pipeline) {
        if (pipeline == null) {
            return ExecutionStatus.PENDING;
        }
        
        return convertGitlabStatus(pipeline.getStatus().toString());
    }
    
    /**
     * Validate GitLab URL
     *
     * @param url GitLab URL to validate
     * @return true if URL is valid, false otherwise
     */
    public static boolean isValidGitlabUrl(String url) {
        try {
            new URI(url);
            return true;
        } catch (URISyntaxException e) {
            return false;
        }
    }
    
    /**
     * Format GitLab API exception message
     *
     * @param e GitLabApiException
     * @return Formatted error message
     */
    public static String formatGitLabApiException(GitLabApiException e) {
        String errorMessage = e.getMessage();
        StringBuilder formattedError = new StringBuilder("GitLab API Error: ");
        
        if (e.getHttpStatus() != 0) {
            formattedError.append("HTTP ").append(e.getHttpStatus()).append(" - ");
        }
        
        if (e.getReason() != null && !e.getReason().isEmpty()) {
            formattedError.append(e.getReason());
        } else if (errorMessage != null && !errorMessage.isEmpty()) {
            formattedError.append(errorMessage);
        } else {
            formattedError.append("Unknown error");
        }
        
        return formattedError.toString();
    }
    
    /**
     * Extract project ID from various formats
     * 
     * @param projectId Project ID or path
     * @return Normalized project ID
     */
    public static String normalizeProjectId(String projectId) {
        // If project ID is a number, return as is
        if (projectId.matches("^\\d+$")) {
            return projectId;
        }
        
        // If project ID contains '/', it's a path with namespace
        if (projectId.contains("/")) {
            // URL encode the path
            try {
                return java.net.URLEncoder.encode(projectId, "UTF-8");
            } catch (java.io.UnsupportedEncodingException e) {
                log.error("Failed to encode project ID", e);
                return projectId;
            }
        }
        
        return projectId;
    }
    
    /**
     * Build a webhook URL for GitLab
     *
     * @param baseUrl Base URL of the API
     * @param path Path for the webhook endpoint
     * @return Complete webhook URL
     */
    public static String buildWebhookUrl(String baseUrl, String path) {
        if (baseUrl.endsWith("/")) {
            baseUrl = baseUrl.substring(0, baseUrl.length() - 1);
        }
        
        if (!path.startsWith("/")) {
            path = "/" + path;
        }
        
        return baseUrl + path;
    }
}
