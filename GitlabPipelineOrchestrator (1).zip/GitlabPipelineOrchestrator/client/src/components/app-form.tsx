import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { gitlabApi } from "@/lib/gitlab-api";
import { useToast } from "@/hooks/use-toast";
import type { App } from "@shared/schema";
import { Textarea } from "@/components/ui/textarea";

const appFormSchema = z.object({
  name: z.string().min(1, "App name is required"),
  accessToken: z.string().min(1, "Access token is required"),
  projectId: z.string().min(1, "Project ID is required"),
  envVars: z.string().optional(),
});

type AppFormData = z.infer<typeof appFormSchema>;

interface AppFormProps {
  app?: App | null;
  onClose: () => void;
}

export function AppForm({ app, onClose }: AppFormProps) {
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<"idle" | "success" | "error">("idle");
  const { toast } = useToast();

  const form = useForm<AppFormData>({
    resolver: zodResolver(appFormSchema),
    defaultValues: {
      name: app?.name || "",
      accessToken: app?.accessToken || "",
      projectId: app?.projectId || "",
      envVars: app?.envVars || "",
    },
  });

  const createAppMutation = useMutation({
    mutationFn: async (data: AppFormData) => {
      if (app) {
        return apiRequest("PUT", `/api/apps/${app.id}`, data);
      } else {
        return apiRequest("POST", "/api/apps", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/apps"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: app ? "App updated successfully" : "App created successfully",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save app",
        variant: "destructive",
      });
    },
  });

  const testConnection = async () => {
    const formData = form.getValues();
    if (!formData.accessToken || !formData.projectId) {
      toast({
        title: "Missing Information",
        description: "Please enter access token and project ID first",
        variant: "destructive",
      });
      return;
    }

    setIsTestingConnection(true);
    setConnectionStatus("idle");

    try {
      const project = await gitlabApi.getProject(formData.projectId, formData.accessToken);

      // If we get project data, connection is successful
      if (project && project.id) {
        setConnectionStatus("success");

        // Auto-fill app name if not provided
        if (!formData.name && project.name) {
          form.setValue("name", project.name);
        }

        toast({
          title: "Connection Successful",
          description: `Connected to project: ${project.name}`,
        });
      }
    } catch (error) {
      console.error("Connection test failed:", error);
      setConnectionStatus("error");
      toast({
        title: "Connection Failed",
        description: "Failed to connect to GitLab project. Please check your credentials.",
        variant: "destructive",
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  const onSubmit = (data: AppFormData) => {
    createAppMutation.mutate(data);
  };

  // Reset connection status when form data changes
  useEffect(() => {
    setConnectionStatus("idle");
  }, [form.watch("accessToken"), form.watch("projectId")]);

  return (
    <Card>
      <CardContent className="pt-6">
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="name">App Name</Label>
            <Input
              id="name"
              {...form.register("name")}
              placeholder="Enter app name"
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.name.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="accessToken">GitLab Access Token</Label>
            <Input
              id="accessToken"
              type="password"
              {...form.register("accessToken")}
              placeholder="glpat-xxxxxxxxxxxxxxxxxxxx"
            />
            <p className="text-xs text-gray-500 mt-1">
              Your GitLab personal access token with API scope
            </p>
            {form.formState.errors.accessToken && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.accessToken.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="projectId">GitLab Project ID</Label>
            <Input
              id="projectId"
              {...form.register("projectId")}
              placeholder="12345678"
            />
            <p className="text-xs text-gray-500 mt-1">
              GitLab project ID from project settings
            </p>
            {form.formState.errors.projectId && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.projectId.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="envVars">Environment Variables</Label>
            <Textarea
              id="envVars"
              {...form.register("envVars")}
              placeholder="ENV_VAR1=value1, ENV_VAR2=value2, API_KEY=secret123"
              rows={4}
            />
            <p className="text-xs text-gray-500 mt-1">
              Comma-separated key=value pairs. These will be injected into pipeline runs for this app.
            </p>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={testConnection}
              disabled={isTestingConnection}
            >
              {isTestingConnection ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : connectionStatus === "success" ? (
                <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
              ) : connectionStatus === "error" ? (
                <AlertCircle className="h-4 w-4 mr-2 text-red-600" />
              ) : null}
              Test Connection
            </Button>

            <Button
              type="submit"
              disabled={createAppMutation.isPending}
            >
              {createAppMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : null}
              {app ? "Update App" : "Save App"}
            </Button>

            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}