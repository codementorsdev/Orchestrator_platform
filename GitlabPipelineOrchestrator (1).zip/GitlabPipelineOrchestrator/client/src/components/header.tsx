import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { RefreshCw, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const pageConfig = {
  "/": {
    title: "Dashboard",
    description: "Overview of pipeline executions and system metrics",
    action: null,
  },
  "/apps": {
    title: "Apps Management",
    description: "Configure GitLab applications with access tokens",
    action: { label: "Add App", icon: Plus },
  },
  "/test-cases": {
    title: "Test Cases",
    description: "Create and manage test case configurations",
    action: { label: "Create Test Case", icon: Plus },
  },
  "/executions": {
    title: "Pipeline Executions",
    description: "Monitor and execute pipeline runs in real-time",
    action: { label: "Refresh", icon: RefreshCw },
  },
};

export function Header() {
  const [location] = useLocation();
  const config = pageConfig[location as keyof typeof pageConfig] || pageConfig["/"];

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{config.title}</h2>
          <p className="text-gray-600 mt-1">{config.description}</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>GitLab Connected</span>
          </div>
          {config.action && (
            <Button>
              <config.action.icon className="w-4 h-4 mr-2" />
              {config.action.label}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
