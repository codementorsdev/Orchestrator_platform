import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Clock, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { gitlabApi } from "@/lib/gitlab-api";
import type { ExecutionWithDetails } from "@shared/schema";

interface PipelineMonitorProps {
  execution: ExecutionWithDetails;
}

export function PipelineMonitor({ execution }: PipelineMonitorProps) {
  // Poll GitLab for real-time pipeline status
  const { data: pipelineStatuses } = useQuery({
    queryKey: ["pipeline-status", execution.id],
    queryFn: async () => {
      const statuses = await Promise.all(
        execution.pipelineRuns.map(async (run) => {
          if (!run.pipelineId) return null;
          
          try {
            const [pipeline, jobs] = await Promise.all([
              gitlabApi.getPipeline(run.app.projectId, run.pipelineId, run.app.accessToken),
              gitlabApi.getPipelineJobs(run.app.projectId, run.pipelineId, run.app.accessToken),
            ]);

            return {
              runId: run.id,
              pipeline,
              jobs,
              stages: jobs.reduce((acc: any[], job: any) => {
                const existingStage = acc.find(s => s.name === job.stage);
                if (existingStage) {
                  existingStage.jobs.push(job);
                  // Update stage status to worst job status
                  if (job.status === 'failed' || (job.status === 'running' && existingStage.status === 'pending')) {
                    existingStage.status = job.status;
                  }
                } else {
                  acc.push({
                    name: job.stage,
                    status: job.status,
                    jobs: [job],
                  });
                }
                return acc;
              }, []),
            };
          } catch (error) {
            console.error(`Failed to fetch pipeline status for run ${run.id}:`, error);
            return null;
          }
        })
      );

      return statuses.filter(Boolean);
    },
    refetchInterval: execution.status === "running" ? 5000 : false, // Poll every 5 seconds if running
    enabled: execution.pipelineRuns.some(run => run.pipelineId),
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-600" />;
      case "running":
        return <Loader2 className="h-4 w-4 text-blue-600 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "running":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getProgressValue = (status: string) => {
    switch (status) {
      case "success":
        return 100;
      case "failed":
        return 100;
      case "running":
        return 60;
      default:
        return 0;
    }
  };

  const formatDuration = (startTime: string, endTime?: string) => {
    const start = new Date(startTime);
    const end = endTime ? new Date(endTime) : new Date();
    const diffMs = end.getTime() - start.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const minutes = Math.floor(diffSec / 60);
    const seconds = diffSec % 60;
    return `${minutes}m ${seconds}s`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-lg font-medium text-gray-900">
          Live Execution: {execution.testCase.name}
        </h4>
        <div className="flex items-center space-x-2">
          <Badge className={getStatusColor(execution.status)}>
            {execution.status}
          </Badge>
          <span className="text-sm text-gray-500">
            {execution.startedAt && formatDuration(execution.startedAt)}
          </span>
        </div>
      </div>

      {/* Sequential Progress Indicator */}
      <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
        <span className="text-sm font-medium text-gray-700">Sequential Progress:</span>
        {execution.pipelineRuns
          .sort((a, b) => a.order - b.order)
          .map((run, index) => (
            <div key={run.id} className="flex items-center">
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                  run.status === 'success' ? 'bg-green-500 text-white' :
                  run.status === 'failed' ? 'bg-red-500 text-white' :
                  run.status === 'running' ? 'bg-blue-500 text-white' :
                  run.status === 'canceled' ? 'bg-gray-400 text-white' :
                  'bg-gray-200 text-gray-600'
                }`}
              >
                {index + 1}
              </div>
              {index < execution.pipelineRuns.length - 1 && (
                <div className={`w-8 h-0.5 mx-1 ${
                  run.status === 'success' ? 'bg-green-300' : 'bg-gray-300'
                }`}></div>
              )}
            </div>
          ))
        }
      </div>

      <div className="space-y-4">
        {execution.pipelineRuns
          .sort((a, b) => a.order - b.order)
          .map((run, index) => {
          const pipelineStatus = pipelineStatuses?.find(s => s.runId === run.id);
          
          return (
            <div key={run.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded">
                    Step {index + 1}/{execution.pipelineRuns.length}
                  </span>
                  {getStatusIcon(pipelineStatus?.pipeline?.status || run.status)}
                  <h5 className="font-medium text-gray-900">
                    {run.app.name} - Project ID: {run.app.projectId}
                  </h5>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-500 font-mono">{run.branch} branch</span>
                  <Badge className={getStatusColor(pipelineStatus?.pipeline?.status || run.status)}>
                    {pipelineStatus?.pipeline?.status || run.status}
                  </Badge>
                </div>
              </div>

              {pipelineStatus?.pipeline && (
                <div className="mb-3">
                  <p className="text-sm text-gray-600">
                    Pipeline #{pipelineStatus.pipeline.id} • 
                    {pipelineStatus.pipeline.web_url && (
                      <a 
                        href={pipelineStatus.pipeline.web_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline ml-1"
                      >
                        View in GitLab
                      </a>
                    )}
                  </p>
                </div>
              )}

              {/* Pipeline Stages */}
              {pipelineStatus?.stages && pipelineStatus.stages.length > 0 && (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
                  {pipelineStatus.stages.map((stage: any, stageIndex: number) => (
                    <div key={stageIndex} className="text-center">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-gray-600 capitalize">
                          {stage.name}
                        </span>
                        {getStatusIcon(stage.status)}
                      </div>
                      <Progress 
                        value={getProgressValue(stage.status)} 
                        className="h-2"
                      />
                      <div className="text-xs text-gray-500 mt-1">
                        {stage.jobs[0]?.duration ? `${stage.jobs[0].duration}s` : '-'}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Fallback if no real-time data */}
              {(!pipelineStatus?.stages || pipelineStatus.stages.length === 0) && (
                <div className="grid grid-cols-5 gap-2">
                  {['build', 'test', 'security', 'package', 'deploy'].map((stageName, stageIndex) => (
                    <div key={stageName} className="text-center">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-gray-600 capitalize">
                          {stageName}
                        </span>
                        {getStatusIcon(stageIndex === 0 ? run.status : 'pending')}
                      </div>
                      <Progress 
                        value={stageIndex === 0 ? getProgressValue(run.status) : 0} 
                        className="h-2"
                      />
                      <div className="text-xs text-gray-500 mt-1">
                        {stageIndex === 0 && run.startedAt ? formatDuration(run.startedAt) : '-'}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-3 flex justify-between items-center text-sm text-gray-500">
                <span>
                  Duration: {run.startedAt ? formatDuration(run.startedAt, run.completedAt) : 'N/A'}
                </span>
                <span>Order: {index + 1} of {execution.pipelineRuns.length}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
