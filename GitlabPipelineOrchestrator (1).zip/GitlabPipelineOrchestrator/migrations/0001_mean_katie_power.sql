ALTER TABLE `apps` ADD `env_vars` text;--> statement-breakpoint
ALTER TABLE `test_cases` DROP COLUMN `env_vars`;