
import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from "@shared/schema";
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';
import path from 'path';
import fs from 'fs';

// Ensure data directory exists
const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'database.sqlite');
const sqlite = new Database(dbPath);

// Enable foreign keys
sqlite.pragma('foreign_keys = ON');

export const db = drizzle(sqlite, { schema });

// Auto-migrate on startup
try {
  const migrationsFolder = './migrations';
  migrate(db, { migrationsFolder });
  console.log('Database migrations completed');
} catch (error) {
  console.log('Migration error - this is normal on first run:', error);
  console.log('Creating tables manually...');
  
  // Create tables manually if migrations fail
  try {
    sqlite.exec(`
      CREATE TABLE IF NOT EXISTS apps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        access_token TEXT NOT NULL,
        project_id TEXT NOT NULL,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
      );

      CREATE TABLE IF NOT EXISTS test_cases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        env_vars TEXT,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
      );

      CREATE TABLE IF NOT EXISTS test_case_apps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        test_case_id INTEGER NOT NULL REFERENCES test_cases(id),
        app_id INTEGER NOT NULL REFERENCES apps(id),
        branch TEXT NOT NULL,
        "order" INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS executions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        test_case_id INTEGER NOT NULL REFERENCES test_cases(id),
        status TEXT NOT NULL DEFAULT 'pending',
        started_at INTEGER,
        completed_at INTEGER,
        duration INTEGER,
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
      );

      CREATE TABLE IF NOT EXISTS pipeline_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        execution_id INTEGER NOT NULL REFERENCES executions(id),
        app_id INTEGER NOT NULL REFERENCES apps(id),
        branch TEXT NOT NULL,
        pipeline_id TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        stages TEXT,
        started_at INTEGER,
        completed_at INTEGER,
        duration INTEGER,
        "order" INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS artifacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pipeline_run_id INTEGER NOT NULL REFERENCES pipeline_runs(id),
        name TEXT NOT NULL,
        url TEXT NOT NULL,
        size INTEGER,
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
      );
    `);
    console.log('Tables created manually');
  } catch (tableError) {
    console.error('Error creating tables manually:', tableError);
  }
}
