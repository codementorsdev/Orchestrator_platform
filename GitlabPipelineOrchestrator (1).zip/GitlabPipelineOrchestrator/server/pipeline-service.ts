import { storage } from "./storage";
import type { TestCaseWithApps, Execution, PipelineRun } from "@shared/schema";

interface PipelineExecutionContext {
  execution: Execution;
  testCase: TestCaseWithApps;
  envVars: Record<string, string>;
}

class PipelineExecutionService {
  private activeExecutions = new Map<number, boolean>();
  private pollingIntervals = new Map<number, NodeJS.Timeout>();

  async executeTestCase(testCase: TestCaseWithApps): Promise<Execution> {
    // Create execution record
    const execution = await storage.createExecution({
      testCaseId: testCase.id,
      status: "running",
      startedAt: new Date().toISOString(),
    });

    this.activeExecutions.set(execution.id, true);

    // Execute pipelines sequentially in background
    this.executeSequentially({
      execution,
      testCase,
      envVars: {},
    }).catch((error) => {
      console.error(`Execution ${execution.id} failed:`, error);
      this.handleExecutionFailure(execution.id, error);
    });

    return execution;
  }

  private async executeSequentially(context: PipelineExecutionContext): Promise<void> {
    const { execution, testCase } = context;

    try {
      // Execute each app's pipeline sequentially
      for (let i = 0; i < testCase.testCaseApps.length; i++) {
        const appConfig = testCase.testCaseApps[i];

        if (!this.activeExecutions.get(execution.id)) {
          console.log(`Execution ${execution.id} was cancelled`);
          return;
        }

        console.log(`Starting pipeline ${i + 1}/${testCase.testCaseApps.length} for ${appConfig.app.name} (${appConfig.branch})`);

        // Create pipeline run record
        const pipelineRun = await storage.createPipelineRun({
          executionId: execution.id,
          appId: appConfig.appId,
          branch: appConfig.branch,
          status: "pending",
          order: i,
        });

        try {
          // Parse app-specific environment variables
          const envVars: Record<string, string> = {};
          if (appConfig.app.envVars) {
            appConfig.app.envVars.split(",").forEach((pair) => {
              const [key, value] = pair.split("=").map((s) => s.trim());
              if (key && value) {
                envVars[key] = value;
              }
            });
          }

          // Trigger pipeline via GitLab API
          const gitlabVariables = Object.entries(envVars).map(([key, value]) => ({
            key,
            value: String(value),
            variable_type: "env_var",
          }));

          const response = await fetch(`https://gitlab.com/api/v4/projects/${appConfig.app.projectId}/pipeline`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${appConfig.app.accessToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              ref: appConfig.branch,
              variables: gitlabVariables,
            }),
          });

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`GitLab API error: ${response.status} - ${errorText}`);
          }

          const pipeline = await response.json();

          // Update pipeline run with GitLab pipeline ID
          await storage.updatePipelineRun(pipelineRun.id, {
            pipelineId: pipeline.id.toString(),
            status: "running",
            startedAt: new Date().toISOString(),
          });

          console.log(`Pipeline ${pipeline.id} started for ${appConfig.app.name}`);

          // Wait for this pipeline to complete before starting the next one
          const pipelineSuccess = await this.waitForPipelineCompletion(
            pipelineRun.id, 
            appConfig.app.projectId, 
            pipeline.id, 
            appConfig.app.accessToken
          );

          // If pipeline failed, stop execution and mark remaining pipelines as canceled
          if (!pipelineSuccess) {
            console.log(`Pipeline ${pipeline.id} failed for ${appConfig.app.name}. Stopping execution.`);
            
            // Mark remaining pipeline runs as canceled
            for (let j = i + 1; j < testCase.testCaseApps.length; j++) {
              const remainingAppConfig = testCase.testCaseApps[j];
              const canceledPipelineRun = await storage.createPipelineRun({
                executionId: execution.id,
                appId: remainingAppConfig.appId,
                branch: remainingAppConfig.branch,
                status: "canceled",
                order: j,
              });
              
              await storage.updatePipelineRun(canceledPipelineRun.id, {
                status: "canceled",
                completedAt: new Date().toISOString(),
              });
            }
            
            await storage.updateExecution(execution.id, {
              status: "failed",
              completedAt: new Date().toISOString(),
              duration: Math.floor((Date.now() - new Date(execution.startedAt!).getTime()) / 1000),
            });

            console.log(`Execution ${execution.id} failed at step ${i + 1}/${testCase.testCaseApps.length}`);
            return;
          }

          console.log(`Pipeline ${pipeline.id} completed successfully for ${appConfig.app.name}. Proceeding to next app (${i + 1}/${testCase.testCaseApps.length} completed).`);

        } catch (error) {
          console.error(`Failed to execute pipeline for ${appConfig.app.name}:`, error);

          await storage.updatePipelineRun(pipelineRun.id, {
            status: "failed",
            completedAt: new Date().toISOString(),
          });

          // Mark execution as failed and stop
          await storage.updateExecution(execution.id, {
            status: "failed",
            completedAt: new Date().toISOString(),
            duration: Math.floor((Date.now() - new Date(execution.startedAt!).getTime()) / 1000),
          });

          throw error;
        }
      }

      // All pipelines completed successfully
      await storage.updateExecution(execution.id, {
        status: "success",
        completedAt: new Date().toISOString(),
        duration: Math.floor((Date.now() - new Date(execution.startedAt!).getTime()) / 1000),
      });

      console.log(`Execution ${execution.id} completed successfully with all ${testCase.testCaseApps.length} pipelines`);

    } catch (error) {
      console.error(`Execution ${execution.id} failed:`, error);
      await this.handleExecutionFailure(execution.id, error);
    } finally {
      this.activeExecutions.delete(execution.id);
    }
  }

  private async waitForPipelineCompletion(
    pipelineRunId: number,
    projectId: string,
    pipelineId: string,
    accessToken: string
  ): Promise<boolean> {
    return new Promise((resolve, reject) => {
      const pollInterval = setInterval(async () => {
        // Store the interval for potential cleanup
        this.pollingIntervals.set(pipelineRunId, pollInterval);
        try {
          // Get pipeline status from GitLab
          const response = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}`, {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
            },
          });

          if (!response.ok) {
            throw new Error(`Failed to get pipeline status: ${response.status}`);
          }

          const pipeline = await response.json();

          // Get pipeline jobs for stage information
          const jobsResponse = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}/jobs`, {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
            },
          });

          let stages = null;
          if (jobsResponse.ok) {
            const jobs = await jobsResponse.json();
            stages = this.processStagesFromJobs(jobs);
          }

          // Always update pipeline run with current status and stages
          await storage.updatePipelineRun(pipelineRunId, {
            status: pipeline.status,
            stages: stages ? JSON.stringify(stages) : null,
            duration: pipeline.duration || null,
          });

          console.log(`Pipeline ${pipelineId} status: ${pipeline.status} - Stages: ${stages ? stages.map(s => `${s.name}:${s.status}`).join(', ') : 'N/A'}`);

          // Check if pipeline reached terminal status
          const terminalStatuses = ['success', 'failed', 'canceled', 'skipped', 'manual'];
          if (terminalStatuses.includes(pipeline.status)) {
            clearInterval(pollInterval);
            this.pollingIntervals.delete(pipelineRunId);

            // Final update with completion time
            await storage.updatePipelineRun(pipelineRunId, {
              status: pipeline.status,
              completedAt: new Date().toISOString(),
              duration: pipeline.duration || null,
              stages: stages ? JSON.stringify(stages) : null,
            });

            console.log(`Pipeline ${pipelineId} completed with status: ${pipeline.status}`);

            // Return true only for success, false for all other terminal states
            resolve(pipeline.status === 'success');
          }

        } catch (error) {
          console.error(`Error polling pipeline ${pipelineId}:`, error);
          clearInterval(pollInterval);
          this.pollingIntervals.delete(pipelineRunId);
          reject(error);
        }
      }, 10000); // Poll every 10 seconds

      // Set timeout for very long-running pipelines (30 minutes)
      const timeoutId = setTimeout(async () => {
        clearInterval(pollInterval);
        this.pollingIntervals.delete(pipelineRunId);
        
        // Update pipeline run as timed out
        await storage.updatePipelineRun(pipelineRunId, {
          status: "failed",
          completedAt: new Date().toISOString(),
        });
        
        console.log(`Pipeline ${pipelineId} timed out after 30 minutes`);
        reject(new Error(`Pipeline ${pipelineId} timed out after 30 minutes`));
      }, 30 * 60 * 1000);

      // Clear timeout when pipeline completes
      const originalResolve = resolve;
      const originalReject = reject;
      
      resolve = (value) => {
        clearTimeout(timeoutId);
        originalResolve(value);
      };
      
      reject = (error) => {
        clearTimeout(timeoutId);
        originalReject(error);
      };
    });
  }

  private processStagesFromJobs(jobs: any[]): any[] {
    const stageMap = new Map<string, any>();

    jobs.forEach((job: any) => {
      const stageName = job.stage;

      if (!stageMap.has(stageName)) {
        stageMap.set(stageName, {
          name: stageName,
          status: job.status,
          jobs: [job],
          duration: job.duration || 0,
        });
      } else {
        const stage = stageMap.get(stageName)!;
        stage.jobs.push(job);

        // Update stage status based on worst job status
        if (job.status === 'failed') {
          stage.status = 'failed';
        } else if (job.status === 'running' && stage.status !== 'failed') {
          stage.status = 'running';
        } else if (job.status === 'success' && stage.status === 'pending') {
          stage.status = 'success';
        }

        // Update duration
        if (job.duration) {
          stage.duration = Math.max(stage.duration, job.duration);
        }
      }
    });

    return Array.from(stageMap.values());
  }

  private async handleExecutionFailure(executionId: number, error: any): Promise<void> {
    try {
      await storage.updateExecution(executionId, {
        status: "failed",
        completedAt: new Date().toISOString(),
      });
    } catch (updateError) {
      console.error(`Failed to update execution ${executionId} status:`, updateError);
    }

    this.activeExecutions.delete(executionId);
  }

  cancelExecution(executionId: number): void {
    this.activeExecutions.delete(executionId);

    const interval = this.pollingIntervals.get(executionId);
    if (interval) {
      clearInterval(interval);
      this.pollingIntervals.delete(executionId);
    }
  }

  isExecutionActive(executionId: number): boolean {
    return this.activeExecutions.has(executionId);
  }
}

export const pipelineService = new PipelineExecutionService();

