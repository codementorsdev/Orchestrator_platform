
import { sqliteTable, text, integer, blob } from "drizzle-orm/sqlite-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const apps = sqliteTable("apps", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  accessToken: text("access_token").notNull(),
  projectId: text("project_id").notNull(),
  envVars: text("env_vars"), // comma-separated key=value pairs
  createdAt: integer("created_at", { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const testCases = sqliteTable("test_cases", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: integer("created_at", { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const testCaseApps = sqliteTable("test_case_apps", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  testCaseId: integer("test_case_id").notNull().references(() => testCases.id),
  appId: integer("app_id").notNull().references(() => apps.id),
  branch: text("branch").notNull(),
  order: integer("order").notNull().default(0), // execution order
});

export const executions = sqliteTable("executions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  testCaseId: integer("test_case_id").notNull().references(() => testCases.id),
  status: text("status").notNull().default("pending"), // pending, running, success, failed
  startedAt: integer("started_at", { mode: 'timestamp' }),
  completedAt: integer("completed_at", { mode: 'timestamp' }),
  duration: integer("duration"), // in seconds
  createdAt: integer("created_at", { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const pipelineRuns = sqliteTable("pipeline_runs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  executionId: integer("execution_id").notNull().references(() => executions.id),
  appId: integer("app_id").notNull().references(() => apps.id),
  branch: text("branch").notNull(),
  pipelineId: text("pipeline_id"), // GitLab pipeline ID
  status: text("status").notNull().default("pending"), // pending, running, success, failed
  stages: text("stages"), // JSON string for pipeline stages data
  startedAt: integer("started_at", { mode: 'timestamp' }),
  completedAt: integer("completed_at", { mode: 'timestamp' }),
  duration: integer("duration"), // in seconds
  order: integer("order").notNull().default(0), // execution order
});

export const artifacts = sqliteTable("artifacts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  pipelineRunId: integer("pipeline_run_id").notNull().references(() => pipelineRuns.id),
  name: text("name").notNull(),
  url: text("url").notNull(),
  size: integer("size"), // in bytes
  createdAt: integer("created_at", { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

// Relations
export const appsRelations = relations(apps, ({ many }) => ({
  testCaseApps: many(testCaseApps),
  pipelineRuns: many(pipelineRuns),
}));

export const testCasesRelations = relations(testCases, ({ many }) => ({
  testCaseApps: many(testCaseApps),
  executions: many(executions),
}));

export const testCaseAppsRelations = relations(testCaseApps, ({ one }) => ({
  testCase: one(testCases, {
    fields: [testCaseApps.testCaseId],
    references: [testCases.id],
  }),
  app: one(apps, {
    fields: [testCaseApps.appId],
    references: [apps.id],
  }),
}));

export const executionsRelations = relations(executions, ({ one, many }) => ({
  testCase: one(testCases, {
    fields: [executions.testCaseId],
    references: [testCases.id],
  }),
  pipelineRuns: many(pipelineRuns),
}));

export const pipelineRunsRelations = relations(pipelineRuns, ({ one, many }) => ({
  execution: one(executions, {
    fields: [pipelineRuns.executionId],
    references: [executions.id],
  }),
  app: one(apps, {
    fields: [pipelineRuns.appId],
    references: [apps.id],
  }),
  artifacts: many(artifacts),
}));

export const artifactsRelations = relations(artifacts, ({ one }) => ({
  pipelineRun: one(pipelineRuns, {
    fields: [artifacts.pipelineRunId],
    references: [pipelineRuns.id],
  }),
}));

// Insert schemas
export const insertAppSchema = createInsertSchema(apps).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTestCaseSchema = createInsertSchema(testCases).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTestCaseAppSchema = createInsertSchema(testCaseApps).omit({
  id: true,
});

export const insertExecutionSchema = createInsertSchema(executions).omit({
  id: true,
  createdAt: true,
}).extend({
  startedAt: z.string().datetime().optional(),
  completedAt: z.string().datetime().optional(),
});

export const insertPipelineRunSchema = createInsertSchema(pipelineRuns).omit({
  id: true,
});

export const insertArtifactSchema = createInsertSchema(artifacts).omit({
  id: true,
  createdAt: true,
});

// Types
export type App = typeof apps.$inferSelect;
export type InsertApp = z.infer<typeof insertAppSchema>;

export type TestCase = typeof testCases.$inferSelect;
export type InsertTestCase = z.infer<typeof insertTestCaseSchema>;

export type TestCaseApp = typeof testCaseApps.$inferSelect;
export type InsertTestCaseApp = z.infer<typeof insertTestCaseAppSchema>;

export type Execution = typeof executions.$inferSelect;
export type InsertExecution = z.infer<typeof insertExecutionSchema>;

export type PipelineRun = typeof pipelineRuns.$inferSelect;
export type InsertPipelineRun = z.infer<typeof insertPipelineRunSchema>;

export type Artifact = typeof artifacts.$inferSelect;
export type InsertArtifact = z.infer<typeof insertArtifactSchema>;

// Extended types for API responses
export type TestCaseWithApps = TestCase & {
  testCaseApps: (TestCaseApp & { app: App })[];
};

export type ExecutionWithDetails = Execution & {
  testCase: TestCase;
  pipelineRuns: (PipelineRun & { app: App; artifacts: Artifact[] })[];
};
