package com.gitlab.orchestrator.config;

import org.gitlab4j.api.GitLabApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for GitLab API integration.
 * Sets up the GitLabApi bean with appropriate authentication.
 */
@Configuration
public class GitLabApiConfig {

    private static final Logger logger = LoggerFactory.getLogger(GitLabApiConfig.class);

    @Value("${gitlab.api.url}")
    private String gitlabApiUrl;

    @Value("${gitlab.api.token}")
    private String gitlabApiToken;

    /**
     * Creates and configures a GitLabApi instance.
     *
     * @return Configured GitLabApi instance
     */
    @Bean
    public GitLabApi gitLabApi() {
        logger.info("Initializing GitLabApi with URL: {}", gitlabApiUrl);
        return new GitLabApi(gitlabApiUrl, gitlabApiToken);
    }
}
