package com.gitlab.orchestrator.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gitlab.orchestrator.dto.PipelineSequenceRequest;
import com.gitlab.orchestrator.dto.PipelineSequenceResponse;
import com.gitlab.orchestrator.service.PipelineSequenceService;

/**
 * REST controller for pipeline sequence operations.
 */
@RestController
@RequestMapping("/api/sequences")
public class PipelineSequenceController {
    
    private static final Logger logger = LoggerFactory.getLogger(PipelineSequenceController.class);
    
    private final PipelineSequenceService pipelineSequenceService;
    
    @Autowired
    public PipelineSequenceController(PipelineSequenceService pipelineSequenceService) {
        this.pipelineSequenceService = pipelineSequenceService;
    }
    
    /**
     * Create a new pipeline sequence.
     *
     * @param request the pipeline sequence request
     * @return the created pipeline sequence
     */
    @PostMapping
    public ResponseEntity<PipelineSequenceResponse> createPipelineSequence(@RequestBody PipelineSequenceRequest request) {
        logger.info("REST request to create pipeline sequence: {}", request.getName());
        PipelineSequenceResponse response = pipelineSequenceService.createPipelineSequence(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    /**
     * Get a pipeline sequence by ID.
     *
     * @param id the pipeline sequence ID
     * @return the pipeline sequence
     */
    @GetMapping("/{id}")
    public ResponseEntity<PipelineSequenceResponse> getPipelineSequence(@PathVariable Long id) {
        logger.info("REST request to get pipeline sequence with ID: {}", id);
        PipelineSequenceResponse response = pipelineSequenceService.getPipelineSequence(id);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get all pipeline sequences.
     *
     * @param name optional name filter
     * @return list of pipeline sequences
     */
    @GetMapping
    public ResponseEntity<List<PipelineSequenceResponse>> getAllPipelineSequences(
            @RequestParam(required = false) String name) {
        logger.info("REST request to get all pipeline sequences, name filter: {}", name);
        
        List<PipelineSequenceResponse> responses;
        if (name != null && !name.isEmpty()) {
            responses = pipelineSequenceService.getPipelineSequencesByName(name);
        } else {
            responses = pipelineSequenceService.getAllPipelineSequences();
        }
        
        return ResponseEntity.ok(responses);
    }
    
    /**
     * Update a pipeline sequence.
     *
     * @param id the pipeline sequence ID
     * @param request the pipeline sequence request
     * @return the updated pipeline sequence
     */
    @PutMapping("/{id}")
    public ResponseEntity<PipelineSequenceResponse> updatePipelineSequence(
            @PathVariable Long id,
            @RequestBody PipelineSequenceRequest request) {
        logger.info("REST request to update pipeline sequence with ID: {}", id);
        PipelineSequenceResponse response = pipelineSequenceService.updatePipelineSequence(id, request);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Delete a pipeline sequence.
     *
     * @param id the pipeline sequence ID
     * @return no content response
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePipelineSequence(@PathVariable Long id) {
        logger.info("REST request to delete pipeline sequence with ID: {}", id);
        pipelineSequenceService.deletePipelineSequence(id);
        return ResponseEntity.noContent().build();
    }
}
