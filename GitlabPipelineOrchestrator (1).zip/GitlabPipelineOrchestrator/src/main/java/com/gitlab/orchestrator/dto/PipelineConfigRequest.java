package com.gitlab.orchestrator.dto;

import java.util.HashMap;
import java.util.Map;

/**
 * DTO for pipeline configuration requests.
 */
public class PipelineConfigRequest {

    private Integer projectId;
    private String branch;
    private String ref;
    private Map<String, String> variables = new HashMap<>();

    // Default constructor
    public PipelineConfigRequest() {
    }

    // Constructor with parameters
    public PipelineConfigRequest(Integer projectId, String branch, String ref, Map<String, String> variables) {
        this.projectId = projectId;
        this.branch = branch;
        this.ref = ref;
        if (variables != null) {
            this.variables = variables;
        }
    }

    // Getters and Setters
    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public Map<String, String> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, String> variables) {
        this.variables = variables;
    }

    @Override
    public String toString() {
        return "PipelineConfigRequest{" +
                "projectId=" + projectId +
                ", branch='" + branch + '\'' +
                ", ref='" + ref + '\'' +
                ", variables=" + variables +
                '}';
    }
}
