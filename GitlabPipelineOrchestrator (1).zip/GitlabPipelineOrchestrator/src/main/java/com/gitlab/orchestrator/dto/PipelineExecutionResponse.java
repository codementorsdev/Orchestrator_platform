package com.gitlab.orchestrator.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.gitlab.orchestrator.model.enums.ExecutionStatus;

/**
 * DTO for pipeline execution response data.
 */
public class PipelineExecutionResponse {

    private Long id;
    private Long pipelineSequenceId;
    private String pipelineSequenceName;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
    private ExecutionStatus status;
    private String errorMessage;
    private Integer currentStep;
    private List<PipelineStepExecutionResponse> stepExecutions = new ArrayList<>();

    // Default constructor
    public PipelineExecutionResponse() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPipelineSequenceId() {
        return pipelineSequenceId;
    }

    public void setPipelineSequenceId(Long pipelineSequenceId) {
        this.pipelineSequenceId = pipelineSequenceId;
    }

    public String getPipelineSequenceName() {
        return pipelineSequenceName;
    }

    public void setPipelineSequenceName(String pipelineSequenceName) {
        this.pipelineSequenceName = pipelineSequenceName;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public ExecutionStatus getStatus() {
        return status;
    }

    public void setStatus(ExecutionStatus status) {
        this.status = status;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Integer getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(Integer currentStep) {
        this.currentStep = currentStep;
    }

    public List<PipelineStepExecutionResponse> getStepExecutions() {
        return stepExecutions;
    }

    public void setStepExecutions(List<PipelineStepExecutionResponse> stepExecutions) {
        this.stepExecutions = stepExecutions;
    }

    /**
     * Inner class for pipeline step execution response data.
     */
    public static class PipelineStepExecutionResponse {
        
        private Long id;
        private String stepName;
        private Integer stepOrder;
        private Long gitlabPipelineId;
        private Integer gitlabProjectId;
        private LocalDateTime startedAt;
        private LocalDateTime completedAt;
        private ExecutionStatus status;
        private String errorMessage;

        // Default constructor
        public PipelineStepExecutionResponse() {
        }

        // Getters and Setters
        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getStepName() {
            return stepName;
        }

        public void setStepName(String stepName) {
            this.stepName = stepName;
        }

        public Integer getStepOrder() {
            return stepOrder;
        }

        public void setStepOrder(Integer stepOrder) {
            this.stepOrder = stepOrder;
        }

        public Long getGitlabPipelineId() {
            return gitlabPipelineId;
        }

        public void setGitlabPipelineId(Long gitlabPipelineId) {
            this.gitlabPipelineId = gitlabPipelineId;
        }

        public Integer getGitlabProjectId() {
            return gitlabProjectId;
        }

        public void setGitlabProjectId(Integer gitlabProjectId) {
            this.gitlabProjectId = gitlabProjectId;
        }

        public LocalDateTime getStartedAt() {
            return startedAt;
        }

        public void setStartedAt(LocalDateTime startedAt) {
            this.startedAt = startedAt;
        }

        public LocalDateTime getCompletedAt() {
            return completedAt;
        }

        public void setCompletedAt(LocalDateTime completedAt) {
            this.completedAt = completedAt;
        }

        public ExecutionStatus getStatus() {
            return status;
        }

        public void setStatus(ExecutionStatus status) {
            this.status = status;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }
    }
}
