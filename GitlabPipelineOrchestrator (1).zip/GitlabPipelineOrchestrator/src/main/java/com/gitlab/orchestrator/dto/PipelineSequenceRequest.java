package com.gitlab.orchestrator.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * DTO for pipeline sequence creation or update requests.
 */
public class PipelineSequenceRequest {

    private String name;
    private String description;
    private List<PipelineStepRequest> steps = new ArrayList<>();

    // Default constructor
    public PipelineSequenceRequest() {
    }

    // Constructor with parameters
    public PipelineSequenceRequest(String name, String description, List<PipelineStepRequest> steps) {
        this.name = name;
        this.description = description;
        if (steps != null) {
            this.steps = steps;
        }
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<PipelineStepRequest> getSteps() {
        return steps;
    }

    public void setSteps(List<PipelineStepRequest> steps) {
        this.steps = steps;
    }

    /**
     * Inner class for pipeline step request data.
     */
    public static class PipelineStepRequest {
        
        private String name;
        private Integer order;
        private PipelineConfigRequest pipelineConfig;

        // Default constructor
        public PipelineStepRequest() {
        }

        // Constructor with parameters
        public PipelineStepRequest(String name, Integer order, PipelineConfigRequest pipelineConfig) {
            this.name = name;
            this.order = order;
            this.pipelineConfig = pipelineConfig;
        }

        // Getters and Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getOrder() {
            return order;
        }

        public void setOrder(Integer order) {
            this.order = order;
        }

        public PipelineConfigRequest getPipelineConfig() {
            return pipelineConfig;
        }

        public void setPipelineConfig(PipelineConfigRequest pipelineConfig) {
            this.pipelineConfig = pipelineConfig;
        }

        @Override
        public String toString() {
            return "PipelineStepRequest{" +
                    "name='" + name + '\'' +
                    ", order=" + order +
                    ", pipelineConfig=" + pipelineConfig +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "PipelineSequenceRequest{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", steps=" + steps +
                '}';
    }
}
