package com.gitlab.orchestrator.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * DTO for pipeline sequence response data.
 */
public class PipelineSequenceResponse {

    private Long id;
    private String name;
    private String description;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<PipelineStepResponse> steps = new ArrayList<>();

    // Default constructor
    public PipelineSequenceResponse() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<PipelineStepResponse> getSteps() {
        return steps;
    }

    public void setSteps(List<PipelineStepResponse> steps) {
        this.steps = steps;
    }

    /**
     * Inner class for pipeline step response data.
     */
    public static class PipelineStepResponse {
        
        private Long id;
        private String name;
        private Integer order;
        private PipelineConfigResponse pipelineConfig;

        // Default constructor
        public PipelineStepResponse() {
        }

        // Getters and Setters
        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getOrder() {
            return order;
        }

        public void setOrder(Integer order) {
            this.order = order;
        }

        public PipelineConfigResponse getPipelineConfig() {
            return pipelineConfig;
        }

        public void setPipelineConfig(PipelineConfigResponse pipelineConfig) {
            this.pipelineConfig = pipelineConfig;
        }
    }

    /**
     * Inner class for pipeline config response data.
     */
    public static class PipelineConfigResponse {
        
        private Long id;
        private Integer projectId;
        private String branch;
        private String ref;
        private Map<String, String> variables;

        // Default constructor
        public PipelineConfigResponse() {
        }

        // Getters and Setters
        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public Integer getProjectId() {
            return projectId;
        }

        public void setProjectId(Integer projectId) {
            this.projectId = projectId;
        }

        public String getBranch() {
            return branch;
        }

        public void setBranch(String branch) {
            this.branch = branch;
        }

        public String getRef() {
            return ref;
        }

        public void setRef(String ref) {
            this.ref = ref;
        }

        public Map<String, String> getVariables() {
            return variables;
        }

        public void setVariables(Map<String, String> variables) {
            this.variables = variables;
        }
    }
}
