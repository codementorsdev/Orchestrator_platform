package com.gitlab.orchestrator.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when there is an error interacting with the GitLab API.
 */
@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class GitLabApiException extends RuntimeException {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Constructs a new GitLabApiException with the specified detail message.
     *
     * @param message the detail message
     */
    public GitLabApiException(String message) {
        super(message);
    }
    
    /**
     * Constructs a new GitLabApiException with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause the cause
     */
    public GitLabApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
