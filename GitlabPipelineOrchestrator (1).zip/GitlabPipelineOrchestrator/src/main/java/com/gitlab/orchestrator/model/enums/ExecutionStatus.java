package com.gitlab.orchestrator.model.enums;

/**
 * Enum representing the possible statuses of pipeline executions.
 */
public enum ExecutionStatus {
    /**
     * Execution is pending and has not started yet.
     */
    PENDING,
    
    /**
     * Execution is currently running.
     */
    RUNNING,
    
    /**
     * Execution has completed successfully.
     */
    SUCCESS,
    
    /**
     * Execution has failed.
     */
    FAILED,
    
    /**
     * Execution was canceled.
     */
    CANCELED,
    
    /**
     * Execution is in a waiting state.
     */
    WAITING
}
