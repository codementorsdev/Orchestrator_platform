package com.gitlab.orchestrator.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gitlab.orchestrator.model.PipelineExecution;
import com.gitlab.orchestrator.model.enums.ExecutionStatus;

/**
 * Repository for PipelineExecution entities.
 */
@Repository
public interface PipelineExecutionRepository extends JpaRepository<PipelineExecution, Long> {
    
    /**
     * Find pipeline executions by pipeline sequence ID.
     *
     * @param pipelineSequenceId The pipeline sequence ID
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByPipelineSequenceId(Long pipelineSequenceId);
    
    /**
     * Find pipeline executions by status.
     *
     * @param status The execution status
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByStatus(ExecutionStatus status);
    
    /**
     * Find running and pending pipeline executions.
     *
     * @return List of active pipeline executions
     */
    @Query("SELECT e FROM PipelineExecution e WHERE e.status = 'RUNNING' OR e.status = 'PENDING'")
    List<PipelineExecution> findActiveExecutions();
    
    /**
     * Find pipeline executions started after a given date.
     *
     * @param startDate The start date
     * @return List of pipeline executions
     */
    List<PipelineExecution> findByStartedAtAfter(LocalDateTime startDate);
    
    /**
     * Find recent pipeline executions for a given sequence, limited to a specific number of results.
     *
     * @param sequenceId The pipeline sequence ID
     * @param limit The maximum number of executions to return (handled in service layer)
     * @return List of recent pipeline executions
     */
    @Query("SELECT e FROM PipelineExecution e WHERE e.pipelineSequence.id = :sequenceId ORDER BY e.startedAt DESC")
    List<PipelineExecution> findRecentExecutions(@Param("sequenceId") Long sequenceId);
}
