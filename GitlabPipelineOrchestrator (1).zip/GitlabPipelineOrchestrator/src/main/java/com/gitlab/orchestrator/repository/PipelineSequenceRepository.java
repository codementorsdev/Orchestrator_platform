package com.gitlab.orchestrator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gitlab.orchestrator.model.PipelineSequence;

/**
 * Repository for PipelineSequence entities.
 */
@Repository
public interface PipelineSequenceRepository extends JpaRepository<PipelineSequence, Long> {
    
    /**
     * Find pipeline sequences by name containing the given string.
     *
     * @param name The name to search for
     * @return List of matching pipeline sequences
     */
    List<PipelineSequence> findByNameContainingIgnoreCase(String name);
}
