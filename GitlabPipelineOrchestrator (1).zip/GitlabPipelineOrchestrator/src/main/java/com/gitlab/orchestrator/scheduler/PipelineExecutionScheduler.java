package com.gitlab.orchestrator.scheduler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.gitlab.orchestrator.model.PipelineExecution;
import com.gitlab.orchestrator.model.enums.ExecutionStatus;
import com.gitlab.orchestrator.repository.PipelineExecutionRepository;
import com.gitlab.orchestrator.service.PipelineExecutionService;

/**
 * Scheduler component for pipeline execution management.
 */
@Component
public class PipelineExecutionScheduler {
    
    private static final Logger logger = LoggerFactory.getLogger(PipelineExecutionScheduler.class);
    
    private final PipelineExecutionRepository pipelineExecutionRepository;
    private final PipelineExecutionService pipelineExecutionService;
    
    @Autowired
    public PipelineExecutionScheduler(
            PipelineExecutionRepository pipelineExecutionRepository,
            PipelineExecutionService pipelineExecutionService) {
        this.pipelineExecutionRepository = pipelineExecutionRepository;
        this.pipelineExecutionService = pipelineExecutionService;
    }
    
    /**
     * Process pending and running pipeline executions.
     * Scheduled to run every 30 seconds.
     */
    @Scheduled(fixedRate = 30000)
    public void processPipelineExecutions() {
        logger.debug("Running scheduled pipeline execution processor");
        
        // Get all pending and running executions
        List<PipelineExecution> activeExecutions = pipelineExecutionRepository.findActiveExecutions();
        
        for (PipelineExecution execution : activeExecutions) {
            try {
                logger.debug("Processing execution ID: {}, status: {}", execution.getId(), execution.getStatus());
                pipelineExecutionService.processNextStep(execution.getId());
            } catch (Exception e) {
                logger.error("Error processing execution ID: {}", execution.getId(), e);
                
                // Mark execution as failed if unhandled exception occurs
                if (execution.getStatus() == ExecutionStatus.PENDING || execution.getStatus() == ExecutionStatus.RUNNING) {
                    try {
                        execution.setStatus(ExecutionStatus.FAILED);
                        execution.setErrorMessage("Unexpected error: " + e.getMessage());
                        pipelineExecutionRepository.save(execution);
                    } catch (Exception ex) {
                        logger.error("Failed to update execution status for ID: {}", execution.getId(), ex);
                    }
                }
            }
        }
    }
    
    /**
     * Update status of running pipeline step executions.
     * Scheduled to run every 60 seconds.
     */
    @Scheduled(fixedRate = 60000)
    public void updatePipelineStatuses() {
        logger.debug("Running scheduled pipeline status updater");
        
        try {
            pipelineExecutionService.updateRunningPipelineStatuses();
        } catch (Exception e) {
            logger.error("Error updating pipeline statuses", e);
        }
    }
}
