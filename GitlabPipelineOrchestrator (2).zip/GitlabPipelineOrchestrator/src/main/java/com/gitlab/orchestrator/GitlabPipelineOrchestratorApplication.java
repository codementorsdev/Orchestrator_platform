package com.gitlab.orchestrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for GitLab Pipeline Orchestrator.
 * This application manages and executes GitLab pipelines in a sequential manner.
 */
@SpringBootApplication
@EnableScheduling
public class GitlabPipelineOrchestratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(GitlabPipelineOrchestratorApplication.class, args);
    }
}
