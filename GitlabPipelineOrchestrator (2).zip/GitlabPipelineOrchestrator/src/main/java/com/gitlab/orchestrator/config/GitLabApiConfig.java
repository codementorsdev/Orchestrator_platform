package com.gitlab.orchestrator.config;

import org.gitlab4j.api.GitLabApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration for GitLab API client.
 */
@Configuration
public class GitLabApiConfig {

    @Value("${gitlab.api.url}")
    private String gitLabApiUrl;
    
    @Value("${gitlab.api.token}")
    private String gitLabApiToken;
    
    @Value("${gitlab.api.mock-mode:false}")
    private boolean mockMode;

    /**
     * Create a GitLabApi bean.
     *
     * @return the GitLabApi instance
     */
    @Bean
    public GitLabApi gitLabApi() {
        if (mockMode) {
            return new GitLabApi(gitLabApiUrl, "mock-token");
        }
        return new GitLabApi(gitLabApiUrl, gitLabApiToken);
    }
}
