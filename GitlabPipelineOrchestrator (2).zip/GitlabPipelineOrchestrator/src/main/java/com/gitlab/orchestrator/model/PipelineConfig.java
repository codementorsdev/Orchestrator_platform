package com.gitlab.orchestrator.model;

import java.util.HashMap;
import java.util.Map;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.Table;

/**
 * Entity representing pipeline configuration details.
 */
@Entity
@Table(name = "pipeline_configs")
public class PipelineConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Integer projectId;

    @Column(nullable = true)
    private String branch;

    @Column
    private String ref;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "pipeline_variables", joinColumns = @JoinColumn(name = "pipeline_config_id"))
    @MapKeyColumn(name = "variable_key")
    @Column(name = "variable_value")
    private Map<String, String> variables = new HashMap<>();

    // Default constructor
    public PipelineConfig() {
    }

    // Constructor with parameters
    public PipelineConfig(Integer projectId, String branch, String ref, Map<String, String> variables) {
        this.projectId = projectId;
        this.branch = branch;
        this.ref = ref;
        if (variables != null) {
            this.variables = variables;
        }
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public Map<String, String> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, String> variables) {
        this.variables = variables;
    }

    @Override
    public String toString() {
        return "PipelineConfig{" +
                "id=" + id +
                ", projectId=" + projectId +
                ", branch='" + branch + '\'' +
                ", ref='" + ref + '\'' +
                ", variables=" + variables +
                '}';
    }
}
