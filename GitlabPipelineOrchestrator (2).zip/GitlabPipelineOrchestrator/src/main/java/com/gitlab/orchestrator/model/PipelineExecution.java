package com.gitlab.orchestrator.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.gitlab.orchestrator.model.enums.ExecutionStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;

/**
 * Entity representing the execution of a pipeline sequence.
 */
@Entity
@Table(name = "pipeline_executions")
public class PipelineExecution {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pipeline_sequence_id", nullable = false)
    private PipelineSequence pipelineSequence;

    @Column(name = "started_at")
    private LocalDateTime startedAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ExecutionStatus status;

    @Column
    private String errorMessage;

    @OneToMany(mappedBy = "pipelineExecution", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @OrderBy("stepOrder ASC")
    private List<PipelineStepExecution> stepExecutions = new ArrayList<>();

    @Column(name = "current_step")
    private Integer currentStep;

    // Default constructor
    public PipelineExecution() {
        this.status = ExecutionStatus.PENDING;
        this.currentStep = 0;
    }

    // Constructor with parameters
    public PipelineExecution(PipelineSequence pipelineSequence) {
        this.pipelineSequence = pipelineSequence;
        this.status = ExecutionStatus.PENDING;
        this.currentStep = 0;
    }

    // Method to add a step execution
    public void addStepExecution(PipelineStepExecution stepExecution) {
        stepExecutions.add(stepExecution);
        stepExecution.setPipelineExecution(this);
    }

    // Method to remove a step execution
    public void removeStepExecution(PipelineStepExecution stepExecution) {
        stepExecutions.remove(stepExecution);
        stepExecution.setPipelineExecution(null);
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PipelineSequence getPipelineSequence() {
        return pipelineSequence;
    }

    public void setPipelineSequence(PipelineSequence pipelineSequence) {
        this.pipelineSequence = pipelineSequence;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public ExecutionStatus getStatus() {
        return status;
    }

    public void setStatus(ExecutionStatus status) {
        this.status = status;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public List<PipelineStepExecution> getStepExecutions() {
        return stepExecutions;
    }

    public void setStepExecutions(List<PipelineStepExecution> stepExecutions) {
        this.stepExecutions.clear();
        if (stepExecutions != null) {
            for (PipelineStepExecution stepExecution : stepExecutions) {
                addStepExecution(stepExecution);
            }
        }
    }

    public Integer getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(Integer currentStep) {
        this.currentStep = currentStep;
    }

    @Override
    public String toString() {
        return "PipelineExecution{" +
                "id=" + id +
                ", pipelineSequenceId=" + (pipelineSequence != null ? pipelineSequence.getId() : null) +
                ", startedAt=" + startedAt +
                ", completedAt=" + completedAt +
                ", status=" + status +
                ", errorMessage='" + errorMessage + '\'' +
                ", currentStep=" + currentStep +
                ", stepExecutionsCount=" + (stepExecutions != null ? stepExecutions.size() : 0) +
                '}';
    }
}
