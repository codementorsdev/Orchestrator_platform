package com.gitlab.orchestrator.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gitlab.orchestrator.model.PipelineStepExecution;
import com.gitlab.orchestrator.model.enums.ExecutionStatus;

/**
 * Repository for PipelineStepExecution entities.
 */
@Repository
public interface PipelineStepExecutionRepository extends JpaRepository<PipelineStepExecution, Long> {
    
    /**
     * Find pipeline step executions by pipeline execution ID.
     *
     * @param pipelineExecutionId The pipeline execution ID
     * @return List of pipeline step executions
     */
    List<PipelineStepExecution> findByPipelineExecutionIdOrderByStepOrderAsc(Long pipelineExecutionId);
    
    /**
     * Find pipeline step executions by status.
     *
     * @param status The execution status
     * @return List of pipeline step executions
     */
    List<PipelineStepExecution> findByStatus(ExecutionStatus status);
    
    /**
     * Find a pipeline step execution by GitLab pipeline ID.
     *
     * @param gitlabPipelineId The GitLab pipeline ID
     * @return Optional containing the pipeline step execution if found
     */
    Optional<PipelineStepExecution> findByGitlabPipelineId(Long gitlabPipelineId);
    
    /**
     * Find pipeline step executions by pipeline execution ID and status.
     *
     * @param pipelineExecutionId The pipeline execution ID
     * @param status The execution status
     * @return List of pipeline step executions
     */
    List<PipelineStepExecution> findByPipelineExecutionIdAndStatus(Long pipelineExecutionId, ExecutionStatus status);
}
