package com.gitlab.orchestrator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gitlab.orchestrator.model.PipelineStep;

/**
 * Repository for PipelineStep entities.
 */
@Repository
public interface PipelineStepRepository extends JpaRepository<PipelineStep, Long> {
    
    /**
     * Find pipeline steps by pipeline sequence ID.
     *
     * @param pipelineSequenceId The pipeline sequence ID
     * @return List of pipeline steps
     */
    List<PipelineStep> findByPipelineSequenceIdOrderByOrderAsc(Long pipelineSequenceId);
}
