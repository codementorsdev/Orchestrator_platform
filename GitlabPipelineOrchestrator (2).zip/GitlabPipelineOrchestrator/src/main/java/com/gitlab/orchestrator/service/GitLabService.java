package com.gitlab.orchestrator.service;

import java.util.Map;

import org.gitlab4j.api.models.Pipeline;

/**
 * Service interface for GitLab API operations.
 */
public interface GitLabService {
    
    /**
     * Create a new pipeline in GitLab.
     *
     * @param projectId the GitLab project ID
     * @param ref the Git reference (branch or tag)
     * @param variables the pipeline variables
     * @return the created GitLab pipeline
     */
    Pipeline createPipeline(Integer projectId, String ref, Map<String, String> variables);
    
    /**
     * Get a pipeline from GitLab.
     *
     * @param projectId the GitLab project ID
     * @param pipelineId the GitLab pipeline ID
     * @return the GitLab pipeline
     */
    Pipeline getPipeline(Integer projectId, Long pipelineId);
    
    /**
     * Cancel a pipeline in GitLab.
     *
     * @param projectId the GitLab project ID
     * @param pipelineId the GitLab pipeline ID
     * @return the updated GitLab pipeline
     */
    Pipeline cancelPipeline(Integer projectId, Long pipelineId);
    
    /**
     * Retry a pipeline in GitLab.
     *
     * @param projectId the GitLab project ID
     * @param pipelineId the GitLab pipeline ID
     * @return the new GitLab pipeline
     */
    Pipeline retryPipeline(Integer projectId, Long pipelineId);
    
    /**
     * Check if a pipeline is complete (success, failed, or canceled).
     *
     * @param pipeline the GitLab pipeline
     * @return true if the pipeline is complete, false otherwise
     */
    boolean isPipelineComplete(Pipeline pipeline);
    
    /**
     * Check if a pipeline was successful.
     *
     * @param pipeline the GitLab pipeline
     * @return true if the pipeline was successful, false otherwise
     */
    boolean isPipelineSuccessful(Pipeline pipeline);
    
    /**
     * Get the pipeline status string from a GitLab pipeline.
     *
     * @param pipeline the GitLab pipeline
     * @return the status string
     */
    String getPipelineStatus(Pipeline pipeline);
    
    /**
     * Check if the service is operating in mock mode.
     *
     * @return true if mock mode is enabled, false otherwise
     */
    boolean isMockModeEnabled();
}
