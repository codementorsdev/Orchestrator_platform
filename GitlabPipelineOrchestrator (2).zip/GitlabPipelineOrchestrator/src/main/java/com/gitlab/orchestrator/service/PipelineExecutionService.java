package com.gitlab.orchestrator.service;

import java.util.List;

import com.gitlab.orchestrator.dto.PipelineExecutionResponse;

/**
 * Service interface for pipeline execution operations.
 */
public interface PipelineExecutionService {
    
    /**
     * Start execution of a pipeline sequence.
     *
     * @param pipelineSequenceId the pipeline sequence ID
     * @return the pipeline execution response
     */
    PipelineExecutionResponse startPipelineExecution(Long pipelineSequenceId);
    
    /**
     * Get a pipeline execution by ID.
     *
     * @param id the pipeline execution ID
     * @return the pipeline execution response
     */
    PipelineExecutionResponse getPipelineExecution(Long id);
    
    /**
     * Get all pipeline executions.
     *
     * @return list of pipeline execution responses
     */
    List<PipelineExecutionResponse> getAllPipelineExecutions();
    
    /**
     * Get pipeline executions for a specific sequence.
     *
     * @param pipelineSequenceId the pipeline sequence ID
     * @return list of pipeline execution responses
     */
    List<PipelineExecutionResponse> getPipelineExecutionsBySequence(Long pipelineSequenceId);
    
    /**
     * Get recent pipeline executions for a specific sequence, limited to a specified count.
     *
     * @param pipelineSequenceId the pipeline sequence ID
     * @param limit the maximum number of executions to return
     * @return list of recent pipeline execution responses
     */
    List<PipelineExecutionResponse> getRecentPipelineExecutions(Long pipelineSequenceId, int limit);
    
    /**
     * Get active (running or pending) pipeline executions.
     *
     * @return list of active pipeline execution responses
     */
    List<PipelineExecutionResponse> getActivePipelineExecutions();
    
    /**
     * Cancel a running pipeline execution.
     *
     * @param id the pipeline execution ID
     * @return the updated pipeline execution response
     */
    PipelineExecutionResponse cancelPipelineExecution(Long id);
    
    /**
     * Process the next step of a pipeline execution.
     * This method is called by the scheduler to advance pipeline executions.
     *
     * @param executionId the pipeline execution ID
     */
    void processNextStep(Long executionId);
    
    /**
     * Update the status of running pipeline step executions.
     * This method is called by the scheduler to check for updates from GitLab.
     */
    void updateRunningPipelineStatuses();
}
