package com.gitlab.orchestrator.service;

import java.util.List;

import com.gitlab.orchestrator.dto.PipelineSequenceRequest;
import com.gitlab.orchestrator.dto.PipelineSequenceResponse;
import com.gitlab.orchestrator.model.PipelineSequence;

/**
 * Service interface for pipeline sequence operations.
 */
public interface PipelineSequenceService {
    
    /**
     * Create a new pipeline sequence.
     *
     * @param request the pipeline sequence request
     * @return the created pipeline sequence response
     */
    PipelineSequenceResponse createPipelineSequence(PipelineSequenceRequest request);
    
    /**
     * Get a pipeline sequence by ID.
     *
     * @param id the pipeline sequence ID
     * @return the pipeline sequence response
     */
    PipelineSequenceResponse getPipelineSequence(Long id);
    
    /**
     * Get all pipeline sequences.
     *
     * @return list of pipeline sequence responses
     */
    List<PipelineSequenceResponse> getAllPipelineSequences();
    
    /**
     * Update a pipeline sequence.
     *
     * @param id the pipeline sequence ID
     * @param request the pipeline sequence request
     * @return the updated pipeline sequence response
     */
    PipelineSequenceResponse updatePipelineSequence(Long id, PipelineSequenceRequest request);
    
    /**
     * Delete a pipeline sequence.
     *
     * @param id the pipeline sequence ID
     */
    void deletePipelineSequence(Long id);
    
    /**
     * Get pipeline sequences by name.
     *
     * @param name the name to search for
     * @return list of pipeline sequence responses
     */
    List<PipelineSequenceResponse> getPipelineSequencesByName(String name);
    
    /**
     * Convert a PipelineSequence entity to a PipelineSequenceResponse DTO.
     *
     * @param pipelineSequence the pipeline sequence entity
     * @return the pipeline sequence response DTO
     */
    PipelineSequenceResponse convertToResponse(PipelineSequence pipelineSequence);
}
