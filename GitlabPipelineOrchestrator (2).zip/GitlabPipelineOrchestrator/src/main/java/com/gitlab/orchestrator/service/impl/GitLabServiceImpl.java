package com.gitlab.orchestrator.service.impl;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.models.Pipeline;
import org.gitlab4j.api.models.PipelineStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.gitlab.orchestrator.exception.GitLabApiException;
import com.gitlab.orchestrator.service.GitLabService;

import java.util.Date;
import java.util.Map;
import java.util.Random;

/**
 * Implementation of GitLabService that interacts with the GitLab API.
 */
@Service
public class GitLabServiceImpl implements GitLabService {

    private static final Logger log = LoggerFactory.getLogger(GitLabServiceImpl.class);
    
    private final GitLabApi gitLabApi;
    private final Random random = new Random();
    
    @Value("${gitlab.api.mock-mode:false}")
    private boolean mockMode;

    /**
     * Constructor with GitLabApi dependency.
     *
     * @param gitLabApi the GitLabApi instance
     */
    public GitLabServiceImpl(GitLabApi gitLabApi) {
        this.gitLabApi = gitLabApi;
    }

    @Override
    public Pipeline createPipeline(Integer projectId, String ref, Map<String, String> variables) {
        if (mockMode) {
            log.debug("Mock mode: Creating mock pipeline for project {} on ref {}", projectId, ref);
            return createMockPipeline(projectId);
        }
        
        try {
            log.debug("Creating pipeline for project {} on ref {}", projectId, ref);
            return gitLabApi.getPipelineApi().createPipeline(projectId, ref, variables);
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Error creating pipeline for project {} on ref {}: {}", projectId, ref, e.getMessage());
            throw new GitLabApiException("Error creating pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public Pipeline getPipeline(Integer projectId, Long pipelineId) {
        if (mockMode) {
            log.debug("Mock mode: Getting mock pipeline {} for project {}", pipelineId, projectId);
            return getMockPipeline(projectId, pipelineId);
        }
        
        try {
            log.debug("Getting pipeline {} for project {}", pipelineId, projectId);
            return gitLabApi.getPipelineApi().getPipeline(projectId, pipelineId);
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Error getting pipeline {} for project {}: {}", pipelineId, projectId, e.getMessage());
            throw new GitLabApiException("Error getting pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public Pipeline cancelPipeline(Integer projectId, Long pipelineId) {
        if (mockMode) {
            log.debug("Mock mode: Cancelling mock pipeline {} for project {}", pipelineId, projectId);
            Pipeline pipeline = getMockPipeline(projectId, pipelineId);
            pipeline.setStatus(PipelineStatus.CANCELED);
            return pipeline;
        }
        
        try {
            log.debug("Cancelling pipeline {} for project {}", pipelineId, projectId);
            // The cancelPipeline method might not be directly available in the API version
            // Use cancel job method as an alternative
            gitLabApi.getPipelineApi().cancelPipelineJobs(projectId, pipelineId);
            return gitLabApi.getPipelineApi().getPipeline(projectId, pipelineId);
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Error cancelling pipeline {} for project {}: {}", pipelineId, projectId, e.getMessage());
            throw new GitLabApiException("Error cancelling pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public Pipeline retryPipeline(Integer projectId, Long pipelineId) {
        if (mockMode) {
            log.debug("Mock mode: Retrying mock pipeline {} for project {}", pipelineId, projectId);
            return createMockPipeline(projectId);
        }
        
        try {
            log.debug("Retrying pipeline {} for project {}", pipelineId, projectId);
            // Note: The retry method might not be available in the version of the GitLab4J API we're using
            // This is a workaround that fetches the pipeline after retrying it
            gitLabApi.getPipelineApi().retryPipelineJob(projectId, pipelineId);
            return gitLabApi.getPipelineApi().getPipeline(projectId, pipelineId);
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Error retrying pipeline {} for project {}: {}", pipelineId, projectId, e.getMessage());
            throw new GitLabApiException("Error retrying pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean isPipelineComplete(Pipeline pipeline) {
        if (pipeline == null) {
            return false;
        }
        PipelineStatus status = pipeline.getStatus();
        return status == PipelineStatus.SUCCESS || status == PipelineStatus.FAILED || status == PipelineStatus.CANCELED;
    }

    @Override
    public boolean isPipelineSuccessful(Pipeline pipeline) {
        if (pipeline == null) {
            return false;
        }
        return pipeline.getStatus() == PipelineStatus.SUCCESS;
    }

    @Override
    public String getPipelineStatus(Pipeline pipeline) {
        if (pipeline == null) {
            return "unknown";
        }
        return pipeline.getStatus().toString().toLowerCase();
    }
    
    @Override
    public boolean isMockModeEnabled() {
        return mockMode;
    }
    
    /**
     * Create a mock pipeline for testing.
     *
     * @param projectId the GitLab project ID
     * @return a mock pipeline
     */
    private Pipeline createMockPipeline(Integer projectId) {
        Pipeline pipeline = new Pipeline();
        long pipelineId = Math.abs(random.nextLong() % 10000) + 1;
        pipeline.setId(pipelineId);
        pipeline.setProjectId(Long.valueOf(projectId));
        pipeline.setRef("main");
        pipeline.setStatus(PipelineStatus.RUNNING);
        pipeline.setCreatedAt(new Date());
        pipeline.setUpdatedAt(new Date());
        return pipeline;
    }
    
    /**
     * Get a mock pipeline with a specific ID.
     *
     * @param projectId the GitLab project ID
     * @param pipelineId the GitLab pipeline ID
     * @return a mock pipeline
     */
    private Pipeline getMockPipeline(Integer projectId, Long pipelineId) {
        Pipeline pipeline = new Pipeline();
        pipeline.setId(pipelineId);
        pipeline.setProjectId(Long.valueOf(projectId));
        pipeline.setRef("main");
        
        // Randomly decide pipeline state based on pipeline ID
        int statusIndex = (int) (pipelineId % 4);
        PipelineStatus[] statuses = {
            PipelineStatus.RUNNING, 
            PipelineStatus.SUCCESS, 
            PipelineStatus.FAILED, 
            PipelineStatus.CANCELED
        };
        pipeline.setStatus(statuses[statusIndex]);
        
        pipeline.setCreatedAt(new Date());
        pipeline.setUpdatedAt(new Date());
        return pipeline;
    }
}
