package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.ApiResponse;
import com.gitlab.orchestrator.dto.LoginRequest;
import com.gitlab.orchestrator.dto.LoginResponse;
import com.gitlab.orchestrator.model.User;
import com.gitlab.orchestrator.service.JwtService;
import com.gitlab.orchestrator.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * Controller for authentication operations.
 */
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserService userService;

    /**
     * Authenticate user and generate JWT token.
     *
     * @param loginRequest the login credentials
     * @return JWT token
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtService.generateToken(authentication);
        
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        User user = userService.getUserByUsername(userDetails.getUsername());
        
        return ResponseEntity.ok(new LoginResponse(jwt, user.getUsername(), user.getRoles()));
    }

    /**
     * Register a new user.
     *
     * @param user the user to register
     * @return the registered user
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody User user) {
        if (userService.existsByUsername(user.getUsername())) {
            return ResponseEntity
                    .badRequest()
                    .body(new ApiResponse(false, "Username is already taken!"));
        }

        if (userService.existsByEmail(user.getEmail())) {
            return ResponseEntity
                    .badRequest()
                    .body(new ApiResponse(false, "Email is already in use!"));
        }

        User createdUser = userService.createUser(user);
        return ResponseEntity.ok(createdUser);
    }
}
