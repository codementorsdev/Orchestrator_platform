package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.WorkflowDto;
import com.gitlab.orchestrator.model.Workflow;
import com.gitlab.orchestrator.service.WorkflowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for the Thymeleaf dashboard views.
 */
@Controller
public class DashboardController {

    @Autowired
    private WorkflowService workflowService;

    /**
     * Display the login page.
     *
     * @return the login view name
     */
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    /**
     * Display the main dashboard.
     *
     * @param model the model to populate with data
     * @return the dashboard view name
     */
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<Workflow> workflows = workflowService.getAllWorkflows();
        
        List<WorkflowDto> workflowDtos = workflows.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        model.addAttribute("workflows", workflowDtos);
        return "dashboard";
    }

    /**
     * Display details for a specific workflow.
     *
     * @param id the workflow ID
     * @param model the model to populate with data
     * @return the workflow detail view name
     */
    @GetMapping("/workflow/{id}")
    public String workflowDetail(@PathVariable Long id, Model model) {
        Workflow workflow = workflowService.getWorkflowById(id);
        model.addAttribute("workflow", convertToDto(workflow));
        return "workflow-detail";
    }

    /**
     * Convert a Workflow entity to a WorkflowDto.
     *
     * @param workflow the workflow entity
     * @return the workflow DTO
     */
    private WorkflowDto convertToDto(Workflow workflow) {
        WorkflowDto workflowDto = new WorkflowDto();
        workflowDto.setId(workflow.getId());
        workflowDto.setName(workflow.getName());
        workflowDto.setDescription(workflow.getDescription());
        workflowDto.setStatus(workflow.getStatus().name());
        workflowDto.setCreatedBy(workflow.getCreatedBy() != null ? workflow.getCreatedBy().getUsername() : null);
        workflowDto.setCreatedAt(workflow.getCreatedAt());
        workflowDto.setUpdatedAt(workflow.getUpdatedAt());
        
        return workflowDto;
    }
}
