package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.ApiResponse;
import com.gitlab.orchestrator.dto.PipelineExecutionDto;
import com.gitlab.orchestrator.model.PipelineExecution;
import com.gitlab.orchestrator.service.PipelineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for pipeline operations.
 */
@RestController
@RequestMapping("/api/pipelines")
public class PipelineController {

    @Autowired
    private PipelineService pipelineService;

    /**
     * Get all pipeline executions.
     *
     * @return list of all pipeline executions
     */
    @GetMapping
    public ResponseEntity<List<PipelineExecutionDto>> getAllPipelineExecutions() {
        List<PipelineExecution> pipelineExecutions = pipelineService.getAllPipelineExecutions();
        
        List<PipelineExecutionDto> pipelineExecutionDtos = pipelineExecutions.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(pipelineExecutionDtos);
    }

    /**
     * Get a pipeline execution by ID.
     *
     * @param id the pipeline execution ID
     * @return the pipeline execution
     */
    @GetMapping("/{id}")
    public ResponseEntity<PipelineExecutionDto> getPipelineExecutionById(@PathVariable Long id) {
        PipelineExecution pipelineExecution = pipelineService.getPipelineExecutionById(id);
        return ResponseEntity.ok(convertToDto(pipelineExecution));
    }

    /**
     * Get pipeline executions for a specific application.
     *
     * @param applicationId the application ID
     * @return list of pipeline executions
     */
    @GetMapping("/application/{applicationId}")
    public ResponseEntity<List<PipelineExecutionDto>> getPipelineExecutionsByApplication(@PathVariable Long applicationId) {
        List<PipelineExecution> pipelineExecutions = pipelineService.getPipelineExecutionsByApplication(applicationId);
        
        List<PipelineExecutionDto> pipelineExecutionDtos = pipelineExecutions.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(pipelineExecutionDtos);
    }

    /**
     * Execute a pipeline for a specific application.
     *
     * @param applicationId the application ID
     * @return the created pipeline execution
     */
    @PostMapping("/execute")
    public ResponseEntity<PipelineExecutionDto> executePipeline(@RequestParam Long applicationId) {
        PipelineExecution pipelineExecution = pipelineService.executePipeline(applicationId);
        return ResponseEntity.ok(convertToDto(pipelineExecution));
    }

    /**
     * Cancel a pipeline execution.
     *
     * @param id the pipeline execution ID
     * @return the updated pipeline execution
     */
    @PostMapping("/{id}/cancel")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<PipelineExecutionDto> cancelPipelineExecution(@PathVariable Long id) {
        PipelineExecution pipelineExecution = pipelineService.cancelPipelineExecution(id);
        return ResponseEntity.ok(convertToDto(pipelineExecution));
    }

    /**
     * Convert a PipelineExecution entity to a PipelineExecutionDto.
     *
     * @param pipelineExecution the pipeline execution entity
     * @return the pipeline execution DTO
     */
    private PipelineExecutionDto convertToDto(PipelineExecution pipelineExecution) {
        PipelineExecutionDto pipelineExecutionDto = new PipelineExecutionDto();
        pipelineExecutionDto.setId(pipelineExecution.getId());
        pipelineExecutionDto.setGitlabPipelineId(pipelineExecution.getGitlabPipelineId());
        pipelineExecutionDto.setStatus(pipelineExecution.getStatus().name());
        pipelineExecutionDto.setApplicationId(pipelineExecution.getApplication().getId());
        pipelineExecutionDto.setApplicationName(pipelineExecution.getApplication().getName());
        pipelineExecutionDto.setWorkflowId(pipelineExecution.getApplication().getWorkflow().getId());
        pipelineExecutionDto.setWorkflowName(pipelineExecution.getApplication().getWorkflow().getName());
        pipelineExecutionDto.setLogUrl(pipelineExecution.getLogUrl());
        pipelineExecutionDto.setExitCode(pipelineExecution.getExitCode());
        pipelineExecutionDto.setStartedAt(pipelineExecution.getStartedAt());
        pipelineExecutionDto.setFinishedAt(pipelineExecution.getFinishedAt());
        pipelineExecutionDto.setCreatedAt(pipelineExecution.getCreatedAt());
        pipelineExecutionDto.setUpdatedAt(pipelineExecution.getUpdatedAt());
        
        return pipelineExecutionDto;
    }
}
