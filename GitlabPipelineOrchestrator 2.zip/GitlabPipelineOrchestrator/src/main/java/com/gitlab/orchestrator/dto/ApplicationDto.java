package com.gitlab.orchestrator.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * DTO for Application data.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationDto {

    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    private String description;

    @NotBlank(message = "GitLab project ID is required")
    private String gitlabProjectId;

    @NotBlank(message = "GitLab branch is required")
    private String gitlabBranch;

    @NotNull(message = "Execution order is required")
    private Integer executionOrder;

    private Long workflowId;

    private String workflowName;

    private Date createdAt;

    private Date updatedAt;
}
