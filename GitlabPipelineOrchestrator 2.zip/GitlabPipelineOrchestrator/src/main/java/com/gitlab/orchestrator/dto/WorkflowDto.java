package com.gitlab.orchestrator.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * DTO for Workflow data.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkflowDto {

    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    private String description;

    private String status;

    private String createdBy;

    private Date createdAt;

    private Date updatedAt;
}
