package com.gitlab.orchestrator.model;

/**
 * Enum representing user roles in the system.
 * TESTER: Default role that can create resources
 * ADMIN: Role with full CRUD privileges
 */
public enum Role {
    TESTER,
    ADMIN
}
