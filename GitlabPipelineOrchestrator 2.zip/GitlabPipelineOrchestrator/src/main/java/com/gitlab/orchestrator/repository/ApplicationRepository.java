package com.gitlab.orchestrator.repository;

import com.gitlab.orchestrator.model.Application;
import com.gitlab.orchestrator.model.Workflow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for Application entity.
 */
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    
    /**
     * Find all applications belonging to a specific workflow.
     *
     * @param workflow the workflow to find applications for
     * @return a list of applications
     */
    List<Application> findByWorkflow(Workflow workflow);
    
    /**
     * Find all applications belonging to a specific workflow, ordered by execution order.
     *
     * @param workflow the workflow to find applications for
     * @return a list of applications ordered by execution order
     */
    List<Application> findByWorkflowOrderByExecutionOrderAsc(Workflow workflow);
    
    /**
     * Find the next application to execute in a workflow based on execution order.
     *
     * @param workflowId the ID of the workflow
     * @param currentOrder the current execution order
     * @return the next application in sequence
     */
    @Query("SELECT a FROM Application a WHERE a.workflow.id = :workflowId AND a.executionOrder > :currentOrder ORDER BY a.executionOrder ASC")
    List<Application> findNextApplicationInWorkflow(Long workflowId, int currentOrder);
}
