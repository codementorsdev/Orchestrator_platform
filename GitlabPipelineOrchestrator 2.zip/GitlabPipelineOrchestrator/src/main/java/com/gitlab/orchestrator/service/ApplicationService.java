package com.gitlab.orchestrator.service;

import com.gitlab.orchestrator.exception.ResourceNotFoundException;
import com.gitlab.orchestrator.model.Application;
import com.gitlab.orchestrator.model.Workflow;
import com.gitlab.orchestrator.repository.ApplicationRepository;
import com.gitlab.orchestrator.repository.WorkflowRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Service for application management.
 */
@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private WorkflowRepository workflowRepository;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    /**
     * Get all applications.
     *
     * @return a list of all applications
     */
    @Transactional(readOnly = true)
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    /**
     * Get an application by ID.
     *
     * @param id the application ID
     * @return the application
     * @throws ResourceNotFoundException if the application is not found
     */
    @Transactional(readOnly = true)
    public Application getApplicationById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with id: " + id));
    }

    /**
     * Create a new application.
     *
     * @param application the application to create
     * @param workflowId the ID of the workflow this application belongs to
     * @return the created application
     * @throws ResourceNotFoundException if the workflow is not found
     */
    @Transactional
    public Application createApplication(Application application, Long workflowId) {
        Workflow workflow = workflowRepository.findById(workflowId)
                .orElseThrow(() -> new ResourceNotFoundException("Workflow not found with id: " + workflowId));
        
        application.setWorkflow(workflow);
        Application savedApplication = applicationRepository.save(application);
        
        // Notify subscribers about new application
        messagingTemplate.convertAndSend("/topic/workflow/" + workflowId + "/applications", savedApplication);
        
        return savedApplication;
    }

    /**
     * Update an existing application.
     *
     * @param id the application ID
     * @param updatedApplication the updated application details
     * @return the updated application
     * @throws ResourceNotFoundException if the application is not found
     */
    @Transactional
    public Application updateApplication(Long id, Application updatedApplication) {
        Application application = getApplicationById(id);
        
        application.setName(updatedApplication.getName());
        application.setDescription(updatedApplication.getDescription());
        application.setGitlabProjectId(updatedApplication.getGitlabProjectId());
        application.setGitlabBranch(updatedApplication.getGitlabBranch());
        application.setExecutionOrder(updatedApplication.getExecutionOrder());
        
        Application savedApplication = applicationRepository.save(application);
        
        // Notify subscribers about updated application
        messagingTemplate.convertAndSend(
                "/topic/workflow/" + application.getWorkflow().getId() + "/applications", 
                savedApplication);
        
        return savedApplication;
    }

    /**
     * Delete an application by ID.
     *
     * @param id the application ID
     * @throws ResourceNotFoundException if the application is not found
     */
    @Transactional
    public void deleteApplication(Long id) {
        Application application = getApplicationById(id);
        Long workflowId = application.getWorkflow().getId();
        
        applicationRepository.deleteById(id);
        
        // Notify subscribers about deleted application
        messagingTemplate.convertAndSend(
                "/topic/workflow/" + workflowId + "/applications/deleted", 
                id);
    }

    /**
     * Get all applications for a specific workflow.
     *
     * @param workflowId the workflow ID
     * @return a list of applications
     * @throws ResourceNotFoundException if the workflow is not found
     */
    @Transactional(readOnly = true)
    public List<Application> getApplicationsByWorkflow(Long workflowId) {
        Workflow workflow = workflowRepository.findById(workflowId)
                .orElseThrow(() -> new ResourceNotFoundException("Workflow not found with id: " + workflowId));
        
        return applicationRepository.findByWorkflowOrderByExecutionOrderAsc(workflow);
    }

    /**
     * Get the next application to execute in a workflow.
     *
     * @param workflowId the workflow ID
     * @param currentOrder the current execution order
     * @return the next application, or null if there are no more applications
     */
    @Transactional(readOnly = true)
    public Application getNextApplication(Long workflowId, int currentOrder) {
        List<Application> nextApplications = applicationRepository.findNextApplicationInWorkflow(workflowId, currentOrder);
        return nextApplications.isEmpty() ? null : nextApplications.get(0);
    }
}
