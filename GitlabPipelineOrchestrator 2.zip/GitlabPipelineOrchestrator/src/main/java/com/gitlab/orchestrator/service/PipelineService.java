package com.gitlab.orchestrator.service;

import com.gitlab.orchestrator.exception.ResourceNotFoundException;
import com.gitlab.orchestrator.model.Application;
import com.gitlab.orchestrator.model.PipelineExecution;
import com.gitlab.orchestrator.model.Workflow;
import com.gitlab.orchestrator.repository.PipelineExecutionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Service for pipeline execution management.
 */
@Service
public class PipelineService {

    private static final Logger logger = LoggerFactory.getLogger(PipelineService.class);

    @Autowired
    private PipelineExecutionRepository pipelineExecutionRepository;

    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private WorkflowService workflowService;

    @Autowired
    private GitlabIntegrationService gitlabService;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    /**
     * Get all pipeline executions.
     *
     * @return a list of all pipeline executions
     */
    @Transactional(readOnly = true)
    public List<PipelineExecution> getAllPipelineExecutions() {
        return pipelineExecutionRepository.findAll();
    }

    /**
     * Get a pipeline execution by ID.
     *
     * @param id the pipeline execution ID
     * @return the pipeline execution
     * @throws ResourceNotFoundException if the pipeline execution is not found
     */
    @Transactional(readOnly = true)
    public PipelineExecution getPipelineExecutionById(Long id) {
        return pipelineExecutionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline execution not found with id: " + id));
    }

    /**
     * Get pipeline executions for a specific application.
     *
     * @param applicationId the application ID
     * @return a list of pipeline executions
     * @throws ResourceNotFoundException if the application is not found
     */
    @Transactional(readOnly = true)
    public List<PipelineExecution> getPipelineExecutionsByApplication(Long applicationId) {
        Application application = applicationService.getApplicationById(applicationId);
        return pipelineExecutionRepository.findByApplication(application);
    }

    /**
     * Execute a pipeline for a specific application.
     *
     * @param applicationId the application ID
     * @return the created pipeline execution
     * @throws ResourceNotFoundException if the application is not found
     */
    @Transactional
    public PipelineExecution executePipeline(Long applicationId) {
        Application application = applicationService.getApplicationById(applicationId);
        
        // Create a new pipeline execution
        PipelineExecution pipelineExecution = new PipelineExecution();
        pipelineExecution.setApplication(application);
        pipelineExecution.setStatus(PipelineExecution.PipelineStatus.PENDING);
        pipelineExecution.setStartedAt(new Date());
        
        PipelineExecution savedExecution = pipelineExecutionRepository.save(pipelineExecution);
        
        // Notify subscribers about new pipeline execution
        messagingTemplate.convertAndSend(
                "/topic/workflow/" + application.getWorkflow().getId() + "/pipelines", 
                savedExecution);
        
        // Trigger the pipeline asynchronously
        triggerPipelineAsync(savedExecution.getId());
        
        return savedExecution;
    }

    /**
     * Trigger a GitLab pipeline asynchronously.
     *
     * @param pipelineExecutionId the pipeline execution ID
     */
    @Async
    @Transactional
    public void triggerPipelineAsync(Long pipelineExecutionId) {
        PipelineExecution pipelineExecution = getPipelineExecutionById(pipelineExecutionId);
        Application application = pipelineExecution.getApplication();
        Workflow workflow = application.getWorkflow();
        
        try {
            // Update status to running
            pipelineExecution.setStatus(PipelineExecution.PipelineStatus.RUNNING);
            pipelineExecution = pipelineExecutionRepository.save(pipelineExecution);
            
            // Notify subscribers about pipeline status change
            messagingTemplate.convertAndSend(
                    "/topic/workflow/" + workflow.getId() + "/pipelines", 
                    pipelineExecution);
            
            // Trigger the GitLab pipeline
            String pipelineId = gitlabService.triggerPipeline(
                    application.getGitlabProjectId(), 
                    application.getGitlabBranch());
            
            pipelineExecution.setGitlabPipelineId(pipelineId);
            pipelineExecution = pipelineExecutionRepository.save(pipelineExecution);
            
            // Monitor the pipeline until it completes
            monitorPipelineExecution(pipelineExecution);
            
        } catch (Exception e) {
            logger.error("Error executing pipeline: ", e);
            pipelineExecution.setStatus(PipelineExecution.PipelineStatus.FAILED);
            pipelineExecution.setFinishedAt(new Date());
            pipelineExecutionRepository.save(pipelineExecution);
            
            // Notify subscribers about pipeline failure
            messagingTemplate.convertAndSend(
                    "/topic/workflow/" + workflow.getId() + "/pipelines", 
                    pipelineExecution);
            
            // Update workflow status
            workflowService.updateWorkflowStatus(workflow.getId(), Workflow.WorkflowStatus.FAILED);
        }
    }

    /**
     * Monitor a pipeline execution until it completes.
     *
     * @param pipelineExecution the pipeline execution to monitor
     */
    private void monitorPipelineExecution(PipelineExecution pipelineExecution) {
        Application application = pipelineExecution.getApplication();
        Workflow workflow = application.getWorkflow();
        
        // Poll the GitLab API until the pipeline completes
        PipelineExecution.PipelineStatus finalStatus = gitlabService.monitorPipeline(
                application.getGitlabProjectId(), 
                pipelineExecution.getGitlabPipelineId());
        
        // Update the pipeline execution status
        pipelineExecution.setStatus(finalStatus);
        pipelineExecution.setFinishedAt(new Date());
        pipelineExecutionRepository.save(pipelineExecution);
        
        // Notify subscribers about pipeline completion
        messagingTemplate.convertAndSend(
                "/topic/workflow/" + workflow.getId() + "/pipelines", 
                pipelineExecution);
        
        // If the pipeline succeeded, trigger the next application's pipeline
        if (finalStatus == PipelineExecution.PipelineStatus.SUCCESS) {
            Application nextApplication = applicationService.getNextApplication(
                    workflow.getId(), 
                    application.getExecutionOrder());
            
            if (nextApplication != null) {
                executePipeline(nextApplication.getId());
            } else {
                // No more applications, workflow is complete
                workflowService.updateWorkflowStatus(workflow.getId(), Workflow.WorkflowStatus.COMPLETED);
            }
        } else {
            // Pipeline failed, update workflow status
            workflowService.updateWorkflowStatus(workflow.getId(), Workflow.WorkflowStatus.FAILED);
        }
    }

    /**
     * Cancel a pipeline execution.
     *
     * @param id the pipeline execution ID
     * @return the updated pipeline execution
     * @throws ResourceNotFoundException if the pipeline execution is not found
     */
    @Transactional
    public PipelineExecution cancelPipelineExecution(Long id) {
        PipelineExecution pipelineExecution = getPipelineExecutionById(id);
        
        if (pipelineExecution.getStatus() == PipelineExecution.PipelineStatus.RUNNING ||
            pipelineExecution.getStatus() == PipelineExecution.PipelineStatus.PENDING) {
            
            // Cancel the GitLab pipeline
            gitlabService.cancelPipeline(
                    pipelineExecution.getApplication().getGitlabProjectId(), 
                    pipelineExecution.getGitlabPipelineId());
            
            pipelineExecution.setStatus(PipelineExecution.PipelineStatus.CANCELLED);
            pipelineExecution.setFinishedAt(new Date());
            PipelineExecution updatedExecution = pipelineExecutionRepository.save(pipelineExecution);
            
            // Notify subscribers about cancelled pipeline
            messagingTemplate.convertAndSend(
                    "/topic/workflow/" + pipelineExecution.getApplication().getWorkflow().getId() + "/pipelines", 
                    updatedExecution);
            
            return updatedExecution;
        }
        
        return pipelineExecution;
    }
}
