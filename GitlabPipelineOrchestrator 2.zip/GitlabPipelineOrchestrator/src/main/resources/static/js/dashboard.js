// Dashboard JavaScript

// Variables
let stompClient = null;
let currentUser = null;
const token = localStorage.getItem('token');

// Check if user is authenticated
function checkAuth() {
    if (!token) {
        window.location.href = '/login';
        return;
    }

    // Show/hide elements based on user role
    const isAdmin = JSON.parse(localStorage.getItem('user_roles') || '[]').includes('ADMIN');
    document.querySelectorAll('.admin-only').forEach(el => {
        el.style.display = isAdmin ? 'inline-block' : 'none';
    });

    // Set username
    document.getElementById('username').textContent = localStorage.getItem('username') || 'User';
}

// Connect to WebSocket
function connectWebSocket() {
    const socket = new SockJS('/ws');
    stompClient = Stomp.over(socket);
    
    const headers = {
        'Authorization': 'Bearer ' + token
    };
    
    stompClient.connect(headers, function() {
        console.log('Connected to WebSocket');
        
        // Subscribe to workflow updates
        stompClient.subscribe('/topic/workflows', function(message) {
            const workflows = JSON.parse(message.body);
            updateWorkflowsTable(workflows);
        });
        
        // Load initial data
        loadWorkflows();
    });
}

// Load all workflows
function loadWorkflows() {
    fetch('/api/workflows', {
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to load workflows');
        }
        return response.json();
    })
    .then(workflows => {
        updateWorkflowsTable(workflows);
    })
    .catch(error => {
        console.error('Error loading workflows:', error);
    });
}

// Update workflows table
function updateWorkflowsTable(workflows) {
    const tbody = document.getElementById('workflowsTable');
    tbody.innerHTML = '';
    
    workflows.forEach(workflow => {
        const tr = document.createElement('tr');
        
        const statusClass = workflow.status === 'COMPLETED' ? 'bg-success' : 
                           workflow.status === 'RUNNING' ? 'bg-primary' : 
                           workflow.status === 'FAILED' ? 'bg-danger' : 
                           workflow.status === 'CANCELLED' ? 'bg-warning' : 'bg-secondary';
        
        tr.innerHTML = `
            <td>${workflow.id}</td>
            <td><a href="/workflow/${workflow.id}">${workflow.name}</a></td>
            <td><span class="badge ${statusClass}">${workflow.status}</span></td>
            <td>${workflow.createdBy || ''}</td>
            <td>${new Date(workflow.createdAt).toLocaleString()}</td>
            <td>
                <div class="btn-group" role="group">
                    <a href="/workflow/${workflow.id}" class="btn btn-sm btn-outline-primary">
                        <i data-feather="eye"></i>
                    </a>
                    <button class="btn btn-sm btn-outline-success execute-workflow-btn" data-workflow-id="${workflow.id}">
                        <i data-feather="play"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger delete-workflow-btn admin-only" data-workflow-id="${workflow.id}">
                        <i data-feather="trash-2"></i>
                    </button>
                </div>
            </td>
        `;
        
        tbody.appendChild(tr);
    });
    
    // Re-initialize Feather icons
    feather.replace();
    
    // Add event listeners to buttons
    addWorkflowButtonListeners();
}

// Add event listeners to workflow action buttons
function addWorkflowButtonListeners() {
    // Execute workflow buttons
    document.querySelectorAll('.execute-workflow-btn').forEach(button => {
        button.addEventListener('click', function() {
            const workflowId = this.getAttribute('data-workflow-id');
            executeWorkflow(workflowId);
        });
    });
    
    // Delete workflow buttons
    document.querySelectorAll('.delete-workflow-btn').forEach(button => {
        button.addEventListener('click', function() {
            const workflowId = this.getAttribute('data-workflow-id');
            if (confirm('Are you sure you want to delete this workflow?')) {
                deleteWorkflow(workflowId);
            }
        });
    });
}

// Execute a workflow
function executeWorkflow(workflowId) {
    fetch(`/api/workflows/${workflowId}/execute`, {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to execute workflow');
        }
        return response.json();
    })
    .then(workflow => {
        console.log('Workflow execution started:', workflow);
        
        // Subscribe to this specific workflow's updates
        subscribeToWorkflow(workflowId);
    })
    .catch(error => {
        console.error('Error executing workflow:', error);
        alert('Failed to execute workflow. Please try again.');
    });
}

// Subscribe to updates for a specific workflow
function subscribeToWorkflow(workflowId) {
    if (stompClient) {
        // Subscribe to workflow status updates
        stompClient.subscribe(`/topic/workflow/${workflowId}`, function(message) {
            const workflow = JSON.parse(message.body);
            console.log(`Workflow ${workflowId} updated:`, workflow);
            
            // Refresh the workflows list
            loadWorkflows();
        });
        
        // Subscribe to pipeline updates for this workflow
        stompClient.subscribe(`/topic/workflow/${workflowId}/pipelines`, function(message) {
            const pipeline = JSON.parse(message.body);
            console.log(`Pipeline updated for workflow ${workflowId}:`, pipeline);
            
            // If we're on the workflow detail page, update the UI
            if (window.location.pathname === `/workflow/${workflowId}`) {
                updatePipelineStatus(pipeline);
            }
        });
    }
}

// Delete a workflow
function deleteWorkflow(workflowId) {
    fetch(`/api/workflows/${workflowId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to delete workflow');
        }
        return response.json();
    })
    .then(result => {
        console.log('Workflow deleted:', result);
        loadWorkflows();
    })
    .catch(error => {
        console.error('Error deleting workflow:', error);
        alert('Failed to delete workflow. Please try again.');
    });
}

// Create a new workflow
function createWorkflow() {
    const name = document.getElementById('workflowName').value;
    const description = document.getElementById('workflowDescription').value;
    
    if (!name) {
        alert('Workflow name is required');
        return;
    }
    
    const workflowData = {
        name: name,
        description: description
    };
    
    fetch('/api/workflows', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify(workflowData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to create workflow');
        }
        return response.json();
    })
    .then(workflow => {
        console.log('Workflow created:', workflow);
        
        // Close modal and reset form
        const modal = bootstrap.Modal.getInstance(document.getElementById('createWorkflowModal'));
        modal.hide();
        document.getElementById('createWorkflowForm').reset();
        
        // Refresh the workflows list
        loadWorkflows();
    })
    .catch(error => {
        console.error('Error creating workflow:', error);
        alert('Failed to create workflow. Please try again.');
    });
}

// Logout function
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('user_roles');
    window.location.href = '/login';
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    checkAuth();
    
    // Connect to WebSocket
    connectWebSocket();
    
    // Create workflow button
    document.getElementById('createWorkflowBtn').addEventListener('click', createWorkflow);
    
    // Logout button
    document.getElementById('logoutBtn').addEventListener('click', logout);
});
