import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { X } from "lucide-react";
import { z } from "zod";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

import { insertApplicationSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { gitlabApi } from "@/lib/gitlab-api";

const formSchema = insertApplicationSchema.extend({
  name: z.string().min(1, "Application name is required"),
  accessToken: z.string().min(1, "Access token is required"),
  projectId: z.number().min(1, "Project ID must be a positive number"),
});

type FormData = z.infer<typeof formSchema>;

interface AddApplicationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddApplicationModal({ open, onOpenChange }: AddApplicationModalProps) {
  const [isValidating, setIsValidating] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      accessToken: "",
      projectId: 0,
      description: "",
      status: "active",
    },
  });

  const createApplicationMutation = useMutation({
    mutationFn: async (data: FormData) => {
      // First validate GitLab connection
      setIsValidating(true);
      const isValid = await gitlabApi.testConnection(data.projectId, data.accessToken);
      setIsValidating(false);

      if (!isValid) {
        throw new Error("Invalid GitLab credentials or project access");
      }

      const response = await apiRequest("POST", "/api/applications", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Success",
        description: "Application registered successfully",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    createApplicationMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-gitlab-surface border-gray-700">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Add New Application
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="name">Application Name</Label>
            <Input
              id="name"
              placeholder="Enter application name"
              className="bg-gitlab-card border-gray-600 focus:border-gitlab-blue"
              {...form.register("name")}
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-400 mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="accessToken">GitLab Access Token</Label>
            <Input
              id="accessToken"
              type="password"
              placeholder="Enter your GitLab access token"
              className="bg-gitlab-card border-gray-600 focus:border-gitlab-blue"
              {...form.register("accessToken")}
            />
            {form.formState.errors.accessToken && (
              <p className="text-sm text-red-400 mt-1">{form.formState.errors.accessToken.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="projectId">Project ID</Label>
            <Input
              id="projectId"
              type="number"
              placeholder="Enter GitLab project ID"
              className="bg-gitlab-card border-gray-600 focus:border-gitlab-blue"
              {...form.register("projectId", { valueAsNumber: true })}
            />
            {form.formState.errors.projectId && (
              <p className="text-sm text-red-400 mt-1">{form.formState.errors.projectId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              placeholder="Brief description of the application"
              className="bg-gitlab-card border-gray-600 focus:border-gitlab-blue h-20 resize-none"
              {...form.register("description")}
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              className="flex-1 border-gray-600 hover:border-gray-500"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gitlab-blue hover:bg-blue-700"
              disabled={createApplicationMutation.isPending || isValidating}
            >
              {isValidating ? "Validating..." : createApplicationMutation.isPending ? "Adding..." : "Add Application"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
