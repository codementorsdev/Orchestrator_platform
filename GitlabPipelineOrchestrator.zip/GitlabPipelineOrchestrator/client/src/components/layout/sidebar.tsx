import { Link, useLocation } from "wouter";
import { ChartPie, Box, PlayCircle, ListTodo } from "lucide-react";
import { SiGitlab } from "react-icons/si";

const navigation = [
  {
    name: "Dashboard",
    href: "/",
    icon: ChartPie,
  },
  {
    name: "Applications",
    href: "/applications",
    icon: Box,
  },
  {
    name: "Test Flows",
    href: "/test-flows",
    icon: PlayCircle,
  },
  {
    name: "Executions",
    href: "/executions",
    icon: ListTodo,
  },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-gitlab-surface border-r border-gray-700 flex flex-col">
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gitlab-blue rounded-lg flex items-center justify-center">
            <SiGitlab className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-lg font-semibold">Pipeline Orchestrator</h1>
            <p className="text-xs text-gray-400">v1.0.0</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;

          return (
            <Link key={item.name} href={item.href}>
              <div
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                  isActive
                    ? "bg-gitlab-blue text-white"
                    : "text-gray-300 hover:bg-gitlab-card"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.name}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center">
            <span className="text-sm font-medium">A</span>
          </div>
          <div>
            <p className="text-sm font-medium">Admin User</p>
            <p className="text-xs text-gray-400">System Administrator</p>
          </div>
        </div>
      </div>
    </div>
  );
}
