import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { gitlabApi } from "@/lib/gitlab-api";
import { useToast } from "@/hooks/use-toast";
import type { App, TestCaseWithApps } from "@shared/schema";

const testCaseFormSchema = z.object({
  name: z.string().min(1, "Test case name is required"),
  description: z.string().optional(),
  envVars: z.string().optional(),
});

type TestCaseFormData = z.infer<typeof testCaseFormSchema>;

interface AppConfig {
  appId: number;
  branch: string;
  app?: App;
}

interface TestCaseFormProps {
  testCase?: TestCaseWithApps | null;
  onClose: () => void;
}

export function TestCaseForm({ testCase, onClose }: TestCaseFormProps) {
  const [appConfigs, setAppConfigs] = useState<AppConfig[]>([]);
  const [loadingBranches, setLoadingBranches] = useState<Record<number, boolean>>({});
  const [availableBranches, setAvailableBranches] = useState<Record<number, string[]>>({});
  const { toast } = useToast();

  const { data: apps = [] } = useQuery<App[]>({
    queryKey: ["/api/apps"],
  });

  const form = useForm<TestCaseFormData>({
    resolver: zodResolver(testCaseFormSchema),
    defaultValues: {
      name: testCase?.name || "",
      description: testCase?.description || "",
      envVars: testCase?.envVars || "",
    },
  });

  // Initialize app configs for editing
  useEffect(() => {
    if (testCase?.testCaseApps) {
      setAppConfigs(
        testCase.testCaseApps.map((tca) => ({
          appId: tca.appId,
          branch: tca.branch,
          app: tca.app,
        }))
      );
    }
  }, [testCase]);

  const loadBranches = async (appId: number) => {
    const app = apps.find((a) => a.id === appId);
    if (!app) return;

    setLoadingBranches((prev) => ({ ...prev, [appId]: true }));

    try {
      const branches = await gitlabApi.getBranches(app.projectId, app.accessToken);
      setAvailableBranches((prev) => ({
        ...prev,
        [appId]: branches.map((b: any) => b.name),
      }));
    } catch (error) {
      console.error("Failed to load branches:", error);
      toast({
        title: "Error",
        description: "Failed to load branches for this app",
        variant: "destructive",
      });
    } finally {
      setLoadingBranches((prev) => ({ ...prev, [appId]: false }));
    }
  };

  const addAppConfig = () => {
    setAppConfigs((prev) => [...prev, { appId: 0, branch: "" }]);
  };

  const removeAppConfig = (index: number) => {
    setAppConfigs((prev) => prev.filter((_, i) => i !== index));
  };

  const updateAppConfig = (index: number, updates: Partial<AppConfig>) => {
    setAppConfigs((prev) =>
      prev.map((config, i) => (i === index ? { ...config, ...updates } : config))
    );

    // Load branches when app is selected
    if (updates.appId && updates.appId !== 0) {
      loadBranches(updates.appId);
    }
  };

  const createTestCaseMutation = useMutation({
    mutationFn: async (data: TestCaseFormData) => {
      const validAppConfigs = appConfigs.filter(
        (config) => config.appId && config.branch
      );

      if (validAppConfigs.length === 0) {
        throw new Error("At least one app configuration is required");
      }

      const payload = {
        testCase: data,
        appConfigs: validAppConfigs.map((config) => ({
          appId: config.appId,
          branch: config.branch,
        })),
      };

      if (testCase) {
        return apiRequest("PUT", `/api/test-cases/${testCase.id}`, payload);
      } else {
        return apiRequest("POST", "/api/test-cases", payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/test-cases"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: testCase ? "Test case updated successfully" : "Test case created successfully",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save test case",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TestCaseFormData) => {
    createTestCaseMutation.mutate(data);
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <Label htmlFor="name">Test Case Name</Label>
            <Input
              id="name"
              {...form.register("name")}
              placeholder="Enter test case name"
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-600 mt-1">
                {form.formState.errors.name.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              placeholder="Describe what this test case does..."
              rows={3}
            />
          </div>

          <div>
            <Label className="text-base font-medium">App & Branch Configuration</Label>
            <div className="space-y-4 mt-3">
              {appConfigs.map((config, index) => (
                <div key={index} className="flex items-end space-x-4 p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <Label>Select App</Label>
                    <Select
                      value={config.appId.toString()}
                      onValueChange={(value) =>
                        updateAppConfig(index, {
                          appId: parseInt(value),
                          branch: "", // Reset branch when app changes
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Choose an app..." />
                      </SelectTrigger>
                      <SelectContent>
                        {apps.map((app) => (
                          <SelectItem key={app.id} value={app.id.toString()}>
                            {app.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex-1">
                    <Label>Select Branch</Label>
                    <Select
                      value={config.branch}
                      onValueChange={(value) => updateAppConfig(index, { branch: value })}
                      disabled={!config.appId || loadingBranches[config.appId]}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={
                          !config.appId 
                            ? "Select app first..." 
                            : loadingBranches[config.appId]
                            ? "Loading branches..."
                            : "Choose a branch..."
                        } />
                      </SelectTrigger>
                      <SelectContent>
                        {availableBranches[config.appId]?.map((branch) => (
                          <SelectItem key={branch} value={branch}>
                            {branch}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeAppConfig(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addAppConfig}
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add App
              </Button>
            </div>
          </div>

          <div>
            <Label htmlFor="envVars">Environment Variables</Label>
            <Textarea
              id="envVars"
              {...form.register("envVars")}
              placeholder="ENV_VAR1=value1, ENV_VAR2=value2, API_KEY=secret123"
              rows={4}
            />
            <p className="text-xs text-gray-500 mt-1">
              Comma-separated key=value pairs. These will be injected into all pipeline runs.
            </p>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="submit"
              disabled={createTestCaseMutation.isPending || appConfigs.length === 0}
            >
              {createTestCaseMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : null}
              {testCase ? "Update Test Case" : "Save Test Case"}
            </Button>

            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
