import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { X, Plus, Minus } from "lucide-react";
import { z } from "zod";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

import { insertTestFlowSchema, type Application } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { gitlabApi } from "@/lib/gitlab-api";

const formSchema = insertTestFlowSchema.extend({
  name: z.string().min(1, "Flow name is required"),
  applicationId: z.number().min(1, "Application selection is required"),
  branch: z.string().min(1, "Branch selection is required"),
});

type FormData = z.infer<typeof formSchema>;

interface AddTestFlowModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface EnvVar {
  key: string;
  value: string;
}

export default function AddTestFlowModal({ open, onOpenChange }: AddTestFlowModalProps) {
  const [selectedApplicationId, setSelectedApplicationId] = useState<number | null>(null);
  const [envVars, setEnvVars] = useState<EnvVar[]>([{ key: "", value: "" }]);
  const [branches, setBranches] = useState<string[]>([]);
  const [loadingBranches, setLoadingBranches] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      applicationId: 0,
      branch: "",
      environmentVariables: {},
    },
  });

  const { data: applications = [] } = useQuery<Application[]>({
    queryKey: ["/api/applications"],
  });

  // Load branches when application is selected
  useEffect(() => {
    if (selectedApplicationId) {
      const application = applications.find(app => app.id === selectedApplicationId);
      if (application) {
        setLoadingBranches(true);
        gitlabApi.getBranches(application.projectId, application.accessToken)
          .then(gitlabBranches => {
            setBranches(gitlabBranches.map(branch => branch.name));
          })
          .catch(error => {
            console.error("Failed to load branches:", error);
            toast({
              title: "Error",
              description: "Failed to load branches from GitLab",
              variant: "destructive",
            });
          })
          .finally(() => {
            setLoadingBranches(false);
          });
      }
    } else {
      setBranches([]);
    }
  }, [selectedApplicationId, applications, toast]);

  const createTestFlowMutation = useMutation({
    mutationFn: async (data: FormData) => {
      // Convert environment variables array to object
      const environmentVariables = envVars.reduce((acc, { key, value }) => {
        if (key.trim() && value.trim()) {
          acc[key.trim()] = value.trim();
        }
        return acc;
      }, {} as Record<string, string>);

      const payload = {
        ...data,
        environmentVariables,
      };

      const response = await apiRequest("POST", "/api/test-flows", payload);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/test-flows"] });
      toast({
        title: "Success",
        description: "Test flow created successfully",
      });
      form.reset();
      setEnvVars([{ key: "", value: "" }]);
      setSelectedApplicationId(null);
      setBranches([]);
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    createTestFlowMutation.mutate(data);
  };

  const addEnvVar = () => {
    setEnvVars([...envVars, { key: "", value: "" }]);
  };

  const removeEnvVar = (index: number) => {
    if (envVars.length > 1) {
      setEnvVars(envVars.filter((_, i) => i !== index));
    }
  };

  const updateEnvVar = (index: number, field: 'key' | 'value', value: string) => {
    const newEnvVars = [...envVars];
    newEnvVars[index][field] = value;
    setEnvVars(newEnvVars);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-gitlab-surface border-gray-700 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Create Test Flow
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onOpenChange(false)}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <Label htmlFor="name">Flow Name</Label>
            <Input
              id="name"
              placeholder="Enter test flow name"
              className="bg-gitlab-card border-gray-600 focus:border-gitlab-blue"
              {...form.register("name")}
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-400 mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="application">Select Application</Label>
            <Select
              onValueChange={(value) => {
                const appId = parseInt(value);
                setSelectedApplicationId(appId);
                form.setValue("applicationId", appId);
                form.setValue("branch", ""); // Reset branch when application changes
              }}
            >
              <SelectTrigger className="bg-gitlab-card border-gray-600 focus:border-gitlab-blue">
                <SelectValue placeholder="Choose an application..." />
              </SelectTrigger>
              <SelectContent className="bg-gitlab-card border-gray-700">
                {applications.map((app) => (
                  <SelectItem key={app.id} value={app.id.toString()}>
                    {app.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.applicationId && (
              <p className="text-sm text-red-400 mt-1">{form.formState.errors.applicationId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="branch">Select Branch</Label>
            <Select
              onValueChange={(value) => form.setValue("branch", value)}
              disabled={!selectedApplicationId || loadingBranches}
            >
              <SelectTrigger className="bg-gitlab-card border-gray-600 focus:border-gitlab-blue">
                <SelectValue 
                  placeholder={
                    loadingBranches 
                      ? "Loading branches..." 
                      : selectedApplicationId 
                        ? "Choose a branch..." 
                        : "Select an application first"
                  } 
                />
              </SelectTrigger>
              <SelectContent className="bg-gitlab-card border-gray-700">
                {branches.map((branch) => (
                  <SelectItem key={branch} value={branch}>
                    {branch}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.branch && (
              <p className="text-sm text-red-400 mt-1">{form.formState.errors.branch.message}</p>
            )}
          </div>

          <div>
            <Label>Environment Variables</Label>
            <div className="space-y-2">
              {envVars.map((envVar, index) => (
                <div key={index} className="flex space-x-2">
                  <Input
                    placeholder="Key"
                    value={envVar.key}
                    onChange={(e) => updateEnvVar(index, 'key', e.target.value)}
                    className="flex-1 bg-gitlab-card border-gray-600 focus:border-gitlab-blue"
                  />
                  <Input
                    placeholder="Value"
                    value={envVar.value}
                    onChange={(e) => updateEnvVar(index, 'value', e.target.value)}
                    className="flex-1 bg-gitlab-card border-gray-600 focus:border-gitlab-blue"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeEnvVar(index)}
                    className="px-3 border-gray-600 text-red-400 hover:text-red-300"
                    disabled={envVars.length === 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addEnvVar}
              className="mt-2 text-sm border-gray-600 text-gitlab-blue hover:text-blue-400"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Environment Variable
            </Button>
          </div>

          <div>
            <Label>Pipeline Stages (Sequence)</Label>
            <div className="bg-gitlab-card rounded-lg p-4 border border-gray-600">
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <span className="w-6 h-6 bg-gitlab-blue rounded-full flex items-center justify-center text-xs font-bold">1</span>
                  <span>Build</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="w-6 h-6 bg-gitlab-blue rounded-full flex items-center justify-center text-xs font-bold">2</span>
                  <span>Test</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="w-6 h-6 bg-gitlab-blue rounded-full flex items-center justify-center text-xs font-bold">3</span>
                  <span>Deploy</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="w-6 h-6 bg-gitlab-blue rounded-full flex items-center justify-center text-xs font-bold">4</span>
                  <span>Integration Tests</span>
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">
                Stages will be executed sequentially as per your GitLab CI/CD configuration
              </p>
            </div>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              className="flex-1 border-gray-600 hover:border-gray-500"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gitlab-blue hover:bg-blue-700"
              disabled={createTestFlowMutation.isPending}
            >
              {createTestFlowMutation.isPending ? "Creating..." : "Create Test Flow"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
