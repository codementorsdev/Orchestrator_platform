interface GitLabBranch {
  name: string;
  commit: {
    id: string;
    short_id: string;
    title: string;
  };
  protected: boolean;
  default: boolean;
}

interface GitLabPipeline {
  id: number;
  status: string;
  ref: string;
  sha: string;
  web_url: string;
  created_at: string;
  updated_at: string;
}

interface GitLabJob {
  id: number;
  name: string;
  status: string;
  stage: string;
  created_at: string;
  started_at: string;
  finished_at: string;
  duration: number;
}

export class GitLabAPI {
  private baseUrl = 'https://gitlab.com/api/v4';

  async testConnection(projectId: number, accessToken: string): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/projects/${projectId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      return response.ok;
    } catch (error) {
      console.error('GitLab connection test failed:', error);
      return false;
    }
  }

  async getBranches(projectId: number, accessToken: string): Promise<GitLabBranch[]> {
    try {
      const response = await fetch(`${this.baseUrl}/projects/${projectId}/repository/branches`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch branches: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to fetch branches:', error);
      throw error;
    }
  }

  async triggerPipeline(
    projectId: number,
    ref: string,
    accessToken: string,
    variables: Record<string, string> = {}
  ): Promise<GitLabPipeline> {
    try {
      const variablesArray = Object.entries(variables).map(([key, value]) => ({
        key,
        value,
      }));

      const response = await fetch(`${this.baseUrl}/projects/${projectId}/pipeline`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ref,
          variables: variablesArray,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to trigger pipeline: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to trigger pipeline:', error);
      throw error;
    }
  }

  async getPipelineStatus(
    projectId: number,
    pipelineId: number,
    accessToken: string
  ): Promise<GitLabPipeline> {
    try {
      const response = await fetch(`${this.baseUrl}/projects/${projectId}/pipelines/${pipelineId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to get pipeline status: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get pipeline status:', error);
      throw error;
    }
  }

  async getPipelineJobs(
    projectId: number,
    pipelineId: number,
    accessToken: string
  ): Promise<GitLabJob[]> {
    try {
      const response = await fetch(`${this.baseUrl}/projects/${projectId}/pipelines/${pipelineId}/jobs`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to get pipeline jobs: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to get pipeline jobs:', error);
      throw error;
    }
  }
}

export const gitlabApi = new GitLabAPI();
