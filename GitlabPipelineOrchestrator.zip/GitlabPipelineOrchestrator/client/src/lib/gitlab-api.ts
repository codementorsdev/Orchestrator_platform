const GITLAB_API_BASE = "https://gitlab.com/api/v4";

class GitLabAPI {
  async makeRequest(endpoint: string, token: string, options: RequestInit = {}) {
    const response = await fetch(`${GITLAB_API_BASE}${endpoint}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`GitLab API Error: ${response.status} - ${errorText}`);
    }

    return response.json();
  }

  async getProject(projectId: string, token: string) {
    return this.makeRequest(`/projects/${projectId}`, token);
  }

  async getBranches(projectId: string, token: string) {
    return this.makeRequest(`/projects/${projectId}/repository/branches`, token);
  }

  async getPipelines(projectId: string, token: string, limit = 10) {
    return this.makeRequest(`/projects/${projectId}/pipelines?per_page=${limit}`, token);
  }

  async getPipeline(projectId: string, pipelineId: string, token: string) {
    const response = await fetch(`/api/gitlab/projects/${projectId}/pipelines/${pipelineId}?accessToken=${encodeURIComponent(token)}`);
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`GitLab API Error: ${response.status} - ${errorText}`);
    }
    
    return response.json();
  }

  async getPipelineJobs(projectId: string, pipelineId: string, token: string) {
    const response = await fetch(`/api/gitlab/projects/${projectId}/pipelines/${pipelineId}/jobs?accessToken=${encodeURIComponent(token)}`);
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`GitLab API Error: ${response.status} - ${errorText}`);
    }
    
    return response.json();
  }

  async triggerPipeline(
    projectId: string,
    token: string,
    branch: string,
    variables: Record<string, string> = {}
  ) {
    const gitlabVariables = Object.entries(variables).map(([key, value]) => ({
      key,
      value: String(value),
      variable_type: "env_var",
    }));

    return this.makeRequest(`/projects/${projectId}/pipeline`, token, {
      method: "POST",
      body: JSON.stringify({
        ref: branch,
        variables: gitlabVariables,
      }),
    });
  }

  async getProjectArtifacts(projectId: string, pipelineId: string, token: string) {
    return this.makeRequest(`/projects/${projectId}/pipelines/${pipelineId}/jobs`, token);
  }

  async downloadArtifact(projectId: string, jobId: string, token: string) {
    const response = await fetch(
      `/api/gitlab/projects/${projectId}/jobs/${jobId}/artifacts?accessToken=${encodeURIComponent(token)}`,
      {
        method: "GET",
      }
    );

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error("No artifacts found for this job");
      }
      throw new Error(`Failed to download artifact: ${response.status}`);
    }

    return response.blob();
  }

  async getJobsWithArtifacts(projectId: string, pipelineId: string, token: string) {
    const jobs = await this.getPipelineJobs(projectId, pipelineId, token);
    return jobs.filter((job: any) => job.artifacts && job.artifacts.length > 0);
  }
}

export const gitlabApi = new GitLabAPI();
