import type { Application, TestFlow, Execution } from "@shared/schema";

export class ClientStorage {
  private getStorageKey(key: string): string {
    return `gitlab_orchestrator_${key}`;
  }

  // Applications
  getApplications(): Application[] {
    try {
      const stored = localStorage.getItem(this.getStorageKey('applications'));
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Failed to get applications from storage:', error);
      return [];
    }
  }

  saveApplications(applications: Application[]): void {
    try {
      localStorage.setItem(this.getStorageKey('applications'), JSON.stringify(applications));
    } catch (error) {
      console.error('Failed to save applications to storage:', error);
    }
  }

  // Test Flows
  getTestFlows(): TestFlow[] {
    try {
      const stored = localStorage.getItem(this.getStorageKey('testFlows'));
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Failed to get test flows from storage:', error);
      return [];
    }
  }

  saveTestFlows(testFlows: TestFlow[]): void {
    try {
      localStorage.setItem(this.getStorageKey('testFlows'), JSON.stringify(testFlows));
    } catch (error) {
      console.error('Failed to save test flows to storage:', error);
    }
  }

  // Executions
  getExecutions(): Execution[] {
    try {
      const stored = localStorage.getItem(this.getStorageKey('executions'));
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Failed to get executions from storage:', error);
      return [];
    }
  }

  saveExecutions(executions: Execution[]): void {
    try {
      localStorage.setItem(this.getStorageKey('executions'), JSON.stringify(executions));
    } catch (error) {
      console.error('Failed to save executions to storage:', error);
    }
  }

  // Settings
  getSettings(): Record<string, any> {
    try {
      const stored = localStorage.getItem(this.getStorageKey('settings'));
      return stored ? JSON.parse(stored) : {};
    } catch (error) {
      console.error('Failed to get settings from storage:', error);
      return {};
    }
  }

  saveSettings(settings: Record<string, any>): void {
    try {
      localStorage.setItem(this.getStorageKey('settings'), JSON.stringify(settings));
    } catch (error) {
      console.error('Failed to save settings to storage:', error);
    }
  }

  // Clear all data
  clearAll(): void {
    try {
      const keys = Object.keys(localStorage).filter(key => 
        key.startsWith('gitlab_orchestrator_')
      );
      keys.forEach(key => localStorage.removeItem(key));
    } catch (error) {
      console.error('Failed to clear storage:', error);
    }
  }
}

export const clientStorage = new ClientStorage();
