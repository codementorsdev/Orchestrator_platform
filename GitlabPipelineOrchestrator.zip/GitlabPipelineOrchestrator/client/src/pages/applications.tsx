import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Edit, Trash2, Box, Server, Smartphone } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

import AddApplicationModal from "@/components/applications/add-application-modal";
import { apiRequest } from "@/lib/queryClient";
import type { Application } from "@shared/schema";

export default function Applications() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: applications = [], isLoading } = useQuery<Application[]>({
    queryKey: ["/api/applications"],
  });

  const deleteApplicationMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/applications/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Success",
        description: "Application deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete application",
        variant: "destructive",
      });
    },
  });

  const getAppIcon = (name: string) => {
    const lowerName = name.toLowerCase();
    if (lowerName.includes("frontend") || lowerName.includes("web")) {
      return <Box className="text-white text-sm" />;
    } else if (lowerName.includes("api") || lowerName.includes("backend") || lowerName.includes("service")) {
      return <Server className="text-white text-sm" />;
    } else if (lowerName.includes("mobile") || lowerName.includes("app")) {
      return <Smartphone className="text-white text-sm" />;
    }
    return <Box className="text-white text-sm" />;
  };

  const getAppColor = (name: string) => {
    const lowerName = name.toLowerCase();
    if (lowerName.includes("frontend") || lowerName.includes("web")) {
      return "bg-gitlab-blue";
    } else if (lowerName.includes("api") || lowerName.includes("backend") || lowerName.includes("service")) {
      return "bg-green-500";
    } else if (lowerName.includes("mobile") || lowerName.includes("app")) {
      return "bg-purple-500";
    }
    return "bg-gitlab-blue";
  };

  const handleDelete = (id: number, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteApplicationMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6 overflow-auto">
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-400">Loading applications...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Applications</h2>
          <p className="text-gray-400">Manage your registered GitLab applications</p>
        </div>
        <Button 
          onClick={() => setIsAddModalOpen(true)} 
          className="bg-gitlab-blue hover:bg-blue-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Application
        </Button>
      </div>

      {applications.length === 0 ? (
        <Card className="bg-gitlab-surface border-gray-700">
          <CardContent className="p-12 text-center">
            <Box className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Applications Yet</h3>
            <p className="text-gray-400 mb-4">
              Get started by adding your first GitLab application
            </p>
            <Button 
              onClick={() => setIsAddModalOpen(true)} 
              className="bg-gitlab-blue hover:bg-blue-700"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Your First Application
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-gitlab-surface border-gray-700">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gitlab-card border-b border-gray-700">
                <tr>
                  <th className="text-left p-4 font-medium text-gray-300">Name</th>
                  <th className="text-left p-4 font-medium text-gray-300">Project ID</th>
                  <th className="text-left p-4 font-medium text-gray-300">Status</th>
                  <th className="text-left p-4 font-medium text-gray-300">Created</th>
                  <th className="text-left p-4 font-medium text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody>
                {applications.map((app) => (
                  <tr key={app.id} className="border-b border-gray-700 hover:bg-gitlab-card transition-colors">
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 ${getAppColor(app.name)} rounded-lg flex items-center justify-center`}>
                          {getAppIcon(app.name)}
                        </div>
                        <div>
                          <p className="font-medium">{app.name}</p>
                          {app.description && (
                            <p className="text-sm text-gray-400">{app.description}</p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="p-4 font-mono text-sm">{app.projectId}</td>
                    <td className="p-4">
                      <Badge 
                        variant="outline" 
                        className={app.status === "active" 
                          ? "bg-green-500 bg-opacity-20 text-green-400 border-green-500" 
                          : "bg-yellow-500 bg-opacity-20 text-yellow-400 border-yellow-500"
                        }
                      >
                        {app.status}
                      </Badge>
                    </td>
                    <td className="p-4 text-sm text-gray-400">
                      {app.createdAt ? new Date(app.createdAt).toLocaleDateString() : "Unknown"}
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-white"
                          onClick={() => {
                            // TODO: Implement edit functionality
                            toast({
                              title: "Coming Soon",
                              description: "Edit functionality will be implemented soon",
                            });
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-red-400"
                          onClick={() => handleDelete(app.id, app.name)}
                          disabled={deleteApplicationMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <AddApplicationModal 
        open={isAddModalOpen} 
        onOpenChange={setIsAddModalOpen} 
      />
    </div>
  );
}
