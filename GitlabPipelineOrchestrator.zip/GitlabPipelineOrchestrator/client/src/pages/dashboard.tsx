import { useQuery } from "@tanstack/react-query";
import { ChartPie, Box, PlayCircle, CheckCircle, Plus, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Application, TestFlow, Execution } from "@shared/schema";

export default function Dashboard() {
  const { data: applications = [] } = useQuery<Application[]>({
    queryKey: ["/api/applications"],
  });

  const { data: testFlows = [] } = useQuery<TestFlow[]>({
    queryKey: ["/api/test-flows"],
  });

  const { data: executions = [] } = useQuery<Execution[]>({
    queryKey: ["/api/executions"],
  });

  const { data: activeExecutions = [] } = useQuery<Execution[]>({
    queryKey: ["/api/executions/active"],
    refetchInterval: 5000, // Poll every 5 seconds
  });

  // Calculate metrics
  const totalApplications = applications.length;
  const activePipelines = activeExecutions.length;
  const totalExecutions = executions.length;
  
  const successfulExecutions = executions.filter(exec => exec.status === "success").length;
  const successRate = totalExecutions > 0 ? ((successfulExecutions / totalExecutions) * 100).toFixed(1) : "0.0";

  const recentExecutions = executions.slice(0, 5);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-3 w-3 text-green-400" />;
      case "running":
        return <PlayCircle className="h-3 w-3 text-orange-400" />;
      case "pending":
        return <Clock className="h-3 w-3 text-blue-400" />;
      default:
        return <Plus className="h-3 w-3 text-purple-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-500 bg-opacity-20 text-green-400";
      case "running":
        return "bg-orange-500 bg-opacity-20 text-orange-400";
      case "failed":
        return "bg-red-500 bg-opacity-20 text-red-400";
      case "pending":
        return "bg-blue-500 bg-opacity-20 text-blue-400";
      default:
        return "bg-gray-500 bg-opacity-20 text-gray-400";
    }
  };

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-2">Dashboard</h2>
        <p className="text-gray-400">Overview of your pipeline orchestration metrics</p>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gitlab-surface border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Applications</p>
                <p className="text-2xl font-semibold">{totalApplications}</p>
              </div>
              <div className="w-12 h-12 bg-gitlab-blue bg-opacity-20 rounded-lg flex items-center justify-center">
                <Box className="text-gitlab-blue text-xl" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-green-400">Active</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gitlab-surface border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Active Pipelines</p>
                <p className="text-2xl font-semibold">{activePipelines}</p>
              </div>
              <div className="w-12 h-12 bg-orange-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                <PlayCircle className="text-orange-500 text-xl" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-orange-400">Running</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gitlab-surface border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Success Rate</p>
                <p className="text-2xl font-semibold">{successRate}%</p>
              </div>
              <div className="w-12 h-12 bg-green-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                <CheckCircle className="text-green-500 text-xl" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-green-400">Overall</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gitlab-surface border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Executions</p>
                <p className="text-2xl font-semibold">{totalExecutions}</p>
              </div>
              <div className="w-12 h-12 bg-purple-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                <ChartPie className="text-purple-500 text-xl" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-purple-400">All time</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Placeholder - Would use recharts or chart.js in full implementation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="bg-gitlab-surface border-gray-700">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Pipeline Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 flex items-center justify-center text-gray-400">
              Chart implementation would go here using Recharts
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gitlab-surface border-gray-700">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Application Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 flex items-center justify-center text-gray-400">
              Chart implementation would go here using Recharts
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="bg-gitlab-surface border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {recentExecutions.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <ChartPie className="mx-auto h-12 w-12 mb-4 opacity-50" />
              <p>No recent executions</p>
              <p className="text-sm">Start by creating applications and test flows</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentExecutions.map((execution) => {
                const testFlow = testFlows.find(tf => tf.id === execution.testFlowId);
                const application = applications.find(app => app.id === testFlow?.applicationId);
                
                return (
                  <div key={execution.id} className="flex items-center space-x-3 p-3 bg-gitlab-card rounded-lg">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getStatusColor(execution.status)}`}>
                      {getStatusIcon(execution.status)}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">
                        {execution.status === "success" ? "Pipeline completed successfully" : 
                         execution.status === "running" ? "Pipeline started" : 
                         execution.status === "failed" ? "Pipeline failed" : "Pipeline queued"}
                      </p>
                      <p className="text-sm text-gray-400">
                        {testFlow?.name || "Unknown flow"} • {application?.name || "Unknown app"} • {
                          execution.startedAt ? new Date(execution.startedAt).toLocaleString() : "Unknown time"
                        }
                      </p>
                    </div>
                    <Badge variant="outline" className={getStatusColor(execution.status)}>
                      {execution.status}
                    </Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
