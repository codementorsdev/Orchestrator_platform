import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RefreshCw, Download, Eye, Play } from "lucide-react";
import { PipelineMonitor } from "@/components/pipeline-monitor";
import { useState } from "react";
import { format } from "date-fns";
import { gitlabApi } from "@/lib/gitlab-api";
import { useToast } from "@/hooks/use-toast";
import type { ExecutionWithDetails } from "@shared/schema";

export default function Executions() {
  const [filter, setFilter] = useState<string>("all");
  const { toast } = useToast();

  const { data: executions = [], isLoading, refetch } = useQuery<ExecutionWithDetails[]>({
    queryKey: ["/api/executions"],
    refetchInterval: 5000, // Poll every 5 seconds for real-time updates
  });

  const filteredExecutions = executions.filter((execution) => {
    if (filter === "all") return true;
    return execution.status === filter;
  });

  const runningExecutions = executions.filter((execution) => execution.status === "running");

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "running":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return "N/A";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  const downloadArtifacts = async (pipelineRun: any) => {
    if (!pipelineRun.pipelineId) {
      toast({
        title: "Error",
        description: "No pipeline ID available for this run",
        variant: "destructive",
      });
      return;
    }

    try {
      const jobs = await gitlabApi.getPipelineJobs(
        pipelineRun.app.projectId,
        pipelineRun.pipelineId,
        pipelineRun.app.accessToken
      );

      const jobsWithArtifacts = jobs.filter((job: any) => job.artifacts && job.artifacts.length > 0);

      if (jobsWithArtifacts.length === 0) {
        toast({
          title: "No Artifacts",
          description: "No artifacts found for this pipeline",
          variant: "destructive",
        });
        return;
      }

      // Download artifacts from the first job with artifacts
      const job = jobsWithArtifacts[0];
      const blob = await gitlabApi.downloadArtifact(
        pipelineRun.app.projectId,
        job.id,
        pipelineRun.app.accessToken
      );

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${pipelineRun.app.name}-${pipelineRun.branch}-artifacts.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Success",
        description: "Artifacts downloaded successfully",
      });
    } catch (error: any) {
      console.error("Failed to download artifacts:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to download artifacts",
        variant: "destructive",
      });
    }
  };

  const downloadAllArtifacts = async (execution: ExecutionWithDetails) => {
    try {
      for (const pipelineRun of execution.pipelineRuns) {
        if (pipelineRun.pipelineId && pipelineRun.status === 'success') {
          await downloadArtifacts(pipelineRun);
          // Add a small delay between downloads
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
    } catch (error) {
      console.error("Failed to download all artifacts:", error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Pipeline Executions</h1>
          <p className="text-gray-600">Monitor real-time pipeline execution status</p>
        </div>
        <div className="flex space-x-3">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter executions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Executions</SelectItem>
              <SelectItem value="running">Running</SelectItem>
              <SelectItem value="success">Success</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Real-time Execution Monitor */}
      {runningExecutions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Play className="h-5 w-5 text-blue-600" />
              Live Executions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {runningExecutions.map((execution) => (
                <PipelineMonitor key={execution.id} execution={execution} />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Execution History */}
      <Card>
        <CardHeader>
          <CardTitle>Execution History</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : filteredExecutions.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Play className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No executions found</p>
              <p className="text-sm">
                {filter === "all" 
                  ? "Execute a test case to see pipeline results here"
                  : `No executions with status "${filter}"`
                }
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredExecutions.map((execution) => (
                <Card key={execution.id} className="border">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="text-lg font-medium text-gray-900">
                          {execution.testCase.name}
                        </h4>
                        <p className="text-sm text-gray-500">
                          {execution.startedAt
                            ? `Started ${format(new Date(execution.startedAt), "MMM d, yyyy 'at' h:mm a")}`
                            : "Not started yet"}
                        </p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge className={getStatusColor(execution.status)}>
                          {execution.status}
                        </Badge>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => downloadAllArtifacts(execution)}
                          disabled={execution.status !== 'success' || execution.pipelineRuns.length === 0}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download All
                        </Button>
                      </div>
                    </div>

                    {/* Pipeline Details */}
                    <div className="space-y-4">
                      {execution.pipelineRuns.map((pipelineRun) => (
                        <div
                          key={pipelineRun.id}
                          className="border border-gray-200 rounded-lg p-4"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <h5 className="font-medium text-gray-900">
                              {pipelineRun.app.name}
                            </h5>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-gray-500">{pipelineRun.branch}</span>
                              <Badge className={getStatusColor(pipelineRun.status)}>
                                {pipelineRun.status}
                              </Badge>
                            </div>
                          </div>

                          {/* Pipeline Stages */}
                          {pipelineRun.stages && (
                            <div className="flex items-center space-x-2 mb-3">
                              {(pipelineRun.stages as any[]).map((stage, index) => {
                                const getStageColor = (status: string) => {
                                  switch (status) {
                                    case "success":
                                      return "bg-green-500";
                                    case "failed":
                                      return "bg-red-500";
                                    case "running":
                                      return "bg-blue-500";
                                    default:
                                      return "bg-gray-300";
                                  }
                                };

                                return (
                                  <div key={index} className="flex-1">
                                    <div className="flex items-center justify-between mb-1">
                                      <span className="text-xs font-medium text-gray-600">
                                        {stage.name}
                                      </span>
                                      <span className="text-xs text-gray-500">
                                        {stage.duration || "0s"}
                                      </span>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-2">
                                      <div
                                        className={`h-2 rounded-full ${getStageColor(stage.status)}`}
                                        style={{
                                          width: stage.status === "success" ? "100%" : 
                                                 stage.status === "running" ? "60%" : "0%"
                                        }}
                                      ></div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}

                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-500">
                              Duration: {formatDuration(pipelineRun.duration)}
                            </span>
                            <div className="flex space-x-2">
                              <Button variant="ghost" size="sm">
                                <Eye className="h-4 w-4 mr-1" />
                                View Details
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => downloadArtifacts(pipelineRun)}
                                disabled={pipelineRun.status !== 'success' || !pipelineRun.pipelineId}
                              >
                                <Download className="h-4 w-4 mr-1" />
                                Download
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {execution.pipelineRuns.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        <p>No pipeline runs found for this execution</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
