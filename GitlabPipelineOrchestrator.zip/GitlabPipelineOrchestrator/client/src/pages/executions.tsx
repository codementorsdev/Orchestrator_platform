import { useQuery } from "@tanstack/react-query";
import { RefreshCw, ExternalLink, CheckCircle, XCircle, Clock, Play, Activity } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { usePolling } from "@/hooks/use-polling";

import type { Execution, TestFlow, Application } from "@shared/schema";

export default function Executions() {
  const { data: executions = [], refetch: refetchExecutions } = useQuery<Execution[]>({
    queryKey: ["/api/executions"],
  });

  const { data: activeExecutions = [], refetch: refetchActiveExecutions } = useQuery<Execution[]>({
    queryKey: ["/api/executions/active"],
  });

  const { data: testFlows = [] } = useQuery<TestFlow[]>({
    queryKey: ["/api/test-flows"],
  });

  const { data: applications = [] } = useQuery<Application[]>({
    queryKey: ["/api/applications"],
  });

  // Poll active executions every 5 seconds
  usePolling(
    async () => {
      if (activeExecutions.length > 0) {
        await refetchActiveExecutions();
      }
    },
    { interval: 5000, enabled: activeExecutions.length > 0 }
  );

  const recentExecutions = executions.slice(0, 10);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-400" />;
      case "running":
        return <Play className="h-4 w-4 text-orange-400" />;
      case "pending":
        return <Clock className="h-4 w-4 text-blue-400" />;
      default:
        return <Activity className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-500 bg-opacity-20 text-green-400 border-green-500";
      case "failed":
        return "bg-red-500 bg-opacity-20 text-red-400 border-red-500";
      case "running":
        return "bg-orange-500 bg-opacity-20 text-orange-400 border-orange-500";
      case "pending":
        return "bg-blue-500 bg-opacity-20 text-blue-400 border-blue-500";
      default:
        return "bg-gray-500 bg-opacity-20 text-gray-400 border-gray-500";
    }
  };

  const getExecutionDetails = (execution: Execution) => {
    const testFlow = testFlows.find(tf => tf.id === execution.testFlowId);
    const application = applications.find(app => app.id === testFlow?.applicationId);
    return { testFlow, application };
  };

  const getProgressPercentage = (stages: Array<{ name: string; status: string; duration?: number }>) => {
    if (!stages || stages.length === 0) return 0;
    const completedStages = stages.filter(stage => ['success', 'failed'].includes(stage.status)).length;
    return (completedStages / stages.length) * 100;
  };

  const formatDuration = (duration?: number) => {
    if (!duration) return "N/A";
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    return `${minutes}m ${seconds}s`;
  };

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Pipeline Executions</h2>
          <p className="text-gray-400">Real-time monitoring of your pipeline executions</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-gitlab-surface px-3 py-2 rounded-lg border border-gray-700">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm">Auto-refresh: ON</span>
          </div>
          <Button 
            onClick={() => {
              refetchExecutions();
              refetchActiveExecutions();
            }}
            className="bg-gitlab-blue hover:bg-blue-700"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Active Executions */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Play className="text-orange-500 mr-2" />
          Active Executions
        </h3>
        
        {activeExecutions.length === 0 ? (
          <Card className="bg-gitlab-surface border-gray-700">
            <CardContent className="p-8 text-center">
              <Activity className="mx-auto h-8 w-8 text-gray-400 mb-4 opacity-50" />
              <p className="text-gray-400">No active executions</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {activeExecutions.map((execution) => {
              const { testFlow, application } = getExecutionDetails(execution);
              const progress = getProgressPercentage(execution.stages || []);
              
              return (
                <Card key={execution.id} className="bg-gitlab-surface border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusColor(execution.status)}`}>
                          {getStatusIcon(execution.status)}
                        </div>
                        <div>
                          <h4 className="font-semibold">{testFlow?.name || "Unknown Test Flow"}</h4>
                          <p className="text-sm text-gray-400">
                            {application?.name || "Unknown App"} • {testFlow?.branch || "Unknown branch"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge variant="outline" className={getStatusColor(execution.status)}>
                          {execution.status}
                        </Badge>
                        <span className="text-sm text-gray-400">
                          Started {execution.startedAt ? new Date(execution.startedAt).toLocaleTimeString() : "Unknown time"}
                        </span>
                      </div>
                    </div>
                    
                    {/* Progress */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-400">Progress</span>
                        <span className="text-sm text-gray-400">{Math.round(progress)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>

                    {/* Stages */}
                    {execution.stages && execution.stages.length > 0 && (
                      <div className="space-y-3">
                        {execution.stages.map((stage, index) => (
                          <div key={index} className="flex items-center space-x-3">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${getStatusColor(stage.status)}`}>
                              {getStatusIcon(stage.status)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{stage.name}</span>
                                <span className={`text-sm ${getStatusColor(stage.status).split(' ')[2]}`}>
                                  {stage.status === "success" ? `✓ Completed (${formatDuration(stage.duration)})` :
                                   stage.status === "running" ? "⏳ Running..." :
                                   stage.status === "failed" ? "✗ Failed" : "⏸️ Pending"}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Recent Executions */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Activity className="text-gray-400 mr-2" />
          Recent Executions
        </h3>
        
        {recentExecutions.length === 0 ? (
          <Card className="bg-gitlab-surface border-gray-700">
            <CardContent className="p-8 text-center">
              <Activity className="mx-auto h-8 w-8 text-gray-400 mb-4 opacity-50" />
              <p className="text-gray-400">No executions yet</p>
              <p className="text-sm text-gray-500 mt-2">Start by running some test flows</p>
            </CardContent>
          </Card>
        ) : (
          <Card className="bg-gitlab-surface border-gray-700">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gitlab-card border-b border-gray-700">
                  <tr>
                    <th className="text-left p-4 font-medium text-gray-300">Flow Name</th>
                    <th className="text-left p-4 font-medium text-gray-300">Application</th>
                    <th className="text-left p-4 font-medium text-gray-300">Branch</th>
                    <th className="text-left p-4 font-medium text-gray-300">Status</th>
                    <th className="text-left p-4 font-medium text-gray-300">Duration</th>
                    <th className="text-left p-4 font-medium text-gray-300">Started</th>
                    <th className="text-left p-4 font-medium text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {recentExecutions.map((execution) => {
                    const { testFlow, application } = getExecutionDetails(execution);
                    
                    return (
                      <tr key={execution.id} className="border-b border-gray-700 hover:bg-gitlab-card transition-colors">
                        <td className="p-4 font-medium">{testFlow?.name || "Unknown Flow"}</td>
                        <td className="p-4 text-gray-400">{application?.name || "Unknown App"}</td>
                        <td className="p-4 font-mono text-sm">{testFlow?.branch || "Unknown"}</td>
                        <td className="p-4">
                          <Badge variant="outline" className={getStatusColor(execution.status)}>
                            {execution.status}
                          </Badge>
                        </td>
                        <td className="p-4 text-sm">{formatDuration(execution.duration)}</td>
                        <td className="p-4 text-sm text-gray-400">
                          {execution.startedAt ? new Date(execution.startedAt).toLocaleString() : "Unknown"}
                        </td>
                        <td className="p-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-gray-400 hover:text-white"
                            onClick={() => {
                              if (execution.pipelineId && application) {
                                window.open(`https://gitlab.com/${application.projectId}/-/pipelines/${execution.pipelineId}`, '_blank');
                              }
                            }}
                            disabled={!execution.pipelineId}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
