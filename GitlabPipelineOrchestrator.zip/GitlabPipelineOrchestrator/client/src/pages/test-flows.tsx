import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Edit, Trash2, Play, History, PlayCircle, Box, Server, Smartphone } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

import AddTestFlowModal from "@/components/test-flows/add-test-flow-modal";
import { apiRequest } from "@/lib/queryClient";
import { gitlabApi } from "@/lib/gitlab-api";
import type { TestFlow, Application } from "@shared/schema";

export default function TestFlows() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: testFlows = [], isLoading } = useQuery<TestFlow[]>({
    queryKey: ["/api/test-flows"],
  });

  const { data: applications = [] } = useQuery<Application[]>({
    queryKey: ["/api/applications"],
  });

  const runTestFlowMutation = useMutation({
    mutationFn: async (testFlow: TestFlow) => {
      const application = applications.find(app => app.id === testFlow.applicationId);
      if (!application) {
        throw new Error("Application not found");
      }

      // Trigger GitLab pipeline
      const pipeline = await gitlabApi.triggerPipeline(
        application.projectId,
        testFlow.branch,
        application.accessToken,
        testFlow.environmentVariables || {}
      );

      // Create execution record
      const executionResponse = await apiRequest("POST", "/api/executions", {
        testFlowId: testFlow.id,
        pipelineId: pipeline.id,
        status: "running",
        stages: [],
      });

      return executionResponse.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/executions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/executions/active"] });
      toast({
        title: "Success",
        description: "Test flow started successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTestFlowMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/test-flows/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/test-flows"] });
      toast({
        title: "Success",
        description: "Test flow deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete test flow",
        variant: "destructive",
      });
    },
  });

  const getAppIcon = (name: string) => {
    const lowerName = name.toLowerCase();
    if (lowerName.includes("frontend") || lowerName.includes("web")) {
      return <Box className="text-white" />;
    } else if (lowerName.includes("api") || lowerName.includes("backend") || lowerName.includes("service")) {
      return <Server className="text-white" />;
    } else if (lowerName.includes("mobile") || lowerName.includes("app")) {
      return <Smartphone className="text-white" />;
    }
    return <Box className="text-white" />;
  };

  const getAppColor = (name: string) => {
    const lowerName = name.toLowerCase();
    if (lowerName.includes("frontend") || lowerName.includes("web")) {
      return "bg-gitlab-blue";
    } else if (lowerName.includes("api") || lowerName.includes("backend") || lowerName.includes("service")) {
      return "bg-green-500";
    } else if (lowerName.includes("mobile") || lowerName.includes("app")) {
      return "bg-purple-500";
    }
    return "bg-gitlab-blue";
  };

  const handleRunTestFlow = (testFlow: TestFlow) => {
    runTestFlowMutation.mutate(testFlow);
  };

  const handleDelete = (id: number, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteTestFlowMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6 overflow-auto">
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-400">Loading test flows...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Test Flows</h2>
          <p className="text-gray-400">Create and manage your pipeline test flows</p>
        </div>
        <Button 
          onClick={() => setIsAddModalOpen(true)} 
          className="bg-gitlab-blue hover:bg-blue-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Test Flow
        </Button>
      </div>

      {testFlows.length === 0 ? (
        <Card className="bg-gitlab-surface border-gray-700">
          <CardContent className="p-12 text-center">
            <PlayCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Test Flows Yet</h3>
            <p className="text-gray-400 mb-4">
              Create your first test flow to start orchestrating pipelines
            </p>
            <Button 
              onClick={() => setIsAddModalOpen(true)} 
              className="bg-gitlab-blue hover:bg-blue-700"
            >
              <Plus className="mr-2 h-4 w-4" />
              Create Your First Test Flow
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testFlows.map((testFlow) => {
            const application = applications.find(app => app.id === testFlow.applicationId);
            const envVarCount = Object.keys(testFlow.environmentVariables || {}).length;

            return (
              <Card key={testFlow.id} className="bg-gitlab-surface border-gray-700 hover:border-gitlab-blue transition-colors">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 ${application ? getAppColor(application.name) : 'bg-gitlab-blue'} rounded-lg flex items-center justify-center`}>
                        {application ? getAppIcon(application.name) : <PlayCircle className="text-white" />}
                      </div>
                      <div>
                        <CardTitle className="text-base">{testFlow.name}</CardTitle>
                        <p className="text-sm text-gray-400">{application?.name || "Unknown App"}</p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-gray-400 hover:text-white p-1"
                        onClick={() => {
                          toast({
                            title: "Coming Soon",
                            description: "Edit functionality will be implemented soon",
                          });
                        }}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-gray-400 hover:text-red-400 p-1"
                        onClick={() => handleDelete(testFlow.id, testFlow.name)}
                        disabled={deleteTestFlowMutation.isPending}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Branch:</span>
                      <Badge variant="outline" className="font-mono text-xs">
                        {testFlow.branch}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Environment Variables:</span>
                      <span>{envVarCount} vars</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Created:</span>
                      <span>{testFlow.createdAt ? new Date(testFlow.createdAt).toLocaleDateString() : "Unknown"}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      className="flex-1 bg-gitlab-blue hover:bg-blue-700 text-sm"
                      onClick={() => handleRunTestFlow(testFlow)}
                      disabled={runTestFlowMutation.isPending || !application}
                    >
                      <Play className="mr-2 h-3 w-3" />
                      {runTestFlowMutation.isPending ? "Starting..." : "Run Flow"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-gray-600 hover:border-gray-500"
                      onClick={() => {
                        toast({
                          title: "Coming Soon",
                          description: "Execution history will be implemented soon",
                        });
                      }}
                    >
                      <History className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <AddTestFlowModal 
        open={isAddModalOpen} 
        onOpenChange={setIsAddModalOpen} 
      />
    </div>
  );
}
