import { storage } from "./storage";
import type { TestCaseWithApps, Execution, PipelineRun } from "@shared/schema";

interface PipelineExecutionContext {
  execution: Execution;
  testCase: TestCaseWithApps;
  envVars: Record<string, string>;
}

class PipelineExecutionService {
  private activeExecutions = new Map<number, boolean>();
  private pollingIntervals = new Map<number, NodeJS.Timeout>();

  async executeTestCase(testCase: TestCaseWithApps): Promise<Execution> {
    // Parse environment variables
    const envVars: Record<string, string> = {};
    if (testCase.envVars) {
      testCase.envVars.split(",").forEach((pair) => {
        const [key, value] = pair.split("=").map((s) => s.trim());
        if (key && value) {
          envVars[key] = value;
        }
      });
    }

    // Create execution record
    const execution = await storage.createExecution({
      testCaseId: testCase.id,
      status: "running",
      startedAt: new Date().toISOString(),
    });

    this.activeExecutions.set(execution.id, true);

    // Execute pipelines sequentially in background
    this.executeSequentially({
      execution,
      testCase,
      envVars,
    }).catch((error) => {
      console.error(`Execution ${execution.id} failed:`, error);
      this.handleExecutionFailure(execution.id, error);
    });

    return execution;
  }

  private async executeSequentially(context: PipelineExecutionContext): Promise<void> {
    const { execution, testCase, envVars } = context;
    
    try {
      const pipelineRuns: PipelineRun[] = [];

      // Execute each app's pipeline sequentially
      for (let i = 0; i < testCase.testCaseApps.length; i++) {
        const appConfig = testCase.testCaseApps[i];
        
        if (!this.activeExecutions.get(execution.id)) {
          console.log(`Execution ${execution.id} was cancelled`);
          return;
        }

        console.log(`Starting pipeline for ${appConfig.app.name} (${appConfig.branch})`);

        // Create pipeline run record
        const pipelineRun = await storage.createPipelineRun({
          executionId: execution.id,
          appId: appConfig.appId,
          branch: appConfig.branch,
          status: "pending",
          order: i,
        });

        try {
          // Trigger pipeline via GitLab API
          const gitlabVariables = Object.entries(envVars).map(([key, value]) => ({
            key,
            value: String(value),
            variable_type: "env_var",
          }));

          const response = await fetch(`https://gitlab.com/api/v4/projects/${appConfig.app.projectId}/pipeline`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${appConfig.app.accessToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              ref: appConfig.branch,
              variables: gitlabVariables,
            }),
          });

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`GitLab API error: ${response.status} - ${errorText}`);
          }

          const pipeline = await response.json();

          // Update pipeline run with GitLab pipeline ID
          await storage.updatePipelineRun(pipelineRun.id, {
            pipelineId: pipeline.id.toString(),
            status: "running",
            startedAt: new Date().toISOString(),
          });

          console.log(`Pipeline ${pipeline.id} started for ${appConfig.app.name}`);

          // Wait for this pipeline to complete before starting the next one
          await this.waitForPipelineCompletion(pipelineRun.id, appConfig.app.projectId, pipeline.id, appConfig.app.accessToken);

          pipelineRuns.push(pipelineRun);

        } catch (error) {
          console.error(`Failed to start pipeline for ${appConfig.app.name}:`, error);
          
          await storage.updatePipelineRun(pipelineRun.id, {
            status: "failed",
            completedAt: new Date().toISOString(),
          });

          // Mark execution as failed
          await storage.updateExecution(execution.id, {
            status: "failed",
            completedAt: new Date().toISOString(),
          });

          throw error;
        }
      }

      // All pipelines completed successfully
      await storage.updateExecution(execution.id, {
        status: "success",
        completedAt: new Date().toISOString(),
        duration: Math.floor((Date.now() - new Date(execution.startedAt!).getTime()) / 1000),
      });

      console.log(`Execution ${execution.id} completed successfully`);

    } catch (error) {
      console.error(`Execution ${execution.id} failed:`, error);
      await this.handleExecutionFailure(execution.id, error);
    } finally {
      this.activeExecutions.delete(execution.id);
    }
  }

  private async waitForPipelineCompletion(
    pipelineRunId: number,
    projectId: string,
    pipelineId: string,
    accessToken: string
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const pollInterval = setInterval(async () => {
        // Store the interval for potential cleanup
        this.pollingIntervals.set(pipelineRunId, pollInterval);
        try {
          // Get pipeline status from GitLab
          const response = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}`, {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
            },
          });

          if (!response.ok) {
            throw new Error(`Failed to get pipeline status: ${response.status}`);
          }

          const pipeline = await response.json();
          
          // Get pipeline jobs for stage information
          const jobsResponse = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}/jobs`, {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
            },
          });

          let stages = null;
          if (jobsResponse.ok) {
            const jobs = await jobsResponse.json();
            stages = this.processStagesFromJobs(jobs);
          }

          // Update pipeline run with current status
          await storage.updatePipelineRun(pipelineRunId, {
            status: pipeline.status,
            stages: stages,
            duration: pipeline.duration || null,
          });

          console.log(`Pipeline ${pipelineId} status: ${pipeline.status}`);

          // Check if pipeline is complete
          if (pipeline.status === 'success' || pipeline.status === 'failed' || pipeline.status === 'canceled') {
            clearInterval(pollInterval);
            this.pollingIntervals.delete(pipelineRunId);
            
            await storage.updatePipelineRun(pipelineRunId, {
              status: pipeline.status,
              completedAt: new Date().toISOString(),
              duration: pipeline.duration || null,
              stages: stages,
            });

            if (pipeline.status === 'success') {
              resolve();
            } else {
              reject(new Error(`Pipeline ${pipelineId} ${pipeline.status}`));
            }
          }

        } catch (error) {
          console.error(`Error polling pipeline ${pipelineId}:`, error);
          clearInterval(pollInterval);
          this.pollingIntervals.delete(pipelineRunId);
          reject(error);
        }
      }, 5000); // Poll every 5 seconds

      // Set timeout for very long-running pipelines (30 minutes)
      setTimeout(() => {
        clearInterval(pollInterval);
        this.pollingIntervals.delete(pipelineRunId);
        reject(new Error(`Pipeline ${pipelineId} timed out after 30 minutes`));
      }, 30 * 60 * 1000);
    });
  }

  private processStagesFromJobs(jobs: any[]): any[] {
    const stageMap = new Map<string, any>();

    jobs.forEach((job: any) => {
      const stageName = job.stage;
      
      if (!stageMap.has(stageName)) {
        stageMap.set(stageName, {
          name: stageName,
          status: job.status,
          jobs: [job],
          duration: job.duration || 0,
        });
      } else {
        const stage = stageMap.get(stageName)!;
        stage.jobs.push(job);
        
        // Update stage status based on worst job status
        if (job.status === 'failed') {
          stage.status = 'failed';
        } else if (job.status === 'running' && stage.status !== 'failed') {
          stage.status = 'running';
        } else if (job.status === 'success' && stage.status === 'pending') {
          stage.status = 'success';
        }
        
        // Update duration
        if (job.duration) {
          stage.duration = Math.max(stage.duration, job.duration);
        }
      }
    });

    return Array.from(stageMap.values());
  }

  private async handleExecutionFailure(executionId: number, error: any): Promise<void> {
    try {
      await storage.updateExecution(executionId, {
        status: "failed",
        completedAt: new Date().toISOString(),
      });
    } catch (updateError) {
      console.error(`Failed to update execution ${executionId} status:`, updateError);
    }
    
    this.activeExecutions.delete(executionId);
  }

  cancelExecution(executionId: number): void {
    this.activeExecutions.delete(executionId);
    
    const interval = this.pollingIntervals.get(executionId);
    if (interval) {
      clearInterval(interval);
      this.pollingIntervals.delete(executionId);
    }
  }

  isExecutionActive(executionId: number): boolean {
    return this.activeExecutions.has(executionId);
  }
}

export const pipelineService = new PipelineExecutionService();

// Simple execution function for immediate use
export async function executeTestCaseSimple(testCase: TestCaseWithApps): Promise<any> {
  // Parse environment variables
  const envVars: Record<string, string> = {};
  if (testCase.envVars) {
    testCase.envVars.split(",").forEach((pair) => {
      const [key, value] = pair.split("=").map((s) => s.trim());
      if (key && value) {
        envVars[key] = value;
      }
    });
  }

  // Create execution record
  const execution = await storage.createExecution({
    testCaseId: testCase.id,
    status: "running",
    startedAt: new Date().toISOString(),
  });

  // Execute pipelines sequentially
  for (let i = 0; i < testCase.testCaseApps.length; i++) {
    const appConfig = testCase.testCaseApps[i];
    
    // Create pipeline run record
    const pipelineRun = await storage.createPipelineRun({
      executionId: execution.id,
      appId: appConfig.appId,
      branch: appConfig.branch,
      status: "running",
      order: i,
    });

    try {
      // Trigger pipeline via GitLab API
      const gitlabVariables = Object.entries(envVars).map(([key, value]) => ({
        key,
        value: String(value),
        variable_type: "env_var",
      }));

      const response = await fetch(`https://gitlab.com/api/v4/projects/${appConfig.app.projectId}/pipeline`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${appConfig.app.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ref: appConfig.branch,
          variables: gitlabVariables,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`GitLab API error: ${response.status} - ${errorText}`);
      }

      const pipeline = await response.json();

      // Update pipeline run with GitLab pipeline ID
      await storage.updatePipelineRun(pipelineRun.id, {
        pipelineId: pipeline.id.toString(),
        status: "running",
        startedAt: new Date().toISOString(),
      });

      console.log(`Pipeline ${pipeline.id} started for ${appConfig.app.name}`);

    } catch (error) {
      console.error(`Failed to start pipeline for ${appConfig.app.name}:`, error);
      
      await storage.updatePipelineRun(pipelineRun.id, {
        status: "failed",
        completedAt: new Date().toISOString(),
      });

      throw error;
    }
  }

  // Mark execution as completed
  await storage.updateExecution(execution.id, {
    status: "success",
    completedAt: new Date().toISOString(),
  });

  return execution;
}