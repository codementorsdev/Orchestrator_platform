import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { executeTestCaseSimple } from "./pipeline-service";
import { insertAppSchema, insertTestCaseSchema, insertExecutionSchema } from "@shared/schema";
import { z } from "zod";
import { pipelineService } from "./pipeline-service";

const createTestCaseWithAppsSchema = z.object({
  testCase: insertTestCaseSchema,
  appConfigs: z.array(z.object({
    appId: z.number(),
    branch: z.string(),
  })),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Apps routes
  app.get("/api/apps", async (req, res) => {
    try {
      const apps = await storage.getApps();
      res.json(apps);
    } catch (error) {
      console.error("Error fetching apps:", error);
      res.status(500).json({ error: "Failed to fetch apps" });
    }
  });

  app.post("/api/apps", async (req, res) => {
    try {
      const validatedData = insertAppSchema.parse(req.body);
      const app = await storage.createApp(validatedData);
      res.status(201).json(app);
    } catch (error) {
      console.error("Error creating app:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create app" });
      }
    }
  });

  app.put("/api/apps/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertAppSchema.partial().parse(req.body);
      const app = await storage.updateApp(id, validatedData);

      if (!app) {
        res.status(404).json({ error: "App not found" });
        return;
      }

      res.json(app);
    } catch (error) {
      console.error("Error updating app:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update app" });
      }
    }
  });

  app.delete("/api/apps/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteApp(id);

      if (!deleted) {
        res.status(404).json({ error: "App not found" });
        return;
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting app:", error);
      res.status(500).json({ error: "Failed to delete app" });
    }
  });

  // Test cases routes
  app.get("/api/test-cases", async (req, res) => {
    try {
      const testCases = await storage.getTestCases();
      res.json(testCases);
    } catch (error) {
      console.error("Error fetching test cases:", error);
      res.status(500).json({ error: "Failed to fetch test cases" });
    }
  });

  app.post("/api/test-cases", async (req, res) => {
    try {
      const validatedData = createTestCaseWithAppsSchema.parse(req.body);
      const testCase = await storage.createTestCase(
        validatedData.testCase,
        validatedData.appConfigs.map(config => ({
          ...config,
          testCaseId: 0, // Will be set by storage
        }))
      );
      res.status(201).json(testCase);
    } catch (error) {
      console.error("Error creating test case:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create test case" });
      }
    }
  });

  app.put("/api/test-cases/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = createTestCaseWithAppsSchema.parse(req.body);
      const testCase = await storage.updateTestCase(
        id,
        validatedData.testCase,
        validatedData.appConfigs.map(config => ({
          ...config,
          testCaseId: id,
        }))
      );

      if (!testCase) {
        res.status(404).json({ error: "Test case not found" });
        return;
      }

      res.json(testCase);
    } catch (error) {
      console.error("Error updating test case:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update test case" });
      }
    }
  });

  app.delete("/api/test-cases/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTestCase(id);

      if (!deleted) {
        res.status(404).json({ error: "Test case not found" });
        return;
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting test case:", error);
      res.status(500).json({ error: "Failed to delete test case" });
    }
  });

  // Executions
  app.get("/api/executions", async (req, res) => {
    try {
      const executions = await storage.getExecutions();
      res.json(executions);
    } catch (error) {
      console.error("Error fetching executions:", error);
      res.status(500).json({ error: "Failed to fetch executions" });
    }
  });

  app.post("/api/executions", async (req, res) => {
    try {
      const { testCaseId } = req.body;

      if (!testCaseId) {
        res.status(400).json({ error: "Test case ID is required" });
        return;
      }

      const testCase = await storage.getTestCaseWithApps(testCaseId);
      if (!testCase) {
        res.status(404).json({ error: "Test case not found" });
        return;
      }

      // Use the pipeline service to execute the test case
      const execution = await pipelineService.executeTestCase(testCase);

      res.json(execution);
    } catch (error) {
      console.error("Error creating execution:", error);
      res.status(500).json({ error: "Failed to create execution" });
    }
  });

  app.post("/api/executions/:id/cancel", async (req, res) => {
    try {
      const { id } = req.params;
      const executionId = parseInt(id);

      if (isNaN(executionId)) {
        res.status(400).json({ error: "Invalid execution ID" });
        return;
      }

      pipelineService.cancelExecution(executionId);

      await storage.updateExecution(executionId, {
        status: "canceled",
        completedAt: new Date().toISOString(),
      });

      res.json({ message: "Execution canceled" });
    } catch (error) {
      console.error("Error canceling execution:", error);
      res.status(500).json({ error: "Failed to cancel execution" });
    }
  });

  app.put("/api/executions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertExecutionSchema.partial().parse(req.body);
      const execution = await storage.updateExecution(id, validatedData);

      if (!execution) {
        res.status(404).json({ error: "Execution not found" });
        return;
      }

      res.json(execution);
    } catch (error) {
      console.error("Error updating execution:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update execution" });
      }
    }
  });

  // Execute test case with sequential pipeline execution
  app.post("/api/test-cases/:id/execute", async (req, res) => {
    try {
      const testCaseId = parseInt(req.params.id);
      const testCase = await storage.getTestCase(testCaseId);

      if (!testCase) {
        res.status(404).json({ error: "Test case not found" });
        return;
      }

      if (testCase.testCaseApps.length === 0) {
        res.status(400).json({ error: "Test case must have at least one app configured" });
        return;
      }

      const execution = await executeTestCaseSimple(testCase);
      res.status(201).json(execution);
    } catch (error) {
      console.error("Error executing test case:", error);
      res.status(500).json({ error: "Failed to execute test case" });
    }
  });

  // Pipeline runs routes
  app.post("/api/pipeline-runs", async (req, res) => {
    try {
      const pipelineRun = await storage.createPipelineRun(req.body);
      res.status(201).json(pipelineRun);
    } catch (error) {
      console.error("Error creating pipeline run:", error);
      res.status(500).json({ error: "Failed to create pipeline run" });
    }
  });

  app.put("/api/pipeline-runs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pipelineRun = await storage.updatePipelineRun(id, req.body);

      if (!pipelineRun) {
        res.status(404).json({ error: "Pipeline run not found" });
        return;
      }

      res.json(pipelineRun);
    } catch (error) {
      console.error("Error updating pipeline run:", error);
      res.status(500).json({ error: "Failed to update pipeline run" });
    }
  });

  // Artifacts routes
  app.post("/api/artifacts", async (req, res) => {
    try {
      const artifact = await storage.createArtifact(req.body);
      res.status(201).json(artifact);
    } catch (error) {
      console.error("Error creating artifact:", error);
      res.status(500).json({ error: "Failed to create artifact" });
    }
  });

  app.get("/api/artifacts/execution/:executionId", async (req, res) => {
    try {
      const executionId = parseInt(req.params.executionId);
      const artifacts = await storage.getArtifactsByExecution(executionId);
      res.json(artifacts);
    } catch (error) {
      console.error("Error fetching artifacts:", error);
      res.status(500).json({ error: "Failed to fetch artifacts" });
    }
  });

  // Stats route
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // GitLab API proxy routes for branches
  app.get("/api/gitlab/projects/:projectId/branches", async (req, res) => {
    try {
      const { projectId } = req.params;
      const { accessToken } = req.query;

      if (!accessToken) {
        res.status(400).json({ error: "Access token required" });
        return;
      }

      const response = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/repository/branches`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`GitLab API error: ${response.status}`);
      }

      const branches = await response.json();
      res.json(branches);
    } catch (error) {
      console.error("Error fetching GitLab branches:", error);
      res.status(500).json({ error: "Failed to fetch branches from GitLab" });
    }
  });

  // GitLab API proxy route for triggering pipelines
  app.post("/api/gitlab/projects/:projectId/pipeline", async (req, res) => {
    try {
      const { projectId } = req.params;
      const { accessToken, branch, variables } = req.body;

      if (!accessToken || !branch) {
        res.status(400).json({ error: "Access token and branch required" });
        return;
      }

      const gitlabVariables = Object.entries(variables || {}).map(([key, value]) => ({
        key,
        value: String(value),
        variable_type: 'env_var',
      }));

      const response = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/pipeline`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ref: branch,
          variables: gitlabVariables,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`GitLab API error: ${response.status} - ${errorText}`);
      }

      const pipeline = await response.json();
      res.json(pipeline);
    } catch (error) {
      console.error("Error triggering GitLab pipeline:", error);
      res.status(500).json({ error: "Failed to trigger pipeline" });
    }
  });

  // GitLab API proxy route for getting pipeline status
  app.get("/api/gitlab/projects/:projectId/pipelines/:pipelineId", async (req, res) => {
    try {
      const { projectId, pipelineId } = req.params;
      const { accessToken } = req.query;

      if (!accessToken) {
        res.status(400).json({ error: "Access token required" });
        return;
      }

      const response = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`GitLab API error: ${response.status}`);
      }

      const pipeline = await response.json();
      res.json(pipeline);
    } catch (error) {
      console.error("Error fetching GitLab pipeline:", error);
      res.status(500).json({ error: "Failed to fetch pipeline from GitLab" });
    }
  });

  // GitLab API proxy route for getting pipeline jobs
  app.get("/api/gitlab/projects/:projectId/pipelines/:pipelineId/jobs", async (req, res) => {
    try {
      const { projectId, pipelineId } = req.params;
      const { accessToken } = req.query;

      if (!accessToken) {
        res.status(400).json({ error: "Access token required" });
        return;
      }

      const response = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}/jobs`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`GitLab API error: ${response.status}`);
      }

      const jobs = await response.json();
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching GitLab pipeline jobs:", error);
      res.status(500).json({ error: "Failed to fetch pipeline jobs from GitLab" });
    }
  });

  // GitLab API proxy route for downloading job artifacts
  app.get("/api/gitlab/projects/:projectId/jobs/:jobId/artifacts", async (req, res) => {
    try {
      const { projectId, jobId } = req.params;
      const { accessToken } = req.query;

      if (!accessToken) {
        res.status(400).json({ error: "Access token required" });
        return;
      }

      const response = await fetch(`https://gitlab.com/api/v4/projects/${projectId}/jobs/${jobId}/artifacts`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        if (response.status === 404) {
          res.status(404).json({ error: "No artifacts found for this job" });
        } else {
          throw new Error(`GitLab API error: ${response.status}`);
        }
        return;
      }

      // Set headers for file download
      const contentDisposition = response.headers.get('content-disposition') || 'attachment; filename="artifacts.zip"';
      const contentType = response.headers.get('content-type') || 'application/zip';

      res.setHeader('Content-Disposition', contentDisposition);
      res.setHeader('Content-Type', contentType);

      // Stream the file to the client
      const buffer = await response.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error("Error downloading GitLab artifacts:", error);
      res.status(500).json({ error: "Failed to download artifacts from GitLab" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}