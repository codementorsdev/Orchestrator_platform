import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertApplicationSchema, insertTestFlowSchema, insertExecutionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Applications routes
  app.get("/api/applications", async (req, res) => {
    try {
      const applications = await storage.getApplications();
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.get("/api/applications/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const application = await storage.getApplication(id);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch application" });
    }
  });

  app.post("/api/applications", async (req, res) => {
    try {
      const validatedData = insertApplicationSchema.parse(req.body);
      const application = await storage.createApplication(validatedData);
      res.status(201).json(application);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create application" });
    }
  });

  app.put("/api/applications/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertApplicationSchema.partial().parse(req.body);
      const application = await storage.updateApplication(id, validatedData);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      res.json(application);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update application" });
    }
  });

  app.delete("/api/applications/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteApplication(id);
      if (!deleted) {
        return res.status(404).json({ message: "Application not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete application" });
    }
  });

  // Test Flows routes
  app.get("/api/test-flows", async (req, res) => {
    try {
      const testFlows = await storage.getTestFlows();
      res.json(testFlows);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch test flows" });
    }
  });

  app.get("/api/test-flows/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const testFlow = await storage.getTestFlow(id);
      if (!testFlow) {
        return res.status(404).json({ message: "Test flow not found" });
      }
      res.json(testFlow);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch test flow" });
    }
  });

  app.post("/api/test-flows", async (req, res) => {
    try {
      const validatedData = insertTestFlowSchema.parse(req.body);
      const testFlow = await storage.createTestFlow(validatedData);
      res.status(201).json(testFlow);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create test flow" });
    }
  });

  app.put("/api/test-flows/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertTestFlowSchema.partial().parse(req.body);
      const testFlow = await storage.updateTestFlow(id, validatedData);
      if (!testFlow) {
        return res.status(404).json({ message: "Test flow not found" });
      }
      res.json(testFlow);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update test flow" });
    }
  });

  app.delete("/api/test-flows/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTestFlow(id);
      if (!deleted) {
        return res.status(404).json({ message: "Test flow not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete test flow" });
    }
  });

  // Executions routes
  app.get("/api/executions", async (req, res) => {
    try {
      const executions = await storage.getExecutions();
      res.json(executions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch executions" });
    }
  });

  app.get("/api/executions/active", async (req, res) => {
    try {
      const executions = await storage.getActiveExecutions();
      res.json(executions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active executions" });
    }
  });

  app.post("/api/executions", async (req, res) => {
    try {
      const validatedData = insertExecutionSchema.parse(req.body);
      const execution = await storage.createExecution(validatedData);
      res.status(201).json(execution);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create execution" });
    }
  });

  app.put("/api/executions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertExecutionSchema.partial().parse(req.body);
      const execution = await storage.updateExecution(id, validatedData);
      if (!execution) {
        return res.status(404).json({ message: "Execution not found" });
      }
      res.json(execution);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update execution" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
