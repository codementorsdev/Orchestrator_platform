import { 
  apps, 
  testCases, 
  testCaseApps, 
  executions, 
  pipelineRuns, 
  artifacts,
  type App, 
  type InsertApp,
  type TestCase,
  type InsertTestCase,
  type TestCaseApp,
  type InsertTestCaseApp,
  type Execution,
  type InsertExecution,
  type PipelineRun,
  type InsertPipelineRun,
  type Artifact,
  type InsertArtifact,
  type TestCaseWithApps,
  type ExecutionWithDetails
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Apps
  getApps(): Promise<App[]>;
  getApp(id: number): Promise<App | undefined>;
  createApp(app: InsertApp): Promise<App>;
  updateApp(id: number, app: Partial<InsertApp>): Promise<App | undefined>;
  deleteApp(id: number): Promise<boolean>;

  // Test Cases
  getTestCases(): Promise<TestCaseWithApps[]>;
  getTestCase(id: number): Promise<TestCaseWithApps | undefined>;
  createTestCase(testCase: InsertTestCase, appConfigs: InsertTestCaseApp[]): Promise<TestCase>;
  updateTestCase(id: number, testCase: Partial<InsertTestCase>, appConfigs?: InsertTestCaseApp[]): Promise<TestCase | undefined>;
  deleteTestCase(id: number): Promise<boolean>;

  // Executions
  getExecutions(): Promise<ExecutionWithDetails[]>;
  getExecution(id: number): Promise<ExecutionWithDetails | undefined>;
  createExecution(execution: InsertExecution): Promise<Execution>;
  updateExecution(id: number, execution: Partial<InsertExecution>): Promise<Execution | undefined>;

  // Pipeline Runs
  createPipelineRun(pipelineRun: InsertPipelineRun): Promise<PipelineRun>;
  updatePipelineRun(id: number, pipelineRun: Partial<InsertPipelineRun>): Promise<PipelineRun | undefined>;
  getPipelineRunsByExecution(executionId: number): Promise<(PipelineRun & { app: App })[]>;

  // Artifacts
  createArtifact(artifact: InsertArtifact): Promise<Artifact>;
  getArtifactsByPipelineRun(pipelineRunId: number): Promise<Artifact[]>;
  getArtifactsByExecution(executionId: number): Promise<(Artifact & { pipelineRun: PipelineRun & { app: App } })[]>;

  // Stats
  getStats(): Promise<{
    totalApps: number;
    totalTestCases: number;
    runningExecutions: number;
    successRate: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getApps(): Promise<App[]> {
    return db.select().from(apps).orderBy(desc(apps.createdAt));
  }

  async getApp(id: number): Promise<App | undefined> {
    const [app] = await db.select().from(apps).where(eq(apps.id, id));
    return app || undefined;
  }

  async createApp(app: InsertApp): Promise<App> {
    const [created] = await db
      .insert(apps)
      .values({
        ...app,
        updatedAt: new Date(),
      })
      .returning();
    return created;
  }

  async updateApp(id: number, app: Partial<InsertApp>): Promise<App | undefined> {
    const [updated] = await db
      .update(apps)
      .set({
        ...app,
        updatedAt: new Date(),
      })
      .where(eq(apps.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteApp(id: number): Promise<boolean> {
    const result = await db.delete(apps).where(eq(apps.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getTestCases(): Promise<TestCaseWithApps[]> {
    const testCasesWithApps = await db.query.testCases.findMany({
      orderBy: [desc(testCases.createdAt)],
      with: {
        testCaseApps: {
          with: {
            app: true,
          },
          orderBy: [testCaseApps.order],
        },
      },
    });
    return testCasesWithApps;
  }

  async getTestCase(id: number): Promise<TestCaseWithApps | undefined> {
    const testCase = await db.query.testCases.findFirst({
      where: eq(testCases.id, id),
      with: {
        testCaseApps: {
          with: {
            app: true,
          },
          orderBy: [testCaseApps.order],
        },
      },
    });
    return testCase || undefined;
  }

  async createTestCase(testCase: InsertTestCase, appConfigs: InsertTestCaseApp[]): Promise<TestCase> {
    const [created] = await db
      .insert(testCases)
      .values({
        ...testCase,
        updatedAt: new Date(),
      })
      .returning();

    // Insert test case apps
    if (appConfigs.length > 0) {
      await db.insert(testCaseApps).values(
        appConfigs.map((config, index) => ({
          ...config,
          testCaseId: created.id,
          order: index,
        }))
      );
    }

    return created;
  }

  async updateTestCase(id: number, testCase: Partial<InsertTestCase>, appConfigs?: InsertTestCaseApp[]): Promise<TestCase | undefined> {
    const [updated] = await db
      .update(testCases)
      .set({
        ...testCase,
        updatedAt: new Date(),
      })
      .where(eq(testCases.id, id))
      .returning();

    // Update app configurations if provided
    if (appConfigs && updated) {
      // Delete existing test case apps
      await db.delete(testCaseApps).where(eq(testCaseApps.testCaseId, id));
      
      // Insert new test case apps
      if (appConfigs.length > 0) {
        await db.insert(testCaseApps).values(
          appConfigs.map((config, index) => ({
            ...config,
            testCaseId: id,
            order: index,
          }))
        );
      }
    }

    return updated || undefined;
  }

  async deleteTestCase(id: number): Promise<boolean> {
    // Delete related test case apps first
    await db.delete(testCaseApps).where(eq(testCaseApps.testCaseId, id));
    
    const result = await db.delete(testCases).where(eq(testCases.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getExecutions(): Promise<ExecutionWithDetails[]> {
    const executionsWithDetails = await db.query.executions.findMany({
      orderBy: [desc(executions.createdAt)],
      with: {
        testCase: true,
        pipelineRuns: {
          with: {
            app: true,
            artifacts: true,
          },
          orderBy: [pipelineRuns.order],
        },
      },
    });
    return executionsWithDetails;
  }

  async getExecution(id: number): Promise<ExecutionWithDetails | undefined> {
    const execution = await db.query.executions.findFirst({
      where: eq(executions.id, id),
      with: {
        testCase: true,
        pipelineRuns: {
          with: {
            app: true,
            artifacts: true,
          },
          orderBy: [pipelineRuns.order],
        },
      },
    });
    return execution || undefined;
  }

  async createExecution(execution: InsertExecution): Promise<Execution> {
    const executionData: any = {
      testCaseId: execution.testCaseId,
      status: execution.status || "pending",
      startedAt: execution.startedAt ? new Date(execution.startedAt) : null,
      completedAt: execution.completedAt ? new Date(execution.completedAt) : null,
      duration: execution.duration || null,
    };
    
    const [created] = await db
      .insert(executions)
      .values(executionData)
      .returning();
    return created;
  }

  async updateExecution(id: number, execution: Partial<InsertExecution>): Promise<Execution | undefined> {
    const executionData: any = {};
    
    if (execution.testCaseId !== undefined) executionData.testCaseId = execution.testCaseId;
    if (execution.status !== undefined) executionData.status = execution.status;
    if (execution.startedAt !== undefined) executionData.startedAt = execution.startedAt ? new Date(execution.startedAt) : null;
    if (execution.completedAt !== undefined) executionData.completedAt = execution.completedAt ? new Date(execution.completedAt) : null;
    if (execution.duration !== undefined) executionData.duration = execution.duration;
    
    const [updated] = await db
      .update(executions)
      .set(executionData)
      .where(eq(executions.id, id))
      .returning();
    return updated || undefined;
  }

  async createPipelineRun(pipelineRun: InsertPipelineRun): Promise<PipelineRun> {
    const pipelineRunData: any = {
      executionId: pipelineRun.executionId,
      appId: pipelineRun.appId,
      branch: pipelineRun.branch,
      pipelineId: pipelineRun.pipelineId || null,
      status: pipelineRun.status || "pending",
      stages: pipelineRun.stages || null,
      startedAt: pipelineRun.startedAt ? new Date(pipelineRun.startedAt) : null,
      completedAt: pipelineRun.completedAt ? new Date(pipelineRun.completedAt) : null,
      duration: pipelineRun.duration || null,
      order: pipelineRun.order || 0,
    };

    const [created] = await db
      .insert(pipelineRuns)
      .values(pipelineRunData)
      .returning();
    return created;
  }

  async updatePipelineRun(id: number, pipelineRun: Partial<InsertPipelineRun>): Promise<PipelineRun | undefined> {
    const pipelineRunData: any = {};
    
    if (pipelineRun.executionId !== undefined) pipelineRunData.executionId = pipelineRun.executionId;
    if (pipelineRun.appId !== undefined) pipelineRunData.appId = pipelineRun.appId;
    if (pipelineRun.branch !== undefined) pipelineRunData.branch = pipelineRun.branch;
    if (pipelineRun.pipelineId !== undefined) pipelineRunData.pipelineId = pipelineRun.pipelineId;
    if (pipelineRun.status !== undefined) pipelineRunData.status = pipelineRun.status;
    if (pipelineRun.stages !== undefined) pipelineRunData.stages = pipelineRun.stages;
    if (pipelineRun.startedAt !== undefined) pipelineRunData.startedAt = pipelineRun.startedAt ? new Date(pipelineRun.startedAt) : null;
    if (pipelineRun.completedAt !== undefined) pipelineRunData.completedAt = pipelineRun.completedAt ? new Date(pipelineRun.completedAt) : null;
    if (pipelineRun.duration !== undefined) pipelineRunData.duration = pipelineRun.duration;
    if (pipelineRun.order !== undefined) pipelineRunData.order = pipelineRun.order;

    const [updated] = await db
      .update(pipelineRuns)
      .set(pipelineRunData)
      .where(eq(pipelineRuns.id, id))
      .returning();
    return updated || undefined;
  }

  async getPipelineRunsByExecution(executionId: number): Promise<(PipelineRun & { app: App })[]> {
    const runs = await db.query.pipelineRuns.findMany({
      where: eq(pipelineRuns.executionId, executionId),
      with: {
        app: true,
      },
      orderBy: [pipelineRuns.order],
    });
    return runs;
  }

  async createArtifact(artifact: InsertArtifact): Promise<Artifact> {
    const [created] = await db
      .insert(artifacts)
      .values(artifact)
      .returning();
    return created;
  }

  async getArtifactsByPipelineRun(pipelineRunId: number): Promise<Artifact[]> {
    return db.select().from(artifacts).where(eq(artifacts.pipelineRunId, pipelineRunId));
  }

  async getArtifactsByExecution(executionId: number): Promise<(Artifact & { pipelineRun: PipelineRun & { app: App } })[]> {
    const artifactsWithDetails = await db.query.artifacts.findMany({
      where: eq(pipelineRuns.executionId, executionId),
      with: {
        pipelineRun: {
          with: {
            app: true,
          },
        },
      },
    });
    return artifactsWithDetails;
  }

  async getStats(): Promise<{
    totalApps: number;
    totalTestCases: number;
    runningExecutions: number;
    successRate: number;
  }> {
    const [appsCount] = await db.select({ count: db.$count(apps) }).from(apps);
    const [testCasesCount] = await db.select({ count: db.$count(testCases) }).from(testCases);
    
    const allExecutions = await db.select().from(executions);
    const runningExecutions = allExecutions.filter(e => e.status === 'running').length;
    const successfulExecutions = allExecutions.filter(e => e.status === 'success').length;
    const successRate = allExecutions.length > 0 ? Math.round((successfulExecutions / allExecutions.length) * 100) : 0;

    return {
      totalApps: appsCount.count,
      totalTestCases: testCasesCount.count,
      runningExecutions,
      successRate,
    };
  }
}

export const storage = new DatabaseStorage();
