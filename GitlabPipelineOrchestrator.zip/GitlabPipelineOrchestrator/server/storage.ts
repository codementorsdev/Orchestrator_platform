import { applications, testFlows, executions, type Application, type InsertApplication, type TestFlow, type InsertTestFlow, type Execution, type InsertExecution } from "@shared/schema";

export interface IStorage {
  // Applications
  getApplications(): Promise<Application[]>;
  getApplication(id: number): Promise<Application | undefined>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplication(id: number, application: Partial<InsertApplication>): Promise<Application | undefined>;
  deleteApplication(id: number): Promise<boolean>;

  // Test Flows
  getTestFlows(): Promise<TestFlow[]>;
  getTestFlow(id: number): Promise<TestFlow | undefined>;
  getTestFlowsByApplication(applicationId: number): Promise<TestFlow[]>;
  createTestFlow(testFlow: InsertTestFlow): Promise<TestFlow>;
  updateTestFlow(id: number, testFlow: Partial<InsertTestFlow>): Promise<TestFlow | undefined>;
  deleteTestFlow(id: number): Promise<boolean>;

  // Executions
  getExecutions(): Promise<Execution[]>;
  getExecution(id: number): Promise<Execution | undefined>;
  getExecutionsByTestFlow(testFlowId: number): Promise<Execution[]>;
  getActiveExecutions(): Promise<Execution[]>;
  createExecution(execution: InsertExecution): Promise<Execution>;
  updateExecution(id: number, execution: Partial<InsertExecution>): Promise<Execution | undefined>;
}

export class MemStorage implements IStorage {
  private applications: Map<number, Application>;
  private testFlows: Map<number, TestFlow>;
  private executions: Map<number, Execution>;
  private nextId: number;

  constructor() {
    this.applications = new Map();
    this.testFlows = new Map();
    this.executions = new Map();
    this.nextId = 1;
  }

  // Applications
  async getApplications(): Promise<Application[]> {
    return Array.from(this.applications.values());
  }

  async getApplication(id: number): Promise<Application | undefined> {
    return this.applications.get(id);
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = this.nextId++;
    const application: Application = {
      id,
      name: insertApplication.name,
      accessToken: insertApplication.accessToken,
      projectId: insertApplication.projectId,
      description: insertApplication.description || null,
      status: insertApplication.status ?? "active",
      createdAt: new Date(),
    };
    this.applications.set(id, application);
    return application;
  }

  async updateApplication(id: number, updateData: Partial<InsertApplication>): Promise<Application | undefined> {
    const existing = this.applications.get(id);
    if (!existing) return undefined;

    const updated: Application = { ...existing, ...updateData };
    this.applications.set(id, updated);
    return updated;
  }

  async deleteApplication(id: number): Promise<boolean> {
    return this.applications.delete(id);
  }

  // Test Flows
  async getTestFlows(): Promise<TestFlow[]> {
    return Array.from(this.testFlows.values());
  }

  async getTestFlow(id: number): Promise<TestFlow | undefined> {
    return this.testFlows.get(id);
  }

  async getTestFlowsByApplication(applicationId: number): Promise<TestFlow[]> {
    return Array.from(this.testFlows.values()).filter(flow => flow.applicationId === applicationId);
  }

  async createTestFlow(insertTestFlow: InsertTestFlow): Promise<TestFlow> {
    const id = this.nextId++;
    const testFlow: TestFlow = {
      id,
      name: insertTestFlow.name,
      applicationId: insertTestFlow.applicationId,
      branch: insertTestFlow.branch,
      environmentVariables: insertTestFlow.environmentVariables || null,
      createdAt: new Date(),
    };
    this.testFlows.set(id, testFlow);
    return testFlow;
  }

  async updateTestFlow(id: number, updateData: Partial<InsertTestFlow>): Promise<TestFlow | undefined> {
    const existing = this.testFlows.get(id);
    if (!existing) return undefined;

    const updated: TestFlow = { ...existing, ...updateData };
    this.testFlows.set(id, updated);
    return updated;
  }

  async deleteTestFlow(id: number): Promise<boolean> {
    return this.testFlows.delete(id);
  }

  // Executions
  async getExecutions(): Promise<Execution[]> {
    return Array.from(this.executions.values()).sort((a, b) => 
      new Date(b.startedAt!).getTime() - new Date(a.startedAt!).getTime()
    );
  }

  async getExecution(id: number): Promise<Execution | undefined> {
    return this.executions.get(id);
  }

  async getExecutionsByTestFlow(testFlowId: number): Promise<Execution[]> {
    return Array.from(this.executions.values()).filter(execution => execution.testFlowId === testFlowId);
  }

  async getActiveExecutions(): Promise<Execution[]> {
    return Array.from(this.executions.values()).filter(execution => 
      ['pending', 'running'].includes(execution.status)
    );
  }

  async createExecution(insertExecution: InsertExecution): Promise<Execution> {
    const id = this.nextId++;
    const execution: Execution = {
      id,
      testFlowId: insertExecution.testFlowId,
      pipelineId: insertExecution.pipelineId || null,
      status: insertExecution.status || "pending",
      duration: insertExecution.duration || null,
      startedAt: new Date(),
      completedAt: null,
      stages: Array.isArray(insertExecution.stages) ? insertExecution.stages : [],
    };
    this.executions.set(id, execution);
    return execution;
  }

  async updateExecution(id: number, updateData: Partial<InsertExecution>): Promise<Execution | undefined> {
    const existing = this.executions.get(id);
    if (!existing) return undefined;

    const updated: Execution = { 
      ...existing, 
      ...updateData,
      stages: Array.isArray(updateData.stages) ? updateData.stages : existing.stages
    };
    if (updateData.status && ['success', 'failed', 'cancelled'].includes(updateData.status)) {
      updated.completedAt = new Date();
    }
    this.executions.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
