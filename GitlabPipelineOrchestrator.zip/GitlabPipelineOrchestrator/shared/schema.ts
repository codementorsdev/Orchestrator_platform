import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  accessToken: text("access_token").notNull(),
  projectId: integer("project_id").notNull(),
  description: text("description"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const testFlows = pgTable("test_flows", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  applicationId: integer("application_id").notNull(),
  branch: text("branch").notNull(),
  environmentVariables: jsonb("environment_variables").$type<Record<string, string>>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
});

export const executions = pgTable("executions", {
  id: serial("id").primaryKey(),
  testFlowId: integer("test_flow_id").notNull(),
  pipelineId: integer("pipeline_id"),
  status: text("status").notNull().default("pending"),
  duration: integer("duration"),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  stages: jsonb("stages").$type<Array<{
    name: string;
    status: string;
    duration?: number;
  }>>().default([]),
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  createdAt: true,
});

export const insertTestFlowSchema = createInsertSchema(testFlows).omit({
  id: true,
  createdAt: true,
});

export const insertExecutionSchema = createInsertSchema(executions).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;

export type InsertTestFlow = z.infer<typeof insertTestFlowSchema>;
export type TestFlow = typeof testFlows.$inferSelect;

export type InsertExecution = z.infer<typeof insertExecutionSchema>;
export type Execution = typeof executions.$inferSelect;
