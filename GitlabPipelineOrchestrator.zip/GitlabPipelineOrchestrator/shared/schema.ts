import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const apps = pgTable("apps", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  accessToken: text("access_token").notNull(),
  projectId: text("project_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const testCases = pgTable("test_cases", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  envVars: text("env_vars"), // comma-separated key=value pairs
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const testCaseApps = pgTable("test_case_apps", {
  id: serial("id").primaryKey(),
  testCaseId: integer("test_case_id").notNull().references(() => testCases.id),
  appId: integer("app_id").notNull().references(() => apps.id),
  branch: text("branch").notNull(),
  order: integer("order").notNull().default(0), // execution order
});

export const executions = pgTable("executions", {
  id: serial("id").primaryKey(),
  testCaseId: integer("test_case_id").notNull().references(() => testCases.id),
  status: text("status").notNull().default("pending"), // pending, running, success, failed
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  duration: integer("duration"), // in seconds
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const pipelineRuns = pgTable("pipeline_runs", {
  id: serial("id").primaryKey(),
  executionId: integer("execution_id").notNull().references(() => executions.id),
  appId: integer("app_id").notNull().references(() => apps.id),
  branch: text("branch").notNull(),
  pipelineId: text("pipeline_id"), // GitLab pipeline ID
  status: text("status").notNull().default("pending"), // pending, running, success, failed
  stages: jsonb("stages"), // pipeline stages data
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  duration: integer("duration"), // in seconds
  order: integer("order").notNull().default(0), // execution order
});

export const artifacts = pgTable("artifacts", {
  id: serial("id").primaryKey(),
  pipelineRunId: integer("pipeline_run_id").notNull().references(() => pipelineRuns.id),
  name: text("name").notNull(),
  url: text("url").notNull(),
  size: integer("size"), // in bytes
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const appsRelations = relations(apps, ({ many }) => ({
  testCaseApps: many(testCaseApps),
  pipelineRuns: many(pipelineRuns),
}));

export const testCasesRelations = relations(testCases, ({ many }) => ({
  testCaseApps: many(testCaseApps),
  executions: many(executions),
}));

export const testCaseAppsRelations = relations(testCaseApps, ({ one }) => ({
  testCase: one(testCases, {
    fields: [testCaseApps.testCaseId],
    references: [testCases.id],
  }),
  app: one(apps, {
    fields: [testCaseApps.appId],
    references: [apps.id],
  }),
}));

export const executionsRelations = relations(executions, ({ one, many }) => ({
  testCase: one(testCases, {
    fields: [executions.testCaseId],
    references: [testCases.id],
  }),
  pipelineRuns: many(pipelineRuns),
}));

export const pipelineRunsRelations = relations(pipelineRuns, ({ one, many }) => ({
  execution: one(executions, {
    fields: [pipelineRuns.executionId],
    references: [executions.id],
  }),
  app: one(apps, {
    fields: [pipelineRuns.appId],
    references: [apps.id],
  }),
  artifacts: many(artifacts),
}));

export const artifactsRelations = relations(artifacts, ({ one }) => ({
  pipelineRun: one(pipelineRuns, {
    fields: [artifacts.pipelineRunId],
    references: [pipelineRuns.id],
  }),
}));

// Insert schemas
export const insertAppSchema = createInsertSchema(apps).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTestCaseSchema = createInsertSchema(testCases).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTestCaseAppSchema = createInsertSchema(testCaseApps).omit({
  id: true,
});

export const insertExecutionSchema = createInsertSchema(executions).omit({
  id: true,
  createdAt: true,
}).extend({
  startedAt: z.string().datetime().optional(),
  completedAt: z.string().datetime().optional(),
});

export const insertPipelineRunSchema = createInsertSchema(pipelineRuns).omit({
  id: true,
});

export const insertArtifactSchema = createInsertSchema(artifacts).omit({
  id: true,
  createdAt: true,
});

// Types
export type App = typeof apps.$inferSelect;
export type InsertApp = z.infer<typeof insertAppSchema>;

export type TestCase = typeof testCases.$inferSelect;
export type InsertTestCase = z.infer<typeof insertTestCaseSchema>;

export type TestCaseApp = typeof testCaseApps.$inferSelect;
export type InsertTestCaseApp = z.infer<typeof insertTestCaseAppSchema>;

export type Execution = typeof executions.$inferSelect;
export type InsertExecution = z.infer<typeof insertExecutionSchema>;

export type PipelineRun = typeof pipelineRuns.$inferSelect;
export type InsertPipelineRun = z.infer<typeof insertPipelineRunSchema>;

export type Artifact = typeof artifacts.$inferSelect;
export type InsertArtifact = z.infer<typeof insertArtifactSchema>;

// Extended types for API responses
export type TestCaseWithApps = TestCase & {
  testCaseApps: (TestCaseApp & { app: App })[];
};

export type ExecutionWithDetails = Execution & {
  testCase: TestCase;
  pipelineRuns: (PipelineRun & { app: App; artifacts: Artifact[] })[];
};
