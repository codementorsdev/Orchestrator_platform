package com.gitlab.orchestrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Main application class for the GitLab Pipeline Orchestrator.
 * This application orchestrates GitLab pipelines across different projects sequentially.
 */
@SpringBootApplication
@EnableScheduling
@EnableAsync
public class GitlabOrchestratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(GitlabOrchestratorApplication.class, args);
    }
}
