package com.gitlab.orchestrator.config;

import com.gitlab.orchestrator.model.Role;
import com.gitlab.orchestrator.model.User;
import com.gitlab.orchestrator.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

/**
 * Component to initialize data when the application starts.
 * Order(2) ensures it runs after DatabaseHealthCheck
 */
@Component
@Order(2)
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired
    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        try {
            // Create admin user if it doesn't exist
            if (!userRepository.existsByUsername("admin")) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setEmail("admin@example.com");
                admin.setActive(true);
                
                Set<Role> adminRoles = new HashSet<>();
                adminRoles.add(Role.ADMIN);
                admin.setRoles(adminRoles);
                
                userRepository.save(admin);
                logger.info("Admin user created");
            }
            
            // Create tester user if it doesn't exist
            if (!userRepository.existsByUsername("tester")) {
                User tester = new User();
                tester.setUsername("tester");
                tester.setPassword(passwordEncoder.encode("tester123"));
                tester.setEmail("tester@example.com");
                tester.setActive(true);
                
                Set<Role> testerRoles = new HashSet<>();
                testerRoles.add(Role.TESTER);
                tester.setRoles(testerRoles);
                
                userRepository.save(tester);
                logger.info("Tester user created");
            }
        } catch (Exception e) {
            logger.error("Error initializing data: " + e.getMessage(), e);
            throw e;
        }
    }
}