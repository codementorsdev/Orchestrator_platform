package com.gitlab.orchestrator.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

/**
 * This configuration is now disabled as we're using H2 in-memory database
 * with Spring Boot auto-configuration instead.
 */
@Configuration
public class DatabaseConfig {
    
    private static final Logger logger = LoggerFactory.getLogger(DatabaseConfig.class);
    
    // Constructor to log that we're using H2
    public DatabaseConfig() {
        logger.info("Using H2 in-memory database with Spring Boot auto-configuration");
    }
}