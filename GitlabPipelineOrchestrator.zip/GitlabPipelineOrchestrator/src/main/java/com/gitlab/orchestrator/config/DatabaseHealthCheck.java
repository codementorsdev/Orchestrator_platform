package com.gitlab.orchestrator.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@Component
@Order(1) // Run before DataInitializer
public class DatabaseHealthCheck implements HealthIndicator, ApplicationRunner {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseHealthCheck.class);
    
    @Autowired
    private DataSource dataSource;
    
    @Override
    public Health health() {
        try (Connection connection = dataSource.getConnection()) {
            if (connection.isValid(1000)) {
                return Health.up().withDetail("database", "H2").build();
            } else {
                return Health.down().withDetail("message", "Database connection is invalid").build();
            }
        } catch (SQLException e) {
            logger.error("Database health check failed", e);
            return Health.down().withDetail("message", e.getMessage()).build();
        }
    }
    
    @Override
    public void run(ApplicationArguments args) throws Exception {
        logger.info("Performing initial database health check");
        
        try (Connection connection = dataSource.getConnection()) {
            // Log connection information
            logger.info("Database connection established: {}", connection.getMetaData().getURL());
            
            // Test a simple query
            try (Statement stmt = connection.createStatement()) {
                stmt.execute("SELECT 1");
                logger.info("Database query test successful");
            }
        } catch (SQLException e) {
            logger.error("Initial database connection test failed", e);
            throw e; // Re-throw to fail application startup if necessary
        }
    }
}