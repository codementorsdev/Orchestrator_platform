package com.gitlab.orchestrator.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Persistence configuration for JPA/Hibernate
 * Using Spring Boot auto-configuration for PostgreSQL
 */
@Configuration
@EnableTransactionManagement
public class PersistenceConfig {

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }
}