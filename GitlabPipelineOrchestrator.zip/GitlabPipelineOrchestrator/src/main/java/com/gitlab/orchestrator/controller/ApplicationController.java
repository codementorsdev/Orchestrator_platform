package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.ApiResponse;
import com.gitlab.orchestrator.dto.ApplicationDto;
import com.gitlab.orchestrator.model.Application;
import com.gitlab.orchestrator.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for application operations.
 */
@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

    /**
     * Get all applications.
     *
     * @return list of all applications
     */
    @GetMapping
    public ResponseEntity<List<ApplicationDto>> getAllApplications() {
        List<Application> applications = applicationService.getAllApplications();
        
        List<ApplicationDto> applicationDtos = applications.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(applicationDtos);
    }

    /**
     * Get an application by ID.
     *
     * @param id the application ID
     * @return the application
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApplicationDto> getApplicationById(@PathVariable Long id) {
        Application application = applicationService.getApplicationById(id);
        return ResponseEntity.ok(convertToDto(application));
    }

    /**
     * Create a new application.
     *
     * @param applicationDto the application to create
     * @param workflowId the ID of the workflow this application belongs to
     * @return the created application
     */
    @PostMapping
    public ResponseEntity<ApplicationDto> createApplication(
            @Valid @RequestBody ApplicationDto applicationDto,
            @RequestParam Long workflowId) {
        
        Application application = convertToEntity(applicationDto);
        Application createdApplication = applicationService.createApplication(application, workflowId);
        
        return ResponseEntity.ok(convertToDto(createdApplication));
    }

    /**
     * Update an existing application.
     *
     * @param id the application ID
     * @param applicationDto the updated application details
     * @return the updated application
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApplicationDto> updateApplication(
            @PathVariable Long id,
            @Valid @RequestBody ApplicationDto applicationDto) {
        
        Application application = convertToEntity(applicationDto);
        Application updatedApplication = applicationService.updateApplication(id, application);
        
        return ResponseEntity.ok(convertToDto(updatedApplication));
    }

    /**
     * Delete an application.
     *
     * @param id the application ID
     * @return success message
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse> deleteApplication(@PathVariable Long id) {
        applicationService.deleteApplication(id);
        return ResponseEntity.ok(new ApiResponse(true, "Application deleted successfully"));
    }

    /**
     * Get all applications for a specific workflow.
     *
     * @param workflowId the workflow ID
     * @return list of applications
     */
    @GetMapping("/workflow/{workflowId}")
    public ResponseEntity<List<ApplicationDto>> getApplicationsByWorkflow(@PathVariable Long workflowId) {
        List<Application> applications = applicationService.getApplicationsByWorkflow(workflowId);
        
        List<ApplicationDto> applicationDtos = applications.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(applicationDtos);
    }

    /**
     * Convert an Application entity to an ApplicationDto.
     *
     * @param application the application entity
     * @return the application DTO
     */
    private ApplicationDto convertToDto(Application application) {
        ApplicationDto applicationDto = new ApplicationDto();
        applicationDto.setId(application.getId());
        applicationDto.setName(application.getName());
        applicationDto.setDescription(application.getDescription());
        applicationDto.setGitlabProjectId(application.getGitlabProjectId());
        applicationDto.setGitlabBranch(application.getGitlabBranch());
        applicationDto.setExecutionOrder(application.getExecutionOrder());
        applicationDto.setWorkflowId(application.getWorkflow().getId());
        applicationDto.setWorkflowName(application.getWorkflow().getName());
        applicationDto.setCreatedAt(application.getCreatedAt());
        applicationDto.setUpdatedAt(application.getUpdatedAt());
        
        return applicationDto;
    }

    /**
     * Convert an ApplicationDto to an Application entity.
     *
     * @param applicationDto the application DTO
     * @return the application entity
     */
    private Application convertToEntity(ApplicationDto applicationDto) {
        Application application = new Application();
        application.setName(applicationDto.getName());
        application.setDescription(applicationDto.getDescription());
        application.setGitlabProjectId(applicationDto.getGitlabProjectId());
        application.setGitlabBranch(applicationDto.getGitlabBranch());
        application.setExecutionOrder(applicationDto.getExecutionOrder());
        
        return application;
    }
}
