package com.gitlab.orchestrator.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gitlab.orchestrator.dto.PipelineExecutionResponse;
import com.gitlab.orchestrator.service.PipelineExecutionService;

/**
 * REST controller for pipeline execution operations.
 */
@RestController
@RequestMapping("/api/executions")
public class PipelineExecutionController {
    
    private static final Logger logger = LoggerFactory.getLogger(PipelineExecutionController.class);
    
    private final PipelineExecutionService pipelineExecutionService;
    
    @Autowired
    public PipelineExecutionController(PipelineExecutionService pipelineExecutionService) {
        this.pipelineExecutionService = pipelineExecutionService;
    }
    
    /**
     * Start a new pipeline execution.
     *
     * @param sequenceId the pipeline sequence ID
     * @return the created pipeline execution
     */
    @PostMapping
    public ResponseEntity<PipelineExecutionResponse> startPipelineExecution(@RequestParam Long sequenceId) {
        logger.info("REST request to start pipeline execution for sequence ID: {}", sequenceId);
        PipelineExecutionResponse response = pipelineExecutionService.startPipelineExecution(sequenceId);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    /**
     * Get a pipeline execution by ID.
     *
     * @param id the pipeline execution ID
     * @return the pipeline execution
     */
    @GetMapping("/{id}")
    public ResponseEntity<PipelineExecutionResponse> getPipelineExecution(@PathVariable Long id) {
        logger.info("REST request to get pipeline execution with ID: {}", id);
        PipelineExecutionResponse response = pipelineExecutionService.getPipelineExecution(id);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get pipeline executions, optionally filtered by sequence ID.
     *
     * @param sequenceId optional sequence ID filter
     * @param active if true, return only active executions
     * @return list of pipeline executions
     */
    @GetMapping
    public ResponseEntity<List<PipelineExecutionResponse>> getPipelineExecutions(
            @RequestParam(required = false) Long sequenceId,
            @RequestParam(required = false, defaultValue = "false") boolean active) {
        
        List<PipelineExecutionResponse> responses;
        
        if (active) {
            logger.info("REST request to get active pipeline executions");
            responses = pipelineExecutionService.getActivePipelineExecutions();
        } else if (sequenceId != null) {
            logger.info("REST request to get pipeline executions for sequence ID: {}", sequenceId);
            responses = pipelineExecutionService.getPipelineExecutionsBySequence(sequenceId);
        } else {
            logger.info("REST request to get all pipeline executions");
            responses = pipelineExecutionService.getAllPipelineExecutions();
        }
        
        return ResponseEntity.ok(responses);
    }
    /**
     * Get recent pipeline executions for a specific sequence.
     *
     * @param sequenceId the pipeline sequence ID
     * @param limit maximum number of executions to return
     * @return list of recent pipeline executions
     */
    @GetMapping("/recent")
    public ResponseEntity<List<PipelineExecutionResponse>> getRecentPipelineExecutions(
            @RequestParam Long sequenceId,
            @RequestParam(defaultValue = "5") int limit) {
        
        logger.info("REST request to get recent pipeline executions for sequence ID: {} with limit: {}", sequenceId, limit);
        List<PipelineExecutionResponse> responses = pipelineExecutionService.getRecentPipelineExecutions(sequenceId, limit);
        return ResponseEntity.ok(responses);
    }
    
    
    /**
     * Cancel a pipeline execution.
     *
     * @param id the pipeline execution ID
     * @return the updated pipeline execution
     */
    @PostMapping("/{id}/cancel")
    public ResponseEntity<PipelineExecutionResponse> cancelPipelineExecution(@PathVariable Long id) {
        logger.info("REST request to cancel pipeline execution with ID: {}", id);
        PipelineExecutionResponse response = pipelineExecutionService.cancelPipelineExecution(id);
        return ResponseEntity.ok(response);
    }
}
