package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.ApiResponse;
import com.gitlab.orchestrator.dto.WorkflowDto;
import com.gitlab.orchestrator.exception.UnauthorizedException;
import com.gitlab.orchestrator.model.Role;
import com.gitlab.orchestrator.model.User;
import com.gitlab.orchestrator.model.Workflow;
import com.gitlab.orchestrator.service.UserService;
import com.gitlab.orchestrator.service.WorkflowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for workflow operations.
 */
@RestController
@RequestMapping("/api/workflows")
public class WorkflowController {

    @Autowired
    private WorkflowService workflowService;

    @Autowired
    private UserService userService;

    /**
     * Get all workflows.
     *
     * @return list of all workflows
     */
    @GetMapping
    public ResponseEntity<List<WorkflowDto>> getAllWorkflows() {
        List<Workflow> workflows = workflowService.getAllWorkflows();
        
        List<WorkflowDto> workflowDtos = workflows.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(workflowDtos);
    }

    /**
     * Get a workflow by ID.
     *
     * @param id the workflow ID
     * @return the workflow
     */
    @GetMapping("/{id}")
    public ResponseEntity<WorkflowDto> getWorkflowById(@PathVariable Long id) {
        Workflow workflow = workflowService.getWorkflowById(id);
        return ResponseEntity.ok(convertToDto(workflow));
    }

    /**
     * Create a new workflow.
     *
     * @param workflowDto the workflow to create
     * @return the created workflow
     */
    @PostMapping
    public ResponseEntity<WorkflowDto> createWorkflow(@Valid @RequestBody WorkflowDto workflowDto) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        User user = userService.getUserByUsername(username);
        
        Workflow workflow = convertToEntity(workflowDto);
        Workflow createdWorkflow = workflowService.createWorkflow(workflow, user);
        
        return ResponseEntity.ok(convertToDto(createdWorkflow));
    }

    /**
     * Update an existing workflow.
     *
     * @param id the workflow ID
     * @param workflowDto the updated workflow details
     * @return the updated workflow
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<WorkflowDto> updateWorkflow(@PathVariable Long id, @Valid @RequestBody WorkflowDto workflowDto) {
        Workflow workflow = convertToEntity(workflowDto);
        Workflow updatedWorkflow = workflowService.updateWorkflow(id, workflow);
        
        return ResponseEntity.ok(convertToDto(updatedWorkflow));
    }

    /**
     * Delete a workflow.
     *
     * @param id the workflow ID
     * @return success message
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<ApiResponse> deleteWorkflow(@PathVariable Long id) {
        workflowService.deleteWorkflow(id);
        return ResponseEntity.ok(new ApiResponse(true, "Workflow deleted successfully"));
    }

    /**
     * Execute a workflow.
     *
     * @param id the workflow ID
     * @return the updated workflow
     */
    @PostMapping("/{id}/execute")
    public ResponseEntity<WorkflowDto> executeWorkflow(@PathVariable Long id) {
        Workflow workflow = workflowService.executeWorkflow(id);
        return ResponseEntity.ok(convertToDto(workflow));
    }

    /**
     * Convert a Workflow entity to a WorkflowDto.
     *
     * @param workflow the workflow entity
     * @return the workflow DTO
     */
    private WorkflowDto convertToDto(Workflow workflow) {
        WorkflowDto workflowDto = new WorkflowDto();
        workflowDto.setId(workflow.getId());
        workflowDto.setName(workflow.getName());
        workflowDto.setDescription(workflow.getDescription());
        workflowDto.setStatus(workflow.getStatus().name());
        workflowDto.setCreatedBy(workflow.getCreatedBy() != null ? workflow.getCreatedBy().getUsername() : null);
        workflowDto.setCreatedAt(workflow.getCreatedAt());
        workflowDto.setUpdatedAt(workflow.getUpdatedAt());
        
        return workflowDto;
    }

    /**
     * Convert a WorkflowDto to a Workflow entity.
     *
     * @param workflowDto the workflow DTO
     * @return the workflow entity
     */
    private Workflow convertToEntity(WorkflowDto workflowDto) {
        Workflow workflow = new Workflow();
        workflow.setName(workflowDto.getName());
        workflow.setDescription(workflowDto.getDescription());
        
        if (workflowDto.getStatus() != null) {
            try {
                workflow.setStatus(Workflow.WorkflowStatus.valueOf(workflowDto.getStatus()));
            } catch (IllegalArgumentException e) {
                workflow.setStatus(Workflow.WorkflowStatus.CREATED);
            }
        }
        
        return workflow;
    }
}
