package com.gitlab.orchestrator.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * DTO for PipelineExecution data.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PipelineExecutionDto {

    private Long id;

    private String gitlabPipelineId;

    private String status;

    private Long applicationId;

    private String applicationName;

    private Long workflowId;

    private String workflowName;

    private String logUrl;

    private Integer exitCode;

    private Date startedAt;

    private Date finishedAt;

    private Date createdAt;

    private Date updatedAt;
}
