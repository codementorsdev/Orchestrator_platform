package com.gitlab.orchestrator.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

/**
 * Entity representing a single step within a pipeline sequence.
 */
@Entity
@Table(name = "pipeline_steps")
public class PipelineStep {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(name = "step_order", nullable = false)
    private Integer order;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "pipeline_config_id", referencedColumnName = "id")
    private PipelineConfig pipelineConfig;

    @ManyToOne
    @JoinColumn(name = "pipeline_sequence_id")
    private PipelineSequence pipelineSequence;

    // Default constructor
    public PipelineStep() {
    }

    // Constructor with parameters
    public PipelineStep(String name, Integer order, PipelineConfig pipelineConfig) {
        this.name = name;
        this.order = order;
        this.pipelineConfig = pipelineConfig;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public PipelineConfig getPipelineConfig() {
        return pipelineConfig;
    }

    public void setPipelineConfig(PipelineConfig pipelineConfig) {
        this.pipelineConfig = pipelineConfig;
    }

    public PipelineSequence getPipelineSequence() {
        return pipelineSequence;
    }

    public void setPipelineSequence(PipelineSequence pipelineSequence) {
        this.pipelineSequence = pipelineSequence;
    }

    @Override
    public String toString() {
        return "PipelineStep{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", order=" + order +
                ", pipelineConfig=" + pipelineConfig +
                '}';
    }
}
