package com.gitlab.orchestrator.repository;

import com.gitlab.orchestrator.model.Application;
import com.gitlab.orchestrator.model.PipelineExecution;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for PipelineExecution entity.
 */
@Repository
public interface PipelineExecutionRepository extends JpaRepository<PipelineExecution, Long> {
    
    /**
     * Find all pipeline executions for a specific application.
     *
     * @param application the application to find executions for
     * @return a list of pipeline executions
     */
    List<PipelineExecution> findByApplication(Application application);
    
    /**
     * Find pipeline executions by status.
     *
     * @param status the status to filter by
     * @return a list of pipeline executions with the specified status
     */
    List<PipelineExecution> findByStatus(PipelineExecution.PipelineStatus status);
    
    /**
     * Find the latest pipeline execution for a specific application.
     *
     * @param applicationId the ID of the application
     * @return the latest pipeline execution
     */
    @Query("SELECT p FROM PipelineExecution p WHERE p.application.id = :applicationId ORDER BY p.createdAt DESC")
    List<PipelineExecution> findLatestByApplicationId(Long applicationId);
    
    /**
     * Find a pipeline execution by GitLab pipeline ID.
     *
     * @param gitlabPipelineId the GitLab pipeline ID
     * @return an Optional containing the pipeline execution if found
     */
    Optional<PipelineExecution> findByGitlabPipelineId(String gitlabPipelineId);
}
