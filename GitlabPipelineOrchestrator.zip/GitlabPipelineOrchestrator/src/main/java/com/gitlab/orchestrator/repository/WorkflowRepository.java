package com.gitlab.orchestrator.repository;

import com.gitlab.orchestrator.model.User;
import com.gitlab.orchestrator.model.Workflow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for Workflow entity.
 */
@Repository
public interface WorkflowRepository extends JpaRepository<Workflow, Long> {
    
    /**
     * Find all workflows created by a specific user.
     *
     * @param createdBy the user who created the workflows
     * @return a list of workflows
     */
    List<Workflow> findByCreatedBy(User createdBy);
    
    /**
     * Find workflows by status.
     *
     * @param status the workflow status to filter by
     * @return a list of workflows with the specified status
     */
    List<Workflow> findByStatus(Workflow.WorkflowStatus status);
    
    /**
     * Find workflows by name containing the specified string (case-insensitive).
     *
     * @param name the name substring to search for
     * @return a list of matching workflows
     */
    List<Workflow> findByNameContainingIgnoreCase(String name);
}
