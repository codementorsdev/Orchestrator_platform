package com.gitlab.orchestrator.service;

import com.gitlab.orchestrator.model.PipelineExecution;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Pipeline;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Service for integrating with GitLab's API.
 */
@Service
public class GitlabIntegrationService {

    private static final Logger logger = LoggerFactory.getLogger(GitlabIntegrationService.class);

    @Value("${gitlab.api.url}")
    private String gitlabApiUrl;

    @Value("${gitlab.api.token}")
    private String gitlabApiToken;

    /**
     * Trigger a pipeline in GitLab.
     *
     * @param projectId the GitLab project ID
     * @param ref the branch or tag reference
     * @return the pipeline ID
     * @throws GitLabApiException if there is an error communicating with GitLab
     */
    public String triggerPipeline(String projectId, String ref) throws GitLabApiException {
        GitLabApi gitLabApi = new GitLabApi(gitlabApiUrl, gitlabApiToken);
        
        logger.info("Triggering pipeline for project {} on branch {}", projectId, ref);
        
        Pipeline pipeline = gitLabApi.getPipelineApi().createPipeline(projectId, ref);
        
        logger.info("Pipeline created with ID: {}", pipeline.getId());
        
        return String.valueOf(pipeline.getId());
    }

    /**
     * Monitor a pipeline until it completes.
     *
     * @param projectId the GitLab project ID
     * @param pipelineId the pipeline ID
     * @return the final pipeline status
     */
    public PipelineExecution.PipelineStatus monitorPipeline(String projectId, String pipelineId) {
        GitLabApi gitLabApi = new GitLabApi(gitlabApiUrl, gitlabApiToken);
        
        try {
            logger.info("Monitoring pipeline {} for project {}", pipelineId, projectId);
            
            // Poll the GitLab API until the pipeline completes
            boolean isComplete = false;
            PipelineExecution.PipelineStatus finalStatus = PipelineExecution.PipelineStatus.PENDING;
            
            while (!isComplete) {
                Pipeline pipeline = gitLabApi.getPipelineApi().getPipeline(projectId, Long.parseLong(pipelineId));
                
                switch (pipeline.getStatus()) {
                    case RUNNING:
                        finalStatus = PipelineExecution.PipelineStatus.RUNNING;
                        break;
                    case SUCCESS:
                        finalStatus = PipelineExecution.PipelineStatus.SUCCESS;
                        isComplete = true;
                        break;
                    case FAILED:
                        finalStatus = PipelineExecution.PipelineStatus.FAILED;
                        isComplete = true;
                        break;
                    case CANCELED:
                        finalStatus = PipelineExecution.PipelineStatus.CANCELLED;
                        isComplete = true;
                        break;
                    case SKIPPED:
                        finalStatus = PipelineExecution.PipelineStatus.SKIPPED;
                        isComplete = true;
                        break;
                    default:
                        // For any other status, keep polling
                        break;
                }
                
                if (!isComplete) {
                    // Wait before polling again
                    Thread.sleep(10000); // 10 seconds
                }
            }
            
            logger.info("Pipeline {} completed with status: {}", pipelineId, finalStatus);
            
            return finalStatus;
            
        } catch (Exception e) {
            logger.error("Error monitoring pipeline: ", e);
            return PipelineExecution.PipelineStatus.FAILED;
        }
    }

    /**
     * Cancel a pipeline in GitLab.
     *
     * @param projectId the GitLab project ID
     * @param pipelineId the pipeline ID
     * @return true if the pipeline was successfully cancelled
     */
    public boolean cancelPipeline(String projectId, String pipelineId) {
        GitLabApi gitLabApi = new GitLabApi(gitlabApiUrl, gitlabApiToken);
        
        try {
            logger.info("Cancelling pipeline {} for project {}", pipelineId, projectId);
            
            // Use the cancel pipeline job API 
            Pipeline cancelledPipeline = gitLabApi.getPipelineApi().cancelPipelineJobs(projectId, Long.parseLong(pipelineId));
            
            return cancelledPipeline != null;
        } catch (Exception e) {
            logger.error("Error cancelling pipeline: ", e);
            return false;
        }
    }
}
