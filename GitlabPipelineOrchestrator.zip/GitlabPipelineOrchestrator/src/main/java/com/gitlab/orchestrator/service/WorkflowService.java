package com.gitlab.orchestrator.service;

import com.gitlab.orchestrator.exception.ResourceNotFoundException;
import com.gitlab.orchestrator.model.Application;
import com.gitlab.orchestrator.model.User;
import com.gitlab.orchestrator.model.Workflow;
import com.gitlab.orchestrator.repository.ApplicationRepository;
import com.gitlab.orchestrator.repository.WorkflowRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Service for workflow management.
 */
@Service
public class WorkflowService {

    @Autowired
    private WorkflowRepository workflowRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private PipelineService pipelineService;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    /**
     * Get all workflows.
     *
     * @return a list of all workflows
     */
    @Transactional(readOnly = true)
    public List<Workflow> getAllWorkflows() {
        return workflowRepository.findAll();
    }

    /**
     * Get a workflow by ID.
     *
     * @param id the workflow ID
     * @return the workflow
     * @throws ResourceNotFoundException if the workflow is not found
     */
    @Transactional(readOnly = true)
    public Workflow getWorkflowById(Long id) {
        return workflowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Workflow not found with id: " + id));
    }

    /**
     * Create a new workflow.
     *
     * @param workflow the workflow to create
     * @param user the user creating the workflow
     * @return the created workflow
     */
    @Transactional
    public Workflow createWorkflow(Workflow workflow, User user) {
        workflow.setCreatedBy(user);
        workflow.setStatus(Workflow.WorkflowStatus.CREATED);
        return workflowRepository.save(workflow);
    }

    /**
     * Update an existing workflow.
     *
     * @param id the workflow ID
     * @param updatedWorkflow the updated workflow details
     * @return the updated workflow
     * @throws ResourceNotFoundException if the workflow is not found
     */
    @Transactional
    public Workflow updateWorkflow(Long id, Workflow updatedWorkflow) {
        Workflow workflow = getWorkflowById(id);
        
        workflow.setName(updatedWorkflow.getName());
        workflow.setDescription(updatedWorkflow.getDescription());
        
        return workflowRepository.save(workflow);
    }

    /**
     * Delete a workflow by ID.
     *
     * @param id the workflow ID
     * @throws ResourceNotFoundException if the workflow is not found
     */
    @Transactional
    public void deleteWorkflow(Long id) {
        if (!workflowRepository.existsById(id)) {
            throw new ResourceNotFoundException("Workflow not found with id: " + id);
        }
        workflowRepository.deleteById(id);
    }

    /**
     * Get workflows created by a specific user.
     *
     * @param user the user who created the workflows
     * @return a list of workflows
     */
    @Transactional(readOnly = true)
    public List<Workflow> getWorkflowsByUser(User user) {
        return workflowRepository.findByCreatedBy(user);
    }

    /**
     * Execute a workflow by starting the first application's pipeline.
     *
     * @param workflowId the ID of the workflow to execute
     * @return the updated workflow
     * @throws ResourceNotFoundException if the workflow is not found
     */
    @Transactional
    public Workflow executeWorkflow(Long workflowId) {
        Workflow workflow = getWorkflowById(workflowId);
        
        // Check if the workflow is already running
        if (workflow.getStatus() == Workflow.WorkflowStatus.RUNNING) {
            return workflow;
        }
        
        // Update workflow status
        workflow.setStatus(Workflow.WorkflowStatus.RUNNING);
        workflowRepository.save(workflow);
        
        // Notify subscribers about workflow status change
        messagingTemplate.convertAndSend("/topic/workflow/" + workflowId, workflow);
        
        // Get applications ordered by execution order
        List<Application> applications = applicationRepository.findByWorkflowOrderByExecutionOrderAsc(workflow);
        
        if (applications.isEmpty()) {
            workflow.setStatus(Workflow.WorkflowStatus.COMPLETED);
            return workflowRepository.save(workflow);
        }
        
        // Start the first application's pipeline
        Application firstApp = applications.get(0);
        pipelineService.executePipeline(firstApp.getId());
        
        return workflow;
    }

    /**
     * Update the status of a workflow based on pipeline execution results.
     *
     * @param workflowId the ID of the workflow to update
     * @param status the new status
     * @return the updated workflow
     */
    @Transactional
    public Workflow updateWorkflowStatus(Long workflowId, Workflow.WorkflowStatus status) {
        Workflow workflow = getWorkflowById(workflowId);
        workflow.setStatus(status);
        Workflow updatedWorkflow = workflowRepository.save(workflow);
        
        // Notify subscribers about workflow status change
        messagingTemplate.convertAndSend("/topic/workflow/" + workflowId, updatedWorkflow);
        
        return updatedWorkflow;
    }
}
