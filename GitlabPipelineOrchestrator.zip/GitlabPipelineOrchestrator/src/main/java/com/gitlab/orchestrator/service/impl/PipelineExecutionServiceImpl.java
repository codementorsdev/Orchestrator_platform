package com.gitlab.orchestrator.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.gitlab4j.api.models.Pipeline;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gitlab.orchestrator.dto.PipelineExecutionResponse;
import com.gitlab.orchestrator.exception.GitLabApiException;
import com.gitlab.orchestrator.exception.ResourceNotFoundException;
import com.gitlab.orchestrator.model.PipelineExecution;
import com.gitlab.orchestrator.model.PipelineSequence;
import com.gitlab.orchestrator.model.PipelineStep;
import com.gitlab.orchestrator.model.PipelineStepExecution;
import com.gitlab.orchestrator.model.enums.ExecutionStatus;
import com.gitlab.orchestrator.repository.PipelineExecutionRepository;
import com.gitlab.orchestrator.repository.PipelineSequenceRepository;
import com.gitlab.orchestrator.repository.PipelineStepExecutionRepository;
import com.gitlab.orchestrator.service.GitLabService;
import com.gitlab.orchestrator.service.PipelineExecutionService;

/**
 * Implementation of the PipelineExecutionService interface.
 */
@Service
public class PipelineExecutionServiceImpl implements PipelineExecutionService {
    
    private static final Logger logger = LoggerFactory.getLogger(PipelineExecutionServiceImpl.class);
    
    private final PipelineExecutionRepository pipelineExecutionRepository;
    private final PipelineSequenceRepository pipelineSequenceRepository;
    private final PipelineStepExecutionRepository pipelineStepExecutionRepository;
    private final GitLabService gitLabService;
    
    @Autowired
    public PipelineExecutionServiceImpl(
            PipelineExecutionRepository pipelineExecutionRepository,
            PipelineSequenceRepository pipelineSequenceRepository,
            PipelineStepExecutionRepository pipelineStepExecutionRepository,
            GitLabService gitLabService) {
        this.pipelineExecutionRepository = pipelineExecutionRepository;
        this.pipelineSequenceRepository = pipelineSequenceRepository;
        this.pipelineStepExecutionRepository = pipelineStepExecutionRepository;
        this.gitLabService = gitLabService;
    }
    
    @Override
    @Transactional
    public PipelineExecutionResponse startPipelineExecution(Long pipelineSequenceId) {
        logger.info("Starting pipeline execution for sequence ID: {}", pipelineSequenceId);
        
        PipelineSequence pipelineSequence = pipelineSequenceRepository.findById(pipelineSequenceId)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline sequence not found with ID: " + pipelineSequenceId));
        
        if (pipelineSequence.getSteps().isEmpty()) {
            throw new IllegalStateException("Cannot start execution: Pipeline sequence has no steps");
        }
        
        // Create pipeline execution
        PipelineExecution execution = new PipelineExecution(pipelineSequence);
        execution.setStartedAt(LocalDateTime.now());
        execution.setStatus(ExecutionStatus.PENDING);
        execution.setCurrentStep(0);
        
        // Create step executions
        for (PipelineStep step : pipelineSequence.getSteps()) {
            PipelineStepExecution stepExecution = new PipelineStepExecution(step);
            stepExecution.setStatus(ExecutionStatus.PENDING);
            execution.addStepExecution(stepExecution);
        }
        
        PipelineExecution savedExecution = pipelineExecutionRepository.save(execution);
        logger.info("Pipeline execution created with ID: {}", savedExecution.getId());
        
        return convertToResponse(savedExecution);
    }
    
    @Override
    @Transactional(readOnly = true)
    public PipelineExecutionResponse getPipelineExecution(Long id) {
        logger.info("Getting pipeline execution with ID: {}", id);
        
        PipelineExecution execution = pipelineExecutionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline execution not found with ID: " + id));
        
        return convertToResponse(execution);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PipelineExecutionResponse> getAllPipelineExecutions() {
        logger.info("Getting all pipeline executions");
        
        List<PipelineExecution> executions = pipelineExecutionRepository.findAll();
        
        return executions.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PipelineExecutionResponse> getPipelineExecutionsBySequence(Long pipelineSequenceId) {
        logger.info("Getting pipeline executions for sequence ID: {}", pipelineSequenceId);
        
        if (!pipelineSequenceRepository.existsById(pipelineSequenceId)) {
            throw new ResourceNotFoundException("Pipeline sequence not found with ID: " + pipelineSequenceId);
        }
        
        List<PipelineExecution> executions = pipelineExecutionRepository.findByPipelineSequenceId(pipelineSequenceId);
        
        return executions.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PipelineExecutionResponse> getRecentPipelineExecutions(Long pipelineSequenceId, int limit) {
        logger.info("Getting recent pipeline executions for sequence ID: {} with limit: {}", pipelineSequenceId, limit);
        
        if (!pipelineSequenceRepository.existsById(pipelineSequenceId)) {
            throw new ResourceNotFoundException("Pipeline sequence not found with ID: " + pipelineSequenceId);
        }
        
        List<PipelineExecution> executions = pipelineExecutionRepository.findRecentExecutions(pipelineSequenceId);
        
        // Apply limit in memory since we cannot use it in the query
        List<PipelineExecution> limitedExecutions = executions.stream()
                .limit(limit)
                .collect(Collectors.toList());
        
        return limitedExecutions.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PipelineExecutionResponse> getActivePipelineExecutions() {
        logger.info("Getting active pipeline executions");
        
        List<PipelineExecution> executions = pipelineExecutionRepository.findActiveExecutions();
        
        return executions.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional
    public PipelineExecutionResponse cancelPipelineExecution(Long id) {
        logger.info("Canceling pipeline execution with ID: {}", id);
        
        PipelineExecution execution = pipelineExecutionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline execution not found with ID: " + id));
        
        if (execution.getStatus() != ExecutionStatus.RUNNING && execution.getStatus() != ExecutionStatus.PENDING) {
            throw new IllegalStateException("Cannot cancel execution: Execution is not running or pending");
        }
        
        // Cancel any running GitLab pipeline
        PipelineStepExecution currentStepExecution = null;
        if (execution.getCurrentStep() < execution.getStepExecutions().size()) {
            currentStepExecution = execution.getStepExecutions().get(execution.getCurrentStep());
            
            if (currentStepExecution.getStatus() == ExecutionStatus.RUNNING && 
                currentStepExecution.getGitlabPipelineId() != null) {
                try {
                    gitLabService.cancelPipeline(
                            currentStepExecution.getGitlabProjectId(),
                            currentStepExecution.getGitlabPipelineId());
                    
                    currentStepExecution.setStatus(ExecutionStatus.CANCELED);
                    currentStepExecution.setCompletedAt(LocalDateTime.now());
                } catch (GitLabApiException e) {
                    logger.warn("Failed to cancel GitLab pipeline: {}", e.getMessage());
                    // Continue with cancellation even if GitLab API call fails
                }
            } else {
                currentStepExecution.setStatus(ExecutionStatus.CANCELED);
                currentStepExecution.setCompletedAt(LocalDateTime.now());
            }
        }
        
        // Set remaining pending steps to canceled
        for (PipelineStepExecution stepExecution : execution.getStepExecutions()) {
            if (stepExecution.getStatus() == ExecutionStatus.PENDING) {
                stepExecution.setStatus(ExecutionStatus.CANCELED);
            }
        }
        
        // Update execution status
        execution.setStatus(ExecutionStatus.CANCELED);
        execution.setCompletedAt(LocalDateTime.now());
        
        PipelineExecution savedExecution = pipelineExecutionRepository.save(execution);
        logger.info("Pipeline execution canceled with ID: {}", savedExecution.getId());
        
        return convertToResponse(savedExecution);
    }
    
    @Override
    @Transactional
    public void processNextStep(Long executionId) {
        logger.info("Processing next step for execution ID: {}", executionId);
        
        PipelineExecution execution = pipelineExecutionRepository.findById(executionId)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline execution not found with ID: " + executionId));
        
        // Handle invalid states
        if (execution.getStatus() != ExecutionStatus.PENDING && execution.getStatus() != ExecutionStatus.RUNNING) {
            logger.info("Execution is not pending or running, skipping next step");
            return;
        }
        
        List<PipelineStepExecution> stepExecutions = execution.getStepExecutions();
        
        // If all steps are done, mark execution as complete
        if (execution.getCurrentStep() >= stepExecutions.size()) {
            execution.setStatus(ExecutionStatus.SUCCESS);
            execution.setCompletedAt(LocalDateTime.now());
            pipelineExecutionRepository.save(execution);
            logger.info("All steps completed, marking execution as successful");
            return;
        }
        
        // Get current step
        PipelineStepExecution currentStep = stepExecutions.get(execution.getCurrentStep());
        PipelineStep pipelineStep = execution.getPipelineSequence().getSteps()
                .stream()
                .filter(step -> step.getId().equals(currentStep.getStepId()))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline step not found with ID: " + currentStep.getStepId()));
        
        // Execute current step if pending
        if (currentStep.getStatus() == ExecutionStatus.PENDING) {
            logger.info("Executing step: {} (order: {})", pipelineStep.getName(), pipelineStep.getOrder());
            
            try {
                // Start pipeline in GitLab
                Pipeline gitlabPipeline = gitLabService.createPipeline(
                        pipelineStep.getPipelineConfig().getProjectId(),
                        pipelineStep.getPipelineConfig().getRef() != null ? 
                                pipelineStep.getPipelineConfig().getRef() : 
                                pipelineStep.getPipelineConfig().getBranch(),
                        pipelineStep.getPipelineConfig().getVariables());
                
                // Update step execution
                currentStep.setGitlabPipelineId(gitlabPipeline.getId());
                currentStep.setStartedAt(LocalDateTime.now());
                currentStep.setStatus(ExecutionStatus.RUNNING);
                
                // Update execution status
                execution.setStatus(ExecutionStatus.RUNNING);
                
                pipelineExecutionRepository.save(execution);
                logger.info("Step execution started with GitLab pipeline ID: {}", gitlabPipeline.getId());
            } catch (GitLabApiException e) {
                logger.error("Failed to start GitLab pipeline: {}", e.getMessage(), e);
                
                // Mark step as failed
                currentStep.setStatus(ExecutionStatus.FAILED);
                currentStep.setErrorMessage("Failed to start GitLab pipeline: " + e.getMessage());
                currentStep.setCompletedAt(LocalDateTime.now());
                
                // Mark execution as failed
                execution.setStatus(ExecutionStatus.FAILED);
                execution.setErrorMessage("Failed to start GitLab pipeline for step: " + pipelineStep.getName());
                execution.setCompletedAt(LocalDateTime.now());
                
                pipelineExecutionRepository.save(execution);
            }
        }
        // If current step is running, check its status
        else if (currentStep.getStatus() == ExecutionStatus.RUNNING) {
            logger.info("Checking status of running step: {} (order: {})", pipelineStep.getName(), pipelineStep.getOrder());
            
            try {
                Pipeline gitlabPipeline = gitLabService.getPipeline(
                        currentStep.getGitlabProjectId(),
                        currentStep.getGitlabPipelineId());
                
                // If pipeline is complete, update step status and move to next step
                if (gitLabService.isPipelineComplete(gitlabPipeline)) {
                    boolean isSuccess = gitLabService.isPipelineSuccessful(gitlabPipeline);
                    
                    currentStep.setStatus(isSuccess ? ExecutionStatus.SUCCESS : ExecutionStatus.FAILED);
                    currentStep.setCompletedAt(LocalDateTime.now());
                    
                    if (!isSuccess) {
                        currentStep.setErrorMessage("GitLab pipeline failed with status: " + gitlabPipeline.getStatus());
                        
                        // Mark execution as failed
                        execution.setStatus(ExecutionStatus.FAILED);
                        execution.setErrorMessage("Step failed: " + pipelineStep.getName());
                        execution.setCompletedAt(LocalDateTime.now());
                    } else {
                        // Move to next step
                        execution.setCurrentStep(execution.getCurrentStep() + 1);
                        
                        // If we've reached the end, mark as successful
                        if (execution.getCurrentStep() >= stepExecutions.size()) {
                            execution.setStatus(ExecutionStatus.SUCCESS);
                            execution.setCompletedAt(LocalDateTime.now());
                        }
                    }
                    
                    pipelineExecutionRepository.save(execution);
                    logger.info("Step completed with status: {}", currentStep.getStatus());
                } else {
                    logger.info("GitLab pipeline still running with status: {}", gitlabPipeline.getStatus());
                }
            } catch (GitLabApiException e) {
                logger.error("Failed to check GitLab pipeline status: {}", e.getMessage(), e);
                
                // We don't mark the step as failed here, as the GitLab API issue might be temporary
            }
        }
    }
    
    @Override
    @Transactional
    public void updateRunningPipelineStatuses() {
        logger.info("Updating status of running pipeline step executions");
        
        List<PipelineStepExecution> runningStepExecutions = pipelineStepExecutionRepository.findByStatus(ExecutionStatus.RUNNING);
        
        for (PipelineStepExecution stepExecution : runningStepExecutions) {
            if (stepExecution.getGitlabPipelineId() == null || stepExecution.getGitlabProjectId() == null) {
                continue;
            }
            
            try {
                Pipeline gitlabPipeline = gitLabService.getPipeline(
                        stepExecution.getGitlabProjectId(),
                        stepExecution.getGitlabPipelineId());
                
                if (gitLabService.isPipelineComplete(gitlabPipeline)) {
                    boolean isSuccess = gitLabService.isPipelineSuccessful(gitlabPipeline);
                    
                    stepExecution.setStatus(isSuccess ? ExecutionStatus.SUCCESS : ExecutionStatus.FAILED);
                    stepExecution.setCompletedAt(LocalDateTime.now());
                    
                    if (!isSuccess) {
                        stepExecution.setErrorMessage("GitLab pipeline failed with status: " + gitlabPipeline.getStatus());
                    }
                    
                    PipelineExecution execution = stepExecution.getPipelineExecution();
                    
                    // If this is the current step, update the execution
                    if (execution.getCurrentStep() == stepExecution.getStepOrder()) {
                        if (isSuccess) {
                            // Move to next step
                            execution.setCurrentStep(execution.getCurrentStep() + 1);
                            
                            // If we've reached the end, mark as successful
                            if (execution.getCurrentStep() >= execution.getStepExecutions().size()) {
                                execution.setStatus(ExecutionStatus.SUCCESS);
                                execution.setCompletedAt(LocalDateTime.now());
                            }
                        } else {
                            // Mark execution as failed
                            execution.setStatus(ExecutionStatus.FAILED);
                            execution.setErrorMessage("Step failed: " + stepExecution.getStepName());
                            execution.setCompletedAt(LocalDateTime.now());
                        }
                        
                        pipelineExecutionRepository.save(execution);
                    }
                    
                    pipelineStepExecutionRepository.save(stepExecution);
                    logger.info("Updated step execution status to: {}", stepExecution.getStatus());
                } else {
                    logger.debug("GitLab pipeline still running with status: {}", gitlabPipeline.getStatus());
                }
            } catch (GitLabApiException e) {
                logger.error("Failed to check GitLab pipeline status: {}", e.getMessage(), e);
                
                // We don't mark the step as failed here, as the GitLab API issue might be temporary
            }
        }
    }
    
    /**
     * Convert a PipelineExecution entity to a PipelineExecutionResponse DTO.
     */
    private PipelineExecutionResponse convertToResponse(PipelineExecution execution) {
        PipelineExecutionResponse response = new PipelineExecutionResponse();
        response.setId(execution.getId());
        response.setPipelineSequenceId(execution.getPipelineSequence().getId());
        response.setPipelineSequenceName(execution.getPipelineSequence().getName());
        response.setStatus(execution.getStatus());
        response.setStartedAt(execution.getStartedAt());
        response.setCompletedAt(execution.getCompletedAt());
        response.setCurrentStep(execution.getCurrentStep());
        response.setErrorMessage(execution.getErrorMessage());
        
        List<PipelineExecutionResponse.PipelineStepExecutionResponse> stepResponses = execution.getStepExecutions().stream()
                .map(step -> {
                    PipelineExecutionResponse.PipelineStepExecutionResponse stepResponse = 
                            new PipelineExecutionResponse.PipelineStepExecutionResponse();
                    stepResponse.setId(step.getId());
                    stepResponse.setStepName(step.getStepName());
                    stepResponse.setStepOrder(step.getStepOrder());
                    stepResponse.setStatus(step.getStatus());
                    stepResponse.setGitlabProjectId(step.getGitlabProjectId());
                    stepResponse.setGitlabPipelineId(step.getGitlabPipelineId());
                    stepResponse.setStartedAt(step.getStartedAt());
                    stepResponse.setCompletedAt(step.getCompletedAt());
                    stepResponse.setErrorMessage(step.getErrorMessage());
                    return stepResponse;
                })
                .collect(Collectors.toList());
        
        response.setStepExecutions(stepResponses);
        
        return response;
    }
}
