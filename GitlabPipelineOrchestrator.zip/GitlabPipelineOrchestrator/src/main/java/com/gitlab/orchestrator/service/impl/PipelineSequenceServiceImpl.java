package com.gitlab.orchestrator.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gitlab.orchestrator.dto.PipelineSequenceRequest;
import com.gitlab.orchestrator.dto.PipelineSequenceResponse;
import com.gitlab.orchestrator.exception.ResourceNotFoundException;
import com.gitlab.orchestrator.model.PipelineConfig;
import com.gitlab.orchestrator.model.PipelineSequence;
import com.gitlab.orchestrator.model.PipelineStep;
import com.gitlab.orchestrator.repository.PipelineSequenceRepository;
import com.gitlab.orchestrator.service.PipelineSequenceService;

/**
 * Implementation of the PipelineSequenceService interface.
 */
@Service
public class PipelineSequenceServiceImpl implements PipelineSequenceService {
    
    private static final Logger logger = LoggerFactory.getLogger(PipelineSequenceServiceImpl.class);
    
    private final PipelineSequenceRepository pipelineSequenceRepository;
    
    @Autowired
    public PipelineSequenceServiceImpl(PipelineSequenceRepository pipelineSequenceRepository) {
        this.pipelineSequenceRepository = pipelineSequenceRepository;
    }
    
    @Override
    @Transactional
    public PipelineSequenceResponse createPipelineSequence(PipelineSequenceRequest request) {
        logger.info("Creating pipeline sequence: {}", request.getName());
        
        PipelineSequence pipelineSequence = new PipelineSequence();
        pipelineSequence.setName(request.getName());
        pipelineSequence.setDescription(request.getDescription());
        pipelineSequence.setCreatedAt(LocalDateTime.now());
        pipelineSequence.setUpdatedAt(LocalDateTime.now());
        
        // Create steps
        if (request.getSteps() != null) {
            for (PipelineSequenceRequest.PipelineStepRequest stepRequest : request.getSteps()) {
                PipelineConfig config = new PipelineConfig();
                config.setProjectId(stepRequest.getPipelineConfig().getProjectId());
                config.setBranch(stepRequest.getPipelineConfig().getBranch());
                config.setRef(stepRequest.getPipelineConfig().getRef());
                config.setVariables(stepRequest.getPipelineConfig().getVariables());
                
                PipelineStep step = new PipelineStep();
                step.setName(stepRequest.getName());
                step.setOrder(stepRequest.getOrder());
                step.setPipelineConfig(config);
                
                pipelineSequence.addStep(step);
            }
        }
        
        PipelineSequence savedSequence = pipelineSequenceRepository.save(pipelineSequence);
        logger.info("Pipeline sequence created with ID: {}", savedSequence.getId());
        
        return convertToResponse(savedSequence);
    }
    
    @Override
    @Transactional(readOnly = true)
    public PipelineSequenceResponse getPipelineSequence(Long id) {
        logger.info("Getting pipeline sequence with ID: {}", id);
        
        PipelineSequence pipelineSequence = pipelineSequenceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline sequence not found with ID: " + id));
        
        return convertToResponse(pipelineSequence);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PipelineSequenceResponse> getAllPipelineSequences() {
        logger.info("Getting all pipeline sequences");
        
        List<PipelineSequence> sequences = pipelineSequenceRepository.findAll();
        
        return sequences.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional
    public PipelineSequenceResponse updatePipelineSequence(Long id, PipelineSequenceRequest request) {
        logger.info("Updating pipeline sequence with ID: {}", id);
        
        PipelineSequence existingSequence = pipelineSequenceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline sequence not found with ID: " + id));
        
        existingSequence.setName(request.getName());
        existingSequence.setDescription(request.getDescription());
        existingSequence.setUpdatedAt(LocalDateTime.now());
        
        // Clear existing steps and add new ones
        existingSequence.getSteps().clear();
        
        if (request.getSteps() != null) {
            for (PipelineSequenceRequest.PipelineStepRequest stepRequest : request.getSteps()) {
                PipelineConfig config = new PipelineConfig();
                config.setProjectId(stepRequest.getPipelineConfig().getProjectId());
                config.setBranch(stepRequest.getPipelineConfig().getBranch());
                config.setRef(stepRequest.getPipelineConfig().getRef());
                config.setVariables(stepRequest.getPipelineConfig().getVariables());
                
                PipelineStep step = new PipelineStep();
                step.setName(stepRequest.getName());
                step.setOrder(stepRequest.getOrder());
                step.setPipelineConfig(config);
                
                existingSequence.addStep(step);
            }
        }
        
        PipelineSequence updatedSequence = pipelineSequenceRepository.save(existingSequence);
        logger.info("Pipeline sequence updated with ID: {}", updatedSequence.getId());
        
        return convertToResponse(updatedSequence);
    }
    
    @Override
    @Transactional
    public void deletePipelineSequence(Long id) {
        logger.info("Deleting pipeline sequence with ID: {}", id);
        
        if (!pipelineSequenceRepository.existsById(id)) {
            throw new ResourceNotFoundException("Pipeline sequence not found with ID: " + id);
        }
        
        pipelineSequenceRepository.deleteById(id);
        logger.info("Pipeline sequence deleted with ID: {}", id);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PipelineSequenceResponse> getPipelineSequencesByName(String name) {
        logger.info("Getting pipeline sequences by name containing: {}", name);
        
        List<PipelineSequence> sequences = pipelineSequenceRepository.findByNameContainingIgnoreCase(name);
        
        return sequences.stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    public PipelineSequenceResponse convertToResponse(PipelineSequence pipelineSequence) {
        PipelineSequenceResponse response = new PipelineSequenceResponse();
        response.setId(pipelineSequence.getId());
        response.setName(pipelineSequence.getName());
        response.setDescription(pipelineSequence.getDescription());
        response.setCreatedAt(pipelineSequence.getCreatedAt());
        response.setUpdatedAt(pipelineSequence.getUpdatedAt());
        
        List<PipelineSequenceResponse.PipelineStepResponse> stepResponses = pipelineSequence.getSteps().stream()
                .map(step -> {
                    PipelineSequenceResponse.PipelineStepResponse stepResponse = new PipelineSequenceResponse.PipelineStepResponse();
                    stepResponse.setId(step.getId());
                    stepResponse.setName(step.getName());
                    stepResponse.setOrder(step.getOrder());
                    
                    PipelineSequenceResponse.PipelineConfigResponse configResponse = new PipelineSequenceResponse.PipelineConfigResponse();
                    PipelineConfig config = step.getPipelineConfig();
                    if (config != null) {
                        configResponse.setId(config.getId());
                        configResponse.setProjectId(config.getProjectId());
                        configResponse.setBranch(config.getBranch());
                        configResponse.setRef(config.getRef());
                        configResponse.setVariables(config.getVariables());
                    }
                    
                    stepResponse.setPipelineConfig(configResponse);
                    return stepResponse;
                })
                .collect(Collectors.toList());
        
        response.setSteps(stepResponses);
        
        return response;
    }
}
