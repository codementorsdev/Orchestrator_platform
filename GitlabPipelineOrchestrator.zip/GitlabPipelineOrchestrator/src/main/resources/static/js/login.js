// Login JavaScript

// Variables
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');

// Login function
function login(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    if (!username || !password) {
        showError('Username and password are required');
        return;
    }
    
    const loginData = {
        username: username,
        password: password
    };
    
    fetch('/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(loginData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Login failed. Please check your credentials.');
        }
        return response.json();
    })
    .then(data => {
        // Store token and user info in localStorage
        localStorage.setItem('token', data.token);
        localStorage.setItem('username', data.username);
        localStorage.setItem('user_roles', JSON.stringify(data.roles));
        
        // Redirect to dashboard
        window.location.href = '/dashboard';
    })
    .catch(error => {
        console.error('Login error:', error);
        showError(error.message);
    });
}

// Show error message
function showError(message) {
    loginError.textContent = message;
    loginError.classList.remove('d-none');
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Check if already logged in
    if (localStorage.getItem('token')) {
        window.location.href = '/dashboard';
    }
    
    // Login form submission
    loginForm.addEventListener('submit', login);
});
