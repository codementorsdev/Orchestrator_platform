package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.ExecutionSequenceDTO;
import com.gitlab.orchestrator.dto.PipelineConfigDTO;
import com.gitlab.orchestrator.service.ExecutionSequenceService;
import com.gitlab.orchestrator.service.PipelineService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controller for managing pipeline configurations and execution sequences.
 * Handles both web UI and REST API endpoints.
 */
@Controller
@RequestMapping("/config")
public class ConfigurationController {

    private static final Logger logger = LoggerFactory.getLogger(ConfigurationController.class);
    
    private final PipelineService pipelineService;
    private final ExecutionSequenceService executionSequenceService;

    @Autowired
    public ConfigurationController(PipelineService pipelineService, 
                                  ExecutionSequenceService executionSequenceService) {
        this.pipelineService = pipelineService;
        this.executionSequenceService = executionSequenceService;
    }

    /**
     * Display the configuration page.
     *
     * @param model Model for Thymeleaf template
     * @return Configuration page template
     */
    @GetMapping
    public String configPage(Model model) {
        model.addAttribute("pipelineConfigs", pipelineService.getAllPipelineConfigs());
        model.addAttribute("executionSequences", executionSequenceService.getAllSequences());
        model.addAttribute("newPipelineConfig", new PipelineConfigDTO());
        model.addAttribute("newExecutionSequence", new ExecutionSequenceDTO());
        
        return "config";
    }

    // === Pipeline Config REST API Endpoints ===
    
    /**
     * Get all pipeline configurations.
     *
     * @return List of pipeline configurations
     */
    @GetMapping("/api/pipelines")
    @ResponseBody
    public ResponseEntity<List<PipelineConfigDTO>> getAllPipelineConfigs() {
        try {
            List<PipelineConfigDTO> configs = pipelineService.getAllPipelineConfigs();
            return ResponseEntity.ok(configs);
        } catch (Exception e) {
            logger.error("Failed to retrieve pipeline configurations: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get a specific pipeline configuration.
     *
     * @param id ID of the pipeline configuration
     * @return Pipeline configuration
     */
    @GetMapping("/api/pipelines/{id}")
    @ResponseBody
    public ResponseEntity<PipelineConfigDTO> getPipelineConfig(@PathVariable Long id) {
        try {
            PipelineConfigDTO config = pipelineService.getPipelineConfigById(id);
            if (config != null) {
                return ResponseEntity.ok(config);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            logger.error("Failed to retrieve pipeline configuration: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Create a new pipeline configuration.
     *
     * @param pipelineConfigDTO Pipeline configuration data
     * @return Created pipeline configuration
     */
    @PostMapping("/api/pipelines")
    @ResponseBody
    public ResponseEntity<PipelineConfigDTO> createPipelineConfig(@RequestBody PipelineConfigDTO pipelineConfigDTO) {
        try {
            PipelineConfigDTO created = pipelineService.createPipelineConfig(pipelineConfigDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            logger.error("Failed to create pipeline configuration: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Update an existing pipeline configuration.
     *
     * @param id ID of the pipeline configuration to update
     * @param pipelineConfigDTO Updated pipeline configuration data
     * @return Updated pipeline configuration
     */
    @PutMapping("/api/pipelines/{id}")
    @ResponseBody
    public ResponseEntity<PipelineConfigDTO> updatePipelineConfig(@PathVariable Long id, 
                                                                  @RequestBody PipelineConfigDTO pipelineConfigDTO) {
        try {
            pipelineConfigDTO.setId(id);
            PipelineConfigDTO updated = pipelineService.updatePipelineConfig(pipelineConfigDTO);
            if (updated != null) {
                return ResponseEntity.ok(updated);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            logger.error("Failed to update pipeline configuration: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Delete a pipeline configuration.
     *
     * @param id ID of the pipeline configuration to delete
     * @return Success/failure message
     */
    @DeleteMapping("/api/pipelines/{id}")
    @ResponseBody
    public ResponseEntity<Map<String, String>> deletePipelineConfig(@PathVariable Long id) {
        try {
            boolean deleted = pipelineService.deletePipelineConfig(id);
            if (deleted) {
                return ResponseEntity.ok(Map.of("status", "success", "message", "Pipeline configuration deleted"));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("status", "error", "message", "Pipeline configuration not found"));
            }
        } catch (Exception e) {
            logger.error("Failed to delete pipeline configuration: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "error", "message", "Internal server error: " + e.getMessage()));
        }
    }

    // === Execution Sequence REST API Endpoints ===
    
    /**
     * Get all execution sequences.
     *
     * @return List of execution sequences
     */
    @GetMapping("/api/sequences")
    @ResponseBody
    public ResponseEntity<List<ExecutionSequenceDTO>> getAllSequences() {
        try {
            List<ExecutionSequenceDTO> sequences = executionSequenceService.getAllSequences();
            return ResponseEntity.ok(sequences);
        } catch (Exception e) {
            logger.error("Failed to retrieve execution sequences: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get a specific execution sequence.
     *
     * @param id ID of the execution sequence
     * @return Execution sequence
     */
    @GetMapping("/api/sequences/{id}")
    @ResponseBody
    public ResponseEntity<ExecutionSequenceDTO> getSequence(@PathVariable Long id) {
        try {
            ExecutionSequenceDTO sequence = executionSequenceService.getSequenceById(id);
            if (sequence != null) {
                return ResponseEntity.ok(sequence);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            logger.error("Failed to retrieve execution sequence: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Create a new execution sequence.
     *
     * @param sequenceDTO Execution sequence data
     * @return Created execution sequence
     */
    @PostMapping("/api/sequences")
    @ResponseBody
    public ResponseEntity<ExecutionSequenceDTO> createSequence(@RequestBody ExecutionSequenceDTO sequenceDTO) {
        try {
            ExecutionSequenceDTO created = executionSequenceService.createSequence(sequenceDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            logger.error("Failed to create execution sequence: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Update an existing execution sequence.
     *
     * @param id ID of the execution sequence to update
     * @param sequenceDTO Updated execution sequence data
     * @return Updated execution sequence
     */
    @PutMapping("/api/sequences/{id}")
    @ResponseBody
    public ResponseEntity<ExecutionSequenceDTO> updateSequence(@PathVariable Long id, 
                                                               @RequestBody ExecutionSequenceDTO sequenceDTO) {
        try {
            sequenceDTO.setId(id);
            ExecutionSequenceDTO updated = executionSequenceService.updateSequence(sequenceDTO);
            if (updated != null) {
                return ResponseEntity.ok(updated);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            logger.error("Failed to update execution sequence: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Delete an execution sequence.
     *
     * @param id ID of the execution sequence to delete
     * @return Success/failure message
     */
    @DeleteMapping("/api/sequences/{id}")
    @ResponseBody
    public ResponseEntity<Map<String, String>> deleteSequence(@PathVariable Long id) {
        try {
            boolean deleted = executionSequenceService.deleteSequence(id);
            if (deleted) {
                return ResponseEntity.ok(Map.of("status", "success", "message", "Execution sequence deleted"));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("status", "error", "message", "Execution sequence not found"));
            }
        } catch (Exception e) {
            logger.error("Failed to delete execution sequence: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "error", "message", "Internal server error: " + e.getMessage()));
        }
    }
}
