package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.PipelineExecutionDTO;
import com.gitlab.orchestrator.service.ExecutionSequenceService;
import com.gitlab.orchestrator.service.PipelineService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST Controller for pipeline execution operations.
 */
@RestController
@RequestMapping("/api/pipelines")
public class PipelineController {

    private static final Logger logger = LoggerFactory.getLogger(PipelineController.class);
    
    private final PipelineService pipelineService;
    private final ExecutionSequenceService executionSequenceService;

    @Autowired
    public PipelineController(PipelineService pipelineService, ExecutionSequenceService executionSequenceService) {
        this.pipelineService = pipelineService;
        this.executionSequenceService = executionSequenceService;
    }

    /**
     * Trigger execution of a sequence of pipelines by sequence ID.
     *
     * @param sequenceId ID of the execution sequence to run
     * @return Response with execution details
     */
    @PostMapping("/execute/{sequenceId}")
    public ResponseEntity<PipelineExecutionDTO> executePipelineSequence(@PathVariable Long sequenceId) {
        logger.info("Received request to execute pipeline sequence: {}", sequenceId);
        
        try {
            PipelineExecutionDTO execution = pipelineService.executeSequenceById(sequenceId);
            return ResponseEntity.ok(execution);
        } catch (Exception e) {
            logger.error("Failed to execute pipeline sequence: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get the current status of an execution.
     *
     * @param executionId ID of the execution to check
     * @return Status information for the requested execution
     */
    @GetMapping("/status/{executionId}")
    public ResponseEntity<PipelineExecutionDTO> getExecutionStatus(@PathVariable String executionId) {
        logger.info("Checking status for execution: {}", executionId);
        
        try {
            PipelineExecutionDTO status = pipelineService.getExecutionStatus(executionId);
            if (status != null) {
                return ResponseEntity.ok(status);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            logger.error("Error retrieving execution status: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get all active pipeline executions.
     *
     * @return List of active executions
     */
    @GetMapping("/active")
    public ResponseEntity<List<PipelineExecutionDTO>> getActiveExecutions() {
        logger.info("Fetching all active pipeline executions");
        
        try {
            List<PipelineExecutionDTO> activeExecutions = pipelineService.getActiveExecutions();
            return ResponseEntity.ok(activeExecutions);
        } catch (Exception e) {
            logger.error("Error retrieving active executions: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Cancel a running pipeline execution.
     *
     * @param executionId ID of the execution to cancel
     * @return Success/failure message
     */
    @PostMapping("/cancel/{executionId}")
    public ResponseEntity<Map<String, String>> cancelExecution(@PathVariable String executionId) {
        logger.info("Canceling execution: {}", executionId);
        
        try {
            boolean cancelled = pipelineService.cancelExecution(executionId);
            if (cancelled) {
                return ResponseEntity.ok(Map.of("status", "cancelled", "message", "Execution cancelled successfully"));
            } else {
                return ResponseEntity.badRequest().body(Map.of("status", "error", "message", "Failed to cancel execution"));
            }
        } catch (Exception e) {
            logger.error("Error cancelling execution: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "error", "message", "Internal server error: " + e.getMessage()));
        }
    }
}
