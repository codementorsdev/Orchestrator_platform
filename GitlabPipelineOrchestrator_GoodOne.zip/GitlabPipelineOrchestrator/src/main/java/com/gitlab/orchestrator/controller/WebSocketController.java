package com.gitlab.orchestrator.controller;

import com.gitlab.orchestrator.dto.PipelineStatusDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

/**
 * Controller for WebSocket communication.
 * Handles sending real-time pipeline status updates to clients.
 */
@Controller
public class WebSocketController {

    private static final Logger logger = LoggerFactory.getLogger(WebSocketController.class);
    
    private final SimpMessagingTemplate messagingTemplate;

    public WebSocketController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    /**
     * Send pipeline status updates to clients.
     *
     * @param status The pipeline status to broadcast
     */
    public void sendPipelineStatus(PipelineStatusDTO status) {
        logger.debug("Sending pipeline status update for execution {} to WebSocket clients", 
                status.getExecutionId());
        try {
            messagingTemplate.convertAndSend("/topic/pipeline-status", status);
        } catch (Exception e) {
            logger.error("Error sending pipeline status update through WebSocket: {}", e.getMessage(), e);
        }
    }

    /**
     * Message mapping for client subscription to pipeline status updates.
     *
     * @param status The status message from client
     * @return The same status message for acknowledgment
     */
    @MessageMapping("/pipeline-status")
    public PipelineStatusDTO pipelineStatus(PipelineStatusDTO status) {
        // This endpoint allows clients to subscribe to status updates
        logger.debug("Received WebSocket message from client: {}", status);
        return status;
    }
}
