package com.gitlab.orchestrator.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Transfer Object for execution sequence.
 * Represents a sequence of pipeline configurations to be executed in order.
 */
public class ExecutionSequenceDTO {
    
    private Long id;
    private String name;
    private String description;
    private List<Long> pipelineConfigIds;
    private boolean active;

    // Default constructor
    public ExecutionSequenceDTO() {
        this.pipelineConfigIds = new ArrayList<>();
        this.active = true;
    }

    // Constructor with fields
    public ExecutionSequenceDTO(Long id, String name, String description, 
                               List<Long> pipelineConfigIds, boolean active) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.pipelineConfigIds = pipelineConfigIds != null ? pipelineConfigIds : new ArrayList<>();
        this.active = active;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Long> getPipelineConfigIds() {
        return pipelineConfigIds;
    }

    public void setPipelineConfigIds(List<Long> pipelineConfigIds) {
        this.pipelineConfigIds = pipelineConfigIds;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * Add a pipeline configuration ID to the sequence.
     *
     * @param pipelineConfigId ID of the pipeline configuration to add
     */
    public void addPipelineConfigId(Long pipelineConfigId) {
        if (this.pipelineConfigIds == null) {
            this.pipelineConfigIds = new ArrayList<>();
        }
        this.pipelineConfigIds.add(pipelineConfigId);
    }

    @Override
    public String toString() {
        return "ExecutionSequenceDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", pipelineConfigIds=" + pipelineConfigIds +
                ", active=" + active +
                '}';
    }
}
