package com.gitlab.orchestrator.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Transfer Object for pipeline execution details.
 * Represents a complete execution of a pipeline sequence.
 */
public class PipelineExecutionDTO {
    
    private String executionId;
    private Long sequenceId;
    private String sequenceName;
    private String overallStatus;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private List<PipelineStatusDTO> pipelineStatuses;
    private boolean active;
    private String errorMessage;

    // Default constructor
    public PipelineExecutionDTO() {
        this.pipelineStatuses = new ArrayList<>();
    }

    // Constructor with fields
    public PipelineExecutionDTO(String executionId, Long sequenceId, String sequenceName,
                               String overallStatus, LocalDateTime startTime, 
                               List<PipelineStatusDTO> pipelineStatuses, boolean active) {
        this.executionId = executionId;
        this.sequenceId = sequenceId;
        this.sequenceName = sequenceName;
        this.overallStatus = overallStatus;
        this.startTime = startTime;
        this.pipelineStatuses = pipelineStatuses != null ? pipelineStatuses : new ArrayList<>();
        this.active = active;
    }

    // Getters and Setters
    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public Long getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(Long sequenceId) {
        this.sequenceId = sequenceId;
    }

    public String getSequenceName() {
        return sequenceName;
    }

    public void setSequenceName(String sequenceName) {
        this.sequenceName = sequenceName;
    }

    public String getOverallStatus() {
        return overallStatus;
    }

    public void setOverallStatus(String overallStatus) {
        this.overallStatus = overallStatus;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public List<PipelineStatusDTO> getPipelineStatuses() {
        return pipelineStatuses;
    }

    public void setPipelineStatuses(List<PipelineStatusDTO> pipelineStatuses) {
        this.pipelineStatuses = pipelineStatuses;
    }

    public void addPipelineStatus(PipelineStatusDTO pipelineStatus) {
        if (this.pipelineStatuses == null) {
            this.pipelineStatuses = new ArrayList<>();
        }
        this.pipelineStatuses.add(pipelineStatus);
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * Calculate the overall progress of this execution based on all pipeline statuses.
     *
     * @return Progress as a percentage from 0 to 100
     */
    public double getOverallProgress() {
        if (pipelineStatuses == null || pipelineStatuses.isEmpty()) {
            return 0;
        }
        
        int currentStepSum = 0;
        int totalStepsSum = 0;
        
        for (PipelineStatusDTO status : pipelineStatuses) {
            currentStepSum += status.getCurrentStep();
            totalStepsSum += status.getTotalSteps();
        }
        
        if (totalStepsSum > 0) {
            return (double) currentStepSum / totalStepsSum * 100;
        } else {
            return 0;
        }
    }

    @Override
    public String toString() {
        return "PipelineExecutionDTO{" +
                "executionId='" + executionId + '\'' +
                ", sequenceId=" + sequenceId +
                ", sequenceName='" + sequenceName + '\'' +
                ", overallStatus='" + overallStatus + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", pipelineStatuses=" + pipelineStatuses +
                ", active=" + active +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}
