package com.gitlab.orchestrator.dto;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for pipeline status.
 * Used for sending real-time pipeline status updates via WebSocket.
 */
public class PipelineStatusDTO {
    
    private String executionId;
    private Long sequenceId;
    private String sequenceName;
    private String pipelineName;
    private Long pipelineId;
    private Integer gitlabPipelineId;
    private String status;
    private String webUrl;
    private int currentStep;
    private int totalSteps;
    private double progress;
    private LocalDateTime startTime;
    private LocalDateTime updateTime;
    private String errorMessage;

    // Default constructor
    public PipelineStatusDTO() {
    }

    // Constructor with fields
    public PipelineStatusDTO(String executionId, Long sequenceId, String sequenceName, String pipelineName, 
                             Long pipelineId, Integer gitlabPipelineId, String status, String webUrl,
                             int currentStep, int totalSteps, LocalDateTime startTime, 
                             LocalDateTime updateTime, String errorMessage) {
        this.executionId = executionId;
        this.sequenceId = sequenceId;
        this.sequenceName = sequenceName;
        this.pipelineName = pipelineName;
        this.pipelineId = pipelineId;
        this.gitlabPipelineId = gitlabPipelineId;
        this.status = status;
        this.webUrl = webUrl;
        this.currentStep = currentStep;
        this.totalSteps = totalSteps;
        this.startTime = startTime;
        this.updateTime = updateTime;
        this.errorMessage = errorMessage;
        calculateProgress();
    }

    // Calculate progress as a percentage
    private void calculateProgress() {
        if (totalSteps > 0) {
            this.progress = (double) currentStep / totalSteps * 100;
        } else {
            this.progress = 0;
        }
    }

    // Getters and Setters
    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public Long getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(Long sequenceId) {
        this.sequenceId = sequenceId;
    }

    public String getSequenceName() {
        return sequenceName;
    }

    public void setSequenceName(String sequenceName) {
        this.sequenceName = sequenceName;
    }

    public String getPipelineName() {
        return pipelineName;
    }

    public void setPipelineName(String pipelineName) {
        this.pipelineName = pipelineName;
    }

    public Long getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(Long pipelineId) {
        this.pipelineId = pipelineId;
    }

    public Integer getGitlabPipelineId() {
        return gitlabPipelineId;
    }

    public void setGitlabPipelineId(Integer gitlabPipelineId) {
        this.gitlabPipelineId = gitlabPipelineId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public int getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(int currentStep) {
        this.currentStep = currentStep;
        calculateProgress();
    }

    public int getTotalSteps() {
        return totalSteps;
    }

    public void setTotalSteps(int totalSteps) {
        this.totalSteps = totalSteps;
        calculateProgress();
    }

    public double getProgress() {
        return progress;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "PipelineStatusDTO{" +
                "executionId='" + executionId + '\'' +
                ", sequenceId=" + sequenceId +
                ", sequenceName='" + sequenceName + '\'' +
                ", pipelineName='" + pipelineName + '\'' +
                ", pipelineId=" + pipelineId +
                ", gitlabPipelineId=" + gitlabPipelineId +
                ", status='" + status + '\'' +
                ", webUrl='" + webUrl + '\'' +
                ", currentStep=" + currentStep +
                ", totalSteps=" + totalSteps +
                ", progress=" + progress +
                ", startTime=" + startTime +
                ", updateTime=" + updateTime +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}
