package com.gitlab.orchestrator.exception;

/**
 * Exception for GitLab API specific errors.
 */
public class GitLabApiException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Create a new GitLabApiException with a message.
     *
     * @param message Error message
     */
    public GitLabApiException(String message) {
        super(message);
    }

    /**
     * Create a new GitLabApiException with a message and cause.
     *
     * @param message Error message
     * @param cause Underlying cause
     */
    public GitLabApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
