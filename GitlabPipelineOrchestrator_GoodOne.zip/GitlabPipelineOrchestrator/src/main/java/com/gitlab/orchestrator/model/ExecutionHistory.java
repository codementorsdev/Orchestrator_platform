package com.gitlab.orchestrator.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity class for storing execution history.
 * Records details of each pipeline execution.
 */
@Entity
@Table(name = "execution_history")
public class ExecutionHistory {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String executionId;
    
    @Column(nullable = false)
    private Long sequenceId;
    
    @Column(nullable = false)
    private String sequenceName;
    
    @Column(nullable = false)
    private String status;
    
    @Column(nullable = false)
    private LocalDateTime startTime;
    
    @Column
    private LocalDateTime endTime;
    
    @Column(length = 10000)
    private String executionDetails;
    
    @Column(length = 1000)
    private String errorMessage;

    // Default constructor
    public ExecutionHistory() {
        this.startTime = LocalDateTime.now();
    }

    // Constructor with fields
    public ExecutionHistory(String executionId, Long sequenceId, String sequenceName,
                           String status, String executionDetails) {
        this.executionId = executionId;
        this.sequenceId = sequenceId;
        this.sequenceName = sequenceName;
        this.status = status;
        this.startTime = LocalDateTime.now();
        this.executionDetails = executionDetails;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getExecutionId() {
        return executionId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }

    public Long getSequenceId() {
        return sequenceId;
    }

    public void setSequenceId(Long sequenceId) {
        this.sequenceId = sequenceId;
    }

    public String getSequenceName() {
        return sequenceName;
    }

    public void setSequenceName(String sequenceName) {
        this.sequenceName = sequenceName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getExecutionDetails() {
        return executionDetails;
    }

    public void setExecutionDetails(String executionDetails) {
        this.executionDetails = executionDetails;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * Complete this execution with the given status and error message.
     *
     * @param status The final status
     * @param errorMessage Error message, if any
     */
    public void complete(String status, String errorMessage) {
        this.status = status;
        this.errorMessage = errorMessage;
        this.endTime = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "ExecutionHistory{" +
                "id=" + id +
                ", executionId='" + executionId + '\'' +
                ", sequenceId=" + sequenceId +
                ", sequenceName='" + sequenceName + '\'' +
                ", status='" + status + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", executionDetails='" + (executionDetails != null ? "[DETAILS]" : null) + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}
