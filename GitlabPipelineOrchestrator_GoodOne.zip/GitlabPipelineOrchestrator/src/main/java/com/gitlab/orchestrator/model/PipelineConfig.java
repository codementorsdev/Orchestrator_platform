package com.gitlab.orchestrator.model;

import jakarta.persistence.*;

/**
 * Entity class for storing pipeline configuration data.
 */
@Entity
@Table(name = "pipeline_configs")
public class PipelineConfig {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(nullable = false)
    private String gitlabUrl;
    
    @Column(nullable = false)
    private String projectId;
    
    @Column(nullable = false)
    private String branch;
    
    @Column(nullable = false)
    private String accessToken;
    
    @Column(length = 1000)
    private String description;
    
    @Column(nullable = false)
    private boolean active;

    // Default constructor
    public PipelineConfig() {
        this.active = true;
    }

    // Constructor with fields
    public PipelineConfig(String name, String gitlabUrl, String projectId, 
                          String branch, String accessToken, String description) {
        this.name = name;
        this.gitlabUrl = gitlabUrl;
        this.projectId = projectId;
        this.branch = branch;
        this.accessToken = accessToken;
        this.description = description;
        this.active = true;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGitlabUrl() {
        return gitlabUrl;
    }

    public void setGitlabUrl(String gitlabUrl) {
        this.gitlabUrl = gitlabUrl;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "PipelineConfig{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", gitlabUrl='" + gitlabUrl + '\'' +
                ", projectId='" + projectId + '\'' +
                ", branch='" + branch + '\'' +
                ", accessToken='[REDACTED]'" +
                ", description='" + description + '\'' +
                ", active=" + active +
                '}';
    }
}
