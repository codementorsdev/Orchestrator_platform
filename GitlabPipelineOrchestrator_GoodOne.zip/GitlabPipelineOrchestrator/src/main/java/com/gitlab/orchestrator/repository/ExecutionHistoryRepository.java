package com.gitlab.orchestrator.repository;

import com.gitlab.orchestrator.model.ExecutionHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for ExecutionHistory entity.
 */
@Repository
public interface ExecutionHistoryRepository extends JpaRepository<ExecutionHistory, Long> {
    
    /**
     * Find execution history by execution ID.
     *
     * @param executionId Unique execution ID
     * @return Optional containing execution history if found
     */
    Optional<ExecutionHistory> findByExecutionId(String executionId);
    
    /**
     * Find execution histories by sequence ID.
     *
     * @param sequenceId Execution sequence ID
     * @return List of execution histories for the given sequence
     */
    List<ExecutionHistory> findBySequenceId(Long sequenceId);
    
    /**
     * Find execution histories by status.
     *
     * @param status Execution status
     * @return List of execution histories with the given status
     */
    List<ExecutionHistory> findByStatus(String status);
    
    /**
     * Find execution histories started after the given time.
     *
     * @param startTime Start time threshold
     * @return List of execution histories started after the given time
     */
    List<ExecutionHistory> findByStartTimeAfter(LocalDateTime startTime);
    
    /**
     * Find the most recent execution histories, ordered by start time.
     *
     * @param limit Maximum number of records to return
     * @return List of recent execution histories
     */
    List<ExecutionHistory> findTop10ByOrderByStartTimeDesc();
}
