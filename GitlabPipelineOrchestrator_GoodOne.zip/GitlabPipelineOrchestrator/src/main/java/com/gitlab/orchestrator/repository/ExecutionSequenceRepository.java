package com.gitlab.orchestrator.repository;

import com.gitlab.orchestrator.model.ExecutionSequence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for ExecutionSequence entity.
 */
@Repository
public interface ExecutionSequenceRepository extends JpaRepository<ExecutionSequence, Long> {
    
    /**
     * Find all active execution sequences.
     *
     * @return List of active execution sequences
     */
    List<ExecutionSequence> findByActiveTrue();
    
    /**
     * Find execution sequence by name.
     *
     * @param name Execution sequence name
     * @return ExecutionSequence with the given name
     */
    ExecutionSequence findByName(String name);
}
