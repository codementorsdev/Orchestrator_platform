package com.gitlab.orchestrator.repository;

import com.gitlab.orchestrator.model.PipelineConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for PipelineConfig entity.
 */
@Repository
public interface PipelineConfigRepository extends JpaRepository<PipelineConfig, Long> {
    
    /**
     * Find all active pipeline configurations.
     *
     * @return List of active pipeline configurations
     */
    List<PipelineConfig> findByActiveTrue();
    
    /**
     * Find pipeline configuration by name.
     *
     * @param name Pipeline configuration name
     * @return PipelineConfig with the given name
     */
    PipelineConfig findByName(String name);
}
