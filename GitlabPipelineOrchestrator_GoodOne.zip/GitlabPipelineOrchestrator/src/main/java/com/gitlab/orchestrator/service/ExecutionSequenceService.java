package com.gitlab.orchestrator.service;

import com.gitlab.orchestrator.dto.ExecutionSequenceDTO;

import java.util.List;

/**
 * Service interface for execution sequence operations.
 */
public interface ExecutionSequenceService {
    
    /**
     * Get all execution sequences.
     *
     * @return List of all execution sequences
     */
    List<ExecutionSequenceDTO> getAllSequences();
    
    /**
     * Get a specific execution sequence by ID.
     *
     * @param id Execution sequence ID
     * @return Execution sequence or null if not found
     */
    ExecutionSequenceDTO getSequenceById(Long id);
    
    /**
     * Create a new execution sequence.
     *
     * @param sequenceDTO Execution sequence data
     * @return Created execution sequence
     */
    ExecutionSequenceDTO createSequence(ExecutionSequenceDTO sequenceDTO);
    
    /**
     * Update an existing execution sequence.
     *
     * @param sequenceDTO Updated execution sequence data
     * @return Updated execution sequence or null if not found
     */
    ExecutionSequenceDTO updateSequence(ExecutionSequenceDTO sequenceDTO);
    
    /**
     * Delete an execution sequence.
     *
     * @param id Execution sequence ID
     * @return true if deleted, false if not found
     */
    boolean deleteSequence(Long id);
}
