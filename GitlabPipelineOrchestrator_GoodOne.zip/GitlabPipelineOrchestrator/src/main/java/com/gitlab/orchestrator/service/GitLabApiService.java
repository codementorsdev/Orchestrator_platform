package com.gitlab.orchestrator.service;

import java.util.Map;

/**
 * Service interface for GitLab API operations.
 */
public interface GitLabApiService {
    
    /**
     * Trigger a pipeline in GitLab.
     *
     * @param gitlabUrl GitLab instance URL
     * @param accessToken GitLab access token
     * @param projectId GitLab project ID
     * @param branch Branch to run pipeline on
     * @return Map containing pipeline details
     * @throws Exception If pipeline triggering fails
     */
    Map<String, Object> triggerPipeline(String gitlabUrl, String accessToken, String projectId, String branch) throws Exception;
    
    /**
     * Get the status of a pipeline in GitLab.
     *
     * @param gitlabUrl GitLab instance URL
     * @param accessToken GitLab access token
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @return Map containing pipeline status details
     * @throws Exception If status retrieval fails
     */
    Map<String, Object> getPipelineStatus(String gitlabUrl, String accessToken, String projectId, Integer pipelineId) throws Exception;
    
    /**
     * Cancel a running pipeline in GitLab.
     *
     * @param gitlabUrl GitLab instance URL
     * @param accessToken GitLab access token
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @return Map containing pipeline details after cancellation
     * @throws Exception If cancellation fails
     */
    Map<String, Object> cancelPipeline(String gitlabUrl, String accessToken, String projectId, Integer pipelineId) throws Exception;
    
    /**
     * Test connection to GitLab.
     *
     * @param gitlabUrl GitLab instance URL
     * @param accessToken GitLab access token
     * @return true if connection is successful
     * @throws Exception If connection test fails
     */
    boolean testConnection(String gitlabUrl, String accessToken) throws Exception;
}
