package com.gitlab.orchestrator.service;

import com.gitlab.orchestrator.dto.PipelineConfigDTO;
import com.gitlab.orchestrator.dto.PipelineExecutionDTO;

import java.util.List;

/**
 * Service interface for pipeline operations.
 */
public interface PipelineService {
    
    /**
     * Get all pipeline configurations.
     *
     * @return List of all pipeline configurations
     */
    List<PipelineConfigDTO> getAllPipelineConfigs();
    
    /**
     * Get a specific pipeline configuration by ID.
     *
     * @param id Pipeline configuration ID
     * @return Pipeline configuration or null if not found
     */
    PipelineConfigDTO getPipelineConfigById(Long id);
    
    /**
     * Create a new pipeline configuration.
     *
     * @param pipelineConfigDTO Pipeline configuration data
     * @return Created pipeline configuration
     */
    PipelineConfigDTO createPipelineConfig(PipelineConfigDTO pipelineConfigDTO);
    
    /**
     * Update an existing pipeline configuration.
     *
     * @param pipelineConfigDTO Updated pipeline configuration data
     * @return Updated pipeline configuration or null if not found
     */
    PipelineConfigDTO updatePipelineConfig(PipelineConfigDTO pipelineConfigDTO);
    
    /**
     * Delete a pipeline configuration.
     *
     * @param id Pipeline configuration ID
     * @return true if deleted, false if not found
     */
    boolean deletePipelineConfig(Long id);
    
    /**
     * Execute a sequence of pipelines.
     *
     * @param sequenceId ID of the execution sequence to run
     * @return Execution details
     */
    PipelineExecutionDTO executeSequenceById(Long sequenceId);
    
    /**
     * Get the status of a pipeline execution.
     *
     * @param executionId Execution ID
     * @return Execution status or null if not found
     */
    PipelineExecutionDTO getExecutionStatus(String executionId);
    
    /**
     * Get all active pipeline executions.
     *
     * @return List of active executions
     */
    List<PipelineExecutionDTO> getActiveExecutions();
    
    /**
     * Cancel a running pipeline execution.
     *
     * @param executionId Execution ID
     * @return true if cancelled, false otherwise
     */
    boolean cancelExecution(String executionId);
}
