package com.gitlab.orchestrator.service.impl;

import com.gitlab.orchestrator.dto.ExecutionSequenceDTO;
import com.gitlab.orchestrator.model.ExecutionSequence;
import com.gitlab.orchestrator.repository.ExecutionSequenceRepository;
import com.gitlab.orchestrator.service.ExecutionSequenceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Implementation of the ExecutionSequenceService interface.
 */
@Service
public class ExecutionSequenceServiceImpl implements ExecutionSequenceService {

    private static final Logger logger = LoggerFactory.getLogger(ExecutionSequenceServiceImpl.class);
    
    private final ExecutionSequenceRepository executionSequenceRepository;

    @Autowired
    public ExecutionSequenceServiceImpl(ExecutionSequenceRepository executionSequenceRepository) {
        this.executionSequenceRepository = executionSequenceRepository;
    }

    @Override
    public List<ExecutionSequenceDTO> getAllSequences() {
        logger.debug("Fetching all execution sequences");
        return executionSequenceRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ExecutionSequenceDTO getSequenceById(Long id) {
        logger.debug("Fetching execution sequence with ID: {}", id);
        return executionSequenceRepository.findById(id)
                .map(this::convertToDTO)
                .orElse(null);
    }

    @Override
    public ExecutionSequenceDTO createSequence(ExecutionSequenceDTO sequenceDTO) {
        logger.info("Creating new execution sequence: {}", sequenceDTO.getName());
        ExecutionSequence sequence = convertToEntity(sequenceDTO);
        ExecutionSequence savedSequence = executionSequenceRepository.save(sequence);
        return convertToDTO(savedSequence);
    }

    @Override
    public ExecutionSequenceDTO updateSequence(ExecutionSequenceDTO sequenceDTO) {
        logger.info("Updating execution sequence with ID: {}", sequenceDTO.getId());
        
        if (sequenceDTO.getId() == null) {
            logger.error("Cannot update execution sequence with null ID");
            return null;
        }
        
        Optional<ExecutionSequence> existingSequence = executionSequenceRepository.findById(sequenceDTO.getId());
        if (existingSequence.isPresent()) {
            ExecutionSequence sequence = convertToEntity(sequenceDTO);
            ExecutionSequence updatedSequence = executionSequenceRepository.save(sequence);
            return convertToDTO(updatedSequence);
        } else {
            logger.error("Execution sequence with ID {} not found", sequenceDTO.getId());
            return null;
        }
    }

    @Override
    public boolean deleteSequence(Long id) {
        logger.info("Deleting execution sequence with ID: {}", id);
        
        if (id == null) {
            logger.error("Cannot delete execution sequence with null ID");
            return false;
        }
        
        Optional<ExecutionSequence> existingSequence = executionSequenceRepository.findById(id);
        if (existingSequence.isPresent()) {
            executionSequenceRepository.deleteById(id);
            return true;
        } else {
            logger.error("Execution sequence with ID {} not found", id);
            return false;
        }
    }

    /**
     * Convert ExecutionSequence entity to ExecutionSequenceDTO.
     *
     * @param sequence ExecutionSequence entity
     * @return ExecutionSequenceDTO
     */
    private ExecutionSequenceDTO convertToDTO(ExecutionSequence sequence) {
        return new ExecutionSequenceDTO(
                sequence.getId(),
                sequence.getName(),
                sequence.getDescription(),
                sequence.getPipelineConfigIds(),
                sequence.isActive());
    }

    /**
     * Convert ExecutionSequenceDTO to ExecutionSequence entity.
     *
     * @param sequenceDTO ExecutionSequenceDTO
     * @return ExecutionSequence entity
     */
    private ExecutionSequence convertToEntity(ExecutionSequenceDTO sequenceDTO) {
        ExecutionSequence sequence = new ExecutionSequence();
        sequence.setId(sequenceDTO.getId());
        sequence.setName(sequenceDTO.getName());
        sequence.setDescription(sequenceDTO.getDescription());
        sequence.setPipelineConfigIds(sequenceDTO.getPipelineConfigIds());
        sequence.setActive(sequenceDTO.isActive());
        return sequence;
    }
}
