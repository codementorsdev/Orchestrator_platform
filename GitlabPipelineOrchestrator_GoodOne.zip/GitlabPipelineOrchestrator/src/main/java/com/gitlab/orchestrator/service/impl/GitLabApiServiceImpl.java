package com.gitlab.orchestrator.service.impl;

import com.gitlab.orchestrator.exception.GitLabApiException;
import com.gitlab.orchestrator.service.GitLabApiService;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.PipelineApi;
import org.gitlab4j.api.models.Pipeline;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Implementation of GitLabApiService using gitlab4j-api library.
 */
@Service
public class GitLabApiServiceImpl implements GitLabApiService {

    private static final Logger logger = LoggerFactory.getLogger(GitLabApiServiceImpl.class);

    @Override
    public Map<String, Object> triggerPipeline(String gitlabUrl, String accessToken, String projectId, String branch) throws Exception {
        logger.info("Triggering pipeline for project: {}, branch: {}", projectId, branch);
        
        try (GitLabApi gitLabApi = createGitLabApi(gitlabUrl, accessToken)) {
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            Pipeline pipeline = pipelineApi.createPipeline(projectId, branch);
            
            if (pipeline == null) {
                throw new GitLabApiException("Failed to create pipeline, null response from GitLab API");
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("id", pipeline.getId());
            result.put("status", pipeline.getStatus().toString());
            result.put("web_url", pipeline.getWebUrl());
            result.put("ref", pipeline.getRef());
            result.put("sha", pipeline.getSha());
            result.put("created_at", pipeline.getCreatedAt());
            
            logger.info("Successfully triggered pipeline ID: {} for project: {}", pipeline.getId(), projectId);
            return result;
        } catch (Exception e) {
            logger.error("Error triggering pipeline for project {}: {}", projectId, e.getMessage(), e);
            throw new GitLabApiException("Failed to trigger pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public Map<String, Object> getPipelineStatus(String gitlabUrl, String accessToken, String projectId, Integer pipelineId) throws Exception {
        logger.debug("Getting status for pipeline: {}, project: {}", pipelineId, projectId);
        
        try (GitLabApi gitLabApi = createGitLabApi(gitlabUrl, accessToken)) {
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            Pipeline pipeline = pipelineApi.getPipeline(projectId, pipelineId);
            
            if (pipeline == null) {
                throw new GitLabApiException("Failed to get pipeline status, null response from GitLab API");
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("id", pipeline.getId());
            result.put("status", pipeline.getStatus().toString());
            result.put("web_url", pipeline.getWebUrl());
            result.put("ref", pipeline.getRef());
            result.put("sha", pipeline.getSha());
            result.put("created_at", pipeline.getCreatedAt());
            result.put("updated_at", pipeline.getUpdatedAt());
            result.put("finished_at", pipeline.getFinishedAt());
            
            return result;
        } catch (Exception e) {
            logger.error("Error getting pipeline status for pipeline {}: {}", pipelineId, e.getMessage(), e);
            throw new GitLabApiException("Failed to get pipeline status: " + e.getMessage(), e);
        }
    }

    @Override
    public Map<String, Object> cancelPipeline(String gitlabUrl, String accessToken, String projectId, Integer pipelineId) throws Exception {
        logger.info("Cancelling pipeline: {}, project: {}", pipelineId, projectId);
        
        try (GitLabApi gitLabApi = createGitLabApi(gitlabUrl, accessToken)) {
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            Pipeline pipeline = pipelineApi.cancelPipelineJobs(projectId, pipelineId);
            
            if (pipeline == null) {
                throw new GitLabApiException("Failed to cancel pipeline, null response from GitLab API");
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("id", pipeline.getId());
            result.put("status", pipeline.getStatus().toString());
            result.put("web_url", pipeline.getWebUrl());
            result.put("ref", pipeline.getRef());
            result.put("sha", pipeline.getSha());
            result.put("created_at", pipeline.getCreatedAt());
            result.put("updated_at", pipeline.getUpdatedAt());
            result.put("finished_at", pipeline.getFinishedAt());
            
            logger.info("Successfully cancelled pipeline ID: {}", pipelineId);
            return result;
        } catch (Exception e) {
            logger.error("Error cancelling pipeline {}: {}", pipelineId, e.getMessage(), e);
            throw new GitLabApiException("Failed to cancel pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean testConnection(String gitlabUrl, String accessToken) throws Exception {
        logger.info("Testing connection to GitLab: {}", gitlabUrl);
        
        try (GitLabApi gitLabApi = createGitLabApi(gitlabUrl, accessToken)) {
            // Just try to get the authenticated user
            gitLabApi.getUserApi().getCurrentUser();
            logger.info("Successfully connected to GitLab: {}", gitlabUrl);
            return true;
        } catch (Exception e) {
            logger.error("Error connecting to GitLab {}: {}", gitlabUrl, e.getMessage(), e);
            throw new GitLabApiException("Failed to connect to GitLab: " + e.getMessage(), e);
        }
    }

    /**
     * Create a new GitLabApi instance with the provided URL and access token.
     *
     * @param gitlabUrl GitLab instance URL
     * @param accessToken GitLab access token
     * @return GitLabApi instance
     */
    private GitLabApi createGitLabApi(String gitlabUrl, String accessToken) {
        // Handle URL normalization
        if (gitlabUrl.endsWith("/")) {
            gitlabUrl = gitlabUrl.substring(0, gitlabUrl.length() - 1);
        }
        
        return new GitLabApi(gitlabUrl, accessToken);
    }
}
