package com.gitlab.orchestrator.service.impl;

import com.gitlab.orchestrator.controller.WebSocketController;
import com.gitlab.orchestrator.dto.PipelineConfigDTO;
import com.gitlab.orchestrator.dto.PipelineExecutionDTO;
import com.gitlab.orchestrator.dto.PipelineStatusDTO;
import com.gitlab.orchestrator.model.ExecutionHistory;
import com.gitlab.orchestrator.model.ExecutionSequence;
import com.gitlab.orchestrator.model.PipelineConfig;
import com.gitlab.orchestrator.repository.ExecutionHistoryRepository;
import com.gitlab.orchestrator.repository.ExecutionSequenceRepository;
import com.gitlab.orchestrator.repository.PipelineConfigRepository;
import com.gitlab.orchestrator.service.GitLabApiService;
import com.gitlab.orchestrator.service.PipelineService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Implementation of the PipelineService interface.
 */
@Service
public class PipelineServiceImpl implements PipelineService {

    private static final Logger logger = LoggerFactory.getLogger(PipelineServiceImpl.class);
    
    private final PipelineConfigRepository pipelineConfigRepository;
    private final ExecutionSequenceRepository executionSequenceRepository;
    private final ExecutionHistoryRepository executionHistoryRepository;
    private final GitLabApiService gitLabApiService;
    private final WebSocketController webSocketController;
    private final ObjectMapper objectMapper;
    
    // In-memory store for active executions
    private final Map<String, PipelineExecutionDTO> activeExecutions = new ConcurrentHashMap<>();

    @Autowired
    public PipelineServiceImpl(
            PipelineConfigRepository pipelineConfigRepository,
            ExecutionSequenceRepository executionSequenceRepository,
            ExecutionHistoryRepository executionHistoryRepository,
            GitLabApiService gitLabApiService,
            WebSocketController webSocketController,
            ObjectMapper objectMapper) {
        this.pipelineConfigRepository = pipelineConfigRepository;
        this.executionSequenceRepository = executionSequenceRepository;
        this.executionHistoryRepository = executionHistoryRepository;
        this.gitLabApiService = gitLabApiService;
        this.webSocketController = webSocketController;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<PipelineConfigDTO> getAllPipelineConfigs() {
        logger.debug("Fetching all pipeline configurations");
        return pipelineConfigRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public PipelineConfigDTO getPipelineConfigById(Long id) {
        logger.debug("Fetching pipeline configuration with ID: {}", id);
        return pipelineConfigRepository.findById(id)
                .map(this::convertToDTO)
                .orElse(null);
    }

    @Override
    public PipelineConfigDTO createPipelineConfig(PipelineConfigDTO pipelineConfigDTO) {
        logger.info("Creating new pipeline configuration: {}", pipelineConfigDTO.getName());
        PipelineConfig pipelineConfig = convertToEntity(pipelineConfigDTO);
        PipelineConfig savedConfig = pipelineConfigRepository.save(pipelineConfig);
        return convertToDTO(savedConfig);
    }

    @Override
    public PipelineConfigDTO updatePipelineConfig(PipelineConfigDTO pipelineConfigDTO) {
        logger.info("Updating pipeline configuration with ID: {}", pipelineConfigDTO.getId());
        
        if (pipelineConfigDTO.getId() == null) {
            logger.error("Cannot update pipeline configuration with null ID");
            return null;
        }
        
        Optional<PipelineConfig> existingConfig = pipelineConfigRepository.findById(pipelineConfigDTO.getId());
        if (existingConfig.isPresent()) {
            PipelineConfig pipelineConfig = convertToEntity(pipelineConfigDTO);
            PipelineConfig updatedConfig = pipelineConfigRepository.save(pipelineConfig);
            return convertToDTO(updatedConfig);
        } else {
            logger.error("Pipeline configuration with ID {} not found", pipelineConfigDTO.getId());
            return null;
        }
    }

    @Override
    public boolean deletePipelineConfig(Long id) {
        logger.info("Deleting pipeline configuration with ID: {}", id);
        
        if (id == null) {
            logger.error("Cannot delete pipeline configuration with null ID");
            return false;
        }
        
        Optional<PipelineConfig> existingConfig = pipelineConfigRepository.findById(id);
        if (existingConfig.isPresent()) {
            pipelineConfigRepository.deleteById(id);
            return true;
        } else {
            logger.error("Pipeline configuration with ID {} not found", id);
            return false;
        }
    }

    @Override
    public PipelineExecutionDTO executeSequenceById(Long sequenceId) {
        logger.info("Executing pipeline sequence with ID: {}", sequenceId);
        
        // Find the execution sequence
        Optional<ExecutionSequence> optionalSequence = executionSequenceRepository.findById(sequenceId);
        if (!optionalSequence.isPresent()) {
            logger.error("Execution sequence with ID {} not found", sequenceId);
            throw new IllegalArgumentException("Execution sequence not found");
        }
        
        ExecutionSequence sequence = optionalSequence.get();
        List<Long> pipelineConfigIds = sequence.getPipelineConfigIds();
        
        if (pipelineConfigIds.isEmpty()) {
            logger.error("Execution sequence {} has no pipeline configurations", sequenceId);
            throw new IllegalArgumentException("Execution sequence has no pipeline configurations");
        }
        
        // Generate a unique execution ID
        String executionId = UUID.randomUUID().toString();
        
        // Create execution history record
        ExecutionHistory executionHistory = new ExecutionHistory(
                executionId,
                sequenceId,
                sequence.getName(),
                "RUNNING",
                null);
        executionHistoryRepository.save(executionHistory);
        
        // Create execution DTO
        PipelineExecutionDTO executionDTO = new PipelineExecutionDTO(
                executionId,
                sequenceId,
                sequence.getName(),
                "RUNNING",
                LocalDateTime.now(),
                new ArrayList<>(),
                true);
        
        // Initialize pipeline statuses for all pipelines in the sequence
        List<PipelineStatusDTO> statuses = new ArrayList<>();
        int totalSteps = pipelineConfigIds.size();
        
        for (int i = 0; i < pipelineConfigIds.size(); i++) {
            Long pipelineConfigId = pipelineConfigIds.get(i);
            PipelineConfig pipelineConfig = pipelineConfigRepository.findById(pipelineConfigId)
                    .orElseThrow(() -> new IllegalArgumentException("Pipeline config not found with ID: " + pipelineConfigId));
            
            PipelineStatusDTO status = new PipelineStatusDTO(
                    executionId,
                    sequenceId,
                    sequence.getName(),
                    pipelineConfig.getName(),
                    pipelineConfigId,
                    null, // No GitLab pipeline ID yet
                    i == 0 ? "PENDING" : "WAITING", // First pipeline is pending, others are waiting
                    null, // No web URL yet
                    i == 0 ? 0 : 0, // Current step progress
                    totalSteps,
                    LocalDateTime.now(),
                    LocalDateTime.now(),
                    null);
            
            statuses.add(status);
        }
        
        executionDTO.setPipelineStatuses(statuses);
        
        // Store in active executions
        activeExecutions.put(executionId, executionDTO);
        
        // Start the first pipeline in a separate thread
        Thread executionThread = new Thread(() -> {
            try {
                executePipelineSequence(executionDTO, pipelineConfigIds, 0);
            } catch (Exception e) {
                logger.error("Error during pipeline sequence execution: {}", e.getMessage(), e);
                
                // Update execution status
                executionDTO.setOverallStatus("FAILED");
                executionDTO.setActive(false);
                executionDTO.setErrorMessage("Execution failed: " + e.getMessage());
                executionDTO.setEndTime(LocalDateTime.now());
                
                // Update execution history
                Optional<ExecutionHistory> historyOpt = executionHistoryRepository.findByExecutionId(executionId);
                if (historyOpt.isPresent()) {
                    ExecutionHistory history = historyOpt.get();
                    history.complete("FAILED", e.getMessage());
                    try {
                        history.setExecutionDetails(objectMapper.writeValueAsString(executionDTO));
                    } catch (Exception ex) {
                        logger.error("Error serializing execution details: {}", ex.getMessage());
                    }
                    executionHistoryRepository.save(history);
                }
                
                // Send WebSocket update
                if (!executionDTO.getPipelineStatuses().isEmpty()) {
                    PipelineStatusDTO lastStatus = executionDTO.getPipelineStatuses().get(
                            Math.max(0, executionDTO.getPipelineStatuses().size() - 1));
                    lastStatus.setStatus("FAILED");
                    lastStatus.setErrorMessage(e.getMessage());
                    lastStatus.setUpdateTime(LocalDateTime.now());
                    webSocketController.sendPipelineStatus(lastStatus);
                }
            }
        });
        
        executionThread.setName("Pipeline-" + executionId);
        executionThread.start();
        
        return executionDTO;
    }

    @Override
    public PipelineExecutionDTO getExecutionStatus(String executionId) {
        logger.debug("Getting status for execution: {}", executionId);
        
        // Check active executions first
        PipelineExecutionDTO activeExecution = activeExecutions.get(executionId);
        if (activeExecution != null) {
            return activeExecution;
        }
        
        // If not active, check history
        Optional<ExecutionHistory> historyOpt = executionHistoryRepository.findByExecutionId(executionId);
        if (historyOpt.isPresent()) {
            ExecutionHistory history = historyOpt.get();
            try {
                // Try to deserialize the stored execution details
                if (history.getExecutionDetails() != null) {
                    return objectMapper.readValue(history.getExecutionDetails(), PipelineExecutionDTO.class);
                } else {
                    // Create a simple execution DTO if no details are available
                    PipelineExecutionDTO executionDTO = new PipelineExecutionDTO();
                    executionDTO.setExecutionId(history.getExecutionId());
                    executionDTO.setSequenceId(history.getSequenceId());
                    executionDTO.setSequenceName(history.getSequenceName());
                    executionDTO.setOverallStatus(history.getStatus());
                    executionDTO.setStartTime(history.getStartTime());
                    executionDTO.setEndTime(history.getEndTime());
                    executionDTO.setActive(false);
                    executionDTO.setErrorMessage(history.getErrorMessage());
                    return executionDTO;
                }
            } catch (Exception e) {
                logger.error("Error deserializing execution details: {}", e.getMessage(), e);
                return null;
            }
        }
        
        return null;
    }

    @Override
    public List<PipelineExecutionDTO> getActiveExecutions() {
        logger.debug("Getting all active executions, count: {}", activeExecutions.size());
        return new ArrayList<>(activeExecutions.values());
    }

    @Override
    public boolean cancelExecution(String executionId) {
        logger.info("Cancelling execution: {}", executionId);
        
        PipelineExecutionDTO execution = activeExecutions.get(executionId);
        if (execution == null) {
            logger.error("No active execution found with ID: {}", executionId);
            return false;
        }
        
        // Update execution status
        execution.setOverallStatus("CANCELLED");
        execution.setActive(false);
        execution.setEndTime(LocalDateTime.now());
        
        // For each running pipeline, try to cancel in GitLab
        for (PipelineStatusDTO status : execution.getPipelineStatuses()) {
            if ("RUNNING".equals(status.getStatus()) && status.getGitlabPipelineId() != null) {
                try {
                    // Get the corresponding pipeline config
                    Optional<PipelineConfig> configOpt = pipelineConfigRepository.findById(status.getPipelineId());
                    if (configOpt.isPresent()) {
                        PipelineConfig config = configOpt.get();
                        gitLabApiService.cancelPipeline(
                                config.getGitlabUrl(), 
                                config.getAccessToken(), 
                                config.getProjectId(), 
                                status.getGitlabPipelineId());
                    }
                } catch (Exception e) {
                    logger.error("Error cancelling GitLab pipeline: {}", e.getMessage(), e);
                }
                
                // Update status
                status.setStatus("CANCELLED");
                status.setUpdateTime(LocalDateTime.now());
                webSocketController.sendPipelineStatus(status);
            }
        }
        
        // Update execution history
        Optional<ExecutionHistory> historyOpt = executionHistoryRepository.findByExecutionId(executionId);
        if (historyOpt.isPresent()) {
            ExecutionHistory history = historyOpt.get();
            history.setStatus("CANCELLED");
            history.setEndTime(LocalDateTime.now());
            try {
                history.setExecutionDetails(objectMapper.writeValueAsString(execution));
            } catch (Exception e) {
                logger.error("Error serializing execution details: {}", e.getMessage());
            }
            executionHistoryRepository.save(history);
        }
        
        // Remove from active executions after a short delay to allow clients to get the final status
        new Thread(() -> {
            try {
                Thread.sleep(30000); // 30 seconds
                activeExecutions.remove(executionId);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
        
        return true;
    }

    /**
     * Execute a sequence of pipelines starting from the specified index.
     *
     * @param executionDTO Execution data
     * @param pipelineConfigIds List of pipeline configuration IDs
     * @param currentIndex Current pipeline index to execute
     */
    private void executePipelineSequence(
            PipelineExecutionDTO executionDTO, 
            List<Long> pipelineConfigIds,
            int currentIndex) throws Exception {
        
        if (currentIndex >= pipelineConfigIds.size()) {
            // All pipelines completed successfully
            completeExecution(executionDTO, "COMPLETED", null);
            return;
        }
        
        // Check if execution is still active
        if (!"RUNNING".equals(executionDTO.getOverallStatus())) {
            logger.info("Execution {} is no longer running (status: {}), stopping sequence",
                    executionDTO.getExecutionId(), executionDTO.getOverallStatus());
            return;
        }
        
        Long pipelineConfigId = pipelineConfigIds.get(currentIndex);
        PipelineConfig pipelineConfig = pipelineConfigRepository.findById(pipelineConfigId)
                .orElseThrow(() -> new IllegalArgumentException("Pipeline config not found with ID: " + pipelineConfigId));
        
        PipelineStatusDTO status = executionDTO.getPipelineStatuses().get(currentIndex);
        status.setStatus("RUNNING");
        status.setCurrentStep(currentIndex);
        status.setUpdateTime(LocalDateTime.now());
        
        // Send WebSocket update for pipeline start
        webSocketController.sendPipelineStatus(status);
        
        try {
            // Trigger the pipeline in GitLab
            Map<String, Object> pipelineData = gitLabApiService.triggerPipeline(
                    pipelineConfig.getGitlabUrl(),
                    pipelineConfig.getAccessToken(),
                    pipelineConfig.getProjectId(),
                    pipelineConfig.getBranch());
            
            // Update status with GitLab pipeline ID and URL
            Integer gitlabPipelineId = (Integer) pipelineData.get("id");
            String webUrl = (String) pipelineData.get("web_url");
            
            status.setGitlabPipelineId(gitlabPipelineId);
            status.setWebUrl(webUrl);
            status.setUpdateTime(LocalDateTime.now());
            
            // Send WebSocket update with pipeline info
            webSocketController.sendPipelineStatus(status);
            
            // Poll for pipeline completion
            String finalStatus = pollPipelineStatus(
                    pipelineConfig.getGitlabUrl(),
                    pipelineConfig.getAccessToken(),
                    pipelineConfig.getProjectId(),
                    gitlabPipelineId,
                    status);
            
            if ("success".equalsIgnoreCase(finalStatus)) {
                // Pipeline completed successfully, move to next
                status.setStatus("COMPLETED");
                status.setCurrentStep(currentIndex + 1);
                status.setUpdateTime(LocalDateTime.now());
                webSocketController.sendPipelineStatus(status);
                
                // Move to the next pipeline
                executePipelineSequence(executionDTO, pipelineConfigIds, currentIndex + 1);
            } else {
                // Pipeline failed or was cancelled
                status.setStatus("FAILED");
                status.setErrorMessage("Pipeline failed with status: " + finalStatus);
                status.setUpdateTime(LocalDateTime.now());
                webSocketController.sendPipelineStatus(status);
                
                completeExecution(executionDTO, "FAILED", "Pipeline " + pipelineConfig.getName() + " failed with status: " + finalStatus);
            }
        } catch (Exception e) {
            logger.error("Error executing pipeline {}: {}", pipelineConfig.getName(), e.getMessage(), e);
            
            status.setStatus("FAILED");
            status.setErrorMessage(e.getMessage());
            status.setUpdateTime(LocalDateTime.now());
            webSocketController.sendPipelineStatus(status);
            
            completeExecution(executionDTO, "FAILED", "Error executing pipeline " + pipelineConfig.getName() + ": " + e.getMessage());
            throw e;
        }
    }

    /**
     * Poll GitLab for pipeline status until completion.
     *
     * @param gitlabUrl GitLab URL
     * @param accessToken GitLab access token
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @param status Status DTO to update with progress
     * @return Final pipeline status
     */
    private String pollPipelineStatus(
            String gitlabUrl,
            String accessToken,
            String projectId,
            Integer pipelineId,
            PipelineStatusDTO status) throws Exception {
        
        final int maxAttempts = 300; // Poll for maximum of 5 minutes
        final int pollIntervalMs = 1000; // 1 second between polls
        
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            Map<String, Object> pipelineStatus = gitLabApiService.getPipelineStatus(
                    gitlabUrl, accessToken, projectId, pipelineId);
            
            String currentStatus = (String) pipelineStatus.get("status");
            logger.debug("Pipeline {} status: {}", pipelineId, currentStatus);
            
            // Update detailed status via WebSocket every 5 seconds
            if (attempt % 5 == 0) {
                status.setUpdateTime(LocalDateTime.now());
                webSocketController.sendPipelineStatus(status);
            }
            
            // Check if pipeline has completed
            if ("success".equalsIgnoreCase(currentStatus) || 
                "failed".equalsIgnoreCase(currentStatus) ||
                "canceled".equalsIgnoreCase(currentStatus) ||
                "cancelled".equalsIgnoreCase(currentStatus) ||
                "skipped".equalsIgnoreCase(currentStatus)) {
                return currentStatus;
            }
            
            Thread.sleep(pollIntervalMs);
        }
        
        throw new Exception("Pipeline execution timed out after " + (maxAttempts * pollIntervalMs / 1000) + " seconds");
    }

    /**
     * Complete an execution with the specified status and error message.
     *
     * @param executionDTO Execution to complete
     * @param status Final status
     * @param errorMessage Error message, if any
     */
    private void completeExecution(PipelineExecutionDTO executionDTO, String status, String errorMessage) {
        logger.info("Completing execution {} with status: {}", executionDTO.getExecutionId(), status);
        
        executionDTO.setOverallStatus(status);
        executionDTO.setActive(false);
        executionDTO.setEndTime(LocalDateTime.now());
        executionDTO.setErrorMessage(errorMessage);
        
        // Update execution history
        Optional<ExecutionHistory> historyOpt = executionHistoryRepository.findByExecutionId(executionDTO.getExecutionId());
        if (historyOpt.isPresent()) {
            ExecutionHistory history = historyOpt.get();
            history.complete(status, errorMessage);
            try {
                history.setExecutionDetails(objectMapper.writeValueAsString(executionDTO));
            } catch (Exception e) {
                logger.error("Error serializing execution details: {}", e.getMessage());
            }
            executionHistoryRepository.save(history);
        }
        
        // Remove from active executions after a short delay to allow clients to get the final status
        new Thread(() -> {
            try {
                Thread.sleep(30000); // 30 seconds
                activeExecutions.remove(executionDTO.getExecutionId());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    /**
     * Convert PipelineConfig entity to PipelineConfigDTO.
     *
     * @param pipelineConfig PipelineConfig entity
     * @return PipelineConfigDTO
     */
    private PipelineConfigDTO convertToDTO(PipelineConfig pipelineConfig) {
        return new PipelineConfigDTO(
                pipelineConfig.getId(),
                pipelineConfig.getName(),
                pipelineConfig.getGitlabUrl(),
                pipelineConfig.getProjectId(),
                pipelineConfig.getBranch(),
                pipelineConfig.getAccessToken(),
                pipelineConfig.getDescription(),
                pipelineConfig.isActive());
    }

    /**
     * Convert PipelineConfigDTO to PipelineConfig entity.
     *
     * @param pipelineConfigDTO PipelineConfigDTO
     * @return PipelineConfig entity
     */
    private PipelineConfig convertToEntity(PipelineConfigDTO pipelineConfigDTO) {
        PipelineConfig pipelineConfig = new PipelineConfig();
        pipelineConfig.setId(pipelineConfigDTO.getId());
        pipelineConfig.setName(pipelineConfigDTO.getName());
        pipelineConfig.setGitlabUrl(pipelineConfigDTO.getGitlabUrl());
        pipelineConfig.setProjectId(pipelineConfigDTO.getProjectId());
        pipelineConfig.setBranch(pipelineConfigDTO.getBranch());
        pipelineConfig.setAccessToken(pipelineConfigDTO.getAccessToken());
        pipelineConfig.setDescription(pipelineConfigDTO.getDescription());
        pipelineConfig.setActive(pipelineConfigDTO.isActive());
        return pipelineConfig;
    }
}
