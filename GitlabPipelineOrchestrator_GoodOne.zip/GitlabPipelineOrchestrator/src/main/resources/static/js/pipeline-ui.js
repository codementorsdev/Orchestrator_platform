/**
 * UI Controller for GitLab Pipeline Orchestrator
 * Handles UI interactions and pipeline status updates
 */
class PipelineUiController {
    constructor() {
        // Map to store active executions by ID
        this.activeExecutions = new Map();
        
        // DOM element references
        this.executionListElement = document.getElementById('execution-list');
        this.sequenceSelectElement = document.getElementById('sequence-select');
        
        // Bind event handlers
        this.bindEventHandlers();
        
        // Initialize UI
        this.loadActiveExecutions();
        this.loadExecutionSequences();
    }
    
    /**
     * Bind event handlers for UI elements
     */
    bindEventHandlers() {
        // WebSocket connection events
        document.addEventListener('websocket-connected', () => {
            this.updateConnectionStatus(true);
        });
        
        document.addEventListener('websocket-error', (event) => {
            this.updateConnectionStatus(false, event.detail.message);
        });
        
        // Pipeline status update events
        document.addEventListener('pipeline-status-update', (event) => {
            this.handlePipelineStatusUpdate(event.detail);
        });
        
        // Execution actions
        document.addEventListener('click', (event) => {
            // Handle execute button
            if (event.target.matches('#execute-button')) {
                this.executeSequence();
            }
            
            // Handle cancel button
            if (event.target.matches('.cancel-execution-btn')) {
                const executionId = event.target.getAttribute('data-execution-id');
                if (executionId) {
                    this.cancelExecution(executionId);
                }
            }
            
            // Handle refresh button
            if (event.target.matches('#refresh-button')) {
                this.loadActiveExecutions();
            }
        });
    }
    
    /**
     * Update the connection status indicator
     * 
     * @param {boolean} connected Connection status
     * @param {string} errorMessage Optional error message
     */
    updateConnectionStatus(connected, errorMessage) {
        const statusElement = document.getElementById('connection-status');
        
        if (connected) {
            statusElement.innerHTML = '<span class="status-connected">Connected</span>';
            statusElement.title = 'WebSocket connection established';
        } else {
            statusElement.innerHTML = '<span class="status-disconnected">Disconnected</span>';
            statusElement.title = errorMessage || 'WebSocket connection lost';
            
            // Show toast notification
            this.showToast('Connection Error', errorMessage || 'WebSocket connection lost', 'error');
        }
    }
    
    /**
     * Load active executions from the server
     */
    loadActiveExecutions() {
        fetch('/api/pipelines/active')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(executions => {
                this.renderExecutions(executions);
            })
            .catch(error => {
                console.error('Error loading active executions:', error);
                this.showToast('Error', 'Failed to load active executions', 'error');
            });
    }
    
    /**
     * Load available execution sequences
     */
    loadExecutionSequences() {
        fetch('/config/api/sequences')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(sequences => {
                // Clear existing options
                this.sequenceSelectElement.innerHTML = '';
                
                // Add option for each sequence
                sequences.forEach(sequence => {
                    const option = document.createElement('option');
                    option.value = sequence.id;
                    option.textContent = sequence.name;
                    this.sequenceSelectElement.appendChild(option);
                });
                
                // Enable execute button if sequences are available
                document.getElementById('execute-button').disabled = sequences.length === 0;
            })
            .catch(error => {
                console.error('Error loading execution sequences:', error);
                this.showToast('Error', 'Failed to load execution sequences', 'error');
            });
    }
    
    /**
     * Execute a pipeline sequence
     */
    executeSequence() {
        const sequenceId = this.sequenceSelectElement.value;
        
        if (!sequenceId) {
            this.showToast('Error', 'Please select a sequence to execute', 'error');
            return;
        }
        
        // Disable execute button during API call
        const executeButton = document.getElementById('execute-button');
        executeButton.disabled = true;
        executeButton.textContent = 'Starting...';
        
        // Call API to execute sequence
        fetch(`/api/pipelines/execute/${sequenceId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(execution => {
            this.showToast('Success', `Started execution: ${execution.sequenceName}`, 'success');
            
            // Add new execution to the list
            this.addExecution(execution);
        })
        .catch(error => {
            console.error('Error executing sequence:', error);
            this.showToast('Error', 'Failed to execute sequence', 'error');
        })
        .finally(() => {
            // Re-enable execute button
            executeButton.disabled = false;
            executeButton.textContent = 'Execute';
        });
    }
    
    /**
     * Cancel a running pipeline execution
     * 
     * @param {string} executionId Execution ID to cancel
     */
    cancelExecution(executionId) {
        // Confirm cancellation
        if (!confirm('Are you sure you want to cancel this execution?')) {
            return;
        }
        
        // Find and disable the cancel button
        const cancelButton = document.querySelector(`.cancel-execution-btn[data-execution-id="${executionId}"]`);
        if (cancelButton) {
            cancelButton.disabled = true;
            cancelButton.textContent = 'Cancelling...';
        }
        
        // Call API to cancel execution
        fetch(`/api/pipelines/cancel/${executionId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(result => {
            this.showToast('Success', 'Execution cancelled', 'success');
            
            // Update execution in UI
            const execution = this.activeExecutions.get(executionId);
            if (execution) {
                execution.overallStatus = 'CANCELLED';
                execution.active = false;
                this.updateExecutionUI(executionId);
            }
        })
        .catch(error => {
            console.error('Error cancelling execution:', error);
            this.showToast('Error', 'Failed to cancel execution', 'error');
            
            // Re-enable cancel button
            if (cancelButton) {
                cancelButton.disabled = false;
                cancelButton.textContent = 'Cancel';
            }
        });
    }
    
    /**
     * Handle a pipeline status update from WebSocket
     * 
     * @param {Object} status Pipeline status object
     */
    handlePipelineStatusUpdate(status) {
        // Get the execution ID from the status
        const executionId = status.executionId;
        
        // Get the current execution or load it if not in memory
        if (!this.activeExecutions.has(executionId)) {
            // This is a status update for an execution we don't know about yet
            // Fetch the execution details
            fetch(`/api/pipelines/status/${executionId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(execution => {
                    this.addExecution(execution);
                    this.updatePipelineStatus(status);
                })
                .catch(error => {
                    console.error(`Error loading execution ${executionId}:`, error);
                });
        } else {
            // Update the pipeline status in the existing execution
            this.updatePipelineStatus(status);
        }
    }
    
    /**
     * Update a pipeline status in an execution
     * 
     * @param {Object} status Pipeline status object
     */
    updatePipelineStatus(status) {
        const executionId = status.executionId;
        const execution = this.activeExecutions.get(executionId);
        
        if (!execution) {
            console.warn(`Received status update for unknown execution: ${executionId}`);
            return;
        }
        
        // Find the pipeline status to update
        let found = false;
        for (let i = 0; i < execution.pipelineStatuses.length; i++) {
            if (execution.pipelineStatuses[i].pipelineId === status.pipelineId) {
                execution.pipelineStatuses[i] = status;
                found = true;
                break;
            }
        }
        
        // If not found, add it
        if (!found) {
            execution.pipelineStatuses.push(status);
        }
        
        // Update the overall status if needed
        if (status.status === 'FAILED' && execution.overallStatus !== 'FAILED') {
            execution.overallStatus = 'FAILED';
            execution.active = false;
            execution.errorMessage = status.errorMessage;
        } else if (status.status === 'CANCELLED' && execution.overallStatus !== 'CANCELLED') {
            execution.overallStatus = 'CANCELLED';
            execution.active = false;
        } else if (status.status === 'COMPLETED' && 
                  status.currentStep === status.totalSteps && 
                  execution.overallStatus !== 'COMPLETED') {
            execution.overallStatus = 'COMPLETED';
            execution.active = false;
        }
        
        // Update the UI
        this.updateExecutionUI(executionId);
    }
    
    /**
     * Add a new execution to the UI
     * 
     * @param {Object} execution Execution object
     */
    addExecution(execution) {
        // Store execution in memory
        this.activeExecutions.set(execution.executionId, execution);
        
        // Create execution element if it doesn't exist
        if (!document.getElementById(`execution-${execution.executionId}`)) {
            // Create execution element
            const executionElement = document.createElement('div');
            executionElement.id = `execution-${execution.executionId}`;
            executionElement.className = 'execution-card';
            executionElement.innerHTML = this.renderExecutionHtml(execution);
            
            // Add to list
            if (this.executionListElement.firstChild) {
                this.executionListElement.insertBefore(executionElement, this.executionListElement.firstChild);
            } else {
                this.executionListElement.appendChild(executionElement);
            }
            
            // Remove no executions message if present
            const noExecutionsElement = document.getElementById('no-executions');
            if (noExecutionsElement) {
                noExecutionsElement.remove();
            }
        }
        
        // Update execution UI
        this.updateExecutionUI(execution.executionId);
    }
    
    /**
     * Update an execution's UI
     * 
     * @param {string} executionId Execution ID to update
     */
    updateExecutionUI(executionId) {
        const execution = this.activeExecutions.get(executionId);
        if (!execution) return;
        
        const executionElement = document.getElementById(`execution-${executionId}`);
        if (!executionElement) return;
        
        // Update header and status
        const headerElement = executionElement.querySelector('.execution-header');
        const statusElement = headerElement.querySelector('.execution-status');
        
        // Update status class
        statusElement.className = `execution-status status-${execution.overallStatus.toLowerCase()}`;
        statusElement.textContent = execution.overallStatus;
        
        // Update progress
        const progressElement = executionElement.querySelector('.execution-progress');
        const progressBar = progressElement.querySelector('.progress-bar');
        const progressText = progressElement.querySelector('.progress-text');
        
        const progress = execution.overallProgress;
        progressBar.style.width = `${progress}%`;
        progressText.textContent = `${Math.round(progress)}%`;
        
        // Update cancel button
        const cancelButton = executionElement.querySelector('.cancel-execution-btn');
        cancelButton.disabled = !execution.active;
        
        // Update pipeline steps
        const pipelineListElement = executionElement.querySelector('.pipeline-list');
        pipelineListElement.innerHTML = '';
        
        execution.pipelineStatuses.forEach(pipeline => {
            const pipelineElement = document.createElement('div');
            pipelineElement.className = `pipeline-item status-${pipeline.status.toLowerCase()}`;
            
            // Create pipeline HTML
            let pipelineHtml = `
                <div class="pipeline-header">
                    <span class="pipeline-name">${pipeline.pipelineName}</span>
                    <span class="pipeline-status">${pipeline.status}</span>
                </div>
            `;
            
            // Add step info
            if (pipeline.status === 'RUNNING' || pipeline.status === 'COMPLETED') {
                pipelineHtml += `
                    <div class="pipeline-details">
                        <div class="pipeline-step">Step ${pipeline.currentStep + 1} of ${pipeline.totalSteps}</div>
                `;
                
                // Add link to GitLab pipeline if available
                if (pipeline.webUrl) {
                    pipelineHtml += `
                        <a href="${pipeline.webUrl}" target="_blank" class="pipeline-link">
                            View in GitLab <i class="feather-external-link"></i>
                        </a>
                    `;
                }
                
                pipelineHtml += `</div>`;
            }
            
            // Add error message if failed
            if (pipeline.status === 'FAILED' && pipeline.errorMessage) {
                pipelineHtml += `
                    <div class="pipeline-error">
                        <div class="error-message">${pipeline.errorMessage}</div>
                    </div>
                `;
            }
            
            pipelineElement.innerHTML = pipelineHtml;
            pipelineListElement.appendChild(pipelineElement);
        });
        
        // Update timestamps
        const timestampElement = executionElement.querySelector('.execution-timestamp');
        timestampElement.textContent = this.formatTimestamp(execution.startTime);
        
        // If execution is not active, update end timestamp
        if (!execution.active && execution.endTime) {
            const durationElement = executionElement.querySelector('.execution-duration');
            durationElement.textContent = this.calculateDuration(execution.startTime, execution.endTime);
        }
    }
    
    /**
     * Render executions in the UI
     * 
     * @param {Array} executions List of execution objects
     */
    renderExecutions(executions) {
        // Clear execution list
        this.executionListElement.innerHTML = '';
        
        // Clear active executions map
        this.activeExecutions.clear();
        
        if (executions.length === 0) {
            this.executionListElement.innerHTML = `
                <div id="no-executions" class="no-data-message">
                    <p>No active pipeline executions</p>
                    <p class="hint">Select an execution sequence and click "Execute" to start</p>
                </div>
            `;
            return;
        }
        
        // Add each execution to the UI
        executions.forEach(execution => {
            this.addExecution(execution);
        });
    }
    
    /**
     * Generate HTML for an execution
     * 
     * @param {Object} execution Execution object
     * @return {string} HTML for the execution
     */
    renderExecutionHtml(execution) {
        return `
            <div class="execution-header">
                <div class="execution-title">
                    <h3>${execution.sequenceName}</h3>
                    <span class="execution-status status-${execution.overallStatus.toLowerCase()}">${execution.overallStatus}</span>
                </div>
                <div class="execution-actions">
                    <button class="cancel-execution-btn btn-danger" data-execution-id="${execution.executionId}" ${!execution.active ? 'disabled' : ''}>
                        Cancel
                    </button>
                </div>
            </div>
            <div class="execution-progress">
                <div class="progress-bar" style="width: ${execution.overallProgress}%"></div>
                <div class="progress-text">${Math.round(execution.overallProgress)}%</div>
            </div>
            <div class="execution-info">
                <div class="execution-timestamp">
                    ${this.formatTimestamp(execution.startTime)}
                </div>
                <div class="execution-duration">
                    ${execution.endTime ? this.calculateDuration(execution.startTime, execution.endTime) : 'Running...'}
                </div>
                <div class="execution-id">
                    ID: ${execution.executionId}
                </div>
            </div>
            <div class="pipeline-list">
                <!-- Pipeline items will be inserted here -->
            </div>
            ${execution.errorMessage ? `
                <div class="execution-error">
                    <h4>Error:</h4>
                    <div class="error-message">${execution.errorMessage}</div>
                </div>
            ` : ''}
        `;
    }
    
    /**
     * Format a timestamp for display
     * 
     * @param {string} timestamp ISO timestamp
     * @return {string} Formatted timestamp
     */
    formatTimestamp(timestamp) {
        if (!timestamp) return 'N/A';
        
        const date = new Date(timestamp);
        return date.toLocaleString();
    }
    
    /**
     * Calculate duration between two timestamps
     * 
     * @param {string} start Start timestamp
     * @param {string} end End timestamp
     * @return {string} Formatted duration
     */
    calculateDuration(start, end) {
        if (!start || !end) return 'N/A';
        
        const startDate = new Date(start);
        const endDate = new Date(end);
        const diffMs = endDate - startDate;
        
        // Format duration
        const seconds = Math.floor((diffMs / 1000) % 60);
        const minutes = Math.floor((diffMs / (1000 * 60)) % 60);
        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        
        let duration = '';
        if (hours > 0) {
            duration += `${hours}h `;
        }
        if (minutes > 0 || hours > 0) {
            duration += `${minutes}m `;
        }
        duration += `${seconds}s`;
        
        return duration;
    }
    
    /**
     * Show a toast notification
     * 
     * @param {string} title Toast title
     * @param {string} message Toast message
     * @param {string} type Toast type (success, error, warning, info)
     */
    showToast(title, message, type = 'info') {
        // Create toast container if it doesn't exist
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            document.body.appendChild(toastContainer);
        }
        
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-header">
                <strong>${title}</strong>
                <button type="button" class="toast-close">&times;</button>
            </div>
            <div class="toast-body">${message}</div>
        `;
        
        // Add to container
        toastContainer.appendChild(toast);
        
        // Add close handler
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.classList.add('toast-hiding');
            setTimeout(() => {
                toast.remove();
            }, 300);
        });
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            toast.classList.add('toast-hiding');
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 5000);
        
        // Animate in
        setTimeout(() => {
            toast.classList.add('toast-visible');
        }, 10);
    }
}

// Initialize the UI controller when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.pipelineUiController = new PipelineUiController();
    
    // Initialize Feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
});
