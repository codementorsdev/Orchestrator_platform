/**
 * WebSocket client for real-time pipeline status updates.
 */
class PipelineWebSocket {
    constructor() {
        this.stompClient = null;
        this.connected = false;
        this.subscriptions = new Map();
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.reconnectInterval = 3000; // 3 seconds
    }

    /**
     * Connect to the WebSocket server.
     */
    connect() {
        console.log('Connecting to WebSocket server...');
        
        const socket = new SockJS('/websocket-endpoint');
        this.stompClient = Stomp.over(socket);
        
        // Disable debug logging
        this.stompClient.debug = null;
        
        this.stompClient.connect({}, 
            (frame) => this.onConnected(frame),
            (error) => this.onError(error)
        );
    }

    /**
     * Handle successful WebSocket connection.
     * 
     * @param {Object} frame Connection frame
     */
    onConnected(frame) {
        console.log('Connected to WebSocket server');
        this.connected = true;
        this.reconnectAttempts = 0;
        
        // Subscribe to pipeline status updates
        this.subscribe('/topic/pipeline-status', (message) => {
            try {
                const pipelineStatus = JSON.parse(message.body);
                this.handlePipelineStatus(pipelineStatus);
            } catch (error) {
                console.error('Error handling pipeline status message:', error);
            }
        });
        
        // Dispatch connection event
        document.dispatchEvent(new CustomEvent('websocket-connected'));
    }

    /**
     * Handle WebSocket connection error.
     * 
     * @param {Object} error Connection error
     */
    onError(error) {
        console.error('WebSocket connection error:', error);
        this.connected = false;
        
        // Attempt reconnection with backoff
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            const delay = this.reconnectInterval * Math.pow(1.5, this.reconnectAttempts - 1);
            console.log(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})...`);
            
            setTimeout(() => this.connect(), delay);
        } else {
            console.error('Max reconnection attempts reached.');
            document.dispatchEvent(new CustomEvent('websocket-error', { 
                detail: { message: 'Failed to connect to server after multiple attempts.' } 
            }));
        }
    }

    /**
     * Subscribe to a WebSocket topic.
     * 
     * @param {string} topic Topic to subscribe to
     * @param {Function} callback Callback for received messages
     */
    subscribe(topic, callback) {
        if (!this.connected) {
            console.warn('Cannot subscribe while disconnected');
            return;
        }
        
        if (this.subscriptions.has(topic)) {
            console.warn(`Already subscribed to topic: ${topic}`);
            return;
        }
        
        const subscription = this.stompClient.subscribe(topic, callback);
        this.subscriptions.set(topic, subscription);
        console.log(`Subscribed to topic: ${topic}`);
    }

    /**
     * Unsubscribe from a WebSocket topic.
     * 
     * @param {string} topic Topic to unsubscribe from
     */
    unsubscribe(topic) {
        if (this.subscriptions.has(topic)) {
            const subscription = this.subscriptions.get(topic);
            subscription.unsubscribe();
            this.subscriptions.delete(topic);
            console.log(`Unsubscribed from topic: ${topic}`);
        }
    }

    /**
     * Disconnect from the WebSocket server.
     */
    disconnect() {
        if (this.stompClient !== null && this.connected) {
            // Unsubscribe from all topics
            for (const [topic, subscription] of this.subscriptions.entries()) {
                subscription.unsubscribe();
                console.log(`Unsubscribed from topic: ${topic}`);
            }
            this.subscriptions.clear();
            
            // Disconnect the client
            this.stompClient.disconnect();
            console.log('Disconnected from WebSocket server');
        }
        this.connected = false;
    }

    /**
     * Handle received pipeline status message.
     * 
     * @param {Object} status Pipeline status object
     */
    handlePipelineStatus(status) {
        // Dispatch custom event with the pipeline status
        document.dispatchEvent(new CustomEvent('pipeline-status-update', { 
            detail: status
        }));
    }
}

// Create global WebSocket client instance
const pipelineWebSocket = new PipelineWebSocket();

// Connect when the page loads
document.addEventListener('DOMContentLoaded', () => {
    pipelineWebSocket.connect();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    pipelineWebSocket.disconnect();
});
