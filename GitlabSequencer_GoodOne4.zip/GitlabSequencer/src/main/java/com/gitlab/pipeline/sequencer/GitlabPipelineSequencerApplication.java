package com.gitlab.pipeline.sequencer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Main application class for GitLab Pipeline Sequencer
 * This application provides REST APIs for creating and executing
 * GitLab pipeline sequences
 */
@SpringBootApplication
@EnableAsync
@EnableScheduling
@EntityScan("com.gitlab.pipeline.sequencer.model")
@EnableJpaRepositories("com.gitlab.pipeline.sequencer.repository")
public class GitlabPipelineSequencerApplication {

    public static void main(String[] args) {
        SpringApplication.run(GitlabPipelineSequencerApplication.class, args);
    }
    
    @RestController
    public static class HealthController {
        @GetMapping("/health")
        public String health() {
            return "OK - GitLab Pipeline Sequencer API is running";
        }
        
        @GetMapping("/")
        public String home() {
            return "Welcome to GitLab Pipeline Sequencer API";
        }
    }
}
