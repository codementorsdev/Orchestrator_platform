package com.gitlab.pipeline.sequencer.config;

import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * Configuration class to handle the DATABASE_URL environment variable for database connection.
 * Converts the standard postgres:// URL format into the JDBC format for Spring Boot.
 */
@Configuration
public class DataSourceConfig {
    
    private static final Logger log = LoggerFactory.getLogger(DataSourceConfig.class);
    
    @Value("${DATABASE_URL:}")
    private String databaseUrl;
    
    /**
     * Creates DataSourceProperties based on the DATABASE_URL environment variable.
     */
    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource")
    public DataSourceProperties dataSourceProperties() {
        DataSourceProperties dataSourceProperties = new DataSourceProperties();
        
        if (StringUtils.hasText(databaseUrl) && databaseUrl.startsWith("postgresql://")) {
            log.info("Found DATABASE_URL in standard format, converting to JDBC URL");
            try {
                URI dbUri = new URI(databaseUrl);
                
                String username = dbUri.getUserInfo().split(":")[0];
                String password = dbUri.getUserInfo().split(":")[1];
                String dbUrl = "jdbc:postgresql://" + dbUri.getHost() + ":" + (dbUri.getPort() != -1 ? dbUri.getPort() : 5432) + 
                        dbUri.getPath() + (dbUri.getQuery() != null ? "?" + dbUri.getQuery() : "");
                
                dataSourceProperties.setUrl(dbUrl);
                dataSourceProperties.setUsername(username);
                dataSourceProperties.setPassword(password);
                log.info("Database URL configured successfully from DATABASE_URL");
            } catch (URISyntaxException e) {
                log.error("Invalid DATABASE_URL format", e);
            }
        } else {
            log.info("Using configured database properties from application.properties");
        }
        
        return dataSourceProperties;
    }
    
    /**
     * Creates the DataSource using HikariCP.
     */
    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource.hikari")
    public DataSource dataSource(DataSourceProperties properties) {
        log.info("Initializing HikariCP data source");
        return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
    }
}