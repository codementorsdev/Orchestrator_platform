package com.gitlab.pipeline.sequencer.controller;

import com.gitlab.pipeline.sequencer.dto.ApiResponse;
import com.gitlab.pipeline.sequencer.dto.ApplicationDto;
import com.gitlab.pipeline.sequencer.service.ApplicationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Application management
 */
@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
@Tag(name = "Application Management", description = "APIs for application operations")
public class ApplicationController {

    private final ApplicationService applicationService;

    @PostMapping
    @Operation(summary = "Create a new application", description = "Creates a new application with the provided details")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "201", description = "Application created successfully", 
                    content = @Content(schema = @Schema(implementation = ApplicationDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input")
    })
    public ResponseEntity<ApiResponse<ApplicationDto>> createApplication(
            @Valid @RequestBody ApplicationDto applicationDto) {
        ApplicationDto createdApplication = applicationService.createApplication(applicationDto);
        return new ResponseEntity<>(ApiResponse.success("Application created successfully", createdApplication), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get an application by ID", description = "Retrieves an application by its ID")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Application found", 
                    content = @Content(schema = @Schema(implementation = ApplicationDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<ApiResponse<ApplicationDto>> getApplicationById(
            @Parameter(description = "Application ID", required = true) @PathVariable Long id) {
        ApplicationDto application = applicationService.getApplicationById(id);
        return ResponseEntity.ok(ApiResponse.success(application));
    }

    @GetMapping
    @Operation(summary = "Get all applications", description = "Retrieves all applications")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Applications retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = ApplicationDto.class)))
    })
    public ResponseEntity<ApiResponse<List<ApplicationDto>>> getAllApplications() {
        List<ApplicationDto> applications = applicationService.getAllApplications();
        return ResponseEntity.ok(ApiResponse.success(applications));
    }
    
    @GetMapping("/flow/{flowId}")
    @Operation(summary = "Get applications by flow ID", description = "Retrieves all applications for a specific flow")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Applications retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = ApplicationDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<ApiResponse<List<ApplicationDto>>> getApplicationsByFlowId(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long flowId) {
        List<ApplicationDto> applications = applicationService.getApplicationsByFlowId(flowId);
        return ResponseEntity.ok(ApiResponse.success(applications));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an application", description = "Updates an existing application with the provided details")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Application updated successfully", 
                    content = @Content(schema = @Schema(implementation = ApplicationDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<ApiResponse<ApplicationDto>> updateApplication(
            @Parameter(description = "Application ID", required = true) @PathVariable Long id,
            @Valid @RequestBody ApplicationDto applicationDto) {
        ApplicationDto updatedApplication = applicationService.updateApplication(id, applicationDto);
        return ResponseEntity.ok(ApiResponse.success("Application updated successfully", updatedApplication));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an application", description = "Deletes an existing application by its ID")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Application deleted successfully"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<Void> deleteApplication(
            @Parameter(description = "Application ID", required = true) @PathVariable Long id) {
        applicationService.deleteApplication(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/{id}/verify")
    @Operation(summary = "Verify GitLab access", description = "Verifies if the GitLab access token is valid for the application")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "GitLab access verified", 
                    content = @Content(schema = @Schema(implementation = Boolean.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<ApiResponse<Boolean>> verifyGitLabAccess(
            @Parameter(description = "Application ID", required = true) @PathVariable Long id) {
        boolean isValid = applicationService.verifyGitLabAccess(id);
        return ResponseEntity.ok(ApiResponse.success(isValid));
    }
}
