package com.gitlab.pipeline.sequencer.controller;

import com.gitlab.pipeline.sequencer.dto.ApiResponse;
import com.gitlab.pipeline.sequencer.dto.ExecutionHistoryDto;
import com.gitlab.pipeline.sequencer.service.ExecutionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * REST controller for pipeline execution operations
 */
@RestController
@RequestMapping("/api/executions")
@RequiredArgsConstructor
@Tag(name = "Pipeline Execution", description = "APIs for pipeline execution operations")
public class ExecutionController {

    private final ExecutionService executionService;

    @PostMapping("/flows/{flowId}/execute")
    @Operation(summary = "Execute a flow", description = "Starts execution of a flow's pipeline sequence")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "202", description = "Flow execution started", 
                    content = @Content(schema = @Schema(implementation = String.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input or no pipelines defined")
    })
    public ResponseEntity<ApiResponse<String>> executeFlow(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long flowId) {
        String executionId = executionService.startFlowExecution(flowId);
        return new ResponseEntity<>(ApiResponse.success("Flow execution started", executionId), HttpStatus.ACCEPTED);
    }

    @GetMapping("/{executionId}/status")
    @Operation(summary = "Get execution status", description = "Retrieves the status of a flow execution")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Execution status retrieved", 
                    content = @Content(schema = @Schema(implementation = ExecutionHistoryDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Execution not found")
    })
    public ResponseEntity<ApiResponse<List<ExecutionHistoryDto>>> getExecutionStatus(
            @Parameter(description = "Execution ID", required = true) @PathVariable String executionId) {
        List<ExecutionHistoryDto> status = executionService.getExecutionStatus(executionId);
        return ResponseEntity.ok(ApiResponse.success(status));
    }

    @GetMapping("/flows/{flowId}/history")
    @Operation(summary = "Get flow execution history", description = "Retrieves execution history for a specific flow")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Execution history retrieved", 
                    content = @Content(schema = @Schema(implementation = ExecutionHistoryDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<ApiResponse<List<ExecutionHistoryDto>>> getFlowExecutionHistory(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long flowId) {
        List<ExecutionHistoryDto> history = executionService.getExecutionHistoryByFlowId(flowId);
        return ResponseEntity.ok(ApiResponse.success(history));
    }

    @GetMapping("/pipelines/{pipelineId}/history")
    @Operation(summary = "Get pipeline execution history", description = "Retrieves execution history for a specific pipeline")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Execution history retrieved", 
                    content = @Content(schema = @Schema(implementation = ExecutionHistoryDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<ApiResponse<List<ExecutionHistoryDto>>> getPipelineExecutionHistory(
            @Parameter(description = "Pipeline ID", required = true) @PathVariable Long pipelineId) {
        List<ExecutionHistoryDto> history = executionService.getExecutionHistoryByPipelineId(pipelineId);
        return ResponseEntity.ok(ApiResponse.success(history));
    }
    
    @GetMapping("/history")
    @Operation(summary = "Get execution history by date range", description = "Retrieves execution history within a specific date range")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Execution history retrieved", 
                    content = @Content(schema = @Schema(implementation = ExecutionHistoryDto.class)))
    })
    public ResponseEntity<ApiResponse<List<ExecutionHistoryDto>>> getExecutionHistoryByDateRange(
            @Parameter(description = "Start date", required = true) 
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @Parameter(description = "End date", required = true) 
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        List<ExecutionHistoryDto> history = executionService.getExecutionHistoryByDateRange(startDate, endDate);
        return ResponseEntity.ok(ApiResponse.success(history));
    }

    @PostMapping("/{executionId}/cancel")
    @Operation(summary = "Cancel execution", description = "Cancels a running flow execution")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Execution canceled", 
                    content = @Content(schema = @Schema(implementation = Boolean.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Execution not found")
    })
    public ResponseEntity<ApiResponse<Boolean>> cancelExecution(
            @Parameter(description = "Execution ID", required = true) @PathVariable String executionId) {
        boolean canceled = executionService.cancelExecution(executionId);
        return ResponseEntity.ok(ApiResponse.success("Execution cancellation " + (canceled ? "successful" : "failed"), canceled));
    }
    
    @GetMapping("/flows/{flowId}/metrics")
    @Operation(summary = "Get execution metrics", description = "Retrieves execution metrics for a specific flow")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Metrics retrieved", 
                    content = @Content(schema = @Schema(implementation = Map.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<ApiResponse<Map<String, Object>>> getExecutionMetrics(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long flowId) {
        Map<String, Object> metrics = executionService.getExecutionMetrics(flowId);
        return ResponseEntity.ok(ApiResponse.success(metrics));
    }
}
