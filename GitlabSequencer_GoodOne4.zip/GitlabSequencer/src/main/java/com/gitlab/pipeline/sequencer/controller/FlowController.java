package com.gitlab.pipeline.sequencer.controller;

import com.gitlab.pipeline.sequencer.dto.ApiResponse;
import com.gitlab.pipeline.sequencer.dto.FlowDto;
import com.gitlab.pipeline.sequencer.service.FlowService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Flow management
 */
@RestController
@RequestMapping("/api/flows")
@RequiredArgsConstructor
@Tag(name = "Flow Management", description = "APIs for flow operations")
public class FlowController {

    private final FlowService flowService;

    @PostMapping
    @Operation(summary = "Create a new flow", description = "Creates a new flow with the provided details")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "201", description = "Flow created successfully", 
                    content = @Content(schema = @Schema(implementation = FlowDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input")
    })
    public ResponseEntity<ApiResponse<FlowDto>> createFlow(
            @Valid @RequestBody FlowDto flowDto) {
        FlowDto createdFlow = flowService.createFlow(flowDto);
        return new ResponseEntity<>(ApiResponse.success("Flow created successfully", createdFlow), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a flow by ID", description = "Retrieves a flow by its ID")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Flow found", 
                    content = @Content(schema = @Schema(implementation = FlowDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<ApiResponse<FlowDto>> getFlowById(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long id) {
        FlowDto flow = flowService.getFlowById(id);
        return ResponseEntity.ok(ApiResponse.success(flow));
    }

    @GetMapping
    @Operation(summary = "Get all flows", description = "Retrieves all flows")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Flows retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = FlowDto.class)))
    })
    public ResponseEntity<ApiResponse<List<FlowDto>>> getAllFlows() {
        List<FlowDto> flows = flowService.getAllFlows();
        return ResponseEntity.ok(ApiResponse.success(flows));
    }

    @GetMapping("/name/{name}")
    @Operation(summary = "Get a flow by name", description = "Retrieves a flow by its name")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Flow found", 
                    content = @Content(schema = @Schema(implementation = FlowDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<ApiResponse<FlowDto>> getFlowByName(
            @Parameter(description = "Flow name", required = true) @PathVariable String name) {
        FlowDto flow = flowService.getFlowByName(name);
        return ResponseEntity.ok(ApiResponse.success(flow));
    }

    @GetMapping("/tag/{tag}")
    @Operation(summary = "Get flows by tag", description = "Retrieves all flows with the specified tag")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Flows retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = FlowDto.class)))
    })
    public ResponseEntity<ApiResponse<List<FlowDto>>> getFlowsByTag(
            @Parameter(description = "Tag", required = true) @PathVariable String tag) {
        List<FlowDto> flows = flowService.findFlowsByTag(tag);
        return ResponseEntity.ok(ApiResponse.success(flows));
    }

    @GetMapping("/tags")
    @Operation(summary = "Get flows by multiple tags", description = "Retrieves all flows with any of the specified tags")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Flows retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = FlowDto.class)))
    })
    public ResponseEntity<ApiResponse<List<FlowDto>>> getFlowsByTags(
            @Parameter(description = "List of tags", required = true) @RequestParam List<String> tags) {
        List<FlowDto> flows = flowService.findFlowsByTags(tags);
        return ResponseEntity.ok(ApiResponse.success(flows));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a flow", description = "Updates an existing flow with the provided details")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Flow updated successfully", 
                    content = @Content(schema = @Schema(implementation = FlowDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<ApiResponse<FlowDto>> updateFlow(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long id,
            @Valid @RequestBody FlowDto flowDto) {
        FlowDto updatedFlow = flowService.updateFlow(id, flowDto);
        return ResponseEntity.ok(ApiResponse.success("Flow updated successfully", updatedFlow));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a flow", description = "Deletes an existing flow by its ID")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Flow deleted successfully"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<Void> deleteFlow(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long id) {
        flowService.deleteFlow(id);
        return ResponseEntity.noContent().build();
    }
}
