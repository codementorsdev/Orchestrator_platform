package com.gitlab.pipeline.sequencer.controller;

import com.gitlab.pipeline.sequencer.dto.ApiResponse;
import com.gitlab.pipeline.sequencer.dto.PipelineDto;
import com.gitlab.pipeline.sequencer.service.PipelineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Pipeline management
 */
@RestController
@RequestMapping("/api/pipelines")
@RequiredArgsConstructor
@Tag(name = "Pipeline Management", description = "APIs for pipeline operations")
public class PipelineController {

    private final PipelineService pipelineService;

    @PostMapping
    @Operation(summary = "Create a new pipeline", description = "Creates a new pipeline with the provided details")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "201", description = "Pipeline created successfully", 
                    content = @Content(schema = @Schema(implementation = PipelineDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input")
    })
    public ResponseEntity<ApiResponse<PipelineDto>> createPipeline(
            @Valid @RequestBody PipelineDto pipelineDto) {
        PipelineDto createdPipeline = pipelineService.createPipeline(pipelineDto);
        return new ResponseEntity<>(ApiResponse.success("Pipeline created successfully", createdPipeline), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a pipeline by ID", description = "Retrieves a pipeline by its ID")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Pipeline found", 
                    content = @Content(schema = @Schema(implementation = PipelineDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<ApiResponse<PipelineDto>> getPipelineById(
            @Parameter(description = "Pipeline ID", required = true) @PathVariable Long id) {
        PipelineDto pipeline = pipelineService.getPipelineById(id);
        return ResponseEntity.ok(ApiResponse.success(pipeline));
    }

    @GetMapping
    @Operation(summary = "Get all pipelines", description = "Retrieves all pipelines")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Pipelines retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = PipelineDto.class)))
    })
    public ResponseEntity<ApiResponse<List<PipelineDto>>> getAllPipelines() {
        List<PipelineDto> pipelines = pipelineService.getAllPipelines();
        return ResponseEntity.ok(ApiResponse.success(pipelines));
    }
    
    @GetMapping("/application/{applicationId}")
    @Operation(summary = "Get pipelines by application ID", description = "Retrieves all pipelines for a specific application")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Pipelines retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = PipelineDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Application not found")
    })
    public ResponseEntity<ApiResponse<List<PipelineDto>>> getPipelinesByApplicationId(
            @Parameter(description = "Application ID", required = true) @PathVariable Long applicationId) {
        List<PipelineDto> pipelines = pipelineService.getPipelinesByApplicationId(applicationId);
        return ResponseEntity.ok(ApiResponse.success(pipelines));
    }
    
    @GetMapping("/flow/{flowId}")
    @Operation(summary = "Get pipelines by flow ID", description = "Retrieves all pipelines for a specific flow, ordered by sequence")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Pipelines retrieved successfully", 
                    content = @Content(schema = @Schema(implementation = PipelineDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Flow not found")
    })
    public ResponseEntity<ApiResponse<List<PipelineDto>>> getPipelinesByFlowId(
            @Parameter(description = "Flow ID", required = true) @PathVariable Long flowId) {
        List<PipelineDto> pipelines = pipelineService.getPipelinesByFlowIdOrdered(flowId);
        return ResponseEntity.ok(ApiResponse.success(pipelines));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a pipeline", description = "Updates an existing pipeline with the provided details")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Pipeline updated successfully", 
                    content = @Content(schema = @Schema(implementation = PipelineDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<ApiResponse<PipelineDto>> updatePipeline(
            @Parameter(description = "Pipeline ID", required = true) @PathVariable Long id,
            @Valid @RequestBody PipelineDto pipelineDto) {
        PipelineDto updatedPipeline = pipelineService.updatePipeline(id, pipelineDto);
        return ResponseEntity.ok(ApiResponse.success("Pipeline updated successfully", updatedPipeline));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a pipeline", description = "Deletes an existing pipeline by its ID")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Pipeline deleted successfully"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Pipeline not found")
    })
    public ResponseEntity<Void> deletePipeline(
            @Parameter(description = "Pipeline ID", required = true) @PathVariable Long id) {
        pipelineService.deletePipeline(id);
        return ResponseEntity.noContent().build();
    }
    
    @PutMapping("/sequence")
    @Operation(summary = "Update pipeline sequence", description = "Updates the sequence order of multiple pipelines")
    @ApiResponses(value = {
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Pipeline sequence updated successfully", 
                    content = @Content(schema = @Schema(implementation = PipelineDto.class))),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Invalid input"),
            @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "One or more pipelines not found")
    })
    public ResponseEntity<ApiResponse<List<PipelineDto>>> updatePipelineSequence(
            @Parameter(description = "List of pipeline IDs in the desired order", required = true) 
            @RequestBody List<Long> pipelineIds) {
        List<PipelineDto> updatedPipelines = pipelineService.updatePipelineSequence(pipelineIds);
        return ResponseEntity.ok(ApiResponse.success("Pipeline sequence updated successfully", updatedPipelines));
    }
}
