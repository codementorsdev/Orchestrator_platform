package com.gitlab.pipeline.sequencer.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Data Transfer Object for Application entity
 */
public class ApplicationDto {
    
    private Long id;
    
    @NotBlank(message = "Name is required")
    @Size(min = 3, max = 100, message = "Name must be between 3 and 100 characters")
    private String name;
    
    @NotNull(message = "Project ID is required")
    @Positive(message = "Project ID must be a positive number")
    private Integer projectId;
    
    @NotBlank(message = "Access token is required")
    private String accessToken;
    
    @NotNull(message = "Flow ID is required")
    private Long flowId;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    // Default constructor
    public ApplicationDto() {
    }
    
    // All args constructor
    public ApplicationDto(Long id, String name, Integer projectId, String accessToken, Long flowId, 
                          LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.name = name;
        this.projectId = projectId;
        this.accessToken = accessToken;
        this.flowId = flowId;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    // Static builder method
    public static Builder builder() {
        return new Builder();
    }
    
    // Getters and setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public Integer getProjectId() {
        return projectId;
    }
    
    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }
    
    public String getAccessToken() {
        return accessToken;
    }
    
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
    
    public Long getFlowId() {
        return flowId;
    }
    
    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ApplicationDto that = (ApplicationDto) o;
        return Objects.equals(id, that.id) &&
               Objects.equals(name, that.name) &&
               Objects.equals(projectId, that.projectId) &&
               Objects.equals(accessToken, that.accessToken) &&
               Objects.equals(flowId, that.flowId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, name, projectId, accessToken, flowId);
    }
    
    @Override
    public String toString() {
        return "ApplicationDto{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", projectId=" + projectId +
                ", accessToken='********'" +
                ", flowId=" + flowId +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
    
    // Builder class
    public static class Builder {
        private Long id;
        private String name;
        private Integer projectId;
        private String accessToken;
        private Long flowId;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        
        private Builder() {
        }
        
        public Builder id(Long id) {
            this.id = id;
            return this;
        }
        
        public Builder name(String name) {
            this.name = name;
            return this;
        }
        
        public Builder projectId(Integer projectId) {
            this.projectId = projectId;
            return this;
        }
        
        public Builder accessToken(String accessToken) {
            this.accessToken = accessToken;
            return this;
        }
        
        public Builder flowId(Long flowId) {
            this.flowId = flowId;
            return this;
        }
        
        public Builder createdAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        
        public Builder updatedAt(LocalDateTime updatedAt) {
            this.updatedAt = updatedAt;
            return this;
        }
        
        public ApplicationDto build() {
            return new ApplicationDto(id, name, projectId, accessToken, flowId, createdAt, updatedAt);
        }
    }
}
