package com.gitlab.pipeline.sequencer.dto;

import com.gitlab.pipeline.sequencer.model.PipelineStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Data Transfer Object for ExecutionHistory entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExecutionHistoryDto {
    
    private Long id;
    
    private String executionId;
    
    private Long flowId;
    
    private String flowName;
    
    private Long pipelineId;
    
    private String pipelineName;
    
    private Integer gitlabPipelineId;
    
    private LocalDateTime startTime;
    
    private LocalDateTime endTime;
    
    private PipelineStatus status;
    
    private String logs;
    
    private String errorMessage;
    
    private Long durationInSeconds;
}
