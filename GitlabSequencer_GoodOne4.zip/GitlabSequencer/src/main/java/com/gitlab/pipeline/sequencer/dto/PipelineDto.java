package com.gitlab.pipeline.sequencer.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import java.time.LocalDateTime;

/**
 * Data Transfer Object for Pipeline entity
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PipelineDto {
    
    private Long id;
    
    @NotBlank(message = "Pipeline name is required")
    private String pipelineName;
    
    @NotBlank(message = "Branch name is required")
    private String branch;
    
    @NotNull(message = "Sequence order is required")
    @PositiveOrZero(message = "Sequence order must be zero or positive")
    private Integer sequenceOrder;
    
    @NotNull(message = "Application ID is required")
    @Positive(message = "Application ID must be positive")
    private Long applicationId;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
}
