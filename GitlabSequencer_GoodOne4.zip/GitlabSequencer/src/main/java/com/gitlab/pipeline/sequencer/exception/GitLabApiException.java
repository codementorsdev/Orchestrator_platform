package com.gitlab.pipeline.sequencer.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when there's an error with the GitLab API
 */
@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class GitLabApiException extends RuntimeException {
    
    private final Integer gitlabErrorCode;
    
    public GitLabApiException(String message) {
        super(message);
        this.gitlabErrorCode = null;
    }
    
    public GitLabApiException(String message, Throwable cause) {
        super(message, cause);
        this.gitlabErrorCode = null;
    }
    
    public GitLabApiException(String message, Integer gitlabErrorCode) {
        super(message);
        this.gitlabErrorCode = gitlabErrorCode;
    }
    
    public GitLabApiException(String message, Integer gitlabErrorCode, Throwable cause) {
        super(message, cause);
        this.gitlabErrorCode = gitlabErrorCode;
    }
    
    public Integer getGitlabErrorCode() {
        return gitlabErrorCode;
    }
}
