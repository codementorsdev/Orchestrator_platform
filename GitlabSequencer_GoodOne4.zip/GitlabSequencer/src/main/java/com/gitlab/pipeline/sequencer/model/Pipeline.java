package com.gitlab.pipeline.sequencer.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * Entity representing a GitLab pipeline configuration
 */
@Entity
@Table(name = "pipelines")
public class Pipeline {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pipeline_name", nullable = false)
    private String pipelineName;

    @Column(nullable = false)
    private String branch;

    @Column(name = "sequence_order", nullable = false)
    private Integer sequenceOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id", nullable = false)
    private Application application;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Default constructor
    public Pipeline() {
    }
    
    // Builder constructor
    private Pipeline(Builder builder) {
        this.id = builder.id;
        this.pipelineName = builder.pipelineName;
        this.branch = builder.branch;
        this.sequenceOrder = builder.sequenceOrder;
        this.application = builder.application;
        this.createdAt = builder.createdAt;
        this.updatedAt = builder.updatedAt;
    }
    
    // Static builder method
    public static Builder builder() {
        return new Builder();
    }

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    // Getters and setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getPipelineName() {
        return pipelineName;
    }
    
    public void setPipelineName(String pipelineName) {
        this.pipelineName = pipelineName;
    }
    
    public String getBranch() {
        return branch;
    }
    
    public void setBranch(String branch) {
        this.branch = branch;
    }
    
    public Integer getSequenceOrder() {
        return sequenceOrder;
    }
    
    public void setSequenceOrder(Integer sequenceOrder) {
        this.sequenceOrder = sequenceOrder;
    }
    
    public Application getApplication() {
        return application;
    }
    
    public void setApplication(Application application) {
        this.application = application;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    // Builder class
    public static class Builder {
        private Long id;
        private String pipelineName;
        private String branch;
        private Integer sequenceOrder;
        private Application application;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        
        private Builder() {
        }
        
        public Builder id(Long id) {
            this.id = id;
            return this;
        }
        
        public Builder pipelineName(String pipelineName) {
            this.pipelineName = pipelineName;
            return this;
        }
        
        public Builder branch(String branch) {
            this.branch = branch;
            return this;
        }
        
        public Builder sequenceOrder(Integer sequenceOrder) {
            this.sequenceOrder = sequenceOrder;
            return this;
        }
        
        public Builder application(Application application) {
            this.application = application;
            return this;
        }
        
        public Builder createdAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        
        public Builder updatedAt(LocalDateTime updatedAt) {
            this.updatedAt = updatedAt;
            return this;
        }
        
        public Pipeline build() {
            return new Pipeline(this);
        }
    }
}
