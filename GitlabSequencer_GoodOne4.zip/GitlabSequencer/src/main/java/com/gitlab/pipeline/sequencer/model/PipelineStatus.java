package com.gitlab.pipeline.sequencer.model;

/**
 * Enum representing the various states of a pipeline execution
 */
public enum PipelineStatus {
    PENDING,
    RUNNING,
    SUCCESS,
    FAILED,
    CANCELED,
    SKIPPED,
    CREATED
}
