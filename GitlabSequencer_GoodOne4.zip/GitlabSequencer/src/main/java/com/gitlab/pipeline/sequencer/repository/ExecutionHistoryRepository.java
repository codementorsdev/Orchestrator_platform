package com.gitlab.pipeline.sequencer.repository;

import com.gitlab.pipeline.sequencer.model.ExecutionHistory;
import com.gitlab.pipeline.sequencer.model.PipelineStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for managing ExecutionHistory entities
 */
@Repository
public interface ExecutionHistoryRepository extends JpaRepository<ExecutionHistory, Long> {
    
    List<ExecutionHistory> findByFlowId(Long flowId);
    
    List<ExecutionHistory> findByFlowIdAndStatus(Long flowId, PipelineStatus status);
    
    List<ExecutionHistory> findByPipelineId(Long pipelineId);
    
    List<ExecutionHistory> findByExecutionId(String executionId);
    
    @Query("SELECT e FROM ExecutionHistory e WHERE e.startTime BETWEEN :startDate AND :endDate")
    List<ExecutionHistory> findByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT e FROM ExecutionHistory e WHERE e.gitlabPipelineId = :gitlabPipelineId")
    Optional<ExecutionHistory> findByGitlabPipelineId(@Param("gitlabPipelineId") Integer gitlabPipelineId);
    
    // Changed to use a native query instead of JPQL for time extraction
    @Query(value = "SELECT AVG(EXTRACT(EPOCH FROM (end_time - start_time))) FROM execution_history e " + 
          "JOIN flow f ON e.flow_id = f.id WHERE f.id = :flowId AND e.status = 'SUCCESS'", nativeQuery = true)
    Double getAverageExecutionTimeForFlow(@Param("flowId") Long flowId);
    
    @Query("SELECT COUNT(e) FROM ExecutionHistory e WHERE e.flow.id = :flowId AND e.status = :status")
    Long countByFlowIdAndStatus(@Param("flowId") Long flowId, @Param("status") PipelineStatus status);
}
