package com.gitlab.pipeline.sequencer.repository;

import com.gitlab.pipeline.sequencer.model.Flow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for managing Flow entities
 */
@Repository
public interface FlowRepository extends JpaRepository<Flow, Long> {
    
    Optional<Flow> findByName(String name);
    
    boolean existsByName(String name);
    
    @Query("SELECT f FROM Flow f JOIN f.tags t WHERE t = :tag")
    List<Flow> findByTag(@Param("tag") String tag);
    
    @Query("SELECT DISTINCT f FROM Flow f JOIN f.tags t WHERE t IN :tags")
    List<Flow> findByTagsIn(@Param("tags") List<String> tags);
}
