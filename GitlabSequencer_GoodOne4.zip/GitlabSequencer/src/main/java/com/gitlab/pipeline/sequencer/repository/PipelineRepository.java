package com.gitlab.pipeline.sequencer.repository;

import com.gitlab.pipeline.sequencer.model.Pipeline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for managing Pipeline entities
 */
@Repository
public interface PipelineRepository extends JpaRepository<Pipeline, Long> {
    
    List<Pipeline> findByApplicationId(Long applicationId);
    
    Optional<Pipeline> findByApplicationIdAndPipelineName(Long applicationId, String pipelineName);
    
    @Query("SELECT p FROM Pipeline p JOIN p.application a WHERE a.flow.id = :flowId ORDER BY p.sequenceOrder ASC")
    List<Pipeline> findPipelinesByFlowIdOrderBySequenceOrder(@Param("flowId") Long flowId);
    
    @Query("SELECT p FROM Pipeline p JOIN p.application a WHERE a.flow.id = :flowId AND a.id = :applicationId ORDER BY p.sequenceOrder ASC")
    List<Pipeline> findPipelinesByFlowIdAndApplicationIdOrderBySequenceOrder(@Param("flowId") Long flowId, @Param("applicationId") Long applicationId);
}
