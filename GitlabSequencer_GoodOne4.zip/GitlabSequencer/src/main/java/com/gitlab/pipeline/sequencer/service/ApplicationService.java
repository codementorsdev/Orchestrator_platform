package com.gitlab.pipeline.sequencer.service;

import com.gitlab.pipeline.sequencer.dto.ApplicationDto;

import java.util.List;

/**
 * Service interface for Application operations
 */
public interface ApplicationService {
    
    /**
     * Create a new application
     *
     * @param applicationDto the application data to create
     * @return the created application
     */
    ApplicationDto createApplication(ApplicationDto applicationDto);
    
    /**
     * Get an application by its ID
     *
     * @param id the application ID
     * @return the application if found
     */
    ApplicationDto getApplicationById(Long id);
    
    /**
     * Get all applications for a specific flow
     *
     * @param flowId the flow ID
     * @return list of applications for the flow
     */
    List<ApplicationDto> getApplicationsByFlowId(Long flowId);
    
    /**
     * Get all applications
     *
     * @return list of all applications
     */
    List<ApplicationDto> getAllApplications();
    
    /**
     * Update an existing application
     *
     * @param id the application ID to update
     * @param applicationDto the updated application data
     * @return the updated application
     */
    ApplicationDto updateApplication(Long id, ApplicationDto applicationDto);
    
    /**
     * Delete an application by its ID
     *
     * @param id the application ID to delete
     */
    void deleteApplication(Long id);
    
    /**
     * Verify GitLab access token for an application
     *
     * @param id the application ID to verify
     * @return true if the token is valid, false otherwise
     */
    boolean verifyGitLabAccess(Long id);
}
