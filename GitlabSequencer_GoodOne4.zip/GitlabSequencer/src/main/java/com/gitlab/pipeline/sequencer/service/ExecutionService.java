package com.gitlab.pipeline.sequencer.service;

import com.gitlab.pipeline.sequencer.dto.ExecutionHistoryDto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Service interface for pipeline execution operations
 */
public interface ExecutionService {
    
    /**
     * Start execution of a flow's pipeline sequence
     *
     * @param flowId the flow ID to execute
     * @return the execution ID
     */
    String startFlowExecution(Long flowId);
    
    /**
     * Get the status of a flow execution
     *
     * @param executionId the execution ID
     * @return list of execution histories for the execution
     */
    List<ExecutionHistoryDto> getExecutionStatus(String executionId);
    
    /**
     * Get execution history for a flow
     *
     * @param flowId the flow ID
     * @return list of execution histories for the flow
     */
    List<ExecutionHistoryDto> getExecutionHistoryByFlowId(Long flowId);
    
    /**
     * Get execution history for a pipeline
     *
     * @param pipelineId the pipeline ID
     * @return list of execution histories for the pipeline
     */
    List<ExecutionHistoryDto> getExecutionHistoryByPipelineId(Long pipelineId);
    
    /**
     * Get execution history for a specific date range
     *
     * @param startDate the start date
     * @param endDate the end date
     * @return list of execution histories within the date range
     */
    List<ExecutionHistoryDto> getExecutionHistoryByDateRange(LocalDateTime startDate, LocalDateTime endDate);
    
    /**
     * Cancel a running execution
     *
     * @param executionId the execution ID to cancel
     * @return true if canceled successfully, false otherwise
     */
    boolean cancelExecution(String executionId);
    
    /**
     * Get execution metrics for a flow
     *
     * @param flowId the flow ID
     * @return map of metric names to values
     */
    Map<String, Object> getExecutionMetrics(Long flowId);
}
