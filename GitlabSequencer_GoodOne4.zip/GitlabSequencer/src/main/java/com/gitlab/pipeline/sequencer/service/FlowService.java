package com.gitlab.pipeline.sequencer.service;

import com.gitlab.pipeline.sequencer.dto.FlowDto;

import java.util.List;

/**
 * Service interface for Flow operations
 */
public interface FlowService {
    
    /**
     * Create a new flow
     *
     * @param flowDto the flow data to create
     * @return the created flow
     */
    FlowDto createFlow(FlowDto flowDto);
    
    /**
     * Get a flow by its ID
     *
     * @param id the flow ID
     * @return the flow if found
     */
    FlowDto getFlowById(Long id);
    
    /**
     * Get a flow by its name
     *
     * @param name the flow name
     * @return the flow if found
     */
    FlowDto getFlowByName(String name);
    
    /**
     * Get all flows
     *
     * @return list of all flows
     */
    List<FlowDto> getAllFlows();
    
    /**
     * Update an existing flow
     *
     * @param id the flow ID to update
     * @param flowDto the updated flow data
     * @return the updated flow
     */
    FlowDto updateFlow(Long id, FlowDto flowDto);
    
    /**
     * Delete a flow by its ID
     *
     * @param id the flow ID to delete
     */
    void deleteFlow(Long id);
    
    /**
     * Find flows by tag
     *
     * @param tag the tag to search for
     * @return list of flows with the specified tag
     */
    List<FlowDto> findFlowsByTag(String tag);
    
    /**
     * Find flows by multiple tags
     *
     * @param tags the list of tags to search for
     * @return list of flows with any of the specified tags
     */
    List<FlowDto> findFlowsByTags(List<String> tags);
}
