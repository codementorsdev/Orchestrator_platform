package com.gitlab.pipeline.sequencer.service;

import org.gitlab4j.api.models.Pipeline;

/**
 * Service interface for GitLab API operations
 */
public interface GitLabService {
    
    /**
     * Trigger a GitLab pipeline
     *
     * @param projectId the GitLab project ID
     * @param accessToken the GitLab access token
     * @param branch the branch to run the pipeline on
     * @param variables optional variables for the pipeline
     * @return the created pipeline
     */
    Pipeline triggerPipeline(Integer projectId, String accessToken, String branch, java.util.Map<String, String> variables);
    
    /**
     * Get the status of a GitLab pipeline
     *
     * @param projectId the GitLab project ID
     * @param accessToken the GitLab access token
     * @param pipelineId the GitLab pipeline ID
     * @return the pipeline with status
     */
    Pipeline getPipelineStatus(Integer projectId, String accessToken, Integer pipelineId);
    
    /**
     * Cancel a running GitLab pipeline
     *
     * @param projectId the GitLab project ID
     * @param accessToken the GitLab access token
     * @param pipelineId the GitLab pipeline ID
     * @return true if canceled successfully, false otherwise
     */
    boolean cancelPipeline(Integer projectId, String accessToken, Integer pipelineId);
    
    /**
     * Retry a failed GitLab pipeline
     *
     * @param projectId the GitLab project ID
     * @param accessToken the GitLab access token
     * @param pipelineId the GitLab pipeline ID
     * @return the retried pipeline
     */
    Pipeline retryPipeline(Integer projectId, String accessToken, Integer pipelineId);
    
    /**
     * Test if a GitLab access token is valid for a project
     *
     * @param projectId the GitLab project ID
     * @param accessToken the GitLab access token
     * @return true if the token is valid, false otherwise
     */
    boolean testConnection(Integer projectId, String accessToken);
    
    /**
     * Get logs for a pipeline job
     *
     * @param projectId the GitLab project ID
     * @param accessToken the GitLab access token
     * @param jobId the GitLab job ID
     * @return the job logs
     */
    String getPipelineJobLogs(Integer projectId, String accessToken, Integer jobId);
}
