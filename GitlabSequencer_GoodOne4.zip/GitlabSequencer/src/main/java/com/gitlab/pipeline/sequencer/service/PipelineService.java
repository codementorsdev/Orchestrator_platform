package com.gitlab.pipeline.sequencer.service;

import com.gitlab.pipeline.sequencer.dto.PipelineDto;

import java.util.List;

/**
 * Service interface for Pipeline operations
 */
public interface PipelineService {
    
    /**
     * Create a new pipeline
     *
     * @param pipelineDto the pipeline data to create
     * @return the created pipeline
     */
    PipelineDto createPipeline(PipelineDto pipelineDto);
    
    /**
     * Get a pipeline by its ID
     *
     * @param id the pipeline ID
     * @return the pipeline if found
     */
    PipelineDto getPipelineById(Long id);
    
    /**
     * Get all pipelines for a specific application
     *
     * @param applicationId the application ID
     * @return list of pipelines for the application
     */
    List<PipelineDto> getPipelinesByApplicationId(Long applicationId);
    
    /**
     * Get all pipelines for a specific flow, ordered by sequence
     *
     * @param flowId the flow ID
     * @return ordered list of pipelines for the flow
     */
    List<PipelineDto> getPipelinesByFlowIdOrdered(Long flowId);
    
    /**
     * Get all pipelines
     *
     * @return list of all pipelines
     */
    List<PipelineDto> getAllPipelines();
    
    /**
     * Update an existing pipeline
     *
     * @param id the pipeline ID to update
     * @param pipelineDto the updated pipeline data
     * @return the updated pipeline
     */
    PipelineDto updatePipeline(Long id, PipelineDto pipelineDto);
    
    /**
     * Delete a pipeline by its ID
     *
     * @param id the pipeline ID to delete
     */
    void deletePipeline(Long id);
    
    /**
     * Update the sequence order of pipelines
     *
     * @param pipelineIds the list of pipeline IDs in the desired order
     * @return the updated list of pipelines
     */
    List<PipelineDto> updatePipelineSequence(List<Long> pipelineIds);
}
