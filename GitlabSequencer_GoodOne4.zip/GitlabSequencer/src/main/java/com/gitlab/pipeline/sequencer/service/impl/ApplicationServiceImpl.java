package com.gitlab.pipeline.sequencer.service.impl;

import com.gitlab.pipeline.sequencer.dto.ApplicationDto;
import com.gitlab.pipeline.sequencer.exception.ResourceNotFoundException;
import com.gitlab.pipeline.sequencer.model.Application;
import com.gitlab.pipeline.sequencer.model.Flow;
import com.gitlab.pipeline.sequencer.repository.ApplicationRepository;
import com.gitlab.pipeline.sequencer.repository.FlowRepository;
import com.gitlab.pipeline.sequencer.service.ApplicationService;
import com.gitlab.pipeline.sequencer.service.GitLabService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of ApplicationService
 */
@Service
public class ApplicationServiceImpl implements ApplicationService {

    private static final Logger log = LoggerFactory.getLogger(ApplicationServiceImpl.class);
    
    private final ApplicationRepository applicationRepository;
    private final FlowRepository flowRepository;
    private final GitLabService gitLabService;
    
    @Autowired
    public ApplicationServiceImpl(ApplicationRepository applicationRepository, 
                                 FlowRepository flowRepository,
                                 GitLabService gitLabService) {
        this.applicationRepository = applicationRepository;
        this.flowRepository = flowRepository;
        this.gitLabService = gitLabService;
    }

    @Override
    @Transactional
    public ApplicationDto createApplication(ApplicationDto applicationDto) {
        log.info("Creating application with name: {} for flow ID: {}", applicationDto.getName(), applicationDto.getFlowId());
        
        if (applicationRepository.existsByFlowIdAndName(applicationDto.getFlowId(), applicationDto.getName())) {
            throw new IllegalArgumentException("Application with name " + applicationDto.getName() + 
                    " already exists in flow with ID " + applicationDto.getFlowId());
        }
        
        Flow flow = flowRepository.findById(applicationDto.getFlowId())
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", applicationDto.getFlowId()));
        
        // Verify GitLab connection
        boolean isValid = gitLabService.testConnection(applicationDto.getProjectId(), applicationDto.getAccessToken());
        if (!isValid) {
            throw new IllegalArgumentException("Invalid GitLab project ID or access token");
        }
        
        Application application = Application.builder()
                .name(applicationDto.getName())
                .projectId(applicationDto.getProjectId())
                .accessToken(applicationDto.getAccessToken())
                .flow(flow)
                .build();
        
        Application savedApplication = applicationRepository.save(application);
        log.info("Application created with ID: {}", savedApplication.getId());
        
        return mapToDto(savedApplication);
    }

    @Override
    @Transactional(readOnly = true)
    public ApplicationDto getApplicationById(Long id) {
        log.info("Getting application with ID: {}", id);
        Application application = findApplicationById(id);
        return mapToDto(application);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDto> getApplicationsByFlowId(Long flowId) {
        log.info("Getting applications for flow ID: {}", flowId);
        
        // Verify flow exists
        if (!flowRepository.existsById(flowId)) {
            throw new ResourceNotFoundException("Flow", "id", flowId);
        }
        
        return applicationRepository.findByFlowId(flowId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDto> getAllApplications() {
        log.info("Getting all applications");
        return applicationRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ApplicationDto updateApplication(Long id, ApplicationDto applicationDto) {
        log.info("Updating application with ID: {}", id);
        Application application = findApplicationById(id);
        
        if (!application.getName().equals(applicationDto.getName()) && 
                applicationRepository.existsByFlowIdAndName(applicationDto.getFlowId(), applicationDto.getName())) {
            throw new IllegalArgumentException("Application with name " + applicationDto.getName() + 
                    " already exists in flow with ID " + applicationDto.getFlowId());
        }
        
        // If flow ID is changing, verify the new flow exists
        if (!application.getFlow().getId().equals(applicationDto.getFlowId())) {
            Flow newFlow = flowRepository.findById(applicationDto.getFlowId())
                    .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", applicationDto.getFlowId()));
            application.setFlow(newFlow);
        }
        
        // If project ID or token changed, verify GitLab connection
        if (!application.getProjectId().equals(applicationDto.getProjectId()) || 
                !application.getAccessToken().equals(applicationDto.getAccessToken())) {
            boolean isValid = gitLabService.testConnection(applicationDto.getProjectId(), applicationDto.getAccessToken());
            if (!isValid) {
                throw new IllegalArgumentException("Invalid GitLab project ID or access token");
            }
        }
        
        application.setName(applicationDto.getName());
        application.setProjectId(applicationDto.getProjectId());
        application.setAccessToken(applicationDto.getAccessToken());
        
        Application updatedApplication = applicationRepository.save(application);
        log.info("Application updated: {}", updatedApplication.getId());
        
        return mapToDto(updatedApplication);
    }

    @Override
    @Transactional
    public void deleteApplication(Long id) {
        log.info("Deleting application with ID: {}", id);
        Application application = findApplicationById(id);
        applicationRepository.delete(application);
        log.info("Application deleted: {}", id);
    }

    @Override
    public boolean verifyGitLabAccess(Long id) {
        log.info("Verifying GitLab access for application with ID: {}", id);
        Application application = findApplicationById(id);
        return gitLabService.testConnection(application.getProjectId(), application.getAccessToken());
    }
    
    private Application findApplicationById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", id));
    }
    
    private ApplicationDto mapToDto(Application application) {
        return ApplicationDto.builder()
                .id(application.getId())
                .name(application.getName())
                .projectId(application.getProjectId())
                .accessToken(application.getAccessToken())
                .flowId(application.getFlow().getId())
                .createdAt(application.getCreatedAt())
                .updatedAt(application.getUpdatedAt())
                .build();
    }
}
