package com.gitlab.pipeline.sequencer.service.impl;

import com.gitlab.pipeline.sequencer.dto.ExecutionHistoryDto;
import com.gitlab.pipeline.sequencer.exception.ResourceNotFoundException;
import com.gitlab.pipeline.sequencer.model.*;
import com.gitlab.pipeline.sequencer.repository.ExecutionHistoryRepository;
import com.gitlab.pipeline.sequencer.repository.FlowRepository;
import com.gitlab.pipeline.sequencer.repository.PipelineRepository;
import com.gitlab.pipeline.sequencer.service.ExecutionService;
import com.gitlab.pipeline.sequencer.service.GitLabService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.gitlab4j.api.models.Pipeline;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Implementation of ExecutionService for pipeline sequence execution
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ExecutionServiceImpl implements ExecutionService {

    private final FlowRepository flowRepository;
    private final PipelineRepository pipelineRepository;
    private final ExecutionHistoryRepository executionHistoryRepository;
    private final GitLabService gitLabService;
    
    // Map to track running executions for cancellation
    private final Map<String, Boolean> runningExecutions = new HashMap<>();

    @Override
    @Transactional
    public String startFlowExecution(Long flowId) {
        log.info("Starting flow execution for flow ID: {}", flowId);
        
        Flow flow = flowRepository.findById(flowId)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", flowId));
        
        List<com.gitlab.pipeline.sequencer.model.Pipeline> pipelines = 
                pipelineRepository.findPipelinesByFlowIdOrderBySequenceOrder(flowId);
        
        if (pipelines.isEmpty()) {
            throw new IllegalStateException("No pipelines defined for flow: " + flow.getName());
        }
        
        // Generate unique execution ID
        String executionId = UUID.randomUUID().toString();
        runningExecutions.put(executionId, true);
        
        // Create initial execution history records
        List<ExecutionHistory> executionHistories = new ArrayList<>();
        for (com.gitlab.pipeline.sequencer.model.Pipeline pipeline : pipelines) {
            ExecutionHistory history = ExecutionHistory.builder()
                    .executionId(executionId)
                    .flow(flow)
                    .pipeline(pipeline)
                    .status(PipelineStatus.PENDING)
                    .startTime(null) // Will be set when the pipeline starts
                    .build();
            executionHistories.add(executionHistoryRepository.save(history));
        }
        
        // Start async execution
        executeFlowAsync(executionId, flow, pipelines);
        
        log.info("Flow execution started with execution ID: {}", executionId);
        return executionId;
    }

    @Async
    protected void executeFlowAsync(String executionId, Flow flow, List<com.gitlab.pipeline.sequencer.model.Pipeline> pipelines) {
        log.info("Executing flow: {} with execution ID: {}", flow.getName(), executionId);
        
        for (com.gitlab.pipeline.sequencer.model.Pipeline pipeline : pipelines) {
            // Check if execution was canceled
            if (!runningExecutions.getOrDefault(executionId, false)) {
                log.info("Execution {} was canceled, stopping further pipelines", executionId);
                break;
            }
            
            try {
                executePipeline(executionId, pipeline);
            } catch (Exception e) {
                log.error("Error executing pipeline: {}", pipeline.getId(), e);
                updateExecutionStatus(executionId, pipeline.getId(), PipelineStatus.FAILED, e.getMessage());
                break; // Stop execution on failure
            }
        }
        
        // Cleanup
        runningExecutions.remove(executionId);
        log.info("Flow execution completed for execution ID: {}", executionId);
    }
    
    private void executePipeline(String executionId, com.gitlab.pipeline.sequencer.model.Pipeline pipeline) {
        log.info("Executing pipeline: {} for execution ID: {}", pipeline.getPipelineName(), executionId);
        
        Application application = pipeline.getApplication();
        LocalDateTime startTime = LocalDateTime.now();
        
        // Update status to RUNNING
        updateExecutionStatus(executionId, pipeline.getId(), PipelineStatus.RUNNING, null);
        
        try {
            // Trigger GitLab pipeline
            Pipeline gitlabPipeline = gitLabService.triggerPipeline(
                    application.getProjectId(),
                    application.getAccessToken(),
                    pipeline.getBranch(),
                    Collections.emptyMap()
            );
            
            // Update GitLab pipeline ID
            // Convert Long to Integer for GitLab pipeline ID
            updateGitLabPipelineId(executionId, pipeline.getId(), gitlabPipeline.getId().intValue());
            
            // Monitor pipeline status
            monitorPipelineExecution(executionId, pipeline, gitlabPipeline.getId().intValue());
            
        } catch (Exception e) {
            log.error("Failed to execute pipeline: {}", pipeline.getId(), e);
            updateExecutionStatus(executionId, pipeline.getId(), PipelineStatus.FAILED, e.getMessage());
            throw e;
        }
    }
    
    private void monitorPipelineExecution(String executionId, com.gitlab.pipeline.sequencer.model.Pipeline pipeline, Integer gitlabPipelineId) {
        log.info("Monitoring GitLab pipeline: {} for execution ID: {}", gitlabPipelineId, executionId);
        
        Application application = pipeline.getApplication();
        boolean completed = false;
        Pipeline gitlabPipeline = null;
        
        // Poll for pipeline status
        while (!completed && runningExecutions.getOrDefault(executionId, false)) {
            try {
                gitlabPipeline = gitLabService.getPipelineStatus(
                        application.getProjectId(),
                        application.getAccessToken(),
                        gitlabPipelineId
                );
                
                String status = gitlabPipeline.getStatus().toString().toLowerCase();
                log.debug("Pipeline {} status: {}", gitlabPipelineId, status);
                
                if (status.equals("success")) {
                    updateExecutionStatus(executionId, pipeline.getId(), PipelineStatus.SUCCESS, null);
                    completed = true;
                } else if (status.equals("failed") || status.equals("canceled")) {
                    PipelineStatus pipelineStatus = status.equals("failed") ? PipelineStatus.FAILED : PipelineStatus.CANCELED;
                    updateExecutionStatus(executionId, pipeline.getId(), pipelineStatus, 
                            "GitLab pipeline " + status + ": " + gitlabPipeline.getId());
                    completed = true;
                    
                    if (pipelineStatus == PipelineStatus.FAILED) {
                        throw new RuntimeException("GitLab pipeline failed: " + gitlabPipelineId);
                    }
                }
                
                if (!completed) {
                    // Wait before polling again
                    Thread.sleep(10000); // 10 seconds
                }
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.warn("Pipeline monitoring interrupted for pipeline: {}", gitlabPipelineId);
                break;
            } catch (Exception e) {
                log.error("Error monitoring pipeline: {}", gitlabPipelineId, e);
                updateExecutionStatus(executionId, pipeline.getId(), PipelineStatus.FAILED, e.getMessage());
                throw new RuntimeException("Failed to monitor pipeline: " + e.getMessage(), e);
            }
        }
        
        if (!completed && !runningExecutions.getOrDefault(executionId, false)) {
            log.info("Execution was canceled, canceling GitLab pipeline: {}", gitlabPipelineId);
            try {
                gitLabService.cancelPipeline(
                        application.getProjectId(),
                        application.getAccessToken(),
                        gitlabPipelineId
                );
            } catch (Exception e) {
                log.error("Failed to cancel GitLab pipeline: {}", gitlabPipelineId, e);
            }
        }
    }
    
    @Transactional
    protected void updateExecutionStatus(String executionId, Long pipelineId, PipelineStatus status, String errorMessage) {
        log.info("Updating execution status for execution ID: {}, pipeline: {} to: {}", 
                executionId, pipelineId, status);
        
        ExecutionHistory history = executionHistoryRepository.findByExecutionId(executionId)
                .stream()
                .filter(h -> h.getPipeline().getId().equals(pipelineId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Execution history", "executionId and pipelineId", 
                        executionId + ":" + pipelineId));
        
        if (status == PipelineStatus.RUNNING && history.getStartTime() == null) {
            history.setStartTime(LocalDateTime.now());
        }
        
        if (status == PipelineStatus.SUCCESS || status == PipelineStatus.FAILED || status == PipelineStatus.CANCELED) {
            history.setEndTime(LocalDateTime.now());
        }
        
        history.setStatus(status);
        
        if (errorMessage != null) {
            history.setErrorMessage(errorMessage);
        }
        
        executionHistoryRepository.save(history);
    }
    
    @Transactional
    protected void updateGitLabPipelineId(String executionId, Long pipelineId, Integer gitlabPipelineId) {
        log.info("Updating GitLab pipeline ID for execution ID: {}, pipeline: {} to: {}", 
                executionId, pipelineId, gitlabPipelineId);
        
        ExecutionHistory history = executionHistoryRepository.findByExecutionId(executionId)
                .stream()
                .filter(h -> h.getPipeline().getId().equals(pipelineId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Execution history", "executionId and pipelineId", 
                        executionId + ":" + pipelineId));
        
        history.setGitlabPipelineId(gitlabPipelineId);
        executionHistoryRepository.save(history);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExecutionHistoryDto> getExecutionStatus(String executionId) {
        log.info("Getting execution status for execution ID: {}", executionId);
        
        List<ExecutionHistory> histories = executionHistoryRepository.findByExecutionId(executionId);
        if (histories.isEmpty()) {
            throw new ResourceNotFoundException("Execution", "executionId", executionId);
        }
        
        return histories.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExecutionHistoryDto> getExecutionHistoryByFlowId(Long flowId) {
        log.info("Getting execution history for flow ID: {}", flowId);
        
        if (!flowRepository.existsById(flowId)) {
            throw new ResourceNotFoundException("Flow", "id", flowId);
        }
        
        return executionHistoryRepository.findByFlowId(flowId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExecutionHistoryDto> getExecutionHistoryByPipelineId(Long pipelineId) {
        log.info("Getting execution history for pipeline ID: {}", pipelineId);
        
        if (!pipelineRepository.existsById(pipelineId)) {
            throw new ResourceNotFoundException("Pipeline", "id", pipelineId);
        }
        
        return executionHistoryRepository.findByPipelineId(pipelineId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExecutionHistoryDto> getExecutionHistoryByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        log.info("Getting execution history for date range: {} to {}", startDate, endDate);
        
        return executionHistoryRepository.findByDateRange(startDate, endDate)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public boolean cancelExecution(String executionId) {
        log.info("Canceling execution for execution ID: {}", executionId);
        
        if (!runningExecutions.containsKey(executionId)) {
            log.warn("Execution ID: {} not found or already completed", executionId);
            return false;
        }
        
        // Mark execution as canceled
        runningExecutions.put(executionId, false);
        
        // Find any running pipelines and cancel them
        List<ExecutionHistory> runningHistories = executionHistoryRepository.findByExecutionId(executionId)
                .stream()
                .filter(h -> h.getStatus() == PipelineStatus.RUNNING && h.getGitlabPipelineId() != null)
                .collect(Collectors.toList());
        
        CompletableFuture<?>[] cancelFutures = runningHistories.stream()
                .map(history -> CompletableFuture.runAsync(() -> {
                    try {
                        // Update status to CANCELED
                        updateExecutionStatus(executionId, history.getPipeline().getId(), 
                                PipelineStatus.CANCELED, "Execution canceled by user");
                        
                        // Cancel GitLab pipeline
                        Application application = history.getPipeline().getApplication();
                        gitLabService.cancelPipeline(
                                application.getProjectId(),
                                application.getAccessToken(),
                                history.getGitlabPipelineId()
                        );
                        
                        log.info("Canceled GitLab pipeline: {} for execution: {}", 
                                history.getGitlabPipelineId(), executionId);
                    } catch (Exception e) {
                        log.error("Failed to cancel pipeline: {}", history.getGitlabPipelineId(), e);
                    }
                }))
                .toArray(CompletableFuture[]::new);
        
        // Wait for all cancellations to complete
        CompletableFuture.allOf(cancelFutures).join();
        
        // Update all pending pipelines to CANCELED
        executionHistoryRepository.findByExecutionId(executionId)
                .stream()
                .filter(h -> h.getStatus() == PipelineStatus.PENDING)
                .forEach(history -> {
                    updateExecutionStatus(executionId, history.getPipeline().getId(), 
                            PipelineStatus.CANCELED, "Execution canceled by user");
                });
        
        log.info("Execution canceled for execution ID: {}", executionId);
        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getExecutionMetrics(Long flowId) {
        log.info("Getting execution metrics for flow ID: {}", flowId);
        
        if (!flowRepository.existsById(flowId)) {
            throw new ResourceNotFoundException("Flow", "id", flowId);
        }
        
        Map<String, Object> metrics = new HashMap<>();
        
        // Total executions
        long totalExecutions = executionHistoryRepository.countByFlowIdAndStatus(flowId, PipelineStatus.SUCCESS) +
                               executionHistoryRepository.countByFlowIdAndStatus(flowId, PipelineStatus.FAILED) +
                               executionHistoryRepository.countByFlowIdAndStatus(flowId, PipelineStatus.CANCELED);
        
        // Success rate
        long successfulExecutions = executionHistoryRepository.countByFlowIdAndStatus(flowId, PipelineStatus.SUCCESS);
        double successRate = totalExecutions > 0 ? (double) successfulExecutions / totalExecutions * 100 : 0;
        
        // Average execution time
        Double avgExecutionTime = executionHistoryRepository.getAverageExecutionTimeForFlow(flowId);
        
        // Status counts
        long failedExecutions = executionHistoryRepository.countByFlowIdAndStatus(flowId, PipelineStatus.FAILED);
        long canceledExecutions = executionHistoryRepository.countByFlowIdAndStatus(flowId, PipelineStatus.CANCELED);
        
        metrics.put("totalExecutions", totalExecutions);
        metrics.put("successfulExecutions", successfulExecutions);
        metrics.put("failedExecutions", failedExecutions);
        metrics.put("canceledExecutions", canceledExecutions);
        metrics.put("successRate", Math.round(successRate * 100) / 100.0); // Round to 2 decimal places
        metrics.put("averageExecutionTimeSeconds", avgExecutionTime != null ? Math.round(avgExecutionTime * 100) / 100.0 : 0);
        
        return metrics;
    }
    
    private ExecutionHistoryDto mapToDto(ExecutionHistory history) {
        Long durationInSeconds = null;
        if (history.getStartTime() != null && history.getEndTime() != null) {
            durationInSeconds = Duration.between(history.getStartTime(), history.getEndTime()).getSeconds();
        }
        
        return ExecutionHistoryDto.builder()
                .id(history.getId())
                .executionId(history.getExecutionId())
                .flowId(history.getFlow().getId())
                .flowName(history.getFlow().getName())
                .pipelineId(history.getPipeline().getId())
                .pipelineName(history.getPipeline().getPipelineName())
                .gitlabPipelineId(history.getGitlabPipelineId())
                .startTime(history.getStartTime())
                .endTime(history.getEndTime())
                .status(history.getStatus())
                .logs(history.getLogs())
                .errorMessage(history.getErrorMessage())
                .durationInSeconds(durationInSeconds)
                .build();
    }
}
