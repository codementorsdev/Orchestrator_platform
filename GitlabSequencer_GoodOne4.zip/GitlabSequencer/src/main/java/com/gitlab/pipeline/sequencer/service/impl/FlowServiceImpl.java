package com.gitlab.pipeline.sequencer.service.impl;

import com.gitlab.pipeline.sequencer.dto.FlowDto;
import com.gitlab.pipeline.sequencer.exception.ResourceNotFoundException;
import com.gitlab.pipeline.sequencer.model.Flow;
import com.gitlab.pipeline.sequencer.repository.FlowRepository;
import com.gitlab.pipeline.sequencer.service.FlowService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of FlowService
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FlowServiceImpl implements FlowService {

    private final FlowRepository flowRepository;

    @Override
    @Transactional
    public FlowDto createFlow(FlowDto flowDto) {
        log.info("Creating flow with name: {}", flowDto.getName());
        
        if (flowRepository.existsByName(flowDto.getName())) {
            throw new IllegalArgumentException("Flow with name " + flowDto.getName() + " already exists");
        }
        
        Flow flow = Flow.builder()
                .name(flowDto.getName())
                .description(flowDto.getDescription())
                .tags(flowDto.getTags())
                .build();
        
        Flow savedFlow = flowRepository.save(flow);
        log.info("Flow created with ID: {}", savedFlow.getId());
        
        return mapToDto(savedFlow);
    }
    
    @Override
    @Transactional(readOnly = true)
    public FlowDto getFlowById(Long id) {
        log.info("Getting flow with ID: {}", id);
        Flow flow = findFlowById(id);
        return mapToDto(flow);
    }
    
    @Override
    @Transactional(readOnly = true)
    public FlowDto getFlowByName(String name) {
        log.info("Getting flow with name: {}", name);
        Flow flow = flowRepository.findByName(name)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "name", name));
        return mapToDto(flow);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FlowDto> getAllFlows() {
        log.info("Getting all flows");
        return flowRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public FlowDto updateFlow(Long id, FlowDto flowDto) {
        log.info("Updating flow with ID: {}", id);
        Flow flow = findFlowById(id);
        
        if (!flow.getName().equals(flowDto.getName()) && flowRepository.existsByName(flowDto.getName())) {
            throw new IllegalArgumentException("Flow with name " + flowDto.getName() + " already exists");
        }
        
        flow.setName(flowDto.getName());
        flow.setDescription(flowDto.getDescription());
        flow.setTags(flowDto.getTags());
        
        Flow updatedFlow = flowRepository.save(flow);
        log.info("Flow updated: {}", updatedFlow.getId());
        
        return mapToDto(updatedFlow);
    }

    @Override
    @Transactional
    public void deleteFlow(Long id) {
        log.info("Deleting flow with ID: {}", id);
        Flow flow = findFlowById(id);
        flowRepository.delete(flow);
        log.info("Flow deleted: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FlowDto> findFlowsByTag(String tag) {
        log.info("Finding flows with tag: {}", tag);
        return flowRepository.findByTag(tag)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<FlowDto> findFlowsByTags(List<String> tags) {
        log.info("Finding flows with tags: {}", tags);
        return flowRepository.findByTagsIn(tags)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }
    
    private Flow findFlowById(Long id) {
        return flowRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flow", "id", id));
    }
    
    private FlowDto mapToDto(Flow flow) {
        return FlowDto.builder()
                .id(flow.getId())
                .name(flow.getName())
                .description(flow.getDescription())
                .tags(flow.getTags())
                .createdAt(flow.getCreatedAt())
                .updatedAt(flow.getUpdatedAt())
                .build();
    }
}
