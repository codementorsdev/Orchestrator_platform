package com.gitlab.pipeline.sequencer.service.impl;

import com.gitlab.pipeline.sequencer.service.GitLabService;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.PipelineApi;
import org.gitlab4j.api.models.Job;
import org.gitlab4j.api.models.Pipeline;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Implementation of GitLabService for interacting with GitLab API
 */
@Service
public class GitLabServiceImpl implements GitLabService {
    
    private static final Logger log = LoggerFactory.getLogger(GitLabServiceImpl.class);
    private static final String GITLAB_URL = "https://gitlab.com";

    @Override
    public Pipeline triggerPipeline(Integer projectId, String accessToken, String branch, Map<String, String> variables) {
        log.info("Triggering pipeline for project ID: {} on branch: {}", projectId, branch);
        
        try (GitLabApi gitLabApi = new GitLabApi(GITLAB_URL, accessToken)) {
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            Pipeline pipeline = pipelineApi.createPipeline(projectId, branch, variables);
            log.info("Pipeline triggered: ID: {} for project: {}", pipeline.getId(), projectId);
            return pipeline;
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Failed to trigger pipeline for project: {} on branch: {}", projectId, branch, e);
            throw new RuntimeException("Failed to trigger pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public Pipeline getPipelineStatus(Integer projectId, String accessToken, Integer pipelineId) {
        log.info("Getting pipeline status for project ID: {}, pipeline ID: {}", projectId, pipelineId);
        
        try (GitLabApi gitLabApi = new GitLabApi(GITLAB_URL, accessToken)) {
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            Pipeline pipeline = pipelineApi.getPipeline(projectId, pipelineId);
            log.info("Pipeline status: {} for pipeline ID: {}", pipeline.getStatus(), pipelineId);
            return pipeline;
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Failed to get pipeline status for project: {}, pipeline: {}", projectId, pipelineId, e);
            throw new RuntimeException("Failed to get pipeline status: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean cancelPipeline(Integer projectId, String accessToken, Integer pipelineId) {
        log.info("Canceling pipeline for project ID: {}, pipeline ID: {}", projectId, pipelineId);
        
        try (GitLabApi gitLabApi = new GitLabApi(GITLAB_URL, accessToken)) {
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            Pipeline pipeline = pipelineApi.cancelPipelineJobs(projectId, pipelineId);
            log.info("Pipeline canceled: ID: {}, status: {}", pipeline.getId(), pipeline.getStatus());
            return "canceled".equalsIgnoreCase(pipeline.getStatus().toString());
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Failed to cancel pipeline for project: {}, pipeline: {}", projectId, pipelineId, e);
            throw new RuntimeException("Failed to cancel pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public Pipeline retryPipeline(Integer projectId, String accessToken, Integer pipelineId) {
        log.info("Retrying pipeline for project ID: {}, pipeline ID: {}", projectId, pipelineId);
        
        try (GitLabApi gitLabApi = new GitLabApi(GITLAB_URL, accessToken)) {
            PipelineApi pipelineApi = gitLabApi.getPipelineApi();
            // Retry individual jobs instead of using retryPipelineJobs which may not be available
            List<Job> jobs = gitLabApi.getJobApi().getJobsForPipeline(projectId, pipelineId);
            for (Job job : jobs) {
                if (job.getStatus().equals("failed")) {
                    gitLabApi.getJobApi().retryJob(projectId, job.getId());
                }
            }
            // Get the updated pipeline
            Pipeline pipeline = pipelineApi.getPipeline(projectId, pipelineId);
            log.info("Pipeline retried: ID: {}, status: {}", pipeline.getId(), pipeline.getStatus());
            return pipeline;
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Failed to retry pipeline for project: {}, pipeline: {}", projectId, pipelineId, e);
            throw new RuntimeException("Failed to retry pipeline: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean testConnection(Integer projectId, String accessToken) {
        log.info("Testing GitLab connection for project ID: {}", projectId);
        
        try (GitLabApi gitLabApi = new GitLabApi(GITLAB_URL, accessToken)) {
            // Try to get the project to verify connection
            gitLabApi.getProjectApi().getProject(projectId);
            log.info("GitLab connection successful for project ID: {}", projectId);
            return true;
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.warn("GitLab connection test failed for project ID: {}: {}", projectId, e.getMessage());
            return false;
        }
    }

    @Override
    public String getPipelineJobLogs(Integer projectId, String accessToken, Integer jobId) {
        log.info("Getting job logs for project ID: {}, job ID: {}", projectId, jobId);
        
        try (GitLabApi gitLabApi = new GitLabApi(GITLAB_URL, accessToken)) {
            // Cast to Long as the API expects Long not Integer
            String jobLog = gitLabApi.getJobApi().getTrace(projectId, jobId.longValue());
            // Don't log the actual logs as they might be too verbose
            log.info("Successfully retrieved logs for job ID: {}", jobId);
            return jobLog;
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Failed to get job logs for project: {}, job: {}", projectId, jobId, e);
            throw new RuntimeException("Failed to get job logs: " + e.getMessage(), e);
        }
    }
    
    /**
     * Helper method to get all jobs for a pipeline
     */
    public List<Job> getPipelineJobs(Integer projectId, String accessToken, Integer pipelineId) {
        try (GitLabApi gitLabApi = new GitLabApi(GITLAB_URL, accessToken)) {
            return gitLabApi.getJobApi().getJobsForPipeline(projectId, pipelineId);
        } catch (org.gitlab4j.api.GitLabApiException e) {
            log.error("Failed to get jobs for pipeline: {}", pipelineId, e);
            throw new RuntimeException("Failed to get pipeline jobs: " + e.getMessage(), e);
        }
    }
}
