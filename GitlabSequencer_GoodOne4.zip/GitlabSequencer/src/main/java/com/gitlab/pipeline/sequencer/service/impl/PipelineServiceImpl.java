package com.gitlab.pipeline.sequencer.service.impl;

import com.gitlab.pipeline.sequencer.dto.PipelineDto;
import com.gitlab.pipeline.sequencer.exception.ResourceNotFoundException;
import com.gitlab.pipeline.sequencer.model.Application;
import com.gitlab.pipeline.sequencer.model.Pipeline;
import com.gitlab.pipeline.sequencer.repository.ApplicationRepository;
import com.gitlab.pipeline.sequencer.repository.PipelineRepository;
import com.gitlab.pipeline.sequencer.service.PipelineService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Implementation of PipelineService
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PipelineServiceImpl implements PipelineService {

    private final PipelineRepository pipelineRepository;
    private final ApplicationRepository applicationRepository;

    @Override
    @Transactional
    public PipelineDto createPipeline(PipelineDto pipelineDto) {
        log.info("Creating pipeline with name: {} for application ID: {}", 
                pipelineDto.getPipelineName(), pipelineDto.getApplicationId());
        
        Application application = applicationRepository.findById(pipelineDto.getApplicationId())
                .orElseThrow(() -> new ResourceNotFoundException("Application", "id", pipelineDto.getApplicationId()));
        
        if (pipelineRepository.findByApplicationIdAndPipelineName(application.getId(), pipelineDto.getPipelineName()).isPresent()) {
            throw new IllegalArgumentException("Pipeline with name " + pipelineDto.getPipelineName() + 
                    " already exists in application with ID " + pipelineDto.getApplicationId());
        }
        
        Pipeline pipeline = Pipeline.builder()
                .pipelineName(pipelineDto.getPipelineName())
                .branch(pipelineDto.getBranch())
                .sequenceOrder(pipelineDto.getSequenceOrder())
                .application(application)
                .build();
        
        Pipeline savedPipeline = pipelineRepository.save(pipeline);
        log.info("Pipeline created with ID: {}", savedPipeline.getId());
        
        return mapToDto(savedPipeline);
    }

    @Override
    @Transactional(readOnly = true)
    public PipelineDto getPipelineById(Long id) {
        log.info("Getting pipeline with ID: {}", id);
        Pipeline pipeline = findPipelineById(id);
        return mapToDto(pipeline);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PipelineDto> getPipelinesByApplicationId(Long applicationId) {
        log.info("Getting pipelines for application ID: {}", applicationId);
        
        // Verify application exists
        if (!applicationRepository.existsById(applicationId)) {
            throw new ResourceNotFoundException("Application", "id", applicationId);
        }
        
        return pipelineRepository.findByApplicationId(applicationId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<PipelineDto> getPipelinesByFlowIdOrdered(Long flowId) {
        log.info("Getting ordered pipelines for flow ID: {}", flowId);
        return pipelineRepository.findPipelinesByFlowIdOrderBySequenceOrder(flowId)
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<PipelineDto> getAllPipelines() {
        log.info("Getting all pipelines");
        return pipelineRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public PipelineDto updatePipeline(Long id, PipelineDto pipelineDto) {
        log.info("Updating pipeline with ID: {}", id);
        Pipeline pipeline = findPipelineById(id);
        
        // If changing application, verify it exists
        if (!pipeline.getApplication().getId().equals(pipelineDto.getApplicationId())) {
            Application newApplication = applicationRepository.findById(pipelineDto.getApplicationId())
                    .orElseThrow(() -> new ResourceNotFoundException("Application", "id", pipelineDto.getApplicationId()));
            pipeline.setApplication(newApplication);
        }
        
        // If name is changing, check for uniqueness within application
        if (!pipeline.getPipelineName().equals(pipelineDto.getPipelineName()) && 
                pipelineRepository.findByApplicationIdAndPipelineName(pipelineDto.getApplicationId(), pipelineDto.getPipelineName()).isPresent()) {
            throw new IllegalArgumentException("Pipeline with name " + pipelineDto.getPipelineName() + 
                    " already exists in application with ID " + pipelineDto.getApplicationId());
        }
        
        pipeline.setPipelineName(pipelineDto.getPipelineName());
        pipeline.setBranch(pipelineDto.getBranch());
        pipeline.setSequenceOrder(pipelineDto.getSequenceOrder());
        
        Pipeline updatedPipeline = pipelineRepository.save(pipeline);
        log.info("Pipeline updated: {}", updatedPipeline.getId());
        
        return mapToDto(updatedPipeline);
    }

    @Override
    @Transactional
    public void deletePipeline(Long id) {
        log.info("Deleting pipeline with ID: {}", id);
        Pipeline pipeline = findPipelineById(id);
        pipelineRepository.delete(pipeline);
        log.info("Pipeline deleted: {}", id);
    }

    @Override
    @Transactional
    public List<PipelineDto> updatePipelineSequence(List<Long> pipelineIds) {
        log.info("Updating pipeline sequence with {} pipelines", pipelineIds.size());
        
        // Verify all pipelines exist
        List<Pipeline> pipelines = pipelineRepository.findAllById(pipelineIds);
        if (pipelines.size() != pipelineIds.size()) {
            throw new ResourceNotFoundException("Not all pipeline IDs were found");
        }
        
        // Create a map for quick lookup
        Map<Long, Pipeline> pipelineMap = pipelines.stream()
                .collect(Collectors.toMap(Pipeline::getId, Function.identity()));
        
        // Update sequence order
        IntStream.range(0, pipelineIds.size())
                .forEach(i -> {
                    Long pipelineId = pipelineIds.get(i);
                    Pipeline pipeline = pipelineMap.get(pipelineId);
                    pipeline.setSequenceOrder(i);
                });
        
        List<Pipeline> updatedPipelines = pipelineRepository.saveAll(pipelines);
        log.info("Updated sequence for {} pipelines", updatedPipelines.size());
        
        return updatedPipelines.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }
    
    private Pipeline findPipelineById(Long id) {
        return pipelineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pipeline", "id", id));
    }
    
    private PipelineDto mapToDto(Pipeline pipeline) {
        return PipelineDto.builder()
                .id(pipeline.getId())
                .pipelineName(pipeline.getPipelineName())
                .branch(pipeline.getBranch())
                .sequenceOrder(pipeline.getSequenceOrder())
                .applicationId(pipeline.getApplication().getId())
                .createdAt(pipeline.getCreatedAt())
                .updatedAt(pipeline.getUpdatedAt())
                .build();
    }
}
