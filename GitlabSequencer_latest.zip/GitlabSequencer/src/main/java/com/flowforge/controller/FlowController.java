package com.flowforge.controller;

import com.flowforge.dto.FlowDTO;
import com.flowforge.dto.PipelineDTO;
import com.flowforge.service.FlowService;
import com.flowforge.service.PipelineService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/flows")
public class FlowController {

    @Autowired
    private FlowService flowService;
    
    @Autowired
    private PipelineService pipelineService;

    @PostMapping
    public ResponseEntity<FlowDTO> createFlow(@Valid @RequestBody FlowDTO flowDTO) {
        FlowDTO createdFlow = flowService.createFlow(flowDTO);
        return new ResponseEntity<>(createdFlow, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<FlowDTO>> getAllFlows() {
        List<FlowDTO> flows = flowService.getAllFlows();
        return new ResponseEntity<>(flows, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FlowDTO> getFlowById(@PathVariable Long id) {
        FlowDTO flow = flowService.getFlowById(id);
        if (flow != null) {
            return new ResponseEntity<>(flow, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{id}/pipelines") 
    public ResponseEntity<List<PipelineDTO>> getPipelinesByFlowId(@PathVariable Long id) {
        List<PipelineDTO> pipelines = flowService.getPipelinesByFlowId(id).stream()
            .map(pipeline -> pipelineService.convertToDTO(pipeline))
            .collect(Collectors.toList());
        if (pipelines != null) {
            return new ResponseEntity<>(pipelines, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<FlowDTO> updateFlow(@PathVariable Long id, @Valid @RequestBody FlowDTO flowDTO) {
        FlowDTO updatedFlow = flowService.updateFlow(id, flowDTO);
        if (updatedFlow != null) {
            return new ResponseEntity<>(updatedFlow, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFlow(@PathVariable Long id) {
        flowService.deleteFlow(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
