package com.flowforge.controller;

import com.flowforge.dto.PipelineExecutionDTO;
import com.flowforge.service.PipelineExecutionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/pipelines/{pipelineId}/executions")
public class PipelineExecutionController {

    @Autowired
    private PipelineExecutionService pipelineExecutionService;

    @PostMapping
    public ResponseEntity<PipelineExecutionDTO> createPipelineExecution(@RequestBody PipelineExecutionDTO pipelineExecutionDTO) {
        PipelineExecutionDTO createdExecution = pipelineExecutionService.convertToDTO(
            pipelineExecutionService.createPipelineExecution(
                pipelineExecutionService.convertToEntity(pipelineExecutionDTO)
            )
        );
        return new ResponseEntity<>(createdExecution, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<PipelineExecutionDTO>> getAllPipelineExecutionsByPipelineId(@PathVariable Long pipelineId) {
        List<PipelineExecutionDTO> executions = pipelineExecutionService.getAllPipelineExecutionsByPipelineId(pipelineId)
            .stream()
            .map(exec -> pipelineExecutionService.convertToDTO(exec))
            .collect(Collectors.toList());
        return new ResponseEntity<>(executions, HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<List<PipelineExecutionDTO>> getAllPipelineExecutions() {
        List<PipelineExecutionDTO> executions = pipelineExecutionService.getAllPipelineExecutions()
            .stream()
            .map(exec -> pipelineExecutionService.convertToDTO(exec))
            .collect(Collectors.toList());
        return new ResponseEntity<>(executions, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PipelineExecutionDTO> getPipelineExecutionById(@PathVariable Long pipelineId, @PathVariable Long id) {
        PipelineExecutionDTO execution = pipelineExecutionService.convertToDTO(
            pipelineExecutionService.getPipelineExecutionById(id)
        );
        if (execution != null) {
            return new ResponseEntity<>(execution, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PipelineExecutionDTO> updatePipelineExecution(@PathVariable Long id, @RequestBody PipelineExecutionDTO pipelineExecutionDTO) {
        PipelineExecutionDTO updatedExecution = pipelineExecutionService.convertToDTO(
            pipelineExecutionService.updatePipelineExecution(
                id,
                pipelineExecutionService.convertToEntity(pipelineExecutionDTO)
            )
        );
        if (updatedExecution != null) {
            return new ResponseEntity<>(updatedExecution, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePipelineExecution(@PathVariable Long id) {
        pipelineExecutionService.deletePipelineExecution(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/{id}/logs")
    public ResponseEntity<String> getPipelineExecutionLogs(@PathVariable Long pipelineId, @PathVariable Long id) {
        String logs = pipelineExecutionService.getPipelineExecutionById(id).getLogs();
        return logs != null ? 
            new ResponseEntity<>(logs, HttpStatus.OK) :
            new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/{id}/payload")
    public ResponseEntity<String> getPipelineExecutionPayload(@PathVariable Long pipelineId, @PathVariable Long id) {
        String payload = pipelineExecutionService.getPipelineExecutionById(id).getExecutionPayload();
        return payload != null ?
            new ResponseEntity<>(payload, HttpStatus.OK) :
            new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
