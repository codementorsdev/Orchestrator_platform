package com.flowforge.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import java.util.List;
import java.time.LocalDateTime;


@Entity
public class FlowExecution {

    @Id
    @GeneratedValue
    private Long id;

    private Long flowId;

    private String status;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    @OneToMany
    private List<PipelineExecution> pipelineExecutions;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFlowId() {
        return flowId;
    }

    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public List<PipelineExecution> getPipelineExecutions() {
        return pipelineExecutions;
    }

    public void setPipelineExecutions(List<PipelineExecution> pipelineExecutions) {
        this.pipelineExecutions = pipelineExecutions;
    }
}
