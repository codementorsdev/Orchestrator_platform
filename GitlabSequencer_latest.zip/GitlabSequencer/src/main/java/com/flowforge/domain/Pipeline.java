package com.flowforge.domain;

import jakarta.persistence.*;

@Entity
public class Pipeline {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String description;
    private String branch;
    private Integer executionSequence;

    @ManyToOne
    @JoinColumn(name = "application_id", referencedColumnName = "id")
    private Application application;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public Integer getExecutionSequence() {
        return executionSequence;
    }

    public void setExecutionSequence(Integer executionSequence) {
        this.executionSequence = executionSequence;
    }

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }
}
