package com.flowforge.domain;

public enum Status {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}
