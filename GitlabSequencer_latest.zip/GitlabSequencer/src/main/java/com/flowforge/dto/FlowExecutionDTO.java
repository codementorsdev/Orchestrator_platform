package com.flowforge.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;
import java.util.List;

public class FlowExecutionDTO {
    @Schema(accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;
    
    @NotNull(message = "Flow ID is required")
    private Long flowId;

    @NotBlank(message = "Status is required")
    private String status;

    @NotNull(message = "Start time is required")
    private LocalDateTime startTime;

    private LocalDateTime endTime;

    @NotNull(message = "Pipeline execution IDs cannot be null")
    private List<Long> pipelineExecutionIds;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFlowId() {
        return flowId;
    }

    public void setFlowId(Long flowId) {
        this.flowId = flowId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public List<Long> getPipelineExecutionIds() {
        return pipelineExecutionIds;
    }

    public void setPipelineExecutionIds(List<Long> pipelineExecutionIds) {
        this.pipelineExecutionIds = pipelineExecutionIds;
    }
}
