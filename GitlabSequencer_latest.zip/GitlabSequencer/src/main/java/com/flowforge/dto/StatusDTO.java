package com.flowforge.dto;

public enum StatusDTO {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}
