package com.flowforge.repository;

import com.flowforge.domain.PipelineExecution;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PipelineExecutionRepository extends JpaRepository<PipelineExecution, Long> {
    List<PipelineExecution> findByPipelineId(Long pipelineId);
    List<PipelineExecution> findByFlowExecutionId(Long flowExecutionId);
}
