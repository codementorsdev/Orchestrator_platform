package com.flowforge.service;

import com.flowforge.domain.Application;
import com.flowforge.dto.ApplicationDTO;
import com.flowforge.repository.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    public ApplicationDTO createApplication(ApplicationDTO applicationDTO) {
        Application application = convertToEntity(applicationDTO);
        Application savedApplication = applicationRepository.save(application);
        return convertToDTO(savedApplication);
    }

    public List<ApplicationDTO> getAllApplications() {
        List<Application> applications = applicationRepository.findAll();
        return applications.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public ApplicationDTO getApplicationById(Long id) {
        Application application = getApplicationEntityById(id);
        if (application != null) {
            return convertToDTO(application);
        }
        return null;
    }

    public Application getApplicationEntityById(Long id) {
        return applicationRepository.findById(id).orElse(null);
    }

    public ApplicationDTO updateApplication(Long id, ApplicationDTO applicationDTO) {
        Application existingApplication = applicationRepository.findById(id).orElse(null);
        if (existingApplication != null) {
            Application application = convertToEntity(applicationDTO);
            application.setId(id);
            Application updatedApplication = applicationRepository.save(application);
            return convertToDTO(updatedApplication);
        }
        return null;
    }

    public void deleteApplication(Long id) {
        applicationRepository.deleteById(id);
    }

    public ApplicationDTO convertToDTO(Application application) {
        ApplicationDTO applicationDTO = new ApplicationDTO();
        applicationDTO.setId(application.getId());
        applicationDTO.setName(application.getName());
        applicationDTO.setDescription(application.getDescription());
        applicationDTO.setProjectId(application.getProjectId());
        applicationDTO.setAccessToken(application.getAccessToken());
        applicationDTO.setGitlabInstanceUrl(application.getGitlabInstanceUrl());
        return applicationDTO;
    }

    public Application convertToEntity(ApplicationDTO applicationDTO) {
        Application application = new Application();
        application.setName(applicationDTO.getName());
        application.setDescription(applicationDTO.getDescription());
        application.setProjectId(applicationDTO.getProjectId());
        application.setAccessToken(applicationDTO.getAccessToken());
        application.setGitlabInstanceUrl(applicationDTO.getGitlabInstanceUrl());
        return application;
    }
}
