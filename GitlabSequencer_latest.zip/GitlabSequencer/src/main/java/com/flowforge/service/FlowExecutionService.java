package com.flowforge.service;

import com.flowforge.domain.*;
import com.flowforge.repository.FlowExecutionRepository;
import org.gitlab4j.api.GitLabApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import com.flowforge.dto.FlowExecutionDTO;

@Service
public class FlowExecutionService {

    @Autowired
    private FlowExecutionRepository flowExecutionRepository;

    @Autowired
    private PipelineExecutionService pipelineExecutionService;

    @Autowired
    private FlowService flowService;

    public FlowExecution createFlowExecution(FlowExecution flowExecution) {
        return flowExecutionRepository.save(flowExecution);
    }

    public List<FlowExecution> getAllFlowExecutions() {
        return flowExecutionRepository.findAll();
    }

    public FlowExecution getFlowExecutionById(Long id) {
        return flowExecutionRepository.findById(id).orElse(null);
    }

    public FlowExecution updateFlowExecution(Long id, FlowExecution flowExecution) {
        FlowExecution existingFlowExecution = flowExecutionRepository.findById(id).orElse(null);
        if (existingFlowExecution != null) {
            flowExecution.setId(id);
            return flowExecutionRepository.save(flowExecution);
        }
        return null;
    }

    public void deleteFlowExecution(Long id) {
        flowExecutionRepository.deleteById(id);
    }

    public FlowExecutionDTO convertToDTO(FlowExecution flowExecution) {
        FlowExecutionDTO dto = new FlowExecutionDTO();
        dto.setId(flowExecution.getId());
        dto.setFlowId(flowExecution.getFlowId());
        dto.setStatus(flowExecution.getStatus());
        dto.setStartTime(flowExecution.getStartTime());
        dto.setEndTime(flowExecution.getEndTime());
        return dto;
    }

    public FlowExecution convertToEntity(FlowExecutionDTO dto) {
        FlowExecution entity = new FlowExecution();
        entity.setFlowId(dto.getFlowId());
        entity.setStatus(dto.getStatus());
        entity.setStartTime(dto.getStartTime());
        entity.setEndTime(dto.getEndTime());
        return entity;
    }

    public List<FlowExecution> getAllFlowExecutionsByFlowId(Long flowId) {
        return flowExecutionRepository.findByFlowId(flowId);
    }

    @Async
    public void processFlowExecutionAsync(Flow flow, Long flowExecutionId) {
        try {
            // Create PipelineExecution records for each pipeline
            // Need to fetch fresh Flow entity with pipelines initialized in a transaction
            Flow freshFlow = flowService.getFlowWithPipelines(flow.getId());
            List<Pipeline> pipelines = freshFlow.getPipelines();
            for (Pipeline pipeline : pipelines) {
                PipelineExecution pipelineExecution = new PipelineExecution();
                pipelineExecution.setFlowExecutionId(flowExecutionId);
                pipelineExecution.setPipelineId(pipeline.getId());
                pipelineExecution.setStatus(Status.PENDING.toString());
                pipelineExecution.setStartTime(LocalDateTime.now());
                pipelineExecutionService.createPipelineExecution(pipelineExecution);
                triggerPipelineAsync(pipeline, null);
            }
        } catch (GitLabApiException e) {
            // Update flow execution status to FAILED
            FlowExecution flowExecution = getFlowExecutionById(flowExecutionId);
            if (flowExecution != null) {
                flowExecution.setStatus(Status.FAILED.toString());
                flowExecution.setEndTime(LocalDateTime.now());
                flowExecutionRepository.save(flowExecution);
            }
        }
    }

    @Async
    public void triggerPipelineAsync(Pipeline pipeline, Long flowExecutionId) throws GitLabApiException {
        pipelineExecutionService.triggerPipeline(pipeline, null);
    }
}
