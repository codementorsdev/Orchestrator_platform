package com.flowforge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowforgeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
