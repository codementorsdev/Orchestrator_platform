package com.pipelineorchestrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main application class for the GitLab Pipeline Orchestration Platform.
 * This application provides functionality for sequentially configuring and executing
 * different GitLab pipelines with real-time execution status monitoring.
 */
@SpringBootApplication
@EnableAsync  // Enable asynchronous execution for pipeline execution
@EnableScheduling  // Enable scheduling for status updates
public class PipelineOrchestratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(PipelineOrchestratorApplication.class, args);
    }
}
