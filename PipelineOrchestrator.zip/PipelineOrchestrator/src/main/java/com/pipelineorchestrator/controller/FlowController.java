package com.pipelineorchestrator.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.pipelineorchestrator.model.Application;
import com.pipelineorchestrator.model.Flow;
import com.pipelineorchestrator.model.Pipeline;
import com.pipelineorchestrator.service.FlowService;
import com.pipelineorchestrator.service.PipelineService;

/**
 * Controller for handling flow-related requests.
 * Manages flow creation, editing, viewing, and execution.
 */
@Controller
@RequestMapping("/flows")
public class FlowController {

    @Autowired
    private FlowService flowService;
    
    @Autowired
    private PipelineService pipelineService;
    
    /**
     * Shows the list of all flows.
     * 
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The flows list view
     */
    @GetMapping
    public String listFlows(Model model, Principal principal) {
        List<Flow> flows = flowService.findAllByUsername(principal.getName());
        model.addAttribute("flows", flows);
        return "flows";
    }
    
    /**
     * Shows the form for creating a new flow.
     * 
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The flow management view
     */
    @GetMapping("/new")
    public String newFlow(Model model, Principal principal) {
        if (!model.containsAttribute("flow")) {
            model.addAttribute("flow", new Flow());
        }
        
        // Get available pipelines for this user
        List<Pipeline> pipelines = pipelineService.findAllByUsername(principal.getName());
        model.addAttribute("pipelines", pipelines);
        
        return "flow-management";
    }
    
    /**
     * Shows the form for editing an existing flow.
     * 
     * @param id The ID of the flow to edit
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The flow management view or error redirect
     */
    @GetMapping("/{id}/edit")
    public String editFlow(@PathVariable Long id, Model model, Principal principal) {
        Flow flow = flowService.findById(id);
        
        if (flow == null) {
            return "redirect:/flows?error=Flow+not+found";
        }
        
        // Security check - make sure the user owns this flow
        if (!flow.getCreatedBy().equals(principal.getName())) {
            return "redirect:/flows?error=Access+denied";
        }
        
        model.addAttribute("flow", flow);
        
        // Get available pipelines for this user
        List<Pipeline> pipelines = pipelineService.findAllByUsername(principal.getName());
        model.addAttribute("pipelines", pipelines);
        
        // If the flow has a pipeline ID, get its applications
        if (flow.getPipelineId() != null) {
            Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
            if (pipeline != null) {
                model.addAttribute("applications", pipeline.getApplications());
            }
        }
        
        return "flow-management";
    }
    
    /**
     * Shows the details of a specific flow.
     * 
     * @param id The ID of the flow to view
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The flow details view or error redirect
     */
    @GetMapping("/{id}")
    public String viewFlow(@PathVariable Long id, Model model, Principal principal) {
        Flow flow = flowService.findById(id);
        
        if (flow == null) {
            return "redirect:/flows?error=Flow+not+found";
        }
        
        // Security check - make sure the user owns this flow
        if (!flow.getCreatedBy().equals(principal.getName())) {
            return "redirect:/flows?error=Access+denied";
        }
        
        model.addAttribute("flow", flow);
        
        // Get the pipeline and its applications
        if (flow.getPipelineId() != null) {
            Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
            if (pipeline != null) {
                model.addAttribute("pipeline", pipeline);
                model.addAttribute("applications", pipeline.getApplications());
            }
        }
        
        // Get execution history if available
        model.addAttribute("executionHistory", flowService.getExecutionHistory(id));
        
        return "flow-details";
    }
    
    /**
     * Saves a new flow.
     * 
     * @param flow The flow object from the form
     * @param bindingResult Validation results
     * @param principal The currently logged-in user
     * @param redirectAttributes Attributes for redirects
     * @return Redirect to flows list on success, back to form on error
     */
    @PostMapping
    public String saveFlow(
            @Valid @ModelAttribute Flow flow,
            BindingResult bindingResult,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("flow", flow);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.flow", bindingResult);
            return "redirect:/flows/new";
        }
        
        // Verify that the pipeline exists and belongs to the user
        if (flow.getPipelineId() != null) {
            Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
            if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
                redirectAttributes.addFlashAttribute("flow", flow);
                redirectAttributes.addFlashAttribute("error", "Selected pipeline not found or access denied");
                return "redirect:/flows/new";
            }
        }
        
        // Set the creator
        flow.setCreatedBy(principal.getName());
        
        // Save the flow
        flowService.save(flow);
        
        redirectAttributes.addFlashAttribute("success", "Flow created successfully");
        return "redirect:/flows";
    }
    
    /**
     * Updates an existing flow.
     * 
     * @param id The ID of the flow to update
     * @param flow The updated flow object from the form
     * @param bindingResult Validation results
     * @param principal The currently logged-in user
     * @param redirectAttributes Attributes for redirects
     * @return Redirect to flows list on success, back to form on error
     */
    @PostMapping("/{id}")
    public String updateFlow(
            @PathVariable Long id,
            @Valid @ModelAttribute Flow flow,
            BindingResult bindingResult,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("flow", flow);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.flow", bindingResult);
            return "redirect:/flows/" + id + "/edit";
        }
        
        // Ensure the ID is set properly
        flow.setId(id);
        
        // Security check - make sure the user owns this flow
        Flow existingFlow = flowService.findById(id);
        if (existingFlow == null || !existingFlow.getCreatedBy().equals(principal.getName())) {
            redirectAttributes.addFlashAttribute("error", "Access denied or flow not found");
            return "redirect:/flows";
        }
        
        // Verify that the pipeline exists and belongs to the user
        if (flow.getPipelineId() != null) {
            Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
            if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
                redirectAttributes.addFlashAttribute("flow", flow);
                redirectAttributes.addFlashAttribute("error", "Selected pipeline not found or access denied");
                return "redirect:/flows/" + id + "/edit";
            }
        }
        
        // Update the flow
        flowService.update(flow);
        
        redirectAttributes.addFlashAttribute("success", "Flow updated successfully");
        return "redirect:/flows";
    }
    
    /**
     * Deletes a flow.
     * 
     * @param id The ID of the flow to delete
     * @param principal The currently logged-in user
     * @param redirectAttributes Attributes for redirects
     * @return Redirect to flows list
     */
    @PostMapping("/{id}/delete")
    public String deleteFlow(
            @PathVariable Long id,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        
        // Security check - make sure the user owns this flow
        Flow flow = flowService.findById(id);
        if (flow == null || !flow.getCreatedBy().equals(principal.getName())) {
            redirectAttributes.addFlashAttribute("error", "Access denied or flow not found");
            return "redirect:/flows";
        }
        
        // Delete the flow
        flowService.delete(id);
        
        redirectAttributes.addFlashAttribute("success", "Flow deleted successfully");
        return "redirect:/flows";
    }
    
    /**
     * Executes a flow.
     * 
     * @param id The ID of the flow to execute
     * @param principal The currently logged-in user
     * @return JSON response with execution details
     */
    @PostMapping("/{id}/execute")
    @ResponseBody
    public String executeFlow(@PathVariable Long id, Principal principal) {
        // Security check - make sure the user owns this flow
        Flow flow = flowService.findById(id);
        if (flow == null || !flow.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied or flow not found\"}";
        }
        
        try {
            // Execute the flow
            boolean success = flowService.executeFlow(id);
            if (success) {
                return "{\"success\": true, \"message\": \"Flow execution started\"}";
            } else {
                return "{\"success\": false, \"message\": \"Failed to start flow execution\"}";
            }
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
    
    /**
     * Returns the status of a flow execution.
     * 
     * @param id The ID of the flow
     * @param executionId The ID of the execution
     * @param principal The currently logged-in user
     * @return JSON response with execution status
     */
    @GetMapping("/{id}/executions/{executionId}/status")
    @ResponseBody
    public String getFlowExecutionStatus(
            @PathVariable Long id,
            @PathVariable Long executionId,
            Principal principal) {
        
        // Security check - make sure the user owns this flow
        Flow flow = flowService.findById(id);
        if (flow == null || !flow.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied or flow not found\"}";
        }
        
        try {
            // Get the execution status
            String status = flowService.getExecutionStatus(id, executionId);
            return "{\"success\": true, \"status\": \"" + status + "\"}";
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
    
    /**
     * Gets the applications for a specific pipeline.
     * Used for dynamically loading applications when a pipeline is selected.
     * 
     * @param pipelineId The ID of the pipeline
     * @param principal The currently logged-in user
     * @return JSON response with applications data
     */
    @GetMapping("/pipeline-applications/{pipelineId}")
    @ResponseBody
    public String getPipelineApplications(@PathVariable Long pipelineId, Principal principal) {
        // Security check - make sure the user owns this pipeline
        Pipeline pipeline = pipelineService.findById(pipelineId);
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied or pipeline not found\"}";
        }
        
        try {
            // Get the applications
            List<Application> applications = pipeline.getApplications();
            
            // Build JSON response
            StringBuilder json = new StringBuilder("{\"success\": true, \"applications\": [");
            
            for (int i = 0; i < applications.size(); i++) {
                Application app = applications.get(i);
                
                json.append("{")
                    .append("\"id\": ").append(app.getId()).append(", ")
                    .append("\"appId\": \"").append(app.getAppId()).append("\", ")
                    .append("\"projectId\": \"").append(app.getProjectId()).append("\", ")
                    .append("\"branch\": \"").append(app.getBranch()).append("\", ")
                    .append("\"sequence\": ").append(app.getSequence())
                    .append("}");
                
                if (i < applications.size() - 1) {
                    json.append(", ");
                }
            }
            
            json.append("]}");
            
            return json.toString();
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
}
