package com.pipelineorchestrator.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.pipelineorchestrator.model.Application;
import com.pipelineorchestrator.model.Pipeline;
import com.pipelineorchestrator.service.PipelineService;

/**
 * Controller for handling pipeline-related requests.
 * Manages pipeline creation, editing, viewing, and execution.
 */
@Controller
@RequestMapping("/pipelines")
public class PipelineController {

    @Autowired
    private PipelineService pipelineService;
    
    /**
     * Shows the list of all pipelines.
     * 
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The pipelines list view
     */
    @GetMapping
    public String listPipelines(Model model, Principal principal) {
        List<Pipeline> pipelines = pipelineService.findAllByUsername(principal.getName());
        model.addAttribute("pipelines", pipelines);
        return "pipelines";
    }
    
    /**
     * Shows the form for creating a new pipeline.
     * 
     * @param model The model to add attributes to
     * @return The pipeline configuration view
     */
    @GetMapping("/new")
    public String newPipeline(Model model) {
        if (!model.containsAttribute("pipeline")) {
            model.addAttribute("pipeline", new Pipeline());
        }
        return "pipeline-config";
    }
    
    /**
     * Shows the form for editing an existing pipeline.
     * 
     * @param id The ID of the pipeline to edit
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The pipeline configuration view or error redirect
     */
    @GetMapping("/{id}/edit")
    public String editPipeline(@PathVariable Long id, Model model, Principal principal) {
        Pipeline pipeline = pipelineService.findById(id);
        
        if (pipeline == null) {
            return "redirect:/pipelines?error=Pipeline+not+found";
        }
        
        // Security check - make sure the user owns this pipeline
        if (!pipeline.getCreatedBy().equals(principal.getName())) {
            return "redirect:/pipelines?error=Access+denied";
        }
        
        model.addAttribute("pipeline", pipeline);
        return "pipeline-config";
    }
    
    /**
     * Shows the details of a specific pipeline.
     * 
     * @param id The ID of the pipeline to view
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The pipeline details view or error redirect
     */
    @GetMapping("/{id}")
    public String viewPipeline(@PathVariable Long id, Model model, Principal principal) {
        Pipeline pipeline = pipelineService.findById(id);
        
        if (pipeline == null) {
            return "redirect:/pipelines?error=Pipeline+not+found";
        }
        
        // Security check - make sure the user owns this pipeline
        if (!pipeline.getCreatedBy().equals(principal.getName())) {
            return "redirect:/pipelines?error=Access+denied";
        }
        
        model.addAttribute("pipeline", pipeline);
        
        // Get execution history if available
        model.addAttribute("executionHistory", pipelineService.getExecutionHistory(id));
        
        return "pipeline-details";
    }
    
    /**
     * Saves a new pipeline.
     * 
     * @param pipeline The pipeline object from the form
     * @param bindingResult Validation results
     * @param principal The currently logged-in user
     * @param redirectAttributes Attributes for redirects
     * @return Redirect to pipelines list on success, back to form on error
     */
    @PostMapping
    public String savePipeline(
            @Valid @ModelAttribute Pipeline pipeline,
            BindingResult bindingResult,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("pipeline", pipeline);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.pipeline", bindingResult);
            return "redirect:/pipelines/new";
        }
        
        // Set the creator
        pipeline.setCreatedBy(principal.getName());
        
        // Save the pipeline
        pipelineService.save(pipeline);
        
        redirectAttributes.addFlashAttribute("success", "Pipeline created successfully");
        return "redirect:/pipelines";
    }
    
    /**
     * Updates an existing pipeline.
     * 
     * @param id The ID of the pipeline to update
     * @param pipeline The updated pipeline object from the form
     * @param bindingResult Validation results
     * @param principal The currently logged-in user
     * @param redirectAttributes Attributes for redirects
     * @return Redirect to pipelines list on success, back to form on error
     */
    @PostMapping("/{id}")
    public String updatePipeline(
            @PathVariable Long id,
            @Valid @ModelAttribute Pipeline pipeline,
            BindingResult bindingResult,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("pipeline", pipeline);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.pipeline", bindingResult);
            return "redirect:/pipelines/" + id + "/edit";
        }
        
        // Ensure the ID is set properly
        pipeline.setId(id);
        
        // Security check - make sure the user owns this pipeline
        Pipeline existingPipeline = pipelineService.findById(id);
        if (existingPipeline == null || !existingPipeline.getCreatedBy().equals(principal.getName())) {
            redirectAttributes.addFlashAttribute("error", "Access denied or pipeline not found");
            return "redirect:/pipelines";
        }
        
        // Update the pipeline
        pipelineService.update(pipeline);
        
        redirectAttributes.addFlashAttribute("success", "Pipeline updated successfully");
        return "redirect:/pipelines";
    }
    
    /**
     * Deletes a pipeline.
     * 
     * @param id The ID of the pipeline to delete
     * @param principal The currently logged-in user
     * @param redirectAttributes Attributes for redirects
     * @return Redirect to pipelines list
     */
    @PostMapping("/{id}/delete")
    public String deletePipeline(
            @PathVariable Long id,
            Principal principal,
            RedirectAttributes redirectAttributes) {
        
        // Security check - make sure the user owns this pipeline
        Pipeline pipeline = pipelineService.findById(id);
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            redirectAttributes.addFlashAttribute("error", "Access denied or pipeline not found");
            return "redirect:/pipelines";
        }
        
        // Delete the pipeline
        pipelineService.delete(id);
        
        redirectAttributes.addFlashAttribute("success", "Pipeline deleted successfully");
        return "redirect:/pipelines";
    }
    
    /**
     * Executes a pipeline.
     * 
     * @param id The ID of the pipeline to execute
     * @param principal The currently logged-in user
     * @return JSON response with execution details
     */
    @PostMapping("/{id}/execute")
    @ResponseBody
    public String executePipeline(@PathVariable Long id, Principal principal) {
        // Security check - make sure the user owns this pipeline
        Pipeline pipeline = pipelineService.findById(id);
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied or pipeline not found\"}";
        }
        
        try {
            // Execute the pipeline
            boolean success = pipelineService.executePipeline(id);
            if (success) {
                return "{\"success\": true, \"message\": \"Pipeline execution started\"}";
            } else {
                return "{\"success\": false, \"message\": \"Failed to start pipeline execution\"}";
            }
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
    
    /**
     * Returns the status of a pipeline execution.
     * 
     * @param id The ID of the pipeline
     * @param executionId The ID of the execution
     * @param principal The currently logged-in user
     * @return JSON response with execution status
     */
    @GetMapping("/{id}/executions/{executionId}/status")
    @ResponseBody
    public String getPipelineExecutionStatus(
            @PathVariable Long id,
            @PathVariable Long executionId,
            Principal principal) {
        
        // Security check - make sure the user owns this pipeline
        Pipeline pipeline = pipelineService.findById(id);
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied or pipeline not found\"}";
        }
        
        try {
            // Get the execution status
            String status = pipelineService.getExecutionStatus(id, executionId);
            return "{\"success\": true, \"status\": \"" + status + "\"}";
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
    
    /**
     * Adds an application to a pipeline.
     * 
     * @param id The ID of the pipeline
     * @param application The application to add
     * @param principal The currently logged-in user
     * @return JSON response with success/failure
     */
    @PostMapping("/{id}/applications")
    @ResponseBody
    public String addApplication(
            @PathVariable Long id,
            @ModelAttribute Application application,
            Principal principal) {
        
        // Security check - make sure the user owns this pipeline
        Pipeline pipeline = pipelineService.findById(id);
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied or pipeline not found\"}";
        }
        
        try {
            // Add the application
            pipelineService.addApplication(id, application);
            return "{\"success\": true, \"message\": \"Application added successfully\"}";
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
    
    /**
     * Removes an application from a pipeline.
     * 
     * @param id The ID of the pipeline
     * @param applicationId The ID of the application to remove
     * @param principal The currently logged-in user
     * @return JSON response with success/failure
     */
    @PostMapping("/{id}/applications/{applicationId}/remove")
    @ResponseBody
    public String removeApplication(
            @PathVariable Long id,
            @PathVariable Long applicationId,
            Principal principal) {
        
        // Security check - make sure the user owns this pipeline
        Pipeline pipeline = pipelineService.findById(id);
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied or pipeline not found\"}";
        }
        
        try {
            // Remove the application
            pipelineService.removeApplication(id, applicationId);
            return "{\"success\": true, \"message\": \"Application removed successfully\"}";
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
}
