package com.pipelineorchestrator.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pipelineorchestrator.dto.TestResultDTO;
import com.pipelineorchestrator.model.Pipeline;
import com.pipelineorchestrator.model.TestSuite;
import com.pipelineorchestrator.service.PipelineService;
import com.pipelineorchestrator.service.TestResultService;

/**
 * Controller for handling test result-related requests.
 * Manages test result viewing and receiving test results from pipelines.
 */
@Controller
@RequestMapping("/tests")
public class TestResultController {

    @Autowired
    private TestResultService testResultService;
    
    @Autowired
    private PipelineService pipelineService;
    
    /**
     * Shows the list of all test results.
     * 
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The test results list view
     */
    @GetMapping
    public String listTestResults(Model model, Principal principal) {
        List<TestResultDTO> recentResults = testResultService.findRecentByUsername(principal.getName());
        model.addAttribute("recentResults", recentResults);
        return "test-results";
    }
    
    /**
     * Shows the details of a specific test result.
     * 
     * @param id The ID of the test result to view
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The test result details view or error redirect
     */
    @GetMapping("/{id}")
    public String viewTestResult(@PathVariable Long id, Model model, Principal principal) {
        TestResultDTO testResult = testResultService.findById(id);
        
        if (testResult == null) {
            model.addAttribute("error", "Test result not found");
            return "test-results";
        }
        
        // Security check - make sure the user has access to this test result
        Pipeline pipeline = pipelineService.findByAppId(testResult.getAppId());
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            model.addAttribute("error", "Access denied");
            return "test-results";
        }
        
        model.addAttribute("testResult", testResult);
        
        // Get recent test results for comparison
        List<TestResultDTO> recentResults = testResultService.findRecentByUsername(principal.getName());
        model.addAttribute("recentResults", recentResults);
        
        return "test-results";
    }
    
    /**
     * Receives and stores test results from a pipeline execution.
     * This endpoint is called by the pipeline scripts to submit test results.
     * 
     * @param testSuite The test suite data from the pipeline
     * @return HTTP response with success/failure
     */
    @PostMapping("/receive")
    @ResponseBody
    public ResponseEntity<String> receiveTestResults(@RequestBody TestSuite testSuite) {
        try {
            // Save the test results
            testResultService.saveTestResult(testSuite);
            return ResponseEntity.ok("{\"success\": true, \"message\": \"Test results saved successfully\"}");
        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
    }
    
    /**
     * Deletes a test result.
     * 
     * @param id The ID of the test result to delete
     * @param principal The currently logged-in user
     * @return JSON response with success/failure
     */
    @PostMapping("/{id}/delete")
    @ResponseBody
    public String deleteTestResult(@PathVariable Long id, Principal principal) {
        TestResultDTO testResult = testResultService.findById(id);
        
        if (testResult == null) {
            return "{\"success\": false, \"message\": \"Test result not found\"}";
        }
        
        // Security check - make sure the user has access to this test result
        Pipeline pipeline = pipelineService.findByAppId(testResult.getAppId());
        if (pipeline == null || !pipeline.getCreatedBy().equals(principal.getName())) {
            return "{\"success\": false, \"message\": \"Access denied\"}";
        }
        
        try {
            // Delete the test result
            testResultService.delete(id);
            return "{\"success\": true, \"message\": \"Test result deleted successfully\"}";
        } catch (Exception e) {
            return "{\"success\": false, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
    
    /**
     * Dashboard page controller
     * 
     * @param model The model to add attributes to
     * @param principal The currently logged-in user
     * @return The dashboard view
     */
    @GetMapping("/dashboard")
    public String dashboard(Model model, Principal principal) {
        // Get test statistics
        model.addAttribute("testStats", testResultService.getTestStatistics(principal.getName()));
        
        // Get recent test results
        List<TestResultDTO> recentResults = testResultService.findRecentByUsername(principal.getName(), 5);
        model.addAttribute("recentTestResults", recentResults);
        
        return "dashboard";
    }
}
