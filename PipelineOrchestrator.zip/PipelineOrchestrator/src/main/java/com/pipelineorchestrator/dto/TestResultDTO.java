package com.pipelineorchestrator.dto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Data Transfer Object for test results.
 * Used to transfer test result data between layers.
 */
public class TestResultDTO {

    private Long id;
    private String appId;
    private String appName;
    private String appDescription;
    private LocalDateTime executionDate;
    private Long pipelineId;
    
    // Suites data in a structured format
    private Map<String, Map<String, Object>> suites;
    
    // Custom data from the test execution
    private Map<String, String> customData;
    
    // Aggregated test counts
    private int totalTests;
    private int passedTests;
    private int failedTests;
    private int skippedTests;
    
    // All unique tags from tests
    private List<String> allTags;
    
    /**
     * Default constructor
     */
    public TestResultDTO() {}
    
    // Getters and setters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public void setAppDescription(String appDescription) {
        this.appDescription = appDescription;
    }

    public LocalDateTime getExecutionDate() {
        return executionDate;
    }

    public void setExecutionDate(LocalDateTime executionDate) {
        this.executionDate = executionDate;
    }

    public Long getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(Long pipelineId) {
        this.pipelineId = pipelineId;
    }

    public Map<String, Map<String, Object>> getSuites() {
        return suites;
    }

    public void setSuites(Map<String, Map<String, Object>> suites) {
        this.suites = suites;
    }

    public Map<String, String> getCustomData() {
        return customData;
    }

    public void setCustomData(Map<String, String> customData) {
        this.customData = customData;
    }

    public int getTotalTests() {
        return totalTests;
    }

    public void setTotalTests(int totalTests) {
        this.totalTests = totalTests;
    }

    public int getPassedTests() {
        return passedTests;
    }

    public void setPassedTests(int passedTests) {
        this.passedTests = passedTests;
    }

    public int getFailedTests() {
        return failedTests;
    }

    public void setFailedTests(int failedTests) {
        this.failedTests = failedTests;
    }

    public int getSkippedTests() {
        return skippedTests;
    }

    public void setSkippedTests(int skippedTests) {
        this.skippedTests = skippedTests;
    }

    public List<String> getAllTags() {
        return allTags;
    }

    public void setAllTags(List<String> allTags) {
        this.allTags = allTags;
    }

    @Override
    public String toString() {
        return "TestResultDTO [id=" + id + ", appId=" + appId + ", appName=" + appName + 
               ", totalTests=" + totalTests + ", passedTests=" + passedTests + 
               ", failedTests=" + failedTests + ", executionDate=" + executionDate + "]";
    }
}
