package com.pipelineorchestrator.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Entity representing an application within a pipeline.
 * Each application corresponds to a GitLab project that can be executed.
 */
@Entity
@Table(name = "applications")
public class Application {

    /**
     * Enum representing the status of an application execution.
     */
    public enum Status {
        PENDING,
        RUNNING,
        SUCCESS,
        FAILED,
        CANCELED
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Application ID is required")
    @Column(name = "app_id", nullable = false)
    private String appId;
    
    @NotBlank(message = "Project ID is required")
    @Column(name = "project_id", nullable = false)
    private String projectId;
    
    @Column(name = "branch")
    private String branch = "main";
    
    @NotBlank(message = "Access token is required")
    @Column(name = "access_token", nullable = false)
    private String accessToken;
    
    @NotNull(message = "Sequence number is required")
    @Column(nullable = false)
    private Integer sequence = 1;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private Status status = Status.PENDING;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pipeline_id")
    @JsonIgnore
    private Pipeline pipeline;
    
    /**
     * Default constructor
     */
    public Application() {}
    
    /**
     * Constructor with fields
     */
    public Application(String appId, String projectId, String branch, String accessToken, Integer sequence) {
        this.appId = appId;
        this.projectId = projectId;
        this.branch = branch;
        this.accessToken = accessToken;
        this.sequence = sequence;
    }
    
    // Getters and setters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Pipeline getPipeline() {
        return pipeline;
    }

    public void setPipeline(Pipeline pipeline) {
        this.pipeline = pipeline;
    }

    @Override
    public String toString() {
        return "Application [id=" + id + ", appId=" + appId + ", projectId=" + projectId + 
               ", branch=" + branch + ", sequence=" + sequence + ", status=" + status + "]";
    }
}
