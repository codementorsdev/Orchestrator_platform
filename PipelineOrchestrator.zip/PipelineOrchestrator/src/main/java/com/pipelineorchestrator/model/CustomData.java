package com.pipelineorchestrator.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Entity representing custom data associated with a test suite.
 * This is used to store arbitrary key-value pairs from the test execution.
 */
@Entity
@Table(name = "custom_data")
public class CustomData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;
    
    @Column(name = "test_suite_id")
    @JsonIgnore
    private Long testSuiteId;
    
    @Column(name = "data_key", nullable = false)
    private String key;
    
    @Column(name = "data_value", nullable = false, length = 1000)
    private String value;
    
    /**
     * Default constructor
     */
    public CustomData() {}
    
    /**
     * Constructor with fields
     */
    public CustomData(Long testSuiteId, String key, String value) {
        this.testSuiteId = testSuiteId;
        this.key = key;
        this.value = value;
    }
    
    // Getters and setters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTestSuiteId() {
        return testSuiteId;
    }

    public void setTestSuiteId(Long testSuiteId) {
        this.testSuiteId = testSuiteId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "CustomData [id=" + id + ", key=" + key + ", value=" + value + "]";
    }
}
