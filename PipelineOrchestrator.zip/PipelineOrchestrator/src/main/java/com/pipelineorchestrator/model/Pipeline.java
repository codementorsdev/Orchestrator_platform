package com.pipelineorchestrator.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * Entity representing a pipeline configuration.
 * A pipeline contains multiple applications to be executed in sequence.
 */
@Entity
@Table(name = "pipelines")
public class Pipeline {

    /**
     * Enum representing the status of a pipeline.
     */
    public enum Status {
        PENDING,
        RUNNING,
        SUCCESS,
        FAILED,
        CANCELED
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Pipeline name is required")
    @Size(max = 100, message = "Pipeline name cannot exceed 100 characters")
    @Column(nullable = false)
    private String name;
    
    @Size(max = 500, message = "Description cannot exceed 500 characters")
    @Column(length = 500)
    private String description;
    
    @OneToMany(mappedBy = "pipeline", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    @OrderBy("sequence ASC")
    private List<Application> applications = new ArrayList<>();
    
    @Column(name = "created_by", nullable = false)
    private String createdBy;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @Column(name = "last_run")
    private LocalDateTime lastRun;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private Status status = Status.PENDING;
    
    /**
     * Default constructor
     */
    public Pipeline() {}
    
    /**
     * Constructor with fields
     */
    public Pipeline(String name, String description, String createdBy) {
        this.name = name;
        this.description = description;
        this.createdBy = createdBy;
    }
    
    /**
     * Sets timestamps before persisting
     */
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = this.createdAt;
    }
    
    /**
     * Updates the updatedAt timestamp before updating the entity
     */
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * Adds an application to this pipeline
     */
    public void addApplication(Application application) {
        applications.add(application);
        application.setPipeline(this);
    }
    
    /**
     * Removes an application from this pipeline
     */
    public void removeApplication(Application application) {
        applications.remove(application);
        application.setPipeline(null);
    }
    
    /**
     * Updates the pipeline status and lastRun timestamp
     */
    public void updateStatus(Status status) {
        this.status = status;
        if (status == Status.RUNNING) {
            this.lastRun = LocalDateTime.now();
        }
    }
    
    // Getters and setters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Application> getApplications() {
        return applications;
    }

    public void setApplications(List<Application> applications) {
        this.applications.clear();
        if (applications != null) {
            applications.forEach(this::addApplication);
        }
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getLastRun() {
        return lastRun;
    }

    public void setLastRun(LocalDateTime lastRun) {
        this.lastRun = lastRun;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Pipeline [id=" + id + ", name=" + name + ", applications=" + applications.size() + 
               ", status=" + status + ", lastRun=" + lastRun + "]";
    }
}
