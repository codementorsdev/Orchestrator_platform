package com.pipelineorchestrator.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Entity representing a test case within a test suite.
 */
@Entity
@Table(name = "tests")
public class Test {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;
    
    @Column(name = "name", nullable = false)
    private String name;
    
    @Column(name = "description", length = 500)
    private String description;
    
    @ElementCollection
    @CollectionTable(name = "test_tags", 
                   joinColumns = @JoinColumn(name = "test_id"))
    @Column(name = "tag")
    private List<String> tags = new ArrayList<>();
    
    @Column(name = "status")
    private String status;
    
    @Column(name = "start_time")
    private Long startTime;
    
    @Column(name = "end_time")
    private Long endTime;
    
    @OneToMany(mappedBy = "test", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<Log> logs = new ArrayList<>();
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "test_suite_id")
    @JsonIgnore
    private TestSuite testSuite;
    
    /**
     * Default constructor
     */
    public Test() {}
    
    /**
     * Constructor with fields
     */
    public Test(String name, String description, List<String> tags, String status) {
        this.name = name;
        this.description = description;
        this.tags = tags;
        this.status = status;
    }
    
    /**
     * Adds a log entry to this test
     */
    public void addLog(Log log) {
        logs.add(log);
        log.setTest(this);
    }
    
    /**
     * Removes a log entry from this test
     */
    public void removeLog(Log log) {
        logs.remove(log);
        log.setTest(null);
    }
    
    /**
     * Calculate the duration of the test execution
     */
    public Long getDuration() {
        if (startTime != null && endTime != null) {
            return endTime - startTime;
        }
        return null;
    }
    
    /**
     * Get the duration as a formatted string
     */
    @Transient
    public String getFormattedDuration() {
        Long duration = getDuration();
        if (duration == null) {
            return "N/A";
        }
        
        if (duration < 1000) {
            return duration + "ms";
        } else if (duration < 60000) {
            return (duration / 1000.0) + "s";
        } else {
            long minutes = duration / 60000;
            long seconds = (duration % 60000) / 1000;
            return minutes + "m " + seconds + "s";
        }
    }
    
    /**
     * Get the tags as a JSON string for use in data attributes
     */
    @Transient
    @JsonIgnore
    public String getTagsAsJson() {
        try {
            return objectMapper.writeValueAsString(tags);
        } catch (JsonProcessingException e) {
            return "[]";
        }
    }
    
    // Getters and setters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public List<Log> getLogs() {
        return logs;
    }

    public void setLogs(List<Log> logs) {
        this.logs.clear();
        if (logs != null) {
            logs.forEach(this::addLog);
        }
    }

    public TestSuite getTestSuite() {
        return testSuite;
    }

    public void setTestSuite(TestSuite testSuite) {
        this.testSuite = testSuite;
    }

    @Override
    public String toString() {
        return "Test [id=" + id + ", name=" + name + ", status=" + status + 
               ", logs=" + logs.size() + "]";
    }
}
