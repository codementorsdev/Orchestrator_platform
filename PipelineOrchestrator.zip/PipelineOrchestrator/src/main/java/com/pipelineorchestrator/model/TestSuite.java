package com.pipelineorchestrator.model;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Entity representing a test suite with its test results.
 * This is the main object received from the pipeline execution.
 */
@Entity
@Table(name = "test_suites")
public class TestSuite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;
    
    @Column(name = "app_id", nullable = false)
    private String appId;
    
    @Column(name = "app_name")
    private String appName;
    
    @Column(name = "app_description", length = 500)
    private String appDescription;
    
    @ElementCollection
    @CollectionTable(name = "test_suite_tags", 
                   joinColumns = @JoinColumn(name = "test_suite_id"))
    @Column(name = "tag")
    private List<String> tags;
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "description", length = 500)
    private String description;
    
    @Column(name = "start_time")
    private Long startTime;
    
    @Column(name = "end_time")
    private Long endTime;
    
    @OneToMany(mappedBy = "testSuite", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    @MapKeyColumn(name = "test_key")
    private Map<String, Test> tests = new HashMap<>();
    
    @ElementCollection
    @CollectionTable(name = "test_suite_custom_data", 
                   joinColumns = @JoinColumn(name = "test_suite_id"))
    @MapKeyColumn(name = "data_key")
    @Column(name = "data_value")
    private Map<String, String> customData = new HashMap<>();
    
    @Column(name = "execution_date")
    @JsonIgnore
    private LocalDateTime executionDate;
    
    @Column(name = "pipeline_id")
    @JsonIgnore
    private Long pipelineId;
    
    /**
     * Default constructor
     */
    public TestSuite() {}
    
    /**
     * Sets execution date before persisting
     */
    @PrePersist
    protected void onCreate() {
        this.executionDate = LocalDateTime.now();
    }
    
    /**
     * Adds a test to this test suite
     */
    public void addTest(String key, Test test) {
        tests.put(key, test);
        test.setTestSuite(this);
    }
    
    /**
     * Removes a test from this test suite
     */
    public void removeTest(String key) {
        Test test = tests.remove(key);
        if (test != null) {
            test.setTestSuite(null);
        }
    }
    
    /**
     * Calculate the duration of the test suite execution
     */
    public Long getDuration() {
        if (startTime != null && endTime != null) {
            return endTime - startTime;
        }
        return null;
    }
    
    // Getters and setters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public void setAppDescription(String appDescription) {
        this.appDescription = appDescription;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public Map<String, Test> getTests() {
        return tests;
    }

    public void setTests(Map<String, Test> tests) {
        this.tests.clear();
        if (tests != null) {
            tests.forEach(this::addTest);
        }
    }

    public Map<String, String> getCustomData() {
        return customData;
    }

    public void setCustomData(Map<String, String> customData) {
        this.customData = customData;
    }

    public LocalDateTime getExecutionDate() {
        return executionDate;
    }

    public void setExecutionDate(LocalDateTime executionDate) {
        this.executionDate = executionDate;
    }

    public Long getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(Long pipelineId) {
        this.pipelineId = pipelineId;
    }

    @Override
    public String toString() {
        return "TestSuite [id=" + id + ", appId=" + appId + ", appName=" + appName + 
               ", name=" + name + ", tests=" + tests.size() + "]";
    }
}
