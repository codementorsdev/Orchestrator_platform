package com.pipelineorchestrator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pipelineorchestrator.model.Application;

/**
 * Repository for Application entity operations.
 */
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    
    /**
     * Find all applications for a specific pipeline
     * 
     * @param pipelineId The ID of the pipeline
     * @return List of applications
     */
    List<Application> findByPipelineIdOrderBySequenceAsc(Long pipelineId);
    
    /**
     * Find an application by its appId within a specific pipeline
     * 
     * @param pipelineId The ID of the pipeline
     * @param appId The application ID
     * @return The application, or null if not found
     */
    Application findByPipelineIdAndAppId(Long pipelineId, String appId);
    
    /**
     * Delete all applications for a specific pipeline
     * 
     * @param pipelineId The ID of the pipeline
     */
    void deleteByPipelineId(Long pipelineId);
    
    /**
     * Check if an application with the given appId exists
     * 
     * @param appId The application ID to check
     * @return True if the application exists, false otherwise
     */
    boolean existsByAppId(String appId);
}
