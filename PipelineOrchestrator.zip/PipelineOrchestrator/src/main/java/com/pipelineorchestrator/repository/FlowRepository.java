package com.pipelineorchestrator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pipelineorchestrator.model.Flow;

/**
 * Repository for Flow entity operations.
 */
@Repository
public interface FlowRepository extends JpaRepository<Flow, Long> {
    
    /**
     * Find all flows created by a specific user
     * 
     * @param createdBy The username of the creator
     * @return List of flows
     */
    List<Flow> findByCreatedBy(String createdBy);
    
    /**
     * Find all flows created by a specific user, ordered by last run date
     * 
     * @param createdBy The username of the creator
     * @return List of flows
     */
    List<Flow> findByCreatedByOrderByLastRunDesc(String createdBy);
    
    /**
     * Find all flows that use a specific pipeline
     * 
     * @param pipelineId The ID of the pipeline
     * @return List of flows
     */
    List<Flow> findByPipelineId(Long pipelineId);
}
