package com.pipelineorchestrator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pipelineorchestrator.model.Pipeline;

/**
 * Repository for Pipeline entity operations.
 */
@Repository
public interface PipelineRepository extends JpaRepository<Pipeline, Long> {
    
    /**
     * Find all pipelines created by a specific user
     * 
     * @param createdBy The username of the creator
     * @return List of pipelines
     */
    List<Pipeline> findByCreatedBy(String createdBy);
    
    /**
     * Find all pipelines created by a specific user, ordered by last run date
     * 
     * @param createdBy The username of the creator
     * @return List of pipelines
     */
    List<Pipeline> findByCreatedByOrderByLastRunDesc(String createdBy);
    
    /**
     * Find a pipeline that contains an application with the given appId
     * 
     * @param appId The application ID to search for
     * @return The pipeline, or null if not found
     */
    @Query(value = "SELECT p FROM Pipeline p JOIN p.applications a WHERE a.appId = :appId")
    Pipeline findByApplicationAppId(@Param("appId") String appId);
}
