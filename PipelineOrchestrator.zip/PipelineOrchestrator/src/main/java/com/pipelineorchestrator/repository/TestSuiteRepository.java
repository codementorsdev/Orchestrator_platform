package com.pipelineorchestrator.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pipelineorchestrator.model.TestSuite;

/**
 * Repository for TestSuite entity operations.
 */
@Repository
public interface TestSuiteRepository extends JpaRepository<TestSuite, Long> {
    
    /**
     * Find all test suites for a specific application
     * 
     * @param appId The application ID
     * @return List of test suites
     */
    List<TestSuite> findByAppId(String appId);
    
    /**
     * Find all test suites for a specific pipeline
     * 
     * @param pipelineId The pipeline ID
     * @return List of test suites
     */
    List<TestSuite> findByPipelineId(Long pipelineId);
    
    /**
     * Find test suites for applications in pipelines created by a specific user
     * 
     * @param username The username
     * @return List of test suites
     */
    @Query(value = "SELECT ts FROM TestSuite ts WHERE ts.pipelineId IN " +
                  "(SELECT p.id FROM Pipeline p WHERE p.createdBy = :username)")
    List<TestSuite> findByUsername(@Param("username") String username);
    
    /**
     * Find test suites for a specific user ordered by execution date
     * 
     * @param username The username
     * @return List of test suites ordered by execution date
     */
    @Query(value = "SELECT ts FROM TestSuite ts WHERE ts.pipelineId IN " +
                  "(SELECT p.id FROM Pipeline p WHERE p.createdBy = :username) " +
                  "ORDER BY ts.executionDate DESC")
    List<TestSuite> findByUsernameOrderByExecutionDateDesc(@Param("username") String username);
    
    /**
     * Count the number of tests with different statuses for a specific user
     * 
     * @param username The username
     * @return Object array with counts [totalCount, passCount, failCount, skipCount]
     */
    @Query(value = "SELECT COUNT(t), " +
                  "SUM(CASE WHEN t.status = 'PASS' THEN 1 ELSE 0 END), " +
                  "SUM(CASE WHEN t.status = 'FAIL' THEN 1 ELSE 0 END), " +
                  "SUM(CASE WHEN t.status = 'SKIP' OR t.status IS NULL THEN 1 ELSE 0 END) " +
                  "FROM Test t WHERE t.testSuite.id IN " +
                  "(SELECT ts.id FROM TestSuite ts WHERE ts.pipelineId IN " +
                  "(SELECT p.id FROM Pipeline p WHERE p.createdBy = :username))")
    Object[] getTestStatistics(@Param("username") String username);
}
