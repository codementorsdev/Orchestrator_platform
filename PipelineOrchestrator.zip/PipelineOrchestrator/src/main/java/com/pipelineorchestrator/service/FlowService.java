package com.pipelineorchestrator.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pipelineorchestrator.model.Flow;
import com.pipelineorchestrator.model.Pipeline;
import com.pipelineorchestrator.repository.FlowRepository;

/**
 * Service for flow-related operations.
 * Handles CRUD operations and flow execution.
 */
@Service
public class FlowService {

    private static final Logger logger = LoggerFactory.getLogger(FlowService.class);
    
    @Autowired
    private FlowRepository flowRepository;
    
    @Autowired
    private PipelineService pipelineService;
    
    // In-memory storage for execution history (would be persisted to database in a production application)
    private Map<Long, List<Map<String, Object>>> executionHistory = new HashMap<>();
    
    /**
     * Find all flows.
     * 
     * @return List of all flows
     */
    public List<Flow> findAll() {
        return flowRepository.findAll();
    }
    
    /**
     * Find all flows created by a specific user.
     * 
     * @param username Username of the creator
     * @return List of flows
     */
    public List<Flow> findAllByUsername(String username) {
        return flowRepository.findByCreatedBy(username);
    }
    
    /**
     * Find a flow by ID.
     * 
     * @param id Flow ID
     * @return The flow, or null if not found
     */
    public Flow findById(Long id) {
        return flowRepository.findById(id).orElse(null);
    }
    
    /**
     * Find recent flows for a user.
     * 
     * @param username Username of the creator
     * @param limit Maximum number of flows to return
     * @return List of flows
     */
    public List<Flow> findRecentByUsername(String username, int limit) {
        List<Flow> flows = flowRepository.findByCreatedByOrderByLastRunDesc(username);
        return flows.size() <= limit ? flows : flows.subList(0, limit);
    }
    
    /**
     * Save a new flow.
     * 
     * @param flow Flow to save
     * @return The saved flow
     */
    @Transactional
    public Flow save(Flow flow) {
        // Validate that the pipeline exists
        Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
        if (pipeline == null) {
            throw new RuntimeException("Pipeline not found with ID: " + flow.getPipelineId());
        }
        
        return flowRepository.save(flow);
    }
    
    /**
     * Update an existing flow.
     * 
     * @param flow Flow to update
     * @return The updated flow
     */
    @Transactional
    public Flow update(Flow flow) {
        if (!flowRepository.existsById(flow.getId())) {
            throw new RuntimeException("Flow not found with ID: " + flow.getId());
        }
        
        // Validate that the pipeline exists
        Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
        if (pipeline == null) {
            throw new RuntimeException("Pipeline not found with ID: " + flow.getPipelineId());
        }
        
        return flowRepository.save(flow);
    }
    
    /**
     * Delete a flow.
     * 
     * @param id ID of the flow to delete
     */
    @Transactional
    public void delete(Long id) {
        flowRepository.deleteById(id);
    }
    
    /**
     * Execute a flow.
     * 
     * @param flowId ID of the flow to execute
     * @return true if execution started successfully, false otherwise
     */
    @Transactional
    public boolean executeFlow(Long flowId) {
        Flow flow = flowRepository.findById(flowId)
                .orElseThrow(() -> new RuntimeException("Flow not found with ID: " + flowId));
        
        // Check if the pipeline exists
        Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
        if (pipeline == null) {
            throw new RuntimeException("Pipeline not found with ID: " + flow.getPipelineId());
        }
        
        // Update flow status
        flow.updateStatus(Flow.Status.RUNNING);
        flowRepository.save(flow);
        
        // Create execution record
        Map<String, Object> execution = new HashMap<>();
        execution.put("id", System.currentTimeMillis());
        execution.put("startTime", LocalDateTime.now());
        execution.put("status", "RUNNING");
        
        if (!executionHistory.containsKey(flowId)) {
            executionHistory.put(flowId, new ArrayList<>());
        }
        executionHistory.get(flowId).add(execution);
        
        // Start execution
        executeFlowAsync(flow, (Long) execution.get("id"));
        
        return true;
    }
    
    /**
     * Get the status of a flow execution.
     * 
     * @param flowId ID of the flow
     * @param executionId ID of the execution
     * @return Status of the execution
     */
    public String getExecutionStatus(Long flowId, Long executionId) {
        List<Map<String, Object>> executions = executionHistory.getOrDefault(flowId, Collections.emptyList());
        
        for (Map<String, Object> execution : executions) {
            if (execution.get("id").equals(executionId)) {
                return (String) execution.get("status");
            }
        }
        
        return "NOT_FOUND";
    }
    
    /**
     * Get the execution history for a flow.
     * 
     * @param flowId ID of the flow
     * @return List of execution records
     */
    public List<Map<String, Object>> getExecutionHistory(Long flowId) {
        return executionHistory.getOrDefault(flowId, Collections.emptyList());
    }
    
    /**
     * Execute a flow asynchronously.
     * 
     * @param flow Flow to execute
     * @param executionId ID of the execution
     */
    @Async
    protected void executeFlowAsync(Flow flow, Long executionId) {
        logger.info("Starting flow execution: {}", flow.getId());
        
        try {
            // Execute the pipeline in the flow
            boolean success = pipelineService.executePipeline(flow.getPipelineId());
            
            // Wait for pipeline execution to complete
            waitForPipelineExecution(flow.getPipelineId());
            
            // Get final pipeline status
            Pipeline pipeline = pipelineService.findById(flow.getPipelineId());
            
            // Update flow status based on pipeline status
            Flow.Status finalStatus = pipeline.getStatus() == Pipeline.Status.SUCCESS ? 
                    Flow.Status.SUCCESS : Flow.Status.FAILED;
            
            flow.updateStatus(finalStatus);
            flowRepository.save(flow);
            
            // Update execution record
            List<Map<String, Object>> executions = executionHistory.get(flow.getId());
            for (Map<String, Object> execution : executions) {
                if (execution.get("id").equals(executionId)) {
                    execution.put("endTime", LocalDateTime.now());
                    execution.put("status", finalStatus.toString());
                    break;
                }
            }
            
            logger.info("Finished flow execution: {} with status: {}", flow.getId(), finalStatus);
        } catch (Exception e) {
            logger.error("Error executing flow: " + flow.getId(), e);
            
            // Update flow status
            flow.updateStatus(Flow.Status.FAILED);
            flowRepository.save(flow);
            
            // Update execution record
            List<Map<String, Object>> executions = executionHistory.get(flow.getId());
            for (Map<String, Object> execution : executions) {
                if (execution.get("id").equals(executionId)) {
                    execution.put("endTime", LocalDateTime.now());
                    execution.put("status", "FAILED");
                    break;
                }
            }
        }
    }
    
    /**
     * Wait for pipeline execution to complete.
     * 
     * @param pipelineId ID of the pipeline
     * @throws InterruptedException if waiting is interrupted
     */
    private void waitForPipelineExecution(Long pipelineId) throws InterruptedException {
        Pipeline pipeline;
        do {
            Thread.sleep(5000); // Check every 5 seconds
            pipeline = pipelineService.findById(pipelineId);
        } while (pipeline.getStatus() == Pipeline.Status.RUNNING);
    }
}
