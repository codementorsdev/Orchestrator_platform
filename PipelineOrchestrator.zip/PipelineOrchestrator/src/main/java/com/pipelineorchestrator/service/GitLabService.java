package com.pipelineorchestrator.service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Service for GitLab API interactions.
 * Handles pipeline triggering and status checking.
 */
@Service
public class GitLabService {

    private static final Logger logger = LoggerFactory.getLogger(GitLabService.class);
    
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    
    @Value("${gitlab.api.url:https://gitlab.com/api/v4}")
    private String gitlabApiUrl;
    
    /**
     * Constructor.
     */
    public GitLabService() {
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        this.objectMapper = new ObjectMapper();
    }
    
    /**
     * Trigger a GitLab pipeline.
     * 
     * @param projectId GitLab project ID
     * @param ref Branch or tag to run pipeline on
     * @param accessToken GitLab access token
     * @return true if pipeline triggered successfully, false otherwise
     */
    public boolean triggerPipeline(String projectId, String ref, String accessToken) {
        logger.info("Triggering pipeline for project: {}, ref: {}", projectId, ref);
        
        try {
            String url = String.format("%s/projects/%s/pipeline", gitlabApiUrl, projectId);
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .header("PRIVATE-TOKEN", accessToken)
                    .POST(HttpRequest.BodyPublishers.ofString("{\"ref\": \"" + ref + "\"}"))
                    .build();
            
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() >= 200 && response.statusCode() < 300) {
                JsonNode jsonNode = objectMapper.readTree(response.body());
                int pipelineId = jsonNode.get("id").asInt();
                logger.info("Pipeline triggered successfully. Pipeline ID: {}", pipelineId);
                
                // Monitor pipeline status until it completes or times out
                return monitorPipelineStatus(projectId, pipelineId, accessToken);
            } else {
                logger.error("Failed to trigger pipeline. Status code: {}, Response: {}", 
                        response.statusCode(), response.body());
                return false;
            }
        } catch (Exception e) {
            logger.error("Error triggering pipeline", e);
            return false;
        }
    }
    
    /**
     * Monitor pipeline status until it completes or times out.
     * 
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @param accessToken GitLab access token
     * @return true if pipeline succeeded, false otherwise
     */
    private boolean monitorPipelineStatus(String projectId, int pipelineId, String accessToken) 
            throws IOException, InterruptedException {
        
        String url = String.format("%s/projects/%s/pipelines/%d", gitlabApiUrl, projectId, pipelineId);
        String status = "pending";
        int attempts = 0;
        int maxAttempts = 60; // 5 minute timeout (60 * 5 seconds)
        
        while (!"success".equals(status) && !"failed".equals(status) && !"canceled".equals(status) && attempts < maxAttempts) {
            Thread.sleep(5000); // Wait 5 seconds between checks
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("PRIVATE-TOKEN", accessToken)
                    .GET()
                    .build();
            
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() >= 200 && response.statusCode() < 300) {
                JsonNode jsonNode = objectMapper.readTree(response.body());
                status = jsonNode.get("status").asText();
                logger.info("Pipeline status: {}", status);
            } else {
                logger.error("Failed to get pipeline status. Status code: {}, Response: {}", 
                        response.statusCode(), response.body());
                return false;
            }
            
            attempts++;
        }
        
        return "success".equals(status);
    }
    
    /**
     * Get pipeline details.
     * 
     * @param projectId GitLab project ID
     * @param pipelineId GitLab pipeline ID
     * @param accessToken GitLab access token
     * @return Pipeline details as a JsonNode, or null if failed
     */
    public JsonNode getPipelineDetails(String projectId, int pipelineId, String accessToken) {
        try {
            String url = String.format("%s/projects/%s/pipelines/%d", gitlabApiUrl, projectId, pipelineId);
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("PRIVATE-TOKEN", accessToken)
                    .GET()
                    .build();
            
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() >= 200 && response.statusCode() < 300) {
                return objectMapper.readTree(response.body());
            } else {
                logger.error("Failed to get pipeline details. Status code: {}, Response: {}", 
                        response.statusCode(), response.body());
                return null;
            }
        } catch (Exception e) {
            logger.error("Error getting pipeline details", e);
            return null;
        }
    }
    
    /**
     * Check if a project exists and the access token has access to it.
     * 
     * @param projectId GitLab project ID
     * @param accessToken GitLab access token
     * @return true if project exists and token has access, false otherwise
     */
    public boolean validateProjectAccess(String projectId, String accessToken) {
        try {
            String url = String.format("%s/projects/%s", gitlabApiUrl, projectId);
            
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("PRIVATE-TOKEN", accessToken)
                    .GET()
                    .build();
            
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            return response.statusCode() >= 200 && response.statusCode() < 300;
        } catch (Exception e) {
            logger.error("Error validating project access", e);
            return false;
        }
    }
}
