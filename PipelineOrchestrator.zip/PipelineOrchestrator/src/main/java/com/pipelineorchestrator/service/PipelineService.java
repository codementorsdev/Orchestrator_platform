package com.pipelineorchestrator.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pipelineorchestrator.model.Application;
import com.pipelineorchestrator.model.Pipeline;
import com.pipelineorchestrator.model.Application.Status;
import com.pipelineorchestrator.repository.ApplicationRepository;
import com.pipelineorchestrator.repository.PipelineRepository;

/**
 * Service for pipeline-related operations.
 * Handles CRUD operations and pipeline execution.
 */
@Service
public class PipelineService {

    private static final Logger logger = LoggerFactory.getLogger(PipelineService.class);
    
    @Autowired
    private PipelineRepository pipelineRepository;
    
    @Autowired
    private ApplicationRepository applicationRepository;
    
    @Autowired
    private GitLabService gitLabService;
    
    // In-memory storage for execution history (would be persisted to database in a production application)
    private Map<Long, List<Map<String, Object>>> executionHistory = new HashMap<>();
    
    /**
     * Find all pipelines.
     * 
     * @return List of all pipelines
     */
    public List<Pipeline> findAll() {
        return pipelineRepository.findAll();
    }
    
    /**
     * Find all pipelines created by a specific user.
     * 
     * @param username Username of the creator
     * @return List of pipelines
     */
    public List<Pipeline> findAllByUsername(String username) {
        return pipelineRepository.findByCreatedBy(username);
    }
    
    /**
     * Find a pipeline by ID.
     * 
     * @param id Pipeline ID
     * @return The pipeline, or null if not found
     */
    public Pipeline findById(Long id) {
        return pipelineRepository.findById(id).orElse(null);
    }
    
    /**
     * Find a pipeline by application ID.
     * 
     * @param appId Application ID
     * @return The pipeline, or null if not found
     */
    public Pipeline findByAppId(String appId) {
        return pipelineRepository.findByApplicationAppId(appId);
    }
    
    /**
     * Find recent pipelines for a user.
     * 
     * @param username Username of the creator
     * @param limit Maximum number of pipelines to return
     * @return List of pipelines
     */
    public List<Pipeline> findRecentByUsername(String username, int limit) {
        List<Pipeline> pipelines = pipelineRepository.findByCreatedByOrderByLastRunDesc(username);
        return pipelines.size() <= limit ? pipelines : pipelines.subList(0, limit);
    }
    
    /**
     * Save a new pipeline.
     * 
     * @param pipeline Pipeline to save
     * @return The saved pipeline
     */
    @Transactional
    public Pipeline save(Pipeline pipeline) {
        // Ensure the applications have proper sequence numbers if not set
        for (int i = 0; i < pipeline.getApplications().size(); i++) {
            Application app = pipeline.getApplications().get(i);
            if (app.getSequence() == null) {
                app.setSequence(i + 1);
            }
        }
        
        return pipelineRepository.save(pipeline);
    }
    
    /**
     * Update an existing pipeline.
     * 
     * @param pipeline Pipeline to update
     * @return The updated pipeline
     */
    @Transactional
    public Pipeline update(Pipeline pipeline) {
        Optional<Pipeline> existingPipelineOpt = pipelineRepository.findById(pipeline.getId());
        if (!existingPipelineOpt.isPresent()) {
            throw new RuntimeException("Pipeline not found with ID: " + pipeline.getId());
        }
        
        Pipeline existingPipeline = existingPipelineOpt.get();
        
        // Update fields
        existingPipeline.setName(pipeline.getName());
        existingPipeline.setDescription(pipeline.getDescription());
        
        // Handle applications
        // First, remove applications that are no longer in the pipeline
        List<Application> existingApps = new ArrayList<>(existingPipeline.getApplications());
        for (Application existingApp : existingApps) {
            boolean found = false;
            for (Application newApp : pipeline.getApplications()) {
                if (existingApp.getId() != null && existingApp.getId().equals(newApp.getId())) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                existingPipeline.removeApplication(existingApp);
            }
        }
        
        // Then, update existing applications and add new ones
        for (Application newApp : pipeline.getApplications()) {
            if (newApp.getId() != null) {
                // This is an existing application, update it
                for (Application existingApp : existingPipeline.getApplications()) {
                    if (existingApp.getId().equals(newApp.getId())) {
                        existingApp.setAppId(newApp.getAppId());
                        existingApp.setProjectId(newApp.getProjectId());
                        existingApp.setBranch(newApp.getBranch());
                        existingApp.setAccessToken(newApp.getAccessToken());
                        existingApp.setSequence(newApp.getSequence());
                        break;
                    }
                }
            } else {
                // This is a new application, add it
                existingPipeline.addApplication(newApp);
            }
        }
        
        // Sort applications by sequence
        existingPipeline.getApplications().sort((a1, a2) -> a1.getSequence().compareTo(a2.getSequence()));
        
        return pipelineRepository.save(existingPipeline);
    }
    
    /**
     * Delete a pipeline.
     * 
     * @param id ID of the pipeline to delete
     */
    @Transactional
    public void delete(Long id) {
        pipelineRepository.deleteById(id);
    }
    
    /**
     * Add an application to a pipeline.
     * 
     * @param pipelineId ID of the pipeline
     * @param application Application to add
     * @return The updated pipeline
     */
    @Transactional
    public Pipeline addApplication(Long pipelineId, Application application) {
        Pipeline pipeline = pipelineRepository.findById(pipelineId)
                .orElseThrow(() -> new RuntimeException("Pipeline not found with ID: " + pipelineId));
        
        // Determine sequence number if not provided
        if (application.getSequence() == null) {
            int maxSequence = pipeline.getApplications().stream()
                    .mapToInt(Application::getSequence)
                    .max()
                    .orElse(0);
            application.setSequence(maxSequence + 1);
        }
        
        pipeline.addApplication(application);
        return pipelineRepository.save(pipeline);
    }
    
    /**
     * Remove an application from a pipeline.
     * 
     * @param pipelineId ID of the pipeline
     * @param applicationId ID of the application to remove
     * @return The updated pipeline
     */
    @Transactional
    public Pipeline removeApplication(Long pipelineId, Long applicationId) {
        Pipeline pipeline = pipelineRepository.findById(pipelineId)
                .orElseThrow(() -> new RuntimeException("Pipeline not found with ID: " + pipelineId));
        
        pipeline.getApplications().removeIf(app -> app.getId().equals(applicationId));
        return pipelineRepository.save(pipeline);
    }
    
    /**
     * Execute a pipeline.
     * 
     * @param pipelineId ID of the pipeline to execute
     * @return true if execution started successfully, false otherwise
     */
    @Transactional
    public boolean executePipeline(Long pipelineId) {
        Pipeline pipeline = pipelineRepository.findById(pipelineId)
                .orElseThrow(() -> new RuntimeException("Pipeline not found with ID: " + pipelineId));
        
        // Check if it has applications
        if (pipeline.getApplications().isEmpty()) {
            throw new RuntimeException("Pipeline has no applications to execute");
        }
        
        // Update pipeline status
        pipeline.updateStatus(Pipeline.Status.RUNNING);
        pipelineRepository.save(pipeline);
        
        // Create execution record
        Map<String, Object> execution = new HashMap<>();
        execution.put("id", System.currentTimeMillis());
        execution.put("startTime", LocalDateTime.now());
        execution.put("status", "RUNNING");
        
        if (!executionHistory.containsKey(pipelineId)) {
            executionHistory.put(pipelineId, new ArrayList<>());
        }
        executionHistory.get(pipelineId).add(execution);
        
        // Start execution
        executeApplicationsAsync(pipeline, (Long) execution.get("id"));
        
        return true;
    }
    
    /**
     * Get the status of a pipeline execution.
     * 
     * @param pipelineId ID of the pipeline
     * @param executionId ID of the execution
     * @return Status of the execution
     */
    public String getExecutionStatus(Long pipelineId, Long executionId) {
        List<Map<String, Object>> executions = executionHistory.getOrDefault(pipelineId, Collections.emptyList());
        
        for (Map<String, Object> execution : executions) {
            if (execution.get("id").equals(executionId)) {
                return (String) execution.get("status");
            }
        }
        
        return "NOT_FOUND";
    }
    
    /**
     * Get the execution history for a pipeline.
     * 
     * @param pipelineId ID of the pipeline
     * @return List of execution records
     */
    public List<Map<String, Object>> getExecutionHistory(Long pipelineId) {
        return executionHistory.getOrDefault(pipelineId, Collections.emptyList());
    }
    
    /**
     * Execute applications asynchronously in sequence.
     * 
     * @param pipeline Pipeline containing applications to execute
     * @param executionId ID of the execution
     */
    @Async
    protected void executeApplicationsAsync(Pipeline pipeline, Long executionId) {
        logger.info("Starting pipeline execution: {}", pipeline.getId());
        
        boolean allSuccess = true;
        
        // Sort applications by sequence
        List<Application> applications = new ArrayList<>(pipeline.getApplications());
        applications.sort((a1, a2) -> a1.getSequence().compareTo(a2.getSequence()));
        
        for (Application app : applications) {
            try {
                // Update application status
                app.setStatus(Status.RUNNING);
                applicationRepository.save(app);
                
                // Execute the application
                boolean success = gitLabService.triggerPipeline(app.getProjectId(), app.getBranch(), app.getAccessToken());
                
                // Update application status
                app.setStatus(success ? Status.SUCCESS : Status.FAILED);
                applicationRepository.save(app);
                
                if (!success) {
                    allSuccess = false;
                    break;
                }
            } catch (Exception e) {
                logger.error("Error executing application: " + app.getAppId(), e);
                app.setStatus(Status.FAILED);
                applicationRepository.save(app);
                allSuccess = false;
                break;
            }
        }
        
        // Update pipeline status
        Pipeline.Status finalStatus = allSuccess ? Pipeline.Status.SUCCESS : Pipeline.Status.FAILED;
        pipeline.updateStatus(finalStatus);
        pipelineRepository.save(pipeline);
        
        // Update execution record
        List<Map<String, Object>> executions = executionHistory.get(pipeline.getId());
        for (Map<String, Object> execution : executions) {
            if (execution.get("id").equals(executionId)) {
                execution.put("endTime", LocalDateTime.now());
                execution.put("status", finalStatus.toString());
                break;
            }
        }
        
        logger.info("Finished pipeline execution: {} with status: {}", pipeline.getId(), finalStatus);
    }
}
