package com.pipelineorchestrator.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pipelineorchestrator.dto.TestResultDTO;
import com.pipelineorchestrator.model.Application;
import com.pipelineorchestrator.model.Log;
import com.pipelineorchestrator.model.Pipeline;
import com.pipelineorchestrator.model.Test;
import com.pipelineorchestrator.model.TestSuite;
import com.pipelineorchestrator.repository.PipelineRepository;
import com.pipelineorchestrator.repository.TestSuiteRepository;

/**
 * Service for test result-related operations.
 * Handles saving and retrieving test results.
 */
@Service
public class TestResultService {

    private static final Logger logger = LoggerFactory.getLogger(TestResultService.class);
    
    @Autowired
    private TestSuiteRepository testSuiteRepository;
    
    @Autowired
    private PipelineRepository pipelineRepository;
    
    /**
     * Save a test result.
     * 
     * @param testSuite Test suite to save
     * @return The saved test suite
     */
    @Transactional
    public TestSuite saveTestResult(TestSuite testSuite) {
        logger.info("Saving test result for app: {}", testSuite.getAppId());
        
        // Find the pipeline that contains this application
        Pipeline pipeline = pipelineRepository.findByApplicationAppId(testSuite.getAppId());
        if (pipeline != null) {
            testSuite.setPipelineId(pipeline.getId());
        } else {
            logger.warn("No pipeline found for app: {}", testSuite.getAppId());
        }
        
        // Process each test to ensure it's properly set up
        for (Map.Entry<String, Test> entry : testSuite.getTests().entrySet()) {
            Test test = entry.getValue();
            if (test.getStatus() == null) {
                // Determine status based on logs
                String status = "PASS";
                for (Log log : test.getLogs()) {
                    if ("FAIL".equals(log.getStatus())) {
                        status = "FAIL";
                        break;
                    }
                }
                test.setStatus(status);
            }
        }
        
        return testSuiteRepository.save(testSuite);
    }
    
    /**
     * Find a test result by ID.
     * 
     * @param id Test result ID
     * @return TestResultDTO or null if not found
     */
    public TestResultDTO findById(Long id) {
        TestSuite testSuite = testSuiteRepository.findById(id).orElse(null);
        return testSuite != null ? convertToDTO(testSuite) : null;
    }
    
    /**
     * Find recent test results for a user.
     * 
     * @param username Username of the user
     * @return List of TestResultDTOs
     */
    public List<TestResultDTO> findRecentByUsername(String username) {
        return findRecentByUsername(username, 10); // Default limit
    }
    
    /**
     * Find recent test results for a user with a limit.
     * 
     * @param username Username of the user
     * @param limit Maximum number of results to return
     * @return List of TestResultDTOs
     */
    public List<TestResultDTO> findRecentByUsername(String username, int limit) {
        List<TestSuite> testSuites = testSuiteRepository.findByUsernameOrderByExecutionDateDesc(username);
        testSuites = testSuites.size() <= limit ? testSuites : testSuites.subList(0, limit);
        List<TestResultDTO> results = new ArrayList<>();
        
        for (TestSuite testSuite : testSuites) {
            results.add(convertToDTO(testSuite));
        }
        
        return results;
    }
    
    /**
     * Delete a test result.
     * 
     * @param id ID of the test result to delete
     */
    @Transactional
    public void delete(Long id) {
        testSuiteRepository.deleteById(id);
    }
    
    /**
     * Get test statistics for a user.
     * 
     * @param username Username of the user
     * @return Map containing test statistics
     */
    public Map<String, Integer> getTestStatistics(String username) {
        Object[] stats = testSuiteRepository.getTestStatistics(username);
        
        Map<String, Integer> result = new HashMap<>();
        if (stats != null && stats.length == 4) {
            result.put("total", ((Number) stats[0]).intValue());
            result.put("passed", ((Number) stats[1]).intValue());
            result.put("failed", ((Number) stats[2]).intValue());
            result.put("skipped", ((Number) stats[3]).intValue());
        } else {
            result.put("total", 0);
            result.put("passed", 0);
            result.put("failed", 0);
            result.put("skipped", 0);
        }
        
        return result;
    }
    
    /**
     * Convert a TestSuite entity to a TestResultDTO.
     * 
     * @param testSuite TestSuite entity
     * @return TestResultDTO
     */
    private TestResultDTO convertToDTO(TestSuite testSuite) {
        TestResultDTO dto = new TestResultDTO();
        
        dto.setId(testSuite.getId());
        dto.setAppId(testSuite.getAppId());
        dto.setAppName(testSuite.getAppName());
        dto.setAppDescription(testSuite.getAppDescription());
        dto.setExecutionDate(testSuite.getExecutionDate());
        dto.setPipelineId(testSuite.getPipelineId());
        
        // Add suites data
        Map<String, Map<String, Object>> suitesMap = new HashMap<>();
        for (String suiteName : testSuite.getTests().keySet()) {
            Test test = testSuite.getTests().get(suiteName);
            
            Map<String, Object> suiteData = suitesMap.computeIfAbsent(
                suiteName, k -> {
                    Map<String, Object> data = new HashMap<>();
                    data.put("name", suiteName);
                    data.put("tests", new HashMap<String, Map<String, Object>>());
                    return data;
                }
            );
            
            // Add test data
            Map<String, Map<String, Object>> testsMap = (Map<String, Map<String, Object>>) suiteData.get("tests");
            Map<String, Object> testData = new HashMap<>();
            testData.put("name", test.getName());
            testData.put("description", test.getDescription());
            testData.put("status", test.getStatus());
            testData.put("startTime", test.getStartTime());
            testData.put("endTime", test.getEndTime());
            testData.put("tags", test.getTags());
            
            // Add logs
            List<Map<String, String>> logs = new ArrayList<>();
            for (Log log : test.getLogs()) {
                Map<String, String> logData = new HashMap<>();
                logData.put("message", log.getMessage());
                logData.put("status", log.getStatus());
                logs.add(logData);
            }
            testData.put("logs", logs);
            
            testsMap.put(test.getName(), testData);
        }
        dto.setSuites(suitesMap);
        
        // Add custom data
        dto.setCustomData(testSuite.getCustomData());
        
        // Calculate test counts
        int totalTests = testSuite.getTests().size();
        int passedTests = 0;
        int failedTests = 0;
        int skippedTests = 0;
        Set<String> allTags = new HashSet<>();
        
        for (Test test : testSuite.getTests().values()) {
            if ("PASS".equals(test.getStatus())) {
                passedTests++;
            } else if ("FAIL".equals(test.getStatus())) {
                failedTests++;
            } else {
                skippedTests++;
            }
            
            // Collect all tags
            if (test.getTags() != null) {
                allTags.addAll(test.getTags());
            }
        }
        
        dto.setTotalTests(totalTests);
        dto.setPassedTests(passedTests);
        dto.setFailedTests(failedTests);
        dto.setSkippedTests(skippedTests);
        dto.setAllTags(new ArrayList<>(allTags));
        
        return dto;
    }
}
