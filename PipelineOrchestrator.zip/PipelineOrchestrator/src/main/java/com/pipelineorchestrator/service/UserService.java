package com.pipelineorchestrator.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pipelineorchestrator.model.User;
import com.pipelineorchestrator.repository.UserRepository;

/**
 * Service for user-related operations.
 * Implements UserDetailsService for Spring Security integration.
 */
@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    /**
     * Find a user by username
     * 
     * @param username The username to search for
     * @return The user, or null if not found
     */
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    /**
     * Find a user by email
     * 
     * @param email The email to search for
     * @return The user, or null if not found
     */
    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    /**
     * Register a new user
     * 
     * @param user The user to register
     * @return The registered user
     */
    @Transactional
    public User registerUser(User user) {
        // Encode the password
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        
        // Set default role
        user.setRole("ROLE_USER");
        
        // Save the user
        return userRepository.save(user);
    }
    
    /**
     * Update a user's last login time
     * 
     * @param username The username of the user
     */
    @Transactional
    public void updateLastLogin(String username) {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            user.setLastLogin(LocalDateTime.now());
            userRepository.save(user);
        }
    }
    
    /**
     * Check if a username is available
     * 
     * @param username The username to check
     * @return True if the username is available, false otherwise
     */
    public boolean isUsernameAvailable(String username) {
        return !userRepository.existsByUsername(username);
    }
    
    /**
     * Check if an email is available
     * 
     * @param email The email to check
     * @return True if the email is available, false otherwise
     */
    public boolean isEmailAvailable(String email) {
        return !userRepository.existsByEmail(email);
    }
    
    /**
     * Implementation of UserDetailsService.loadUserByUsername method.
     * This is used by Spring Security for authentication.
     * 
     * @param username The username to load
     * @return UserDetails object for the user
     * @throws UsernameNotFoundException if user not found
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found: " + username);
        }
        return user;
    }
}
