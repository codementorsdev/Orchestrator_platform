/**
 * GitLab Pipeline Orchestration Platform
 * Authentication related JavaScript functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    initAuthForms();
});

/**
 * Initialize authentication forms
 */
function initAuthForms() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (loginForm) {
        initLoginForm(loginForm);
    }
    
    if (registerForm) {
        initRegisterForm(registerForm);
    }
}

/**
 * Initialize login form
 * @param {HTMLFormElement} form - The login form element
 */
function initLoginForm(form) {
    // Client-side validation
    form.addEventListener('submit', function(e) {
        const username = form.querySelector('#username');
        const password = form.querySelector('#password');
        let isValid = true;
        
        // Simple validation
        if (!username.value.trim()) {
            showInputError(username, 'Username is required');
            isValid = false;
        } else {
            clearInputError(username);
        }
        
        if (!password.value.trim()) {
            showInputError(password, 'Password is required');
            isValid = false;
        } else {
            clearInputError(password);
        }
        
        if (!isValid) {
            e.preventDefault();
        }
    });
    
    // Reset form fields on load (for security)
    form.reset();
    
    // Focus on first input
    const firstInput = form.querySelector('input');
    if (firstInput) {
        firstInput.focus();
    }
}

/**
 * Initialize register form
 * @param {HTMLFormElement} form - The registration form element
 */
function initRegisterForm(form) {
    const username = form.querySelector('#username');
    const email = form.querySelector('#email');
    const password = form.querySelector('#password');
    const confirmPassword = form.querySelector('#confirmPassword');
    
    // Client-side validation
    form.addEventListener('submit', function(e) {
        let isValid = true;
        
        // Username validation
        if (!username.value.trim()) {
            showInputError(username, 'Username is required');
            isValid = false;
        } else if (username.value.length < 3) {
            showInputError(username, 'Username must be at least 3 characters');
            isValid = false;
        } else {
            clearInputError(username);
        }
        
        // Email validation
        if (!email.value.trim()) {
            showInputError(email, 'Email is required');
            isValid = false;
        } else if (!isValidEmail(email.value)) {
            showInputError(email, 'Please enter a valid email address');
            isValid = false;
        } else {
            clearInputError(email);
        }
        
        // Password validation
        if (!password.value) {
            showInputError(password, 'Password is required');
            isValid = false;
        } else if (password.value.length < 8) {
            showInputError(password, 'Password must be at least 8 characters');
            isValid = false;
        } else {
            clearInputError(password);
        }
        
        // Confirm password
        if (password.value !== confirmPassword.value) {
            showInputError(confirmPassword, 'Passwords do not match');
            isValid = false;
        } else {
            clearInputError(confirmPassword);
        }
        
        if (!isValid) {
            e.preventDefault();
        }
    });
    
    // Reset form fields on load
    form.reset();
    
    // Focus on first input
    const firstInput = form.querySelector('input');
    if (firstInput) {
        firstInput.focus();
    }
}

/**
 * Show an error message for an input field
 * @param {HTMLInputElement} inputElement - The input element
 * @param {string} message - The error message
 */
function showInputError(inputElement, message) {
    inputElement.classList.add('is-invalid');
    
    // Find or create the error message element
    let errorElement = inputElement.nextElementSibling;
    if (!errorElement || !errorElement.classList.contains('invalid-feedback')) {
        errorElement = document.createElement('div');
        errorElement.className = 'invalid-feedback';
        inputElement.parentNode.insertBefore(errorElement, inputElement.nextSibling);
    }
    
    errorElement.textContent = message;
}

/**
 * Clear error styling and messages from an input field
 * @param {HTMLInputElement} inputElement - The input element
 */
function clearInputError(inputElement) {
    inputElement.classList.remove('is-invalid');
    
    // Find and remove the error message element
    const errorElement = inputElement.nextElementSibling;
    if (errorElement && errorElement.classList.contains('invalid-feedback')) {
        errorElement.textContent = '';
    }
}

/**
 * Validate email format
 * @param {string} email - The email to validate
 * @returns {boolean} True if email is valid
 */
function isValidEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
}

/**
 * Handle logout functionality
 */
function handleLogout() {
    // In a real implementation, this would send a request to invalidate the session
    console.log('Logging out user');
    
    // Redirect to login page
    window.location.href = '/login';
}

// Set up logout button event listener
document.addEventListener('DOMContentLoaded', function() {
    const logoutBtn = document.querySelector('.logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            handleLogout();
        });
    }
});
