/**
 * GitLab Pipeline Orchestration Platform
 * Flow management functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    initFlowManagement();
});

/**
 * Initialize flow management functionality
 */
function initFlowManagement() {
    const flowForm = document.getElementById('flowConfigForm');
    if (flowForm) {
        initFlowConfigForm(flowForm);
    }
    
    const flowList = document.querySelector('.flow-list');
    if (flowList) {
        initFlowList();
    }
    
    const flowDetails = document.querySelector('.flow-details');
    if (flowDetails) {
        initFlowDetails();
    }
}

/**
 * Initialize flow configuration form
 * @param {HTMLFormElement} form - The flow configuration form
 */
function initFlowConfigForm(form) {
    // Handle form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        saveFlowConfig();
    });
    
    // Initialize pipeline selector
    const pipelineSelect = document.getElementById('pipelineSelect');
    if (pipelineSelect) {
        pipelineSelect.addEventListener('change', function() {
            loadPipelineApplications(this.value);
        });
    }
}

/**
 * Save flow configuration
 */
function saveFlowConfig() {
    const form = document.getElementById('flowConfigForm');
    const formData = new FormData(form);
    
    // Convert FormData to JSON object
    const flowData = {
        name: formData.get('flowName'),
        description: formData.get('flowDescription'),
        pipelineId: formData.get('pipelineSelect')
    };
    
    console.log('Saving flow configuration:', flowData);
    
    // In a real implementation, send this data to the server via AJAX
    // For now, we'll simulate a server response
    setTimeout(() => {
        showAlert('Flow configuration saved successfully!', 'success');
        
        // Redirect to the flow list page after saving
        // window.location.href = '/flows';
    }, 1000);
}

/**
 * Load applications for the selected pipeline
 * @param {string} pipelineId - The ID of the selected pipeline
 */
function loadPipelineApplications(pipelineId) {
    if (!pipelineId) {
        const appContainer = document.querySelector('.pipeline-applications');
        if (appContainer) {
            appContainer.innerHTML = '<p class="text-muted">Select a pipeline to view applications</p>';
        }
        return;
    }
    
    console.log(`Loading applications for pipeline: ${pipelineId}`);
    
    // In a real implementation, this would fetch data from the server
    // For demonstration, we'll simulate a server response
    simulateLoadPipelineApplications(pipelineId);
}

/**
 * Simulate loading pipeline applications
 * @param {string} pipelineId - The ID of the selected pipeline
 */
function simulateLoadPipelineApplications(pipelineId) {
    // Simulate loading delay
    const appContainer = document.querySelector('.pipeline-applications');
    if (!appContainer) return;
    
    appContainer.innerHTML = '<p class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading applications...</p>';
    
    setTimeout(() => {
        // Generate sample applications data
        const sampleApps = [
            { id: 'app1', name: 'Frontend App', projectId: '12345', branch: 'main', sequence: 1 },
            { id: 'app2', name: 'Backend API', projectId: '67890', branch: 'develop', sequence: 2 },
            { id: 'app3', name: 'Database Service', projectId: '54321', branch: 'main', sequence: 3 }
        ];
        
        // Render applications
        let html = '<h4 class="mt-4">Pipeline Applications</h4>';
        html += '<div class="list-group">';
        
        sampleApps.forEach(app => {
            html += `
                <div class="list-group-item">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5>${app.name}</h5>
                            <small class="text-muted">Project ID: ${app.projectId}, Branch: ${app.branch}</small>
                        </div>
                        <span class="badge bg-primary rounded-pill">Sequence: ${app.sequence}</span>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        
        appContainer.innerHTML = html;
    }, 1000);
}

/**
 * Initialize flow list
 */
function initFlowList() {
    const executeButtons = document.querySelectorAll('.execute-flow-btn');
    executeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const flowId = this.getAttribute('data-flow-id');
            executeFlow(flowId);
        });
    });
    
    const viewButtons = document.querySelectorAll('.view-flow-btn');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const flowId = this.getAttribute('data-flow-id');
            navigateToFlowDetails(flowId);
        });
    });
}

/**
 * Execute a flow
 * @param {string} flowId - The ID of the flow to execute
 */
function executeFlow(flowId) {
    console.log(`Executing flow: ${flowId}`);
    
    // Show execution started message
    showAlert(`Flow execution started`, 'info');
    
    // Update the UI to show the flow is running
    const statusEl = document.querySelector(`.flow-status[data-flow-id="${flowId}"]`);
    if (statusEl) {
        statusEl.classList.remove('status-success', 'status-pending', 'status-failed');
        statusEl.classList.add('status-running');
        statusEl.textContent = 'Running';
    }
    
    // In a real implementation, this would make an API call to trigger the flow
    // For demonstration, we'll simulate a flow run with periodic updates
    simulateFlowExecution(flowId);
}

/**
 * Simulate flow execution with status updates
 * @param {string} flowId - The ID of the flow
 */
function simulateFlowExecution(flowId) {
    const statusEl = document.querySelector(`.flow-status[data-flow-id="${flowId}"]`);
    if (!statusEl) return;
    
    // Create a progress element
    const progressContainer = document.createElement('div');
    progressContainer.className = 'progress mt-2';
    progressContainer.innerHTML = `
        <div class="progress-bar progress-bar-striped progress-bar-animated" 
             role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
             style="width: 0%"></div>
    `;
    
    const flowItem = statusEl.closest('.flow-item');
    if (flowItem) {
        flowItem.appendChild(progressContainer);
    }
    
    const progressBar = progressContainer.querySelector('.progress-bar');
    let progress = 0;
    
    // Simulate progress updates
    const progressInterval = setInterval(() => {
        progress += Math.floor(Math.random() * 10) + 1;
        if (progress >= 100) {
            progress = 100;
            clearInterval(progressInterval);
            
            // Simulate success/failure (80% chance of success)
            const success = Math.random() < 0.8;
            
            if (success) {
                statusEl.classList.remove('status-running');
                statusEl.classList.add('status-success');
                statusEl.textContent = 'Success';
                showAlert(`Flow execution completed successfully!`, 'success');
            } else {
                statusEl.classList.remove('status-running');
                statusEl.classList.add('status-failed');
                statusEl.textContent = 'Failed';
                showAlert(`Flow execution failed. Check logs for details.`, 'danger');
            }
            
            // Remove progress bar after completion
            setTimeout(() => {
                progressContainer.remove();
            }, 2000);
        }
        
        progressBar.style.width = `${progress}%`;
        progressBar.setAttribute('aria-valuenow', progress);
    }, 1000);
}

/**
 * Navigate to flow details page
 * @param {string} flowId - The ID of the flow
 */
function navigateToFlowDetails(flowId) {
    // In a real implementation, this would navigate to a flow details page
    window.location.href = `/flows/${flowId}`;
}

/**
 * Initialize flow details page
 */
function initFlowDetails() {
    // Toggle test case details
    const testHeaders = document.querySelectorAll('.test-case-header');
    testHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const testBody = this.nextElementSibling;
            testBody.classList.toggle('active');
        });
    });
    
    // Initialize timeline visualization
    initTimelineVisualization();
}

/**
 * Initialize timeline visualization for flow execution
 */
function initTimelineVisualization() {
    const timelineContainer = document.querySelector('.flow-timeline');
    if (!timelineContainer) return;
    
    // In a real implementation, this would use actual data from the server
    // For demonstration, we'll use sample data
    const steps = timelineContainer.querySelectorAll('.timeline-step');
    
    steps.forEach((step, index) => {
        // Add click handler to show details
        step.addEventListener('click', function() {
            const details = this.querySelector('.timeline-details');
            if (details) {
                details.classList.toggle('active');
            }
        });
        
        // Simulate step completion for demonstration
        setTimeout(() => {
            step.classList.add('completed');
            
            const status = step.querySelector('.timeline-status');
            if (status) {
                status.textContent = 'Completed';
                status.classList.add('status-success');
            }
        }, (index + 1) * 2000);
    });
}
