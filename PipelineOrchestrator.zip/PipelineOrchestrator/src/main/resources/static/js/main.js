/**
 * GitLab Pipeline Orchestration Platform
 * Main JavaScript file
 */

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('GitLab Pipeline Orchestration Platform initialized');
    
    // Setup navigation toggle for mobile
    setupMobileNav();
    
    // Setup user dropdown menu
    setupUserDropdown();
    
    // Initialize page-specific functionality
    initializePage();
    
    // Setup alerts auto-close
    setupAlerts();
});

/**
 * Set up the mobile navigation
 */
function setupMobileNav() {
    const mobileNavToggle = document.querySelector('.mobile-nav-toggle');
    if (mobileNavToggle) {
        mobileNavToggle.addEventListener('click', function() {
            const navLinks = document.querySelector('.nav-links');
            navLinks.classList.toggle('active');
        });
    }
}

/**
 * Set up the user dropdown menu
 */
function setupUserDropdown() {
    const userMenuToggle = document.querySelector('.user-menu-toggle');
    if (userMenuToggle) {
        userMenuToggle.addEventListener('click', function(e) {
            e.preventDefault();
            const userDropdown = document.querySelector('.user-dropdown');
            userDropdown.classList.toggle('active');
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function closeDropdown(e) {
                if (!e.target.closest('.user-menu')) {
                    userDropdown.classList.remove('active');
                    document.removeEventListener('click', closeDropdown);
                }
            });
        });
    }
}

/**
 * Initialize page-specific functionality based on the current page
 */
function initializePage() {
    const body = document.body;
    
    if (body.classList.contains('page-login') || body.classList.contains('page-register')) {
        // Initialize authentication pages
        initAuthPages();
    } else if (body.classList.contains('page-dashboard')) {
        // Initialize dashboard
        initDashboard();
    } else if (body.classList.contains('page-pipeline-config')) {
        // Initialize pipeline configuration
        initPipelineConfig();
    } else if (body.classList.contains('page-flow-management')) {
        // Initialize flow management
        initFlowManagement();
    } else if (body.classList.contains('page-test-results')) {
        // Initialize test results
        initTestResults();
    }
}

/**
 * Initialize authentication pages
 */
function initAuthPages() {
    const authForm = document.querySelector('.auth-form');
    if (authForm) {
        authForm.addEventListener('submit', function(e) {
            const requiredFields = authForm.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                showAlert('Please fill in all required fields.', 'danger');
            }
        });
    }
}

/**
 * Initialize dashboard
 */
function initDashboard() {
    // Update real-time status indicators
    updateStatusIndicators();
    
    // Set up refresh button
    const refreshBtn = document.querySelector('.refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            updateStatusIndicators();
            showAlert('Dashboard refreshed', 'info');
        });
    }
}

/**
 * Update status indicators in real-time
 */
function updateStatusIndicators() {
    // In a real implementation, this would fetch data from backend
    console.log('Updating status indicators');
    
    // Example of how to update a status indicator
    const statusElements = document.querySelectorAll('.pipeline-status');
    statusElements.forEach(element => {
        // Simulate random status changes for demo purposes
        if (Math.random() > 0.7) {
            const statuses = ['status-success', 'status-running', 'status-pending', 'status-failed'];
            const newStatus = statuses[Math.floor(Math.random() * statuses.length)];
            
            // Remove all status classes
            element.classList.remove('status-success', 'status-running', 'status-pending', 'status-failed');
            
            // Add new status class
            element.classList.add(newStatus);
            
            // Update text
            if (newStatus === 'status-success') element.textContent = 'Success';
            if (newStatus === 'status-running') element.textContent = 'Running';
            if (newStatus === 'status-pending') element.textContent = 'Pending';
            if (newStatus === 'status-failed') element.textContent = 'Failed';
        }
    });
}

/**
 * Set up auto-closing alerts
 */
function setupAlerts() {
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 5000);
    });
}

/**
 * Show an alert message
 * @param {string} message - The message to display
 * @param {string} type - The alert type (success, warning, danger, info)
 */
function showAlert(message, type = 'info') {
    const alertsContainer = document.querySelector('.alerts-container');
    if (!alertsContainer) return;
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    
    alertsContainer.appendChild(alert);
    
    // Auto-close the alert after 5 seconds
    setTimeout(() => {
        alert.style.opacity = '0';
        setTimeout(() => {
            alert.remove();
        }, 300);
    }, 5000);
}

/**
 * Format a date string
 * @param {number} timestamp - The timestamp to format
 * @returns {string} Formatted date string
 */
function formatDate(timestamp) {
    if (!timestamp) return 'N/A';
    
    const date = new Date(timestamp);
    return date.toLocaleString();
}

/**
 * Calculate duration between two timestamps
 * @param {number} startTime - Start timestamp
 * @param {number} endTime - End timestamp
 * @returns {string} Formatted duration
 */
function calculateDuration(startTime, endTime) {
    if (!startTime || !endTime) return 'N/A';
    
    const duration = endTime - startTime;
    
    if (duration < 1000) {
        return `${duration}ms`;
    } else if (duration < 60000) {
        return `${Math.floor(duration / 1000)}s`;
    } else {
        const minutes = Math.floor(duration / 60000);
        const seconds = Math.floor((duration % 60000) / 1000);
        return `${minutes}m ${seconds}s`;
    }
}
