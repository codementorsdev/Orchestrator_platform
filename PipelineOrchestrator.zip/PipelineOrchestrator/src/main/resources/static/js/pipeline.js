/**
 * GitLab Pipeline Orchestration Platform
 * Pipeline configuration and execution functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    initPipelineConfig();
    initPipelineExecution();
});

/**
 * Initialize pipeline configuration
 */
function initPipelineConfig() {
    const pipelineForm = document.getElementById('pipelineConfigForm');
    if (!pipelineForm) return;
    
    // Handle form submission
    pipelineForm.addEventListener('submit', function(e) {
        e.preventDefault();
        savePipelineConfig();
    });
    
    // Handle adding a new application to the pipeline
    const addAppBtn = document.getElementById('addApplicationBtn');
    if (addAppBtn) {
        addAppBtn.addEventListener('click', function() {
            addApplicationToForm();
        });
    }
    
    // Initialize any existing application rows (for edit mode)
    initExistingApplicationRows();
}

/**
 * Save pipeline configuration
 */
function savePipelineConfig() {
    const form = document.getElementById('pipelineConfigForm');
    const formData = new FormData(form);
    
    // Convert FormData to JSON object
    const pipelineData = {
        name: formData.get('pipelineName'),
        description: formData.get('pipelineDescription'),
        applications: []
    };
    
    // Get all application rows
    const appRows = document.querySelectorAll('.application-row');
    appRows.forEach((row, index) => {
        const appId = row.querySelector('[name^="appId"]').value;
        const projectId = row.querySelector('[name^="projectId"]').value;
        const branch = row.querySelector('[name^="branch"]').value;
        const accessToken = row.querySelector('[name^="accessToken"]').value;
        const sequence = row.querySelector('[name^="sequence"]').value;
        
        pipelineData.applications.push({
            appId,
            projectId,
            branch,
            accessToken,
            sequence: sequence || index + 1
        });
    });
    
    console.log('Saving pipeline configuration:', pipelineData);
    
    // In a real implementation, send this data to the server via AJAX
    // For now, we'll simulate a server response
    setTimeout(() => {
        showAlert('Pipeline configuration saved successfully!', 'success');
        
        // Redirect to the pipeline list page after saving
        // window.location.href = '/pipelines';
    }, 1000);
}

/**
 * Add a new application input row to the form
 */
function addApplicationToForm() {
    const appContainer = document.querySelector('.applications-container');
    const rowCount = document.querySelectorAll('.application-row').length;
    
    const newRow = document.createElement('div');
    newRow.className = 'application-row card mb-3';
    newRow.innerHTML = `
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="card-title">Application #${rowCount + 1}</h5>
                <button type="button" class="btn btn-sm btn-danger remove-app-btn">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="appId${rowCount}">Application ID</label>
                        <input type="text" class="form-control" id="appId${rowCount}" 
                               name="appId${rowCount}" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="projectId${rowCount}">GitLab Project ID</label>
                        <input type="text" class="form-control" id="projectId${rowCount}" 
                               name="projectId${rowCount}" required>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="branch${rowCount}">Branch</label>
                        <input type="text" class="form-control" id="branch${rowCount}" 
                               name="branch${rowCount}" placeholder="main" value="main">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="accessToken${rowCount}">Access Token</label>
                        <input type="password" class="form-control" id="accessToken${rowCount}" 
                               name="accessToken${rowCount}" required>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="sequence${rowCount}">Execution Sequence</label>
                <input type="number" class="form-control" id="sequence${rowCount}" 
                       name="sequence${rowCount}" value="${rowCount + 1}" min="1">
                <small class="form-text text-muted">
                    The order in which this application will be executed in the pipeline.
                </small>
            </div>
        </div>
    `;
    
    appContainer.appendChild(newRow);
    
    // Add event listener to the remove button
    const removeBtn = newRow.querySelector('.remove-app-btn');
    removeBtn.addEventListener('click', function() {
        newRow.remove();
        // Renumber the remaining rows
        renumberApplicationRows();
    });
}

/**
 * Renumber the application rows after removing one
 */
function renumberApplicationRows() {
    const appRows = document.querySelectorAll('.application-row');
    appRows.forEach((row, index) => {
        const titleEl = row.querySelector('.card-title');
        if (titleEl) {
            titleEl.textContent = `Application #${index + 1}`;
        }
    });
}

/**
 * Initialize existing application rows (for edit mode)
 */
function initExistingApplicationRows() {
    const removeButtons = document.querySelectorAll('.remove-app-btn');
    removeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = btn.closest('.application-row');
            row.remove();
            renumberApplicationRows();
        });
    });
}

/**
 * Initialize pipeline execution
 */
function initPipelineExecution() {
    const executeButtons = document.querySelectorAll('.execute-pipeline-btn');
    if (!executeButtons.length) return;
    
    executeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const pipelineId = btn.getAttribute('data-pipeline-id');
            executePipeline(pipelineId);
        });
    });
}

/**
 * Execute a pipeline
 * @param {string} pipelineId - The ID of the pipeline to execute
 */
function executePipeline(pipelineId) {
    console.log(`Executing pipeline: ${pipelineId}`);
    
    // Show execution started message
    showAlert(`Pipeline execution started`, 'info');
    
    // Update the UI to show the pipeline is running
    const statusEl = document.querySelector(`.pipeline-status[data-pipeline-id="${pipelineId}"]`);
    if (statusEl) {
        statusEl.classList.remove('status-success', 'status-pending', 'status-failed');
        statusEl.classList.add('status-running');
        statusEl.textContent = 'Running';
    }
    
    // In a real implementation, this would make an API call to trigger the pipeline
    // For demonstration, we'll simulate a pipeline run with periodic updates
    simulatePipelineExecution(pipelineId);
}

/**
 * Simulate pipeline execution with status updates
 * @param {string} pipelineId - The ID of the pipeline
 */
function simulatePipelineExecution(pipelineId) {
    const statusEl = document.querySelector(`.pipeline-status[data-pipeline-id="${pipelineId}"]`);
    if (!statusEl) return;
    
    // Create a progress element
    const progressContainer = document.createElement('div');
    progressContainer.className = 'progress mt-2';
    progressContainer.innerHTML = `
        <div class="progress-bar progress-bar-striped progress-bar-animated" 
             role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"
             style="width: 0%"></div>
    `;
    
    const pipelineItem = statusEl.closest('.pipeline-item');
    if (pipelineItem) {
        pipelineItem.appendChild(progressContainer);
    }
    
    const progressBar = progressContainer.querySelector('.progress-bar');
    let progress = 0;
    
    // Simulate progress updates
    const progressInterval = setInterval(() => {
        progress += Math.floor(Math.random() * 10) + 1;
        if (progress >= 100) {
            progress = 100;
            clearInterval(progressInterval);
            
            // Simulate success/failure (80% chance of success)
            const success = Math.random() < 0.8;
            
            if (success) {
                statusEl.classList.remove('status-running');
                statusEl.classList.add('status-success');
                statusEl.textContent = 'Success';
                showAlert(`Pipeline execution completed successfully!`, 'success');
            } else {
                statusEl.classList.remove('status-running');
                statusEl.classList.add('status-failed');
                statusEl.textContent = 'Failed';
                showAlert(`Pipeline execution failed. Check logs for details.`, 'danger');
            }
            
            // Remove progress bar after completion
            setTimeout(() => {
                progressContainer.remove();
            }, 2000);
        }
        
        progressBar.style.width = `${progress}%`;
        progressBar.setAttribute('aria-valuenow', progress);
    }, 1000);
}
