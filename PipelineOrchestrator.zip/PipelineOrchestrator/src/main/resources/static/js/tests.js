/**
 * GitLab Pipeline Orchestration Platform
 * Test results visualization functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    initTestResults();
});

/**
 * Initialize test results visualization
 */
function initTestResults() {
    const testResultsContainer = document.querySelector('.test-results');
    if (!testResultsContainer) return;
    
    // Initialize test suite toggles
    initTestSuiteToggles();
    
    // Initialize test filters
    initTestFilters();
    
    // Initialize test visualizations
    initTestVisualizations();
}

/**
 * Initialize test suite toggles
 */
function initTestSuiteToggles() {
    const suiteToggles = document.querySelectorAll('.test-suite-toggle');
    suiteToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const suiteContent = this.closest('.test-suite').querySelector('.test-suite-content');
            suiteContent.classList.toggle('active');
            
            const icon = this.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-chevron-down');
                icon.classList.toggle('fa-chevron-up');
            }
        });
    });
}

/**
 * Initialize test filters
 */
function initTestFilters() {
    const filterForm = document.getElementById('testFilterForm');
    if (!filterForm) return;
    
    filterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        applyTestFilters();
    });
    
    // Initialize tag filter checkboxes
    const tagCheckboxes = document.querySelectorAll('.tag-filter');
    tagCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            applyTestFilters();
        });
    });
    
    // Initialize status filter
    const statusSelect = document.getElementById('statusFilter');
    if (statusSelect) {
        statusSelect.addEventListener('change', function() {
            applyTestFilters();
        });
    }
    
    // Initialize search input
    const searchInput = document.getElementById('searchFilter');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(function() {
            applyTestFilters();
        }, 300));
    }
}

/**
 * Apply test filters based on form inputs
 */
function applyTestFilters() {
    const searchTerm = document.getElementById('searchFilter')?.value.toLowerCase() || '';
    const selectedStatus = document.getElementById('statusFilter')?.value || '';
    
    // Get selected tags
    const selectedTags = [];
    const tagCheckboxes = document.querySelectorAll('.tag-filter:checked');
    tagCheckboxes.forEach(checkbox => {
        selectedTags.push(checkbox.value);
    });
    
    console.log('Applying filters:', {
        searchTerm,
        selectedStatus,
        selectedTags
    });
    
    // Filter test cases
    const testCases = document.querySelectorAll('.test-case');
    testCases.forEach(testCase => {
        const testName = testCase.getAttribute('data-test-name').toLowerCase();
        const testStatus = testCase.getAttribute('data-test-status');
        const testTags = JSON.parse(testCase.getAttribute('data-test-tags') || '[]');
        
        // Check if test matches all filters
        const matchesSearch = searchTerm === '' || testName.includes(searchTerm);
        const matchesStatus = selectedStatus === '' || testStatus === selectedStatus;
        const matchesTags = selectedTags.length === 0 || 
                          selectedTags.some(tag => testTags.includes(tag));
        
        // Show/hide based on filter matches
        if (matchesSearch && matchesStatus && matchesTags) {
            testCase.style.display = 'block';
        } else {
            testCase.style.display = 'none';
        }
    });
    
    // Update counts
    updateTestCounts();
}

/**
 * Update test counts after filtering
 */
function updateTestCounts() {
    const testSuites = document.querySelectorAll('.test-suite');
    testSuites.forEach(suite => {
        const totalTests = suite.querySelectorAll('.test-case').length;
        const visibleTests = suite.querySelectorAll('.test-case[style="display: block"]').length;
        
        const countEl = suite.querySelector('.test-count');
        if (countEl) {
            if (visibleTests < totalTests) {
                countEl.textContent = `Showing ${visibleTests} of ${totalTests} tests`;
            } else {
                countEl.textContent = `${totalTests} tests`;
            }
        }
    });
}

/**
 * Initialize test visualizations (charts, etc.)
 */
function initTestVisualizations() {
    // Initialize test duration chart
    initTestDurationChart();
    
    // Initialize test status summary
    initTestStatusSummary();
    
    // Initialize test logs viewer
    initTestLogsViewer();
}

/**
 * Initialize test duration chart
 */
function initTestDurationChart() {
    const chartCanvas = document.getElementById('testDurationChart');
    if (!chartCanvas || typeof Chart === 'undefined') return;
    
    // Gather test duration data
    const testCases = document.querySelectorAll('.test-case');
    const testNames = [];
    const durations = [];
    
    testCases.forEach(test => {
        const name = test.getAttribute('data-test-name');
        const startTime = parseInt(test.getAttribute('data-start-time') || '0');
        const endTime = parseInt(test.getAttribute('data-end-time') || '0');
        
        if (startTime && endTime) {
            testNames.push(name);
            durations.push((endTime - startTime) / 1000); // Convert to seconds
        }
    });
    
    // Create the chart
    new Chart(chartCanvas, {
        type: 'bar',
        data: {
            labels: testNames,
            datasets: [{
                label: 'Test Duration (seconds)',
                data: durations,
                backgroundColor: 'rgba(74, 74, 143, 0.7)',
                borderColor: 'rgba(74, 74, 143, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Duration (seconds)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Test Cases'
                    }
                }
            }
        }
    });
}

/**
 * Initialize test status summary
 */
function initTestStatusSummary() {
    const summaryContainer = document.querySelector('.test-summary');
    if (!summaryContainer) return;
    
    // Gather test status data
    const testCases = document.querySelectorAll('.test-case');
    let passed = 0;
    let failed = 0;
    let skipped = 0;
    
    testCases.forEach(test => {
        const status = test.getAttribute('data-test-status');
        if (status === 'PASS') passed++;
        else if (status === 'FAIL') failed++;
        else skipped++;
    });
    
    // Update summary elements
    const totalEl = summaryContainer.querySelector('.total-tests');
    const passedEl = summaryContainer.querySelector('.passed-tests');
    const failedEl = summaryContainer.querySelector('.failed-tests');
    const skippedEl = summaryContainer.querySelector('.skipped-tests');
    
    if (totalEl) totalEl.textContent = testCases.length;
    if (passedEl) passedEl.textContent = passed;
    if (failedEl) failedEl.textContent = failed;
    if (skippedEl) skippedEl.textContent = skipped;
    
    // Create pie chart if Chart.js is available
    const chartCanvas = document.getElementById('testStatusChart');
    if (chartCanvas && typeof Chart !== 'undefined') {
        new Chart(chartCanvas, {
            type: 'pie',
            data: {
                labels: ['Passed', 'Failed', 'Skipped'],
                datasets: [{
                    data: [passed, failed, skipped],
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.7)',
                        'rgba(220, 53, 69, 0.7)',
                        'rgba(108, 117, 125, 0.7)'
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(220, 53, 69, 1)',
                        'rgba(108, 117, 125, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
    }
}

/**
 * Initialize test logs viewer
 */
function initTestLogsViewer() {
    const logContainers = document.querySelectorAll('.test-logs');
    logContainers.forEach(container => {
        // Add syntax highlighting or formatting if needed
    });
    
    // Add log filter functionality
    const logFilterInputs = document.querySelectorAll('.log-filter');
    logFilterInputs.forEach(input => {
        input.addEventListener('input', function() {
            const filterValue = this.value.toLowerCase();
            const logContainer = this.closest('.test-case').querySelector('.test-logs');
            
            if (!logContainer) return;
            
            const logEntries = logContainer.querySelectorAll('.log-entry');
            logEntries.forEach(entry => {
                const logText = entry.textContent.toLowerCase();
                if (filterValue === '' || logText.includes(filterValue)) {
                    entry.style.display = 'flex';
                } else {
                    entry.style.display = 'none';
                }
            });
        });
    });
}

/**
 * Debounce function to limit execution frequency
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        const context = this;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), wait);
    };
}

/**
 * Format test duration from start and end times
 * @param {number} startTime - Start timestamp
 * @param {number} endTime - End timestamp
 * @returns {string} Formatted duration
 */
function formatTestDuration(startTime, endTime) {
    if (!startTime || !endTime) return 'N/A';
    
    const duration = endTime - startTime;
    
    if (duration < 1000) {
        return `${duration}ms`;
    } else if (duration < 60000) {
        return `${(duration / 1000).toFixed(2)}s`;
    } else {
        const minutes = Math.floor(duration / 60000);
        const seconds = ((duration % 60000) / 1000).toFixed(2);
        return `${minutes}m ${seconds}s`;
    }
}

/**
 * Export test results as JSON
 */
function exportTestResults() {
    // Gather all test data
    const testSuites = document.querySelectorAll('.test-suite');
    const result = {
        appId: document.querySelector('[data-app-id]')?.getAttribute('data-app-id'),
        appName: document.querySelector('[data-app-name]')?.getAttribute('data-app-name'),
        suites: {}
    };
    
    testSuites.forEach(suite => {
        const suiteName = suite.getAttribute('data-suite-name');
        result.suites[suiteName] = {
            name: suiteName,
            tests: {}
        };
        
        const testCases = suite.querySelectorAll('.test-case');
        testCases.forEach(test => {
            const testName = test.getAttribute('data-test-name');
            result.suites[suiteName].tests[testName] = {
                name: testName,
                status: test.getAttribute('data-test-status'),
                startTime: parseInt(test.getAttribute('data-start-time') || '0'),
                endTime: parseInt(test.getAttribute('data-end-time') || '0')
            };
        });
    });
    
    // Convert to JSON string
    const jsonStr = JSON.stringify(result, null, 2);
    
    // Create download link
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `test-results-${new Date().toISOString()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Set up export button
document.addEventListener('DOMContentLoaded', function() {
    const exportBtn = document.querySelector('.export-results-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportTestResults);
    }
});
