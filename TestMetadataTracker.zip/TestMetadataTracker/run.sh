#!/bin/bash

# Set JAVA_HOME environment variable
export JAVA_HOME="/nix/store/2vwkssqpzykk37r996cafq7x63imf4sp-openjdk-21+35"
export PATH="$JAVA_HOME/bin:$PATH"

# Set the server port to 5000 (Replit's non-firewalled port)
export SERVER_PORT=5000

# Print Java and Maven information
echo "Using Java version:"
java -version
echo ""

# Run Spring Boot application
./mvnw spring-boot:run -Dspring-boot.run.jvmArguments="-Dserver.port=5000"