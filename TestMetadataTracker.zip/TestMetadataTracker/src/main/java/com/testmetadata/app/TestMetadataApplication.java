package com.testmetadata.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main application class for the Test Metadata Application.
 * This application provides REST APIs to store and retrieve test execution metadata.
 */
@SpringBootApplication
public class TestMetadataApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestMetadataApplication.class, args);
    }
}
