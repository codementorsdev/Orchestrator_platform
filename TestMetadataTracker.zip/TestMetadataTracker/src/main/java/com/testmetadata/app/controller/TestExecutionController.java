package com.testmetadata.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.testmetadata.app.dto.TestExecutionRequest;
import com.testmetadata.app.dto.TestExecutionResponse;
import com.testmetadata.app.service.TestExecutionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/**
 * REST controller for managing test execution metadata.
 */
@RestController
@RequestMapping("/api/test-executions")
@Tag(name = "Test Execution", description = "APIs for managing test execution metadata")
public class TestExecutionController {

    private final TestExecutionService testExecutionService;

    @Autowired
    public TestExecutionController(TestExecutionService testExecutionService) {
        this.testExecutionService = testExecutionService;
    }

    @PostMapping
    @Operation(summary = "Store test execution metadata", description = "Persists test execution metadata to the database")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Test execution metadata stored successfully", 
                content = @Content(schema = @Schema(implementation = TestExecutionResponse.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input provided"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<TestExecutionResponse> storeTestExecution(@Valid @RequestBody TestExecutionRequest request) {
        TestExecutionResponse response = testExecutionService.saveTestExecution(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get test execution by ID", description = "Retrieves test execution metadata based on the provided ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Test execution found", 
                content = @Content(schema = @Schema(implementation = TestExecutionResponse.class))),
        @ApiResponse(responseCode = "404", description = "Test execution not found"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<TestExecutionResponse> getTestExecution(
            @Parameter(description = "ID of the test execution", required = true) @PathVariable Long id) {
        TestExecutionResponse response = testExecutionService.getTestExecutionById(id);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @Operation(summary = "Get all test executions", description = "Retrieves all test execution metadata with optional filtering by appId")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Test executions found", 
                content = @Content(schema = @Schema(implementation = TestExecutionResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<TestExecutionResponse>> getAllTestExecutions(
            @Parameter(description = "Filter by application ID") @RequestParam(required = false) String appId) {
        List<TestExecutionResponse> executions;
        if (appId != null && !appId.isEmpty()) {
            executions = testExecutionService.getTestExecutionsByAppId(appId);
        } else {
            executions = testExecutionService.getAllTestExecutions();
        }
        return ResponseEntity.ok(executions);
    }
}
