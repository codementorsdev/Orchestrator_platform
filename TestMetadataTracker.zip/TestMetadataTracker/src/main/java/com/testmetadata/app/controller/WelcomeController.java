package com.testmetadata.app.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller for handling welcome/home requests
 */
@RestController
@RequestMapping("/")
public class WelcomeController {

    /**
     * Welcome endpoint for the root path
     * 
     * @return Welcome message and API information
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> welcome() {
        Map<String, Object> response = new HashMap<>();
        response.put("application", "Test Metadata Service");
        response.put("version", "1.0.0");
        response.put("status", "running");
        response.put("documentation", "/swagger-ui/index.html");
        response.put("api", "/api/v1/test-executions");
        
        return ResponseEntity.ok(response);
    }
}