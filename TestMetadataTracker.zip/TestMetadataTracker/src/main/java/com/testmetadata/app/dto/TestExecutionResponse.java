package com.testmetadata.app.dto;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for test execution response data
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@Schema(description = "Test execution metadata response")
public class TestExecutionResponse {

    @Schema(description = "Unique identifier for the stored test execution")
    private Long id;

    @Schema(description = "Unique identifier for the application", example = "my-awesome-app")
    private String appId;

    @Schema(description = "Name of the application", example = "My Awesome Application")
    private String appName;

    @Schema(description = "Description of the application", example = "This is a test application for end-to-end testing.")
    private String appDescription;

    @Schema(description = "Timestamp when the execution data was recorded")
    private Instant recordedAt;

    @Schema(description = "List of test suites executed")
    private List<TestSuiteDTO> suites;

    @Schema(description = "Custom data fields for the test execution")
    private Map<String, String> customData;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(Include.NON_NULL)
    public static class TestSuiteDTO {
        @Schema(description = "ID of the test suite in the database")
        private Long id;

        @Schema(description = "Name of the test suite", example = "SampleTestSuite")
        private String name;

        @Schema(description = "Description of the test suite", example = "A sample test suite for demonstration")
        private String description;

        @Schema(description = "Tags associated with the test suite")
        private List<String> tags;

        @Schema(description = "Timestamp when the suite started execution (epoch milliseconds)", example = "1742804321506")
        private Long startTime;

        @Schema(description = "Timestamp when the suite completed execution (epoch milliseconds)", example = "1742804321572")
        private Long endTime;

        @Schema(description = "Map of tests executed in this suite")
        private Map<String, TestDTO> tests;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(Include.NON_NULL)
    public static class TestDTO {
        @Schema(description = "ID of the test in the database")
        private Long id;

        @Schema(description = "Name of the test case", example = "sample_test2")
        private String name;

        @Schema(description = "Description of the test case", example = "Some awesome test case 2")
        private String description;

        @Schema(description = "Tags associated with the test case")
        private List<String> tags;

        @Schema(description = "Timestamp when the test started execution (epoch milliseconds)", example = "1742804321561")
        private Long startTime;

        @Schema(description = "Timestamp when the test completed execution (epoch milliseconds)", example = "1742804321561")
        private Long endTime;

        @Schema(description = "Logs generated during the test execution")
        private List<TestLogDTO> logs;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(Include.NON_NULL)
    public static class TestLogDTO {
        @Schema(description = "ID of the log entry in the database")
        private Long id;

        @Schema(description = "Log message content", example = "Sample Log Message - Step 1")
        private String message;

        @Schema(description = "Status of the log entry", example = "PASS")
        private String status;
    }
}
