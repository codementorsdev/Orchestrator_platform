package com.testmetadata.app.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity representing a test execution 
 */
@Entity
@Table(name = "test_executions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestExecution {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String appId;

    @Column(nullable = false)
    private String appName;

    @Column(length = 1000)
    private String appDescription;

    @Column(nullable = false)
    private Instant recordedAt;

    @OneToMany(mappedBy = "testExecution", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<TestSuite> suites = new ArrayList<>();

    @OneToMany(mappedBy = "testExecution", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<CustomData> customData = new ArrayList<>();

    /**
     * Add a test suite to this execution and handle bidirectional relationship
     */
    public void addTestSuite(TestSuite suite) {
        suites.add(suite);
        suite.setTestExecution(this);
    }

    /**
     * Add custom data to this execution and handle bidirectional relationship
     */
    public void addCustomData(CustomData data) {
        customData.add(data);
        data.setTestExecution(this);
    }
}
