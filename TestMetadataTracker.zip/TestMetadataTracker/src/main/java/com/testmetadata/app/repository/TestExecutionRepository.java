package com.testmetadata.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.testmetadata.app.model.TestExecution;

/**
 * Repository for TestExecution entities
 */
@Repository
public interface TestExecutionRepository extends JpaRepository<TestExecution, Long> {
    
    /**
     * Find all test executions for a particular application ID
     * 
     * @param appId the application ID to filter by
     * @return a list of test executions for the application
     */
    List<TestExecution> findByAppIdOrderByRecordedAtDesc(String appId);
}
