package com.testmetadata.app.service;

import java.util.List;

import com.testmetadata.app.dto.TestExecutionRequest;
import com.testmetadata.app.dto.TestExecutionResponse;

/**
 * Service interface for managing test execution data
 */
public interface TestExecutionService {
    
    /**
     * Save a new test execution
     * 
     * @param request the test execution data to save
     * @return response with the saved test execution details
     */
    TestExecutionResponse saveTestExecution(TestExecutionRequest request);
    
    /**
     * Get a test execution by its ID
     * 
     * @param id the ID of the test execution to retrieve
     * @return the test execution details
     */
    TestExecutionResponse getTestExecutionById(Long id);
    
    /**
     * Get all test executions
     * 
     * @return a list of all test executions
     */
    List<TestExecutionResponse> getAllTestExecutions();
    
    /**
     * Get test executions by application ID
     * 
     * @param appId the application ID to filter by
     * @return a list of test executions for the application
     */
    List<TestExecutionResponse> getTestExecutionsByAppId(String appId);
}
