package com.testmetadata.app.service.impl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.testmetadata.app.dto.TestExecutionRequest;
import com.testmetadata.app.dto.TestExecutionResponse;
import com.testmetadata.app.exception.ResourceNotFoundException;
import com.testmetadata.app.model.CustomData;
import com.testmetadata.app.model.Test;
import com.testmetadata.app.model.TestExecution;
import com.testmetadata.app.model.TestLog;
import com.testmetadata.app.model.TestSuite;
import com.testmetadata.app.repository.TestExecutionRepository;
import com.testmetadata.app.service.TestExecutionService;

/**
 * Implementation of the TestExecutionService
 */
@Service
public class TestExecutionServiceImpl implements TestExecutionService {

    private final TestExecutionRepository testExecutionRepository;

    @Autowired
    public TestExecutionServiceImpl(TestExecutionRepository testExecutionRepository) {
        this.testExecutionRepository = testExecutionRepository;
    }

    @Override
    @Transactional
    public TestExecutionResponse saveTestExecution(TestExecutionRequest request) {
        // Create the test execution entity
        TestExecution execution = TestExecution.builder()
                .appId(request.getAppId())
                .appName(request.getAppName())
                .appDescription(request.getAppDescription())
                .recordedAt(Instant.now())
                .build();

        // Process test suites
        if (request.getSuites() != null) {
            for (TestExecutionRequest.TestSuiteDTO suiteDto : request.getSuites()) {
                TestSuite suite = TestSuite.builder()
                        .name(suiteDto.getName())
                        .description(suiteDto.getDescription())
                        .tags(suiteDto.getTags() != null ? new ArrayList<>(suiteDto.getTags()) : new ArrayList<>())
                        .startTime(suiteDto.getStartTime())
                        .endTime(suiteDto.getEndTime())
                        .testKey("suite-" + suiteDto.getName())
                        .build();
                
                execution.addTestSuite(suite);

                // Process tests in the suite
                if (suiteDto.getTests() != null) {
                    for (Map.Entry<String, TestExecutionRequest.TestDTO> entry : suiteDto.getTests().entrySet()) {
                        String testKey = entry.getKey();
                        TestExecutionRequest.TestDTO testDto = entry.getValue();

                        Test test = Test.builder()
                                .name(testDto.getName())
                                .description(testDto.getDescription())
                                .tags(testDto.getTags() != null ? new ArrayList<>(testDto.getTags()) : new ArrayList<>())
                                .startTime(testDto.getStartTime())
                                .endTime(testDto.getEndTime())
                                .build();
                        
                        suite.addTest(test);

                        // Process logs for this test
                        if (testDto.getLogs() != null) {
                            for (TestExecutionRequest.TestLogDTO logDto : testDto.getLogs()) {
                                TestLog log = TestLog.builder()
                                        .message(logDto.getMessage())
                                        .status(logDto.getStatus())
                                        .build();
                                
                                test.addLog(log);
                            }
                        }
                    }
                }
            }
        }

        // Process custom data
        if (request.getCustomData() != null) {
            for (Map.Entry<String, String> entry : request.getCustomData().entrySet()) {
                CustomData customData = CustomData.builder()
                        .dataKey(entry.getKey())
                        .dataValue(entry.getValue())
                        .build();
                
                execution.addCustomData(customData);
            }
        }

        // Save the test execution
        TestExecution savedExecution = testExecutionRepository.save(execution);
        
        // Convert to response
        return mapToResponse(savedExecution);
    }

    @Override
    @Transactional(readOnly = true)
    public TestExecutionResponse getTestExecutionById(Long id) {
        TestExecution execution = testExecutionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Test execution not found with id: " + id));
        
        return mapToResponse(execution);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TestExecutionResponse> getAllTestExecutions() {
        return testExecutionRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TestExecutionResponse> getTestExecutionsByAppId(String appId) {
        return testExecutionRepository.findByAppIdOrderByRecordedAtDesc(appId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    /**
     * Maps a TestExecution entity to a TestExecutionResponse DTO
     */
    private TestExecutionResponse mapToResponse(TestExecution execution) {
        TestExecutionResponse response = new TestExecutionResponse();
        response.setId(execution.getId());
        response.setAppId(execution.getAppId());
        response.setAppName(execution.getAppName());
        response.setAppDescription(execution.getAppDescription());
        response.setRecordedAt(execution.getRecordedAt());
        
        // Map custom data
        Map<String, String> customDataMap = new HashMap<>();
        for (CustomData customData : execution.getCustomData()) {
            customDataMap.put(customData.getDataKey(), customData.getDataValue());
        }
        response.setCustomData(customDataMap);
        
        // Map suites
        List<TestExecutionResponse.TestSuiteDTO> suiteDtos = new ArrayList<>();
        for (TestSuite suite : execution.getSuites()) {
            TestExecutionResponse.TestSuiteDTO suiteDto = new TestExecutionResponse.TestSuiteDTO();
            suiteDto.setId(suite.getId());
            suiteDto.setName(suite.getName());
            suiteDto.setDescription(suite.getDescription());
            suiteDto.setTags(suite.getTags());
            suiteDto.setStartTime(suite.getStartTime());
            suiteDto.setEndTime(suite.getEndTime());
            
            // Map tests in the suite
            Map<String, TestExecutionResponse.TestDTO> testMap = new HashMap<>();
            for (Test test : suite.getTests()) {
                TestExecutionResponse.TestDTO testDto = new TestExecutionResponse.TestDTO();
                testDto.setId(test.getId());
                testDto.setName(test.getName());
                testDto.setDescription(test.getDescription());
                testDto.setTags(test.getTags());
                testDto.setStartTime(test.getStartTime());
                testDto.setEndTime(test.getEndTime());
                
                // Map logs
                List<TestExecutionResponse.TestLogDTO> logDtos = new ArrayList<>();
                for (TestLog log : test.getLogs()) {
                    TestExecutionResponse.TestLogDTO logDto = new TestExecutionResponse.TestLogDTO();
                    logDto.setId(log.getId());
                    logDto.setMessage(log.getMessage());
                    logDto.setStatus(log.getStatus());
                    logDtos.add(logDto);
                }
                testDto.setLogs(logDtos);
                
                // Use the test name as the key
                testMap.put(test.getName(), testDto);
            }
            suiteDto.setTests(testMap);
            
            suiteDtos.add(suiteDto);
        }
        response.setSuites(suiteDtos);
        
        return response;
    }
}
