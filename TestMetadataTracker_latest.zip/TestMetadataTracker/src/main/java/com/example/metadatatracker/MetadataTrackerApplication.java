package com.example.metadatatracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetadataTrackerApplication {
    public static void main(String[] args) {
        SpringApplication.run(MetadataTrackerApplication.class, args);
    }
}
