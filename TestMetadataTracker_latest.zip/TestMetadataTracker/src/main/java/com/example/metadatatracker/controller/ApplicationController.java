package com.example.metadatatracker.controller;

import com.example.metadatatracker.dto.ApplicationPayloadDTO;
import com.example.metadatatracker.entity.Application;
import com.example.metadatatracker.service.ApplicationService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/applications")
public class ApplicationController {
    private final ApplicationService applicationService;

    public ApplicationController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @PostMapping
    public Application createApplication(@RequestBody ApplicationPayloadDTO applicationPayloadDTO) {
        return applicationService.saveFullPayload(applicationPayloadDTO);
    }

    @GetMapping("/{id}")
    public Application getApplicationById(@PathVariable Long id) {
        return applicationService.getApplicationById(id);
    }

    @GetMapping
    public List<Application> getAllApplications() {
        return applicationService.getAllApplications();
    }
}
