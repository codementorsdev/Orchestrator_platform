package com.example.metadatatracker.controller;

import com.example.metadatatracker.entity.Log;
import com.example.metadatatracker.service.LogService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/logs")
public class LogController {
    private final LogService logService;

    public LogController(LogService logService) {
        this.logService = logService;
    }

    @PostMapping
    public Log createLog(@RequestBody Log log) {
        return logService.saveLog(log);
    }

    @GetMapping("/test/{testId}")
    public List<Log> getLogsByTestId(@PathVariable Long testId) {
        return logService.getLogsByTestId(testId);
    }
}
