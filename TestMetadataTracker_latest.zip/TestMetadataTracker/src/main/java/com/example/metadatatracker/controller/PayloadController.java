package com.example.metadatatracker.controller;

import com.example.metadatatracker.dto.ApplicationPayloadDTO;
import com.example.metadatatracker.service.ApplicationService;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/payloads")
@Tag(name = "Payload API", description = "Operations with complete test metadata payloads")
public class PayloadController {
    private final ApplicationService applicationService;

    public PayloadController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @Operation(summary = "Save complete test metadata payload", 
               description = "Persists a complete test metadata hierarchy including application, suites, tests and logs")
    @ApiResponse(responseCode = "200", description = "Successfully saved payload",
            content = @Content(schema = @Schema(implementation = ApplicationPayloadDTO.class)))
    @PostMapping
    public ApplicationPayloadDTO savePayload(
            @RequestBody @Schema(description = "Complete test metadata payload to save") 
            ApplicationPayloadDTO payloadDTO) {
        return applicationService.getFullPayloadById(
            applicationService.saveFullPayload(payloadDTO).getId()
        );
    }

    @Operation(summary = "Get payload by ID", 
               description = "Retrieves a complete test metadata payload by its ID")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved payload",
            content = @Content(schema = @Schema(implementation = ApplicationPayloadDTO.class)))
    @GetMapping("/{id}")
    public ApplicationPayloadDTO getPayloadById(
            @Parameter(description = "ID of the payload to retrieve", required = true)
            @PathVariable Long id) {
        return applicationService.getFullPayloadById(id);
    }
}
