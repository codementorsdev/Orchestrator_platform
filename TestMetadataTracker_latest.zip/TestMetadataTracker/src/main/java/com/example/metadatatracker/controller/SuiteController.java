package com.example.metadatatracker.controller;

import com.example.metadatatracker.entity.Suite;
import com.example.metadatatracker.service.SuiteService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/suites")
public class SuiteController {
    private final SuiteService suiteService;

    public SuiteController(SuiteService suiteService) {
        this.suiteService = suiteService;
    }

    @PostMapping
    public Suite createSuite(@RequestBody Suite suite) {
        return suiteService.saveSuite(suite);
    }

    @GetMapping("/application/{applicationId}")
    public List<Suite> getSuitesByApplicationId(@PathVariable Long applicationId) {
        return suiteService.getSuitesByApplicationId(applicationId);
    }
}
