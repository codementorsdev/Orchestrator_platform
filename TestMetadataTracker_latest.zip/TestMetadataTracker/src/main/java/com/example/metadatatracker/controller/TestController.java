package com.example.metadatatracker.controller;

import com.example.metadatatracker.entity.Test;
import com.example.metadatatracker.service.TestService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/tests")
public class TestController {
    private final TestService testService;

    public TestController(TestService testService) {
        this.testService = testService;
    }

    @PostMapping
    public Test createTest(@RequestBody Test test) {
        return testService.saveTest(test);
    }

    @GetMapping("/suite/{suiteId}")
    public List<Test> getTestsBySuiteId(@PathVariable Long suiteId) {
        return testService.getTestsBySuiteId(suiteId);
    }
}
