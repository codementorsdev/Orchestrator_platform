package com.example.metadatatracker.dto;

import com.example.metadatatracker.entity.CustomData;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
@Schema(description = "Complete test metadata payload containing application, suites, tests and logs")
public class ApplicationPayloadDTO {
    @Schema(description = "Unique identifier for the application", example = "my-awesome-app")
    private String appId;

    @Schema(description = "Name of the application", example = "My Awesome Application") 
    private String appName;

    @Schema(description = "Description of the application", example = "This is a test application for end-to-end testing")
    private String appDescription;

    @Schema(description = "List of test suites belonging to the application")
    private List<SuiteDTO> suites;

    @Schema(description = "Custom key-value data associated with the application")
    private CustomData customData;

    @Data
    @Schema(description = "Test suite containing a group of related tests")
    public static class SuiteDTO {
        @Schema(description = "Name of the test suite", example = "SampleTestSuite")
        private String name;

        @Schema(description = "Description of the test suite", example = "A sample test suite for demonstration")
        private String description;

        @Schema(description = "Tags associated with the test suite", example = "[\"sanity\", \"example\"]")
        private List<String> tags;

        @Schema(description = "Start time of test suite execution in epoch milliseconds", example = "1744357337865")
        private Long startTime;

        @Schema(description = "End time of test suite execution in epoch milliseconds", example = "1744357337932")
        private Long endTime;

        @Schema(description = "Map of test cases belonging to this suite (key=testId, value=testDetails)")
        private Map<String, TestDTO> tests;
    }

    @Data
    @Schema(description = "Individual test case with its execution details")
    public static class TestDTO {
        @Schema(description = "Name of the test case", example = "sample_test1")
        private String name;

        @Schema(description = "Description of the test case", example = "Some awesome test case") 
        private String description;

        @Schema(description = "Tags associated with the test case", example = "[\"test1\", \"sanity\"]")
        private List<String> tags;

        @Schema(description = "Start time of test execution in epoch milliseconds", example = "1744357337926")
        private Long startTime;

        @Schema(description = "End time of test execution in epoch milliseconds", example = "1744357337926")
        private Long endTime;

        @Schema(description = "List of log messages from test execution")
        private List<LogDTO> logs;
    }

    @Data
    @Schema(description = "Log message from test execution")
    public static class LogDTO {
        @Schema(description = "Log message content", example = "Sample Log Message - Step 1")
        private String message;

        @Schema(description = "Log status/severity", example = "PASS",
                allowableValues = {"INFO", "PASS", "FAIL", "SKIP"})
        private String status;
    }
}
