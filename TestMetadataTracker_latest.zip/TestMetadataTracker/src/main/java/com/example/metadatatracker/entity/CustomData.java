package com.example.metadatatracker.entity;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class CustomData {
    private String data1;
    private String data2;
}
