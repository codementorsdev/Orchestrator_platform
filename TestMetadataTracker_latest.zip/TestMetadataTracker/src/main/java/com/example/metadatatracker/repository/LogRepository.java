package com.example.metadatatracker.repository;

import com.example.metadatatracker.entity.Log;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LogRepository extends JpaRepository<Log, Long> {
    List<Log> findByTestId(Long testId);
}
