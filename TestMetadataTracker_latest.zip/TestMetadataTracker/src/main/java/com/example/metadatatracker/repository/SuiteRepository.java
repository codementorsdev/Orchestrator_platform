package com.example.metadatatracker.repository;

import com.example.metadatatracker.entity.Suite;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SuiteRepository extends JpaRepository<Suite, Long> {
    List<Suite> findByApplicationId(Long applicationId);
}
