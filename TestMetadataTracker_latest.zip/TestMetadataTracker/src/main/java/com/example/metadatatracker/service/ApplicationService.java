package com.example.metadatatracker.service;

import com.example.metadatatracker.dto.ApplicationPayloadDTO;
import com.example.metadatatracker.entity.*;
import com.example.metadatatracker.repository.ApplicationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ApplicationService {
    private final ApplicationRepository applicationRepository;
    private final SuiteService suiteService;
    private final TestService testService;
    private final LogService logService;

    public ApplicationService(ApplicationRepository applicationRepository, SuiteService suiteService, TestService testService, LogService logService) {
        this.applicationRepository = applicationRepository;
        this.suiteService = suiteService;
        this.testService = testService;
        this.logService = logService;
    }

    @Transactional
    public Application saveApplication(Application application) {
        return applicationRepository.save(application);
    }

    public Application getApplicationById(Long id) {
        return applicationRepository.findById(id).orElse(null);
    }

    public Application getApplicationByAppId(String appId) {
        return applicationRepository.findByAppId(appId);
    }

    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

   @Transactional
    public Application saveFullPayload(ApplicationPayloadDTO payloadDTO) {
        Application application = mapToApplication(payloadDTO);
        Application savedApplication = applicationRepository.save(application);

        if (application.getSuites() != null) {
            for (Suite suite : application.getSuites()) {
                suite.setApplication(savedApplication);
                Suite savedSuite = suiteService.saveSuite(suite);

                if (suite.getTests() != null) {
                    for (Test test : suite.getTests().values()) {
                        test.setSuite(savedSuite);
                        Test savedTest = testService.saveTest(test);

                        if (test.getLogs() != null) {
                            for (Log log : test.getLogs()) {
                                log.setTest(savedTest);
                                logService.saveLog(log);
                            }
                        }
                    }
                }
            }
        }

        return savedApplication;
    }

    public ApplicationPayloadDTO getFullPayloadById(Long id) {
        Application application = applicationRepository.findById(id).orElse(null);
        return application != null ? mapToPayloadDTO(application) : null;
    }

   private Application mapToApplication(ApplicationPayloadDTO dto) {
        Application application = new Application();
        application.setAppId(dto.getAppId());
        application.setAppName(dto.getAppName());
        application.setAppDescription(dto.getAppDescription());
        application.setCustomData(dto.getCustomData());

        if (dto.getSuites() != null) {
            List<Suite> suites = dto.getSuites().stream()
                .map(suiteDTO -> {
                    Suite suite = new Suite();
                    suite.setName(suiteDTO.getName());
                    suite.setDescription(suiteDTO.getDescription());
                    suite.setTags(suiteDTO.getTags());
                    suite.setStartTime(suiteDTO.getStartTime());
                    suite.setEndTime(suiteDTO.getEndTime());

                    if (suiteDTO.getTests() != null) {
                        Map<String, Test> tests = suiteDTO.getTests().entrySet().stream()
                            .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                entry -> {
                                    ApplicationPayloadDTO.TestDTO testDTO = entry.getValue();
                                    Test test = new Test();
                                    test.setName(testDTO.getName());
                                    test.setDescription(testDTO.getDescription());
                                    test.setTags(testDTO.getTags());
                                    test.setStartTime(testDTO.getStartTime());
                                    test.setEndTime(testDTO.getEndTime());

                                    if (testDTO.getLogs() != null) {
                                        List<Log> logs = testDTO.getLogs().stream()
                                            .map(logDTO -> {
                                                Log log = new Log();
                                                log.setMessage(logDTO.getMessage());
                                                log.setStatus(logDTO.getStatus());
                                                return log;
                                            })
                                            .collect(Collectors.toList());
                                        test.setLogs(logs);
                                    }
                                    return test;
                                }
                            ));
                        suite.setTests(tests);
                    }
                    return suite;
                })
                .collect(Collectors.toList());
            application.setSuites(suites);
        }

        return application;
    }

    private ApplicationPayloadDTO mapToPayloadDTO(Application application) {
        ApplicationPayloadDTO dto = new ApplicationPayloadDTO();
        dto.setAppId(application.getAppId());
        dto.setAppName(application.getAppName());
        dto.setAppDescription(application.getAppDescription());
        dto.setCustomData(application.getCustomData());

        if (application.getSuites() != null) {
            List<ApplicationPayloadDTO.SuiteDTO> suiteDTOs = application.getSuites().stream()
                .map(suite -> {
                    ApplicationPayloadDTO.SuiteDTO suiteDTO = new ApplicationPayloadDTO.SuiteDTO();
                    suiteDTO.setName(suite.getName());
                    suiteDTO.setDescription(suite.getDescription());
                    suiteDTO.setTags(suite.getTags());
                    suiteDTO.setStartTime(suite.getStartTime());
                    suiteDTO.setEndTime(suite.getEndTime());

                    if (suite.getTests() != null) {
                        Map<String, ApplicationPayloadDTO.TestDTO> testDTOs = suite.getTests().entrySet().stream()
                            .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                entry -> {
                                    Test test = entry.getValue();
                                    ApplicationPayloadDTO.TestDTO testDTO = new ApplicationPayloadDTO.TestDTO();
                                    testDTO.setName(test.getName());
                                    testDTO.setDescription(test.getDescription());
                                    testDTO.setTags(test.getTags());
                                    testDTO.setStartTime(test.getStartTime());
                                    testDTO.setEndTime(test.getEndTime());

                                    if (test.getLogs() != null) {
                                        List<ApplicationPayloadDTO.LogDTO> logDTOs = test.getLogs().stream()
                                            .map(log -> {
                                                ApplicationPayloadDTO.LogDTO logDTO = new ApplicationPayloadDTO.LogDTO();
                                                logDTO.setMessage(log.getMessage());
                                                logDTO.setStatus(log.getStatus());
                                                return logDTO;
                                            })
                                            .collect(Collectors.toList());
                                        testDTO.setLogs(logDTOs);
                                    }
                                    return testDTO;
                                }
                            ));
                        suiteDTO.setTests(testDTOs);
                    }
                    return suiteDTO;
                })
                .collect(Collectors.toList());
            dto.setSuites(suiteDTOs);
        }
        return dto;
    }
}
