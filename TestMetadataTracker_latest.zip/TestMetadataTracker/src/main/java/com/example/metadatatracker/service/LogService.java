package com.example.metadatatracker.service;

import com.example.metadatatracker.entity.Log;
import com.example.metadatatracker.repository.LogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class LogService {
    private final LogRepository logRepository;

    public LogService(LogRepository logRepository) {
        this.logRepository = logRepository;
    }

    @Transactional
    public Log saveLog(Log log) {
        return logRepository.save(log);
    }

    public List<Log> getLogsByTestId(Long testId) {
        return logRepository.findByTestId(testId);
    }
}
