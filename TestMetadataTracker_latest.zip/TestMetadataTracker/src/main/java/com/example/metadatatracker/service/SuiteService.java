package com.example.metadatatracker.service;

import com.example.metadatatracker.entity.Suite;
import com.example.metadatatracker.repository.SuiteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class SuiteService {
    private final SuiteRepository suiteRepository;

    public SuiteService(SuiteRepository suiteRepository) {
        this.suiteRepository = suiteRepository;
    }

    @Transactional
    public Suite saveSuite(Suite suite) {
        return suiteRepository.save(suite);
    }

    public List<Suite> getSuitesByApplicationId(Long applicationId) {
        return suiteRepository.findByApplicationId(applicationId);
    }
}
