package com.example.metadatatracker.service;

import com.example.metadatatracker.entity.Test;
import com.example.metadatatracker.repository.TestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class TestService {
    private final TestRepository testRepository;

    public TestService(TestRepository testRepository) {
        this.testRepository = testRepository;
    }

    @Transactional
    public Test saveTest(Test test) {
        return testRepository.save(test);
    }

    public List<Test> getTestsBySuiteId(Long suiteId) {
        return testRepository.findBySuiteId(suiteId);
    }
}
