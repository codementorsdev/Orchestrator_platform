import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Apps } from './pages/Apps';
import { TestCases } from './pages/TestCases';
import { Executions } from './pages/Executions';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/apps" element={<Apps />} />
          <Route path="/test-cases" element={<TestCases />} />
          <Route path="/executions" element={<Executions />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;