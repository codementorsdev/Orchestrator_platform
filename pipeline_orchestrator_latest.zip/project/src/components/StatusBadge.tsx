import React from 'react';
import { CheckCircle, XCircle, Clock, AlertCircle, Pause } from 'lucide-react';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const getStatusConfig = (status: string) => {
    switch (status.toLowerCase()) {
      case 'success':
      case 'passed':
        return {
          color: 'bg-green-100 text-green-800',
          icon: CheckCircle,
          iconColor: 'text-green-500'
        };
      case 'failed':
      case 'error':
        return {
          color: 'bg-red-100 text-red-800',
          icon: XCircle,
          iconColor: 'text-red-500'
        };
      case 'running':
      case 'pending':
        return {
          color: 'bg-blue-100 text-blue-800',
          icon: Clock,
          iconColor: 'text-blue-500'
        };
      case 'canceled':
      case 'cancelled':
        return {
          color: 'bg-gray-100 text-gray-800',
          icon: Pause,
          iconColor: 'text-gray-500'
        };
      default:
        return {
          color: 'bg-yellow-100 text-yellow-800',
          icon: AlertCircle,
          iconColor: 'text-yellow-500'
        };
    }
  };

  const config = getStatusConfig(status);
  const Icon = config.icon;
  
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-2 text-base'
  };

  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-4 w-4',
    lg: 'h-5 w-5'
  };

  return (
    <span className={`inline-flex items-center rounded-full font-medium ${config.color} ${sizeClasses[size]}`}>
      <Icon className={`mr-1 ${iconSizes[size]} ${config.iconColor}`} />
      {status}
    </span>
  );
};