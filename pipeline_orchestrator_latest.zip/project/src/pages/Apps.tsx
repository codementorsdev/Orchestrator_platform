import React, { useState, useEffect } from 'react';
import { Plus, Settings, Trash2, Edit, Eye, EyeOff } from 'lucide-react';
import { storageService } from '../services/storage';
import { gitlabService } from '../services/gitlab';
import type { App, GitlabProject } from '../types';

export const Apps: React.FC = () => {
  const [apps, setApps] = useState<App[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingApp, setEditingApp] = useState<App | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    accessToken: '',
    projectId: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [projectInfo, setProjectInfo] = useState<GitlabProject | null>(null);
  const [showTokens, setShowTokens] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setApps(storageService.getApps());
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // Validate GitLab connection
      await gitlabService.getProject(formData.accessToken, formData.projectId);

      const app: App = {
        id: editingApp?.id || crypto.randomUUID(),
        name: formData.name,
        accessToken: formData.accessToken,
        projectId: formData.projectId,
        createdAt: editingApp?.createdAt || new Date().toISOString(),
      };

      storageService.saveApp(app);
      setApps(storageService.getApps());
      setIsModalOpen(false);
      setEditingApp(null);
      setFormData({ name: '', accessToken: '', projectId: '' });
      setProjectInfo(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to validate GitLab connection');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = (app: App) => {
    setEditingApp(app);
    setFormData({
      name: app.name,
      accessToken: app.accessToken,
      projectId: app.projectId,
    });
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this app?')) {
      storageService.deleteApp(id);
      setApps(storageService.getApps());
    }
  };

  const validateConnection = async () => {
    if (!formData.accessToken || !formData.projectId) return;
    
    setIsLoading(true);
    setError('');
    
    try {
      const project = await gitlabService.getProject(formData.accessToken, formData.projectId);
      setProjectInfo(project);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to validate connection');
      setProjectInfo(null);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTokenVisibility = (appId: string) => {
    setShowTokens(prev => ({
      ...prev,
      [appId]: !prev[appId]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">GitLab Apps</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add App
        </button>
      </div>

      {apps.length === 0 ? (
        <div className="text-center py-12">
          <Settings className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No apps configured</h3>
          <p className="mt-1 text-sm text-gray-500">
            Get started by adding your first GitLab app configuration.
          </p>
          <div className="mt-6">
            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add App
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {apps.map((app) => (
            <div key={app.id} className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Settings className="h-8 w-8 text-gray-400" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        {app.name}
                      </dt>
                      <dd className="text-sm text-gray-900">
                        Project ID: {app.projectId}
                      </dd>
                    </dl>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Access Token:</span>
                    <button
                      onClick={() => toggleTokenVisibility(app.id)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      {showTokens[app.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <p className="text-sm text-gray-900 font-mono mt-1">
                    {showTokens[app.id] ? app.accessToken : '•'.repeat(20)}
                  </p>
                </div>
                <div className="mt-4 flex justify-end space-x-2">
                  <button
                    onClick={() => handleEdit(app)}
                    className="text-indigo-600 hover:text-indigo-900 text-sm font-medium"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(app.id)}
                    className="text-red-600 hover:text-red-900 text-sm font-medium"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <div className="bg-gray-50 px-5 py-3">
                <div className="text-sm">
                  <span className="text-gray-500">Created: </span>
                  <span className="text-gray-900">
                    {new Date(app.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {editingApp ? 'Edit App' : 'Add New App'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    App Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                    placeholder="My GitLab App"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Access Token
                  </label>
                  <input
                    type="password"
                    required
                    value={formData.accessToken}
                    onChange={(e) => setFormData({ ...formData, accessToken: e.target.value })}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                    placeholder="glpat-xxxxxxxxxxxxxxxxxxxx"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Project ID
                  </label>
                  <div className="mt-1 flex rounded-md shadow-sm">
                    <input
                      type="text"
                      required
                      value={formData.projectId}
                      onChange={(e) => setFormData({ ...formData, projectId: e.target.value })}
                      className="flex-1 block w-full border-gray-300 rounded-l-md focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      placeholder="12345678"
                    />
                    <button
                      type="button"
                      onClick={validateConnection}
                      disabled={isLoading || !formData.accessToken || !formData.projectId}
                      className="inline-flex items-center px-3 py-2 border border-l-0 border-gray-300 rounded-r-md bg-gray-50 text-gray-500 text-sm hover:bg-gray-100 disabled:opacity-50"
                    >
                      Validate
                    </button>
                  </div>
                </div>

                {error && (
                  <div className="text-red-600 text-sm">{error}</div>
                )}

                {projectInfo && (
                  <div className="bg-green-50 border border-green-200 rounded-md p-3">
                    <div className="text-sm text-green-800">
                      <strong>✓ Connected to:</strong> {projectInfo.path_with_namespace}
                    </div>
                  </div>
                )}

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setIsModalOpen(false);
                      setEditingApp(null);
                      setFormData({ name: '', accessToken: '', projectId: '' });
                      setError('');
                      setProjectInfo(null);
                    }}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="px-4 py-2 text-sm font-medium text-white bg-orange-600 border border-transparent rounded-md hover:bg-orange-700 disabled:opacity-50"
                  >
                    {isLoading ? 'Saving...' : editingApp ? 'Update' : 'Save'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};