import React, { useState, useEffect } from 'react';
import { BarChart3, GitBranch, Play, Settings, TrendingUp, Activity, Calendar, Clock, Target, Zap } from 'lucide-react';
import { storageService } from '../services/storage';
import { StatusBadge } from '../components/StatusBadge';
import type { App, TestCase, PipelineExecution } from '../types';

export const Dashboard: React.FC = () => {
  const [apps, setApps] = useState<App[]>([]);
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [executions, setExecutions] = useState<PipelineExecution[]>([]);

  useEffect(() => {
    setApps(storageService.getApps());
    setTestCases(storageService.getTestCases());
    setExecutions(storageService.getExecutions());
  }, []);

  const recentExecutions = executions
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
    .slice(0, 5);

  const executionStats = {
    total: executions.length,
    success: executions.filter(e => e.status === 'success').length,
    failed: executions.filter(e => e.status === 'failed').length,
    running: executions.filter(e => e.status === 'running').length,
  };

  const successRate = executionStats.total > 0 
    ? Math.round((executionStats.success / executionStats.total) * 100)
    : 0;

  // Calculate trend data for the last 7 days
  const getTrendData = () => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return date.toISOString().split('T')[0];
    });

    return last7Days.map(date => {
      const dayExecutions = executions.filter(e => 
        e.startedAt.split('T')[0] === date
      );
      return {
        date,
        total: dayExecutions.length,
        success: dayExecutions.filter(e => e.status === 'success').length,
        failed: dayExecutions.filter(e => e.status === 'failed').length,
        successRate: dayExecutions.length > 0 
          ? Math.round((dayExecutions.filter(e => e.status === 'success').length / dayExecutions.length) * 100)
          : 0
      };
    });
  };

  // Calculate execution time statistics
  const getExecutionTimeStats = () => {
    const completedExecutions = executions.filter(e => e.completedAt);
    const executionTimes = completedExecutions.map(e => {
      const start = new Date(e.startedAt).getTime();
      const end = new Date(e.completedAt!).getTime();
      return Math.round((end - start) / 1000 / 60); // in minutes
    });

    const avgTime = executionTimes.length > 0 
      ? Math.round(executionTimes.reduce((a, b) => a + b, 0) / executionTimes.length)
      : 0;

    const maxTime = executionTimes.length > 0 ? Math.max(...executionTimes) : 0;
    const minTime = executionTimes.length > 0 ? Math.min(...executionTimes) : 0;

    return { avgTime, maxTime, minTime, totalCompleted: completedExecutions.length };
  };

  // Get app usage statistics
  const getAppUsageStats = () => {
    const appUsage = new Map<string, number>();
    
    executions.forEach(execution => {
      execution.pipelines.forEach(pipeline => {
        const count = appUsage.get(pipeline.appId) || 0;
        appUsage.set(pipeline.appId, count + 1);
      });
    });

    return Array.from(appUsage.entries())
      .map(([appId, count]) => {
        const app = apps.find(a => a.id === appId);
        return { appName: app?.name || 'Unknown', count };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  };

  const trendData = getTrendData();
  const timeStats = getExecutionTimeStats();
  const appUsageStats = getAppUsageStats();

  const stats = [
    {
      name: 'Total Apps',
      value: apps.length,
      icon: Settings,
      color: 'text-blue-600',
      bg: 'bg-blue-100',
      change: '+12%',
      changeType: 'positive'
    },
    {
      name: 'Test Cases',
      value: testCases.length,
      icon: GitBranch,
      color: 'text-green-600',
      bg: 'bg-green-100',
      change: '+8%',
      changeType: 'positive'
    },
    {
      name: 'Total Executions',
      value: executionStats.total,
      icon: Play,
      color: 'text-purple-600',
      bg: 'bg-purple-100',
      change: `+${executionStats.total > 0 ? Math.round((executionStats.total / 30) * 100) : 0}%`,
      changeType: 'positive'
    },
    {
      name: 'Success Rate',
      value: `${successRate}%`,
      icon: TrendingUp,
      color: 'text-orange-600',
      bg: 'bg-orange-100',
      change: successRate > 80 ? '+5%' : '-2%',
      changeType: successRate > 80 ? 'positive' : 'negative'
    }
  ];

  const maxTrendValue = Math.max(...trendData.map(d => d.total), 1);
  const maxUsageValue = Math.max(...appUsageStats.map(d => d.count), 1);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="flex items-center text-sm text-gray-500">
          <Activity className="h-4 w-4 mr-1" />
          Live GitLab Data
        </div>
      </div>

      {/* Enhanced Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white overflow-hidden shadow rounded-lg hover:shadow-md transition-shadow">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className={`p-3 rounded-md ${stat.bg}`}>
                      <Icon className={`h-6 w-6 ${stat.color}`} />
                    </div>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        {stat.name}
                      </dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {stat.value}
                        </div>
                        <div className={`ml-2 flex items-baseline text-sm font-semibold ${
                          stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {stat.change}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Execution Trend Chart */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">7-Day Execution Trend</h3>
            <Calendar className="h-5 w-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {trendData.map((day, index) => (
              <div key={day.date} className="flex items-center space-x-3">
                <div className="w-16 text-xs text-gray-500">
                  {new Date(day.date).toLocaleDateString('en-US', { weekday: 'short' })}
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${(day.total / maxTrendValue) * 100}%` }}
                      ></div>
                    </div>
                    <div className="w-8 text-xs text-gray-600">{day.total}</div>
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <div className="flex-1 bg-gray-100 rounded-full h-1">
                      <div 
                        className="bg-green-500 h-1 rounded-full"
                        style={{ width: `${day.total > 0 ? (day.success / day.total) * 100 : 0}%` }}
                      ></div>
                    </div>
                    <div className="w-8 text-xs text-green-600">{day.successRate}%</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Success Rate Gauge */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Success Rate Gauge</h3>
            <Target className="h-5 w-5 text-gray-400" />
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-32 h-32">
              <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-gray-300"
                  stroke="currentColor"
                  strokeWidth="3"
                  fill="transparent"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className={successRate >= 80 ? "text-green-500" : successRate >= 60 ? "text-yellow-500" : "text-red-500"}
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  fill="transparent"
                  strokeDasharray={`${successRate}, 100`}
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">{successRate}%</div>
                  <div className="text-xs text-gray-500">Success</div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-semibold text-green-600">{executionStats.success}</div>
              <div className="text-xs text-gray-500">Success</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-red-600">{executionStats.failed}</div>
              <div className="text-xs text-gray-500">Failed</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-blue-600">{executionStats.running}</div>
              <div className="text-xs text-gray-500">Running</div>
            </div>
          </div>
        </div>
      </div>

      {/* Performance Metrics Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Execution Time Analytics */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Execution Time Analytics</h3>
            <Clock className="h-5 w-5 text-gray-400" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{timeStats.avgTime}m</div>
              <div className="text-sm text-gray-600">Average Time</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{timeStats.minTime}m</div>
              <div className="text-sm text-gray-600">Fastest Time</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{timeStats.maxTime}m</div>
              <div className="text-sm text-gray-600">Slowest Time</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{timeStats.totalCompleted}</div>
              <div className="text-sm text-gray-600">Completed</div>
            </div>
          </div>
        </div>

        {/* App Usage Chart */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Most Used Apps</h3>
            <Zap className="h-5 w-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {appUsageStats.length > 0 ? appUsageStats.map((app, index) => (
              <div key={app.appName} className="flex items-center space-x-3">
                <div className="w-4 text-sm font-medium text-gray-500">#{index + 1}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-900">{app.appName}</span>
                    <span className="text-sm text-gray-600">{app.count} runs</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(app.count / maxUsageValue) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            )) : (
              <div className="text-center py-4 text-gray-500">
                No app usage data available
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Executions */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Recent Executions
          </h3>
          {recentExecutions.length === 0 ? (
            <div className="text-center py-8">
              <Play className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No executions yet</h3>
              <p className="mt-1 text-sm text-gray-500">
                Create a test case and run it to see execution history.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentExecutions.map((execution) => {
                const testCase = testCases.find(tc => tc.id === execution.testCaseId);
                const duration = execution.completedAt 
                  ? Math.round((new Date(execution.completedAt).getTime() - new Date(execution.startedAt).getTime()) / 1000 / 60)
                  : null;
                
                return (
                  <div key={execution.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <h4 className="text-sm font-medium text-gray-900">
                          {testCase?.name || 'Unknown Test Case'}
                        </h4>
                        <StatusBadge status={execution.status} size="sm" />
                        {duration && (
                          <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                            {duration}m
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        Started: {new Date(execution.startedAt).toLocaleString()}
                      </p>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="text-xs text-gray-400">
                          {execution.pipelines.length} pipeline(s)
                        </span>
                        <span className="text-xs text-gray-400">•</span>
                        <span className="text-xs text-gray-400">
                          {execution.pipelines.filter(p => p.status === 'success').length} successful
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      <div className="flex space-x-1">
                        {execution.pipelines.slice(0, 3).map((pipeline, index) => (
                          <div key={index} className={`w-2 h-2 rounded-full ${
                            pipeline.status === 'success' ? 'bg-green-500' :
                            pipeline.status === 'failed' ? 'bg-red-500' :
                            pipeline.status === 'running' ? 'bg-blue-500' :
                            'bg-gray-300'
                          }`}></div>
                        ))}
                        {execution.pipelines.length > 3 && (
                          <span className="text-xs text-gray-400">+{execution.pipelines.length - 3}</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <a
            href="/apps"
            className="block w-full text-left px-4 py-3 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors group"
          >
            <div className="flex items-center">
              <Settings className="h-5 w-5 text-gray-400 mr-3 group-hover:text-blue-500" />
              <span className="text-sm font-medium text-gray-900">Manage Apps</span>
            </div>
          </a>
          <a
            href="/test-cases"
            className="block w-full text-left px-4 py-3 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors group"
          >
            <div className="flex items-center">
              <GitBranch className="h-5 w-5 text-gray-400 mr-3 group-hover:text-green-500" />
              <span className="text-sm font-medium text-gray-900">Create Test Case</span>
            </div>
          </a>
          <a
            href="/executions"
            className="block w-full text-left px-4 py-3 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors group"
          >
            <div className="flex items-center">
              <Play className="h-5 w-5 text-gray-400 mr-3 group-hover:text-purple-500" />
              <span className="text-sm font-medium text-gray-900">View Executions</span>
            </div>
          </a>
        </div>
      </div>
    </div>
  );
};