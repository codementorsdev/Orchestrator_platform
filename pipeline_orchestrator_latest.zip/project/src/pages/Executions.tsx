import React, { useState, useEffect } from 'react';
import { Play, Download, RefreshCw, Clock, ExternalLink, CheckCircle, XCircle, Loader } from 'lucide-react';
import { storageService } from '../services/storage';
import { gitlabService } from '../services/gitlab';
import { StatusBadge } from '../components/StatusBadge';
import type { App, TestCase, PipelineExecution } from '../types';

export const Executions: React.FC = () => {
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [apps, setApps] = useState<App[]>([]);
  const [executions, setExecutions] = useState<PipelineExecution[]>([]);
  const [runningExecutions, setRunningExecutions] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setTestCases(storageService.getTestCases());
    setApps(storageService.getApps());
    setExecutions(storageService.getExecutions());
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      updateRunningExecutions();
    }, 5000); // Check every 5 seconds for more responsive updates

    return () => clearInterval(interval);
  }, [runningExecutions]);

  const updateRunningExecutions = async () => {
    const currentExecutions = storageService.getExecutions();
    const running = currentExecutions.filter(e => e.status === 'running');
    
    for (const execution of running) {
      try {
        let allCompleted = true;
        let hasFailure = false;
        const updatedPipelines = [];

        for (const pipeline of execution.pipelines) {
          if (pipeline.pipelineId) {
            const app = apps.find(a => a.id === pipeline.appId);
            if (app) {
              const updatedPipeline = await gitlabService.getPipeline(
                app.accessToken,
                app.projectId,
                pipeline.pipelineId
              );
              
              updatedPipelines.push({
                ...pipeline,
                status: updatedPipeline.status,
              });

              if (!['success', 'failed', 'canceled'].includes(updatedPipeline.status)) {
                allCompleted = false;
              }
              
              if (['failed', 'canceled'].includes(updatedPipeline.status)) {
                hasFailure = true;
              }
            }
          } else {
            updatedPipelines.push(pipeline);
            if (!['success', 'failed', 'canceled'].includes(pipeline.status)) {
              allCompleted = false;
            }
          }
        }

        const updatedExecution: PipelineExecution = {
          ...execution,
          pipelines: updatedPipelines,
          status: allCompleted 
            ? (hasFailure ? 'failed' : 'success')
            : 'running',
          completedAt: allCompleted ? new Date().toISOString() : undefined,
        };

        storageService.saveExecution(updatedExecution);
      } catch (error) {
        console.error('Failed to update execution:', error);
      }
    }

    setExecutions(storageService.getExecutions());
  };

  const runTestCase = async (testCase: TestCase) => {
    setIsLoading(true);
    const executionId = crypto.randomUUID();
    setRunningExecutions(prev => new Set(prev).add(executionId));

    try {
      const execution: PipelineExecution = {
        id: executionId,
        testCaseId: testCase.id,
        status: 'running',
        startedAt: new Date().toISOString(),
        pipelines: testCase.apps.map(appConfig => ({
          appId: appConfig.appId,
          status: 'pending',
        })),
      };

      storageService.saveExecution(execution);
      setExecutions(storageService.getExecutions());

      // Execute pipelines sequentially
      for (let i = 0; i < testCase.apps.length; i++) {
        const appConfig = testCase.apps[i];
        const app = apps.find(a => a.id === appConfig.appId);
        
        if (app) {
          try {
            // Update status to running for current pipeline
            execution.pipelines[i].status = 'running';
            storageService.saveExecution(execution);
            setExecutions(storageService.getExecutions());

            // Trigger the pipeline
            const pipeline = await gitlabService.triggerPipeline(
              app.accessToken,
              app.projectId,
              appConfig.branch,
              appConfig.environmentVariables
            );

            execution.pipelines[i] = {
              ...execution.pipelines[i],
              pipelineId: pipeline.id,
              status: pipeline.status,
              webUrl: pipeline.web_url,
            };

            storageService.saveExecution(execution);
            setExecutions(storageService.getExecutions());

            // Wait for pipeline to complete before moving to next
            let pipelineCompleted = false;
            let attempts = 0;
            const maxAttempts = 120; // 10 minutes max wait time

            while (!pipelineCompleted && attempts < maxAttempts) {
              await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5 seconds
              
              try {
                const updatedPipeline = await gitlabService.getPipeline(
                  app.accessToken,
                  app.projectId,
                  pipeline.id
                );

                execution.pipelines[i].status = updatedPipeline.status;
                storageService.saveExecution(execution);
                setExecutions(storageService.getExecutions());

                if (['success', 'failed', 'canceled'].includes(updatedPipeline.status)) {
                  pipelineCompleted = true;
                  
                  // If pipeline failed, stop execution of remaining pipelines
                  if (['failed', 'canceled'].includes(updatedPipeline.status)) {
                    // Mark remaining pipelines as canceled
                    for (let j = i + 1; j < execution.pipelines.length; j++) {
                      execution.pipelines[j].status = 'canceled';
                    }
                    execution.status = 'failed';
                    execution.completedAt = new Date().toISOString();
                    storageService.saveExecution(execution);
                    setExecutions(storageService.getExecutions());
                    return; // Exit the function early
                  }
                }
              } catch (error) {
                console.error('Failed to check pipeline status:', error);
              }
              
              attempts++;
            }

            // If pipeline didn't complete within time limit, mark as timeout
            if (!pipelineCompleted) {
              execution.pipelines[i].status = 'failed';
              execution.status = 'failed';
              execution.completedAt = new Date().toISOString();
              storageService.saveExecution(execution);
              setExecutions(storageService.getExecutions());
              return;
            }

          } catch (error) {
            console.error('Failed to trigger pipeline:', error);
            execution.pipelines[i].status = 'failed';
            execution.status = 'failed';
            execution.completedAt = new Date().toISOString();
            storageService.saveExecution(execution);
            setExecutions(storageService.getExecutions());
            return; // Stop execution on error
          }
        }
      }

      // All pipelines completed successfully
      execution.status = 'success';
      execution.completedAt = new Date().toISOString();
      storageService.saveExecution(execution);
      setExecutions(storageService.getExecutions());

    } catch (error) {
      console.error('Failed to run test case:', error);
    } finally {
      setIsLoading(false);
      setRunningExecutions(prev => {
        const newSet = new Set(prev);
        newSet.delete(executionId);
        return newSet;
      });
    }
  };

  const downloadArtifacts = async (execution: PipelineExecution) => {
    for (const pipeline of execution.pipelines) {
      if (pipeline.pipelineId) {
        const app = apps.find(a => a.id === pipeline.appId);
        if (app) {
          try {
            const artifacts = await gitlabService.getArtifacts(
              app.accessToken,
              app.projectId,
              pipeline.pipelineId
            );
            
            // Open download links in new tabs
            artifacts.forEach(artifact => {
              window.open(`${artifact.downloadUrl}?private_token=${app.accessToken}`, '_blank');
            });
          } catch (error) {
            console.error('Failed to download artifacts:', error);
          }
        }
      }
    }
  };

  const getStageIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'failed':
      case 'canceled':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'running':
        return <Loader className="h-5 w-5 text-blue-500 animate-spin" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-gray-400" />;
      default:
        return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Pipeline Executions</h1>
        <button
          onClick={() => window.location.reload()}
          className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </button>
      </div>

      {/* Test Cases - Play Section */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Available Test Cases
          </h3>
          {testCases.length === 0 ? (
            <div className="text-center py-8">
              <Play className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No test cases available</h3>
              <p className="mt-1 text-sm text-gray-500">
                Create a test case first to start running pipelines.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {testCases.map((testCase) => (
                <div key={testCase.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-gray-900">{testCase.name}</h4>
                    <p className="text-sm text-gray-500 mt-1">
                      {testCase.apps.length} app(s) configured - Sequential execution
                    </p>
                    <div className="flex items-center space-x-4 mt-2">
                      {testCase.apps.map((appConfig, index) => {
                        const app = apps.find(a => a.id === appConfig.appId);
                        return (
                          <span key={index} className="text-xs text-gray-400">
                            #{index + 1}: {app?.name} ({appConfig.branch})
                          </span>
                        );
                      })}
                    </div>
                  </div>
                  <button
                    onClick={() => runTestCase(testCase)}
                    disabled={isLoading}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 disabled:opacity-50"
                  >
                    <Play className="h-4 w-4 mr-2" />
                    Run
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Execution History */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Execution History
          </h3>
          {executions.length === 0 ? (
            <div className="text-center py-8">
              <Clock className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No executions yet</h3>
              <p className="mt-1 text-sm text-gray-500">
                Run a test case to see execution history here.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {executions
                .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
                .map((execution) => {
                  const testCase = testCases.find(tc => tc.id === execution.testCaseId);
                  return (
                    <div key={execution.id} className="border rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="text-lg font-medium text-gray-900">
                            {testCase?.name || 'Unknown Test Case'}
                          </h4>
                          <p className="text-sm text-gray-500">
                            Started: {new Date(execution.startedAt).toLocaleString()}
                            {execution.completedAt && (
                              <span className="ml-2">
                                • Completed: {new Date(execution.completedAt).toLocaleString()}
                              </span>
                            )}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <StatusBadge status={execution.status} />
                          {execution.status === 'success' && (
                            <button
                              onClick={() => downloadArtifacts(execution)}
                              className="inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded text-blue-700 bg-blue-100 hover:bg-blue-200"
                            >
                              <Download className="h-3 w-3 mr-1" />
                              Artifacts
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Sequential Pipeline Status with Visual Flow */}
                      <div className="space-y-4">
                        <h5 className="text-sm font-medium text-gray-700">Pipeline Execution Flow:</h5>
                        <div className="flex items-center space-x-2 overflow-x-auto pb-2">
                          {execution.pipelines.map((pipeline, index) => {
                            const app = apps.find(a => a.id === pipeline.appId);
                            const appConfig = testCase?.apps.find(ac => ac.appId === pipeline.appId);
                            return (
                              <React.Fragment key={index}>
                                <div className="flex-shrink-0 bg-white border-2 border-gray-200 rounded-lg p-3 min-w-[200px]">
                                  <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center space-x-2">
                                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        #{index + 1}
                                      </span>
                                      {getStageIcon(pipeline.status)}
                                    </div>
                                    {pipeline.webUrl && (
                                      <a
                                        href={pipeline.webUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-blue-600 hover:text-blue-800"
                                      >
                                        <ExternalLink className="h-4 w-4" />
                                      </a>
                                    )}
                                  </div>
                                  <div className="text-sm">
                                    <div className="font-medium text-gray-900">
                                      {app?.name || 'Unknown App'}
                                    </div>
                                    <div className="text-gray-500">
                                      {appConfig?.branch || 'unknown branch'}
                                    </div>
                                    <div className="mt-1">
                                      <StatusBadge status={pipeline.status} size="sm" />
                                    </div>
                                  </div>
                                </div>
                                {index < execution.pipelines.length - 1 && (
                                  <div className="flex-shrink-0 text-gray-400">
                                    →
                                  </div>
                                )}
                              </React.Fragment>
                            );
                          })}
                        </div>
                      </div>

                      {/* Environment Variables Summary */}
                      {testCase && testCase.apps.some(app => Object.keys(app.environmentVariables).length > 0) && (
                        <div className="mt-4 pt-4 border-t">
                          <h5 className="text-sm font-medium text-gray-700 mb-2">Environment Variables:</h5>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            {testCase.apps.map((appConfig, index) => {
                              const app = apps.find(a => a.id === appConfig.appId);
                              if (Object.keys(appConfig.environmentVariables).length === 0) return null;
                              return (
                                <div key={index} className="text-xs bg-gray-50 p-2 rounded">
                                  <div className="font-medium">{app?.name}:</div>
                                  <div className="text-gray-600">
                                    {Object.entries(appConfig.environmentVariables).map(([key, value]) => (
                                      <div key={key}>{key}={value}</div>
                                    ))}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};