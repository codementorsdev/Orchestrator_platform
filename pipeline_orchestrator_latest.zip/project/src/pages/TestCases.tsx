import React, { useState, useEffect } from 'react';
import { Plus, GitBranch, Trash2, Edit, Save, X } from 'lucide-react';
import { storageService } from '../services/storage';
import { gitlabService } from '../services/gitlab';
import type { App, TestCase, GitlabBranch } from '../types';

export const TestCases: React.FC = () => {
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [apps, setApps] = useState<App[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTestCase, setEditingTestCase] = useState<TestCase | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    apps: [] as { appId: string; branch: string; environmentVariables: Record<string, string> }[],
  });
  const [currentAppConfig, setCurrentAppConfig] = useState({
    appId: '',
    branch: '',
    environmentVariables: '',
  });
  const [branches, setBranches] = useState<Record<string, GitlabBranch[]>>({});
  const [loadingBranches, setLoadingBranches] = useState<Record<string, boolean>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    setTestCases(storageService.getTestCases());
    setApps(storageService.getApps());
  }, []);

  const loadBranches = async (appId: string) => {
    const app = apps.find(a => a.id === appId);
    if (!app) return;

    setLoadingBranches(prev => ({ ...prev, [appId]: true }));
    try {
      const branchList = await gitlabService.getBranches(app.accessToken, app.projectId);
      setBranches(prev => ({ ...prev, [appId]: branchList }));
    } catch (err) {
      console.error('Failed to load branches:', err);
      setError(`Failed to load branches for ${app.name}: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setLoadingBranches(prev => ({ ...prev, [appId]: false }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      if (formData.apps.length === 0) {
        throw new Error('Please add at least one app configuration to the test case');
      }

      const testCase: TestCase = {
        id: editingTestCase?.id || crypto.randomUUID(),
        name: formData.name,
        apps: formData.apps,
        createdAt: editingTestCase?.createdAt || new Date().toISOString(),
      };

      storageService.saveTestCase(testCase);
      setTestCases(storageService.getTestCases());
      setIsModalOpen(false);
      setEditingTestCase(null);
      setFormData({ name: '', apps: [] });
      setCurrentAppConfig({ appId: '', branch: '', environmentVariables: '' });
      setBranches({});
      setLoadingBranches({});
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save test case');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = (testCase: TestCase) => {
    setEditingTestCase(testCase);
    setFormData({
      name: testCase.name,
      apps: testCase.apps,
    });
    setIsModalOpen(true);
    
    // Load branches for all apps in the test case
    testCase.apps.forEach(appConfig => {
      if (!branches[appConfig.appId]) {
        loadBranches(appConfig.appId);
      }
    });
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this test case?')) {
      storageService.deleteTestCase(id);
      setTestCases(storageService.getTestCases());
    }
  };

  const addAppToTestCase = () => {
    if (!currentAppConfig.appId || !currentAppConfig.branch) {
      setError('Please select both an app and a branch');
      return;
    }

    // Check if this app is already in the test case
    const existingApp = formData.apps.find(app => app.appId === currentAppConfig.appId);
    if (existingApp) {
      setError('This app is already added to the test case');
      return;
    }

    const envVars: Record<string, string> = {};
    if (currentAppConfig.environmentVariables) {
      currentAppConfig.environmentVariables.split(',').forEach(pair => {
        const [key, value] = pair.split('=').map(s => s.trim());
        if (key && value) {
          envVars[key] = value;
        }
      });
    }

    const newAppConfig = {
      appId: currentAppConfig.appId,
      branch: currentAppConfig.branch,
      environmentVariables: envVars,
    };

    setFormData(prev => ({
      ...prev,
      apps: [...prev.apps, newAppConfig],
    }));

    setCurrentAppConfig({ appId: '', branch: '', environmentVariables: '' });
    setError('');
  };

  const removeAppFromTestCase = (index: number) => {
    setFormData(prev => ({
      ...prev,
      apps: prev.apps.filter((_, i) => i !== index),
    }));
  };

  const handleAppSelection = (appId: string) => {
    setCurrentAppConfig({ ...currentAppConfig, appId, branch: '' });
    if (appId && !branches[appId]) {
      loadBranches(appId);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Test Cases</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Test Case
        </button>
      </div>

      {testCases.length === 0 ? (
        <div className="text-center py-12">
          <GitBranch className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No test cases</h3>
          <p className="mt-1 text-sm text-gray-500">
            Create your first test case to start running pipeline tests.
          </p>
          <div className="mt-6">
            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Test Case
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {testCases.map((testCase) => (
            <div key={testCase.id} className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <GitBranch className="h-8 w-8 text-gray-400 mr-4" />
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">{testCase.name}</h3>
                      <p className="text-sm text-gray-500">
                        Created: {new Date(testCase.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit(testCase)}
                      className="text-indigo-600 hover:text-indigo-900"
                    >
                      <Edit className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(testCase.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">
                    Configured Apps ({testCase.apps.length})
                  </h4>
                  <div className="space-y-2">
                    {testCase.apps.map((appConfig, index) => {
                      const app = apps.find(a => a.id === appConfig.appId);
                      return (
                        <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2">
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                #{index + 1}
                              </span>
                              <span className="text-sm font-medium text-gray-900">
                                {app?.name || 'Unknown App'}
                              </span>
                              <span className="text-sm text-gray-500">•</span>
                              <span className="text-sm text-gray-600">
                                Branch: {appConfig.branch}
                              </span>
                            </div>
                            {Object.keys(appConfig.environmentVariables).length > 0 && (
                              <div className="mt-1 text-xs text-gray-500">
                                Env vars: {Object.keys(appConfig.environmentVariables).join(', ')}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {editingTestCase ? 'Edit Test Case' : 'Add New Test Case'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Test Case Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                    placeholder="My Test Case"
                  />
                </div>

                {/* Add App Configuration */}
                <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                  <h4 className="text-sm font-medium text-gray-900 mb-3">Add App Configuration</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Select App
                      </label>
                      <select
                        value={currentAppConfig.appId}
                        onChange={(e) => handleAppSelection(e.target.value)}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      >
                        <option value="">Select an app...</option>
                        {apps.map((app) => (
                          <option key={app.id} value={app.id}>
                            {app.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Select Branch
                      </label>
                      <select
                        value={currentAppConfig.branch}
                        onChange={(e) => setCurrentAppConfig({ ...currentAppConfig, branch: e.target.value })}
                        disabled={!currentAppConfig.appId || loadingBranches[currentAppConfig.appId]}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm disabled:bg-gray-100"
                      >
                        <option value="">
                          {loadingBranches[currentAppConfig.appId] 
                            ? 'Loading branches...' 
                            : currentAppConfig.appId 
                              ? 'Select a branch...' 
                              : 'Select an app first'
                          }
                        </option>
                        {branches[currentAppConfig.appId]?.map((branch) => (
                          <option key={branch.name} value={branch.name}>
                            {branch.name} {branch.default ? '(default)' : ''}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700">
                      Environment Variables (comma-separated: KEY1=value1, KEY2=value2)
                    </label>
                    <textarea
                      value={currentAppConfig.environmentVariables}
                      onChange={(e) => setCurrentAppConfig({ ...currentAppConfig, environmentVariables: e.target.value })}
                      rows={3}
                      className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-orange-500 focus:border-orange-500 sm:text-sm"
                      placeholder="NODE_ENV=production, DEBUG=true"
                    />
                  </div>

                  <div className="mt-4">
                    <button
                      type="button"
                      onClick={addAppToTestCase}
                      disabled={!currentAppConfig.appId || !currentAppConfig.branch}
                      className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-green-600 hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add to Test Case
                    </button>
                  </div>
                </div>

                {/* Configured Apps List */}
                {formData.apps.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 mb-3">
                      Configured Apps ({formData.apps.length}) - Execution Order
                    </h4>
                    <div className="space-y-2">
                      {formData.apps.map((appConfig, index) => {
                        const app = apps.find(a => a.id === appConfig.appId);
                        return (
                          <div key={index} className="flex items-center justify-between bg-white border p-3 rounded-md">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2">
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                  #{index + 1}
                                </span>
                                <span className="text-sm font-medium text-gray-900">
                                  {app?.name || 'Unknown App'}
                                </span>
                                <span className="text-sm text-gray-500">•</span>
                                <span className="text-sm text-gray-600">
                                  Branch: {appConfig.branch}
                                </span>
                              </div>
                              {Object.keys(appConfig.environmentVariables).length > 0 && (
                                <div className="mt-1 text-xs text-gray-500">
                                  Env vars: {Object.keys(appConfig.environmentVariables).join(', ')}
                                </div>
                              )}
                            </div>
                            <button
                              type="button"
                              onClick={() => removeAppFromTestCase(index)}
                              className="text-red-600 hover:text-red-900"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                    <div className="mt-2 text-xs text-gray-500">
                      Apps will execute in the order shown above (sequentially)
                    </div>
                  </div>
                )}

                {error && (
                  <div className="text-red-600 text-sm bg-red-50 border border-red-200 rounded-md p-3">
                    {error}
                  </div>
                )}

                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setIsModalOpen(false);
                      setEditingTestCase(null);
                      setFormData({ name: '', apps: [] });
                      setCurrentAppConfig({ appId: '', branch: '', environmentVariables: '' });
                      setError('');
                      setBranches({});
                      setLoadingBranches({});
                    }}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading || formData.apps.length === 0}
                    className="px-4 py-2 text-sm font-medium text-white bg-orange-600 border border-transparent rounded-md hover:bg-orange-700 disabled:opacity-50"
                  >
                    {isLoading ? 'Saving...' : editingTestCase ? 'Update' : 'Save'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};