import type { GitlabProject, GitlabBranch, GitlabPipeline } from '../types';

class GitlabService {
  private async makeRequest(url: string, accessToken: string, options: RequestInit = {}) {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`GitLab API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async getProject(accessToken: string, projectId: string): Promise<GitlabProject> {
    const url = `https://gitlab.com/api/v4/projects/${projectId}`;
    return this.makeRequest(url, accessToken);
  }

  async getBranches(accessToken: string, projectId: string): Promise<GitlabBranch[]> {
    const url = `https://gitlab.com/api/v4/projects/${projectId}/repository/branches`;
    return this.makeRequest(url, accessToken);
  }

  async getPipelines(accessToken: string, projectId: string): Promise<GitlabPipeline[]> {
    const url = `https://gitlab.com/api/v4/projects/${projectId}/pipelines?per_page=20`;
    return this.makeRequest(url, accessToken);
  }

  async getPipeline(accessToken: string, projectId: string, pipelineId: number): Promise<GitlabPipeline> {
    const url = `https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}`;
    return this.makeRequest(url, accessToken);
  }

  async triggerPipeline(
    accessToken: string,
    projectId: string,
    branch: string,
    variables: Record<string, string> = {}
  ): Promise<GitlabPipeline> {
    const url = `https://gitlab.com/api/v4/projects/${projectId}/pipeline`;
    
    const variablesArray = Object.entries(variables).map(([key, value]) => ({
      key,
      value,
      variable_type: 'env_var'
    }));

    return this.makeRequest(url, accessToken, {
      method: 'POST',
      body: JSON.stringify({
        ref: branch,
        variables: variablesArray,
      }),
    });
  }

  async getArtifacts(accessToken: string, projectId: string, pipelineId: number) {
    const url = `https://gitlab.com/api/v4/projects/${projectId}/pipelines/${pipelineId}/jobs`;
    const jobs = await this.makeRequest(url, accessToken);
    
    const artifacts = [];
    for (const job of jobs) {
      if (job.artifacts && job.artifacts.length > 0) {
        const artifactUrl = `https://gitlab.com/api/v4/projects/${projectId}/jobs/${job.id}/artifacts`;
        artifacts.push({
          jobName: job.name,
          downloadUrl: artifactUrl,
          size: job.artifacts.reduce((total: number, artifact: any) => total + (artifact.size || 0), 0),
        });
      }
    }
    
    return artifacts;
  }
}

export const gitlabService = new GitlabService();