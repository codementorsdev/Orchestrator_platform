import type { App, TestCase, PipelineExecution } from '../types';

class StorageService {
  private getItem<T>(key: string): T[] {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : [];
  }

  private setItem<T>(key: string, data: T[]): void {
    localStorage.setItem(key, JSON.stringify(data));
  }

  // Apps
  getApps(): App[] {
    return this.getItem<App>('gitlab-apps');
  }

  saveApp(app: App): void {
    const apps = this.getApps();
    const existingIndex = apps.findIndex(a => a.id === app.id);
    
    if (existingIndex >= 0) {
      apps[existingIndex] = app;
    } else {
      apps.push(app);
    }
    
    this.setItem('gitlab-apps', apps);
  }

  deleteApp(id: string): void {
    const apps = this.getApps().filter(app => app.id !== id);
    this.setItem('gitlab-apps', apps);
  }

  // Test Cases
  getTestCases(): TestCase[] {
    return this.getItem<TestCase>('gitlab-testcases');
  }

  saveTestCase(testCase: TestCase): void {
    const testCases = this.getTestCases();
    const existingIndex = testCases.findIndex(tc => tc.id === testCase.id);
    
    if (existingIndex >= 0) {
      testCases[existingIndex] = testCase;
    } else {
      testCases.push(testCase);
    }
    
    this.setItem('gitlab-testcases', testCases);
  }

  deleteTestCase(id: string): void {
    const testCases = this.getTestCases().filter(tc => tc.id !== id);
    this.setItem('gitlab-testcases', testCases);
  }

  // Pipeline Executions
  getExecutions(): PipelineExecution[] {
    return this.getItem<PipelineExecution>('gitlab-executions');
  }

  saveExecution(execution: PipelineExecution): void {
    const executions = this.getExecutions();
    const existingIndex = executions.findIndex(e => e.id === execution.id);
    
    if (existingIndex >= 0) {
      executions[existingIndex] = execution;
    } else {
      executions.push(execution);
    }
    
    this.setItem('gitlab-executions', executions);
  }

  deleteExecution(id: string): void {
    const executions = this.getExecutions().filter(e => e.id !== id);
    this.setItem('gitlab-executions', executions);
  }
}

export const storageService = new StorageService();