export interface App {
  id: string;
  name: string;
  accessToken: string;
  projectId: string;
  createdAt: string;
}

export interface TestCase {
  id: string;
  name: string;
  apps: {
    appId: string;
    branch: string;
    environmentVariables: Record<string, string>;
  }[];
  createdAt: string;
}

export interface PipelineExecution {
  id: string;
  testCaseId: string;
  status: 'pending' | 'running' | 'success' | 'failed' | 'canceled';
  startedAt: string;
  completedAt?: string;
  pipelines: {
    appId: string;
    pipelineId?: number;
    status: string;
    webUrl?: string;
    artifacts?: Artifact[];
  }[];
}

export interface Artifact {
  filename: string;
  size: number;
  downloadUrl: string;
}

export interface GitlabProject {
  id: number;
  name: string;
  path_with_namespace: string;
  web_url: string;
}

export interface GitlabBranch {
  name: string;
  protected: boolean;
  default: boolean;
}

export interface GitlabPipeline {
  id: number;
  status: string;
  ref: string;
  web_url: string;
  created_at: string;
  updated_at: string;
}